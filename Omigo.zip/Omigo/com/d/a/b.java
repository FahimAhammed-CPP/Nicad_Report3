package com.d.a;

import android.util.Log;
import com.f.a.a;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONObject;

public final class b {
  public static com.f.a.b a(JSONObject paramJSONObject) {
    com.f.a.b b1 = new com.f.a.b();
    Vector<a> vector = new Vector();
    b1.a(paramJSONObject.optInt("curPage"));
    b1.a(paramJSONObject.optBoolean("hasMore"));
    if (!paramJSONObject.isNull("data")) {
      JSONArray jSONArray = paramJSONObject.optJSONArray("data");
      for (byte b2 = 0; b2 < jSONArray.length(); b2++) {
        JSONObject jSONObject = jSONArray.optJSONObject(b2);
        a a = new a();
        a.a(jSONObject.optString("novelId"));
        a.b(jSONObject.optString("novelName"));
        a.c(jSONObject.optString("novelImageUrl"));
        a.d(jSONObject.optString("novelAuthor"));
        a.a(jSONObject.optInt("clicks"));
        a.e(jSONObject.optString("novelType"));
        a.f(jSONObject.optString("novelUrl"));
        a.h(jSONObject.optString("content"));
        Log.e("JsonUtil", "content:::" + jSONObject.optString("content"));
        vector.add(a);
      } 
    } 
    b1.a(vector);
    return b1;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/d/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */