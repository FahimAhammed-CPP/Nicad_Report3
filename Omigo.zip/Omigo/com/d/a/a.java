package com.d.a;

import android.util.Log;
import com.a.a.e;
import com.a.a.g;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import org.json.JSONObject;

public final class a {
  public static JSONObject a(String paramString) {
    try {
      URL uRL = new URL();
      this(paramString);
      try {
        HttpURLConnection httpURLConnection;
        Proxy proxy = g.b(e.e);
        if (proxy != null) {
          httpURLConnection = (HttpURLConnection)uRL.openConnection(proxy);
        } else {
          httpURLConnection = (HttpURLConnection)uRL.openConnection();
        } 
        httpURLConnection.setConnectTimeout(20000);
        httpURLConnection.setRequestProperty("Content-Type", "text/plain");
        httpURLConnection.setRequestProperty("charset", "utf-8");
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setDoInput(true);
        if (httpURLConnection.getResponseCode() != 200) {
          Log.e("HttpComm", "error ----访问服务器失败");
          return null;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        InputStreamReader inputStreamReader = new InputStreamReader();
        this(httpURLConnection.getInputStream());
        BufferedReader bufferedReader = new BufferedReader();
        this(inputStreamReader);
        String str;
        for (str = bufferedReader.readLine(); str != null; str = bufferedReader.readLine())
          stringBuilder2.append(str); 
        inputStreamReader.close();
        str = stringBuilder2.toString();
        StringBuilder stringBuilder1 = new StringBuilder();
        this("result...");
        Log.e("HttpComm", stringBuilder1.append(str).toString());
        JSONObject jSONObject = new JSONObject(str);
      } catch (Exception null) {
        Log.e("HttpComm", "error: " + exception.getMessage());
        exception = null;
      } 
    } catch (MalformedURLException exception) {
      Log.e("URL地址有问题", "URL地址有问题  ----------" + exception.getMessage());
      exception.printStackTrace();
      exception = null;
    } 
    return (JSONObject)exception;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/d/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */