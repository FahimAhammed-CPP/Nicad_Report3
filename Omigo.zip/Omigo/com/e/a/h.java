package com.e.a;

import android.os.Message;
import android.view.View;

final class h implements View.OnLongClickListener {
  h(f paramf, int paramInt) {}
  
  public final boolean onLongClick(View paramView) {
    Message message = new Message();
    message.what = 63;
    message.arg1 = this.a;
    f.a(this.b).sendMessage(message);
    return true;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */