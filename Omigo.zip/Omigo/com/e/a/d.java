package com.e.a;

import android.content.Intent;
import android.view.View;
import com.a.a.e;
import com.f.a.a;
import com.g.g.BookDetailActivity;

final class d implements View.OnClickListener {
  d(c paramc, a parama) {}
  
  public final void onClick(View paramView) {
    Intent intent = new Intent(c.a(this.b), BookDetailActivity.class);
    e.d = this.a;
    c.a(this.b).startActivity(intent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */