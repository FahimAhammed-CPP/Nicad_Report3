package com.e.a;

import android.content.DialogInterface;
import com.a.a.c;
import com.a.a.e;
import com.b.a.c;

final class n implements DialogInterface.OnClickListener {
  n(l paraml) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    c c1 = j.b(this.a.c);
    long l1 = this.a.b;
    c1.a.delete("booktable", "_id=" + l1, null);
    j.c(this.a.c).sendEmptyMessage(777);
    c c = (c)e.f.remove(Long.valueOf(this.a.b));
    if (c != null)
      c.a(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */