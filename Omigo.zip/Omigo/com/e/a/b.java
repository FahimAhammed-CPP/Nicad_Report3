package com.e.a;

import android.content.Intent;
import android.view.View;
import com.g.g.FenleiItemListActivity;

final class b implements View.OnClickListener {
  b(a parama, String paramString1, String paramString2) {}
  
  public final void onClick(View paramView) {
    Intent intent = new Intent(a.a(this.c), FenleiItemListActivity.class);
    intent.putExtra("typeId", this.a);
    intent.putExtra("typeName", this.b);
    a.a(this.c).startActivity(intent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */