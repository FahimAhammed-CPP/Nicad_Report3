package com.e.a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import com.f.a.d;
import java.util.ArrayList;

public final class a extends BaseAdapter {
  private Context a;
  
  private ArrayList b;
  
  public a(Context paramContext, ArrayList paramArrayList) {
    this.a = paramContext;
    this.b = paramArrayList;
  }
  
  public final int getCount() {
    return this.b.size();
  }
  
  public final Object getItem(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public final long getItemId(int paramInt) {
    return paramInt;
  }
  
  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    View view = LayoutInflater.from(this.a).inflate(2130903051, null);
    d d = this.b.get(paramInt);
    String str1 = d.a();
    String str2 = d.b();
    Button button = (Button)view.findViewById(2131230819);
    button.setText(d.b());
    button.setOnClickListener(new b(this, str1, str2));
    return view;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */