package com.e.a;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.c;
import com.a.a.e;
import com.a.a.g;
import com.b.a.c;
import com.f.a.a;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public final class j extends BaseAdapter {
  private Context a;
  
  private List b = new ArrayList();
  
  private c c;
  
  private Handler d;
  
  public j(Context paramContext, List paramList, Handler paramHandler) {
    this.a = paramContext;
    this.c = new c(paramContext);
    this.c.a();
    List list = paramList;
    if (paramList == null)
      list = new ArrayList(); 
    this.b = list;
    this.d = paramHandler;
  }
  
  public final int getCount() {
    return this.b.size();
  }
  
  public final Object getItem(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public final long getItemId(int paramInt) {
    return paramInt;
  }
  
  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    e e;
    boolean bool = false;
    if (paramView == null) {
      paramView = LayoutInflater.from(this.a).inflate(2130903048, null);
      e = new e();
      e.a = (RelativeLayout)paramView.findViewById(2131230765);
      e.b = (ImageView)paramView.findViewById(2131230767);
      e.h = (ImageView)paramView.findViewById(2131230776);
      e.c = (TextView)paramView.findViewById(2131230768);
      e.d = (TextView)paramView.findViewById(2131230769);
      e.g = (TextView)paramView.findViewById(2131230790);
      e.e = (TextView)paramView.findViewById(2131230772);
      e.f = (TextView)paramView.findViewById(2131230775);
      e.i = (ProgressBar)paramView.findViewById(2131230793);
      paramView.setTag(e);
    } else {
      e = (e)paramView.getTag();
    } 
    a a = this.b.get(paramInt);
    long l = a.a();
    e.c.setText(a.c());
    if (a.l() == 0L) {
      e.d.setText("");
    } else {
      e.d.setText("最后阅读：" + g.a(a.l()));
    } 
    e.i.setVisibility(0);
    e.e.setText(a.g());
    e.f.setText(a.e());
    e.g.setText("0.0%");
    if (a.n() != null)
      e.g.setText(a.n() + "%"); 
    e.h.setVisibility(8);
    e.b.setImageDrawable(null);
    Hashtable hashtable = e.f;
    e.i.setProgress(0);
    if (hashtable != null && hashtable.size() > 0 && hashtable.containsKey(a.b())) {
      c c1 = (c)e.f.get(a.b());
      ProgressBar progressBar = e.i;
      if (c1.c == 0) {
        paramInt = bool;
      } else {
        paramInt = c1.d * 100 / c1.c;
      } 
      progressBar.setProgress(paramInt);
      if (c1.e == 1) {
        a.g(((c)e.f.remove(a.b())).g);
      } else if (c1.e == -1) {
        e.f.remove(a.b());
      } 
    } 
    if (a.i() != null)
      e.b.setImageDrawable(g.a(this.a, a.i())); 
    if (a.j() != null && !hashtable.containsKey(a.b()))
      e.i.setVisibility(8); 
    e.a.setOnClickListener(new k(this, a));
    e.a.setOnLongClickListener(new l(this, a, l));
    return paramView;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */