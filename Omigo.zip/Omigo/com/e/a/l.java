package com.e.a;

import android.app.AlertDialog;
import android.view.View;
import com.f.a.a;

final class l implements View.OnLongClickListener {
  l(j paramj, a parama, long paramLong) {}
  
  public final boolean onLongClick(View paramView) {
    (new AlertDialog.Builder(j.a(this.c))).setTitle("温馨提示").setMessage("是否删除 《" + this.a.c() + "》？").setPositiveButton("确定", new n(this)).setNegativeButton("取消", new m(this)).show();
    return true;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */