package com.e.a;

import android.os.Message;
import android.view.View;

final class g implements View.OnClickListener {
  g(f paramf, int paramInt) {}
  
  public final void onClick(View paramView) {
    Message message = new Message();
    message.what = 62;
    message.arg1 = this.a;
    f.a(this.b).sendMessage(message);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */