package com.e.a;

import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

final class i {
  TextView a;
  
  TextView b;
  
  TextView c;
  
  TextView d;
  
  RelativeLayout e;
  
  Button f;
  
  i(f paramf) {}
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */