package com.e.a;

import android.content.Intent;
import android.view.View;
import com.a.a.e;
import com.f.a.a;
import com.g.g.BookDetailActivity;

final class k implements View.OnClickListener {
  k(j paramj, a parama) {}
  
  public final void onClick(View paramView) {
    Intent intent = new Intent(j.a(this.b), BookDetailActivity.class);
    e.d = this.a;
    j.a(this.b).startActivity(intent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */