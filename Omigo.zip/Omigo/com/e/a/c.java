package com.e.a;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.a.a.g;
import com.f.a.a;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public final class c extends BaseAdapter {
  private Context a;
  
  private List b = new ArrayList();
  
  private HashSet c;
  
  public c(Context paramContext, List paramList, HashSet paramHashSet) {
    this.a = paramContext;
    List list = paramList;
    if (paramList == null)
      list = new ArrayList(); 
    this.b = list;
    this.c = paramHashSet;
  }
  
  public final int getCount() {
    return this.b.size();
  }
  
  public final Object getItem(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public final long getItemId(int paramInt) {
    return paramInt;
  }
  
  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    e e;
    if (paramView == null) {
      paramView = LayoutInflater.from(this.a).inflate(2130903045, null);
      e = new e();
      e.a = (RelativeLayout)paramView.findViewById(2131230765);
      e.b = (ImageView)paramView.findViewById(2131230767);
      e.h = (ImageView)paramView.findViewById(2131230776);
      e.c = (TextView)paramView.findViewById(2131230768);
      e.d = (TextView)paramView.findViewById(2131230769);
      e.e = (TextView)paramView.findViewById(2131230772);
      e.f = (TextView)paramView.findViewById(2131230775);
      paramView.setTag(e);
    } else {
      e = (e)paramView.getTag();
    } 
    a a = this.b.get(paramInt);
    e.c.setText(a.c());
    e.d.setText(a.f());
    e.e.setText(a.g());
    e.f.setText(a.e());
    e.b.setImageDrawable(null);
    if (a.i() != null)
      e.b.setImageDrawable(g.a(this.a, a.i())); 
    e.h.setVisibility(8);
    if (this.c.contains(a.b()))
      e.h.setVisibility(0); 
    e.a.setOnClickListener(new d(this, a));
    return paramView;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */