package com.e.a;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.f.a.c;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public final class f extends BaseAdapter {
  DecimalFormat a = new DecimalFormat("##.##");
  
  private ArrayList b;
  
  private Context c;
  
  private Handler d;
  
  public f(Context paramContext, ArrayList paramArrayList, Handler paramHandler) {
    this.c = paramContext;
    ArrayList arrayList = paramArrayList;
    if (paramArrayList == null)
      arrayList = new ArrayList(); 
    this.b = arrayList;
    this.d = paramHandler;
  }
  
  public final int getCount() {
    return this.b.size();
  }
  
  public final Object getItem(int paramInt) {
    return this.b.get(paramInt);
  }
  
  public final long getItemId(int paramInt) {
    return paramInt;
  }
  
  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (paramView == null) {
      i i1 = new i(this);
      paramView = LayoutInflater.from(this.c).inflate(2130903047, null);
      i1.e = (RelativeLayout)paramView.findViewById(2131230784);
      i1.a = (TextView)paramView.findViewById(2131230785);
      i1.b = (TextView)paramView.findViewById(2131230786);
      i1.c = (TextView)paramView.findViewById(2131230788);
      i1.d = (TextView)paramView.findViewById(2131230789);
      i1.f = (Button)paramView.findViewById(2131230787);
      paramView.setTag(i1);
      c c1 = this.b.get(paramInt);
      i1.a.setText(c1.h());
      i1.b.setText(c1.f());
      String str1 = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date(c1.g()));
      i1.c.setText(str1);
      i1.d.setText("[" + c1.d() + "%]");
      i1.e.setOnClickListener(new g(this, paramInt));
      i1.e.setOnLongClickListener(new h(this, paramInt));
      return paramView;
    } 
    i i = (i)paramView.getTag();
    c c = this.b.get(paramInt);
    i.a.setText(c.h());
    i.b.setText(c.f());
    String str = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date(c.g()));
    i.c.setText(str);
    i.d.setText("[" + c.d() + "%]");
    i.e.setOnClickListener(new g(this, paramInt));
    i.e.setOnLongClickListener(new h(this, paramInt));
    return paramView;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/e/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */