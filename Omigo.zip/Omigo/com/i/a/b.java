package com.i.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Region;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Scroller;

public final class b extends View {
  GradientDrawable A;
  
  GradientDrawable B;
  
  GradientDrawable C;
  
  GradientDrawable D;
  
  Handler E = null;
  
  Paint F;
  
  Scroller G;
  
  private int H = 480;
  
  private int I = 800;
  
  private int J = 0;
  
  private int K = 0;
  
  private Path L;
  
  private Path M;
  
  Bitmap a = null;
  
  Bitmap b = null;
  
  PointF c = new PointF();
  
  PointF d = new PointF();
  
  PointF e = new PointF();
  
  PointF f = new PointF();
  
  PointF g = new PointF();
  
  PointF h = new PointF();
  
  PointF i = new PointF();
  
  PointF j = new PointF();
  
  PointF k = new PointF();
  
  float l;
  
  float m;
  
  float n;
  
  float o;
  
  ColorMatrixColorFilter p;
  
  Matrix q;
  
  float[] r = new float[] { 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F };
  
  boolean s;
  
  float t;
  
  int[] u;
  
  int[] v;
  
  GradientDrawable w;
  
  GradientDrawable x;
  
  GradientDrawable y;
  
  GradientDrawable z;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this(paramContext, paramInt1, paramInt2, (byte)0);
  }
  
  private b(Context paramContext, int paramInt1, int paramInt2, byte paramByte) {
    super(paramContext);
    this.H = paramInt1;
    this.I = paramInt2;
    this.t = (float)Math.hypot(paramInt1, paramInt2);
    this.L = new Path();
    this.M = new Path();
    int[] arrayOfInt = new int[2];
    arrayOfInt[0] = 3355443;
    arrayOfInt[1] = -1338821837;
    this.z = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, arrayOfInt);
    this.z.setGradientType(0);
    this.y = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, arrayOfInt);
    this.y.setGradientType(0);
    this.u = new int[] { -15658735, 1118481 };
    this.x = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, this.u);
    this.x.setGradientType(0);
    this.w = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, this.u);
    this.w.setGradientType(0);
    this.v = new int[] { -2146365167, 1118481 };
    this.C = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, this.v);
    this.C.setGradientType(0);
    this.D = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, this.v);
    this.D.setGradientType(0);
    this.B = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, this.v);
    this.B.setGradientType(0);
    this.A = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, this.v);
    this.A.setGradientType(0);
    this.F = new Paint();
    this.F.setStyle(Paint.Style.FILL);
    ColorMatrix colorMatrix = new ColorMatrix();
    colorMatrix.set(new float[] { 
          0.55F, 0.0F, 0.0F, 0.0F, 80.0F, 0.0F, 0.55F, 0.0F, 0.0F, 80.0F, 
          0.0F, 0.0F, 0.55F, 0.0F, 80.0F, 0.0F, 0.0F, 0.0F, 0.2F, 0.0F });
    this.p = new ColorMatrixColorFilter(colorMatrix);
    this.q = new Matrix();
    this.G = new Scroller(getContext());
    this.c.x = 0.01F;
    this.c.y = 0.01F;
  }
  
  private static PointF a(PointF paramPointF1, PointF paramPointF2, PointF paramPointF3, PointF paramPointF4) {
    PointF pointF = new PointF();
    float f1 = (paramPointF2.y - paramPointF1.y) / (paramPointF2.x - paramPointF1.x);
    float f2 = (paramPointF1.x * paramPointF2.y - paramPointF2.x * paramPointF1.y) / (paramPointF1.x - paramPointF2.x);
    float f3 = (paramPointF4.y - paramPointF3.y) / (paramPointF4.x - paramPointF3.x);
    pointF.x = ((paramPointF3.x * paramPointF4.y - paramPointF4.x * paramPointF3.y) / (paramPointF3.x - paramPointF4.x) - f2) / (f1 - f3);
    pointF.y = f1 * pointF.x + f2;
    return pointF;
  }
  
  public final void a() {
    if (!this.G.isFinished())
      this.G.abortAnimation(); 
  }
  
  public final void a(float paramFloat1, float paramFloat2) {
    if (paramFloat1 <= (this.H / 2)) {
      this.J = 0;
    } else {
      this.J = this.H;
    } 
    if (paramFloat2 <= (this.I / 2)) {
      this.K = 0;
    } else {
      this.K = this.I;
    } 
    if ((this.J == 0 && this.K == this.I) || (this.J == this.H && this.K == 0)) {
      this.s = true;
      return;
    } 
    this.s = false;
  }
  
  public final void a(Bitmap paramBitmap1, Bitmap paramBitmap2) {
    this.a = paramBitmap1;
    this.b = paramBitmap2;
  }
  
  public final boolean a(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 2) {
      this.c.x = paramMotionEvent.getX();
      this.c.y = paramMotionEvent.getY();
      postInvalidate();
    } 
    if (paramMotionEvent.getAction() == 0) {
      this.c.x = paramMotionEvent.getX();
      this.c.y = paramMotionEvent.getY();
    } 
    if (paramMotionEvent.getAction() == 1) {
      int i;
      int j;
      if (this.J > 0) {
        i = -((int)(this.H + this.c.x));
      } else {
        i = (int)(this.H - this.c.x + this.H);
      } 
      if (this.K > 0) {
        j = (int)(this.I - this.c.y);
      } else {
        j = (int)(1.0F - this.c.y);
      } 
      this.G.startScroll((int)this.c.x, (int)this.c.y, i, j, 1200);
      postInvalidate();
    } 
    return true;
  }
  
  public final boolean b() {
    return !(this.J > 0);
  }
  
  public final void computeScroll() {
    super.computeScroll();
    if (this.G.computeScrollOffset()) {
      float f1 = this.G.getCurrX();
      float f2 = this.G.getCurrY();
      this.c.x = f1;
      this.c.y = f2;
      postInvalidate();
    } 
  }
  
  protected final void onDraw(Canvas paramCanvas) {
    GradientDrawable gradientDrawable;
    int i;
    int j;
    paramCanvas.drawColor(-5592406);
    this.l = (this.c.x + this.J) / 2.0F;
    this.m = (this.c.y + this.K) / 2.0F;
    this.e.x = this.l - (this.K - this.m) * (this.K - this.m) / (this.J - this.l);
    this.e.y = this.K;
    this.i.x = this.J;
    this.i.y = this.m - (this.J - this.l) * (this.J - this.l) / (this.K - this.m);
    this.e.x -= (this.J - this.e.x) / 2.0F;
    this.d.y = this.K;
    if (this.c.x > 0.0F && this.c.x < this.H && (this.d.x < 0.0F || this.d.x > this.H)) {
      if (this.d.x < 0.0F)
        this.d.x = this.H - this.d.x; 
      float f = Math.abs(this.J - this.c.x);
      f2 = this.H * f / this.d.x;
      this.c.x = Math.abs(this.J - f2);
      f2 = Math.abs(this.J - this.c.x) * Math.abs(this.K - this.c.y) / f;
      this.c.y = Math.abs(this.K - f2);
      this.l = (this.c.x + this.J) / 2.0F;
      this.m = (this.c.y + this.K) / 2.0F;
      this.e.x = this.l - (this.K - this.m) * (this.K - this.m) / (this.J - this.l);
      this.e.y = this.K;
      this.i.x = this.J;
      this.i.y = this.m - (this.J - this.l) * (this.J - this.l) / (this.K - this.m);
      this.e.x -= (this.J - this.e.x) / 2.0F;
    } 
    this.h.x = this.J;
    this.i.y -= (this.K - this.i.y) / 2.0F;
    this.o = (float)Math.hypot((this.c.x - this.J), (this.c.y - this.K));
    this.g = a(this.c, this.e, this.d, this.h);
    this.k = a(this.c, this.i, this.d, this.h);
    this.f.x = (this.d.x + this.e.x * 2.0F + this.g.x) / 4.0F;
    this.f.y = (this.e.y * 2.0F + this.d.y + this.g.y) / 4.0F;
    this.j.x = (this.h.x + this.i.x * 2.0F + this.k.x) / 4.0F;
    this.j.y = (this.i.y * 2.0F + this.h.y + this.k.y) / 4.0F;
    Bitmap bitmap1 = this.a;
    Path path = this.L;
    this.L.reset();
    this.L.moveTo(this.d.x, this.d.y);
    this.L.quadTo(this.e.x, this.e.y, this.g.x, this.g.y);
    this.L.lineTo(this.c.x, this.c.y);
    this.L.lineTo(this.k.x, this.k.y);
    this.L.quadTo(this.i.x, this.i.y, this.h.x, this.h.y);
    this.L.lineTo(this.J, this.K);
    this.L.close();
    paramCanvas.save();
    paramCanvas.clipPath(path, Region.Op.DIFFERENCE);
    paramCanvas.drawBitmap(bitmap1, 0.0F, 0.0F, null);
    paramCanvas.restore();
    Bitmap bitmap2 = this.b;
    this.M.reset();
    this.M.moveTo(this.d.x, this.d.y);
    this.M.lineTo(this.f.x, this.f.y);
    this.M.lineTo(this.j.x, this.j.y);
    this.M.lineTo(this.h.x, this.h.y);
    this.M.lineTo(this.J, this.K);
    this.M.close();
    this.n = (float)Math.toDegrees(Math.atan2((this.e.x - this.J), (this.i.y - this.K)));
    if (this.s) {
      i = (int)this.d.x;
      j = (int)(this.d.x + this.o / 4.0F);
      gradientDrawable = this.w;
    } else {
      i = (int)(this.d.x - this.o / 4.0F);
      j = (int)this.d.x;
      gradientDrawable = this.x;
    } 
    paramCanvas.save();
    paramCanvas.clipPath(this.L);
    paramCanvas.clipPath(this.M, Region.Op.INTERSECT);
    paramCanvas.drawBitmap(bitmap2, 0.0F, 0.0F, null);
    paramCanvas.rotate(this.n, this.d.x, this.d.y);
    gradientDrawable.setBounds(i, (int)this.d.y, j, (int)(this.t + this.d.y));
    gradientDrawable.draw(paramCanvas);
    paramCanvas.restore();
    if (this.s) {
      d1 = 0.7853981633974483D - Math.atan2((this.e.y - this.c.y), (this.c.x - this.e.x));
    } else {
      d1 = 0.7853981633974483D - Math.atan2((this.c.y - this.e.y), (this.c.x - this.e.x));
    } 
    double d2 = Math.cos(d1);
    double d1 = Math.sin(d1) * 35.35D;
    float f1 = (float)(35.35D * d2 + this.c.x);
    if (this.s) {
      f2 = (float)(d1 + this.c.y);
    } else {
      f2 = (float)(this.c.y - d1);
    } 
    this.M.reset();
    this.M.moveTo(f1, f2);
    this.M.lineTo(this.c.x, this.c.y);
    this.M.lineTo(this.e.x, this.e.y);
    this.M.lineTo(this.d.x, this.d.y);
    this.M.close();
    paramCanvas.save();
    paramCanvas.clipPath(this.L, Region.Op.XOR);
    paramCanvas.clipPath(this.M, Region.Op.INTERSECT);
    if (this.s) {
      i = (int)this.e.x;
      j = (int)this.e.x + 25;
      gradientDrawable = this.C;
    } else {
      i = (int)(this.e.x - 25.0F);
      j = (int)this.e.x + 1;
      gradientDrawable = this.D;
    } 
    paramCanvas.rotate((float)Math.toDegrees(Math.atan2((this.c.x - this.e.x), (this.e.y - this.c.y))), this.e.x, this.e.y);
    gradientDrawable.setBounds(i, (int)(this.e.y - this.t), j, (int)this.e.y);
    gradientDrawable.draw(paramCanvas);
    paramCanvas.restore();
    this.M.reset();
    this.M.moveTo(f1, f2);
    this.M.lineTo(this.c.x, this.c.y);
    this.M.lineTo(this.i.x, this.i.y);
    this.M.lineTo(this.h.x, this.h.y);
    this.M.close();
    paramCanvas.save();
    paramCanvas.clipPath(this.L, Region.Op.XOR);
    paramCanvas.clipPath(this.M, Region.Op.INTERSECT);
    if (this.s) {
      j = (int)this.i.y;
      i = (int)(this.i.y + 25.0F);
      gradientDrawable = this.B;
    } else {
      j = (int)(this.i.y - 25.0F);
      i = (int)(this.i.y + 1.0F);
      gradientDrawable = this.A;
    } 
    paramCanvas.rotate((float)Math.toDegrees(Math.atan2((this.i.y - this.c.y), (this.i.x - this.c.x))), this.i.x, this.i.y);
    if (this.i.y < 0.0F) {
      f2 = this.i.y - this.I;
    } else {
      f2 = this.i.y;
    } 
    int k = (int)Math.hypot(this.i.x, f2);
    if (k > this.t) {
      gradientDrawable.setBounds((int)(this.i.x - 25.0F) - k, j, (int)(this.i.x + this.t) - k, i);
    } else {
      gradientDrawable.setBounds((int)(this.i.x - this.t), j, (int)this.i.x, i);
    } 
    gradientDrawable.draw(paramCanvas);
    paramCanvas.restore();
    bitmap2 = this.a;
    float f2 = Math.min(Math.abs(((int)(this.d.x + this.e.x) / 2) - this.e.x), Math.abs(((int)(this.h.y + this.i.y) / 2) - this.i.y));
    this.M.reset();
    this.M.moveTo(this.j.x, this.j.y);
    this.M.lineTo(this.f.x, this.f.y);
    this.M.lineTo(this.g.x, this.g.y);
    this.M.lineTo(this.c.x, this.c.y);
    this.M.lineTo(this.k.x, this.k.y);
    this.M.close();
    if (this.s) {
      i = (int)(this.d.x - 1.0F);
      j = (int)(f2 + this.d.x + 1.0F);
      gradientDrawable = this.y;
    } else {
      i = (int)(this.d.x - f2 - 1.0F);
      j = (int)(this.d.x + 1.0F);
      gradientDrawable = this.z;
    } 
    paramCanvas.save();
    paramCanvas.clipPath(this.L);
    paramCanvas.clipPath(this.M, Region.Op.INTERSECT);
    this.F.setColorFilter((ColorFilter)this.p);
    f1 = (float)Math.hypot((this.J - this.e.x), (this.i.y - this.K));
    f2 = (this.J - this.e.x) / f1;
    f1 = (this.i.y - this.K) / f1;
    this.r[0] = 1.0F - 2.0F * f1 * f1;
    this.r[1] = f1 * 2.0F * f2;
    this.r[3] = this.r[1];
    this.r[4] = 1.0F - f2 * 2.0F * f2;
    this.q.reset();
    this.q.setValues(this.r);
    this.q.preTranslate(-this.e.x, -this.e.y);
    this.q.postTranslate(this.e.x, this.e.y);
    paramCanvas.drawBitmap(bitmap2, this.q, this.F);
    this.F.setColorFilter(null);
    paramCanvas.rotate(this.n, this.d.x, this.d.y);
    gradientDrawable.setBounds(i, (int)this.d.y, j, (int)(this.d.y + this.t));
    gradientDrawable.draw(paramCanvas);
    paramCanvas.restore();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/i/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */