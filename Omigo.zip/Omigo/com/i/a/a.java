package com.i.a;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.widget.SeekBar;
import android.widget.TextView;
import com.a.a.g;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public final class a {
  private Paint A;
  
  private SeekBar B;
  
  private TextView C;
  
  private DecimalFormat D = new DecimalFormat("0.00");
  
  public int a = 0;
  
  public int b = 0;
  
  public int c = 0;
  
  public Vector d = new Vector();
  
  public ArrayList e = new ArrayList();
  
  public ArrayList f = new ArrayList();
  
  public ArrayList g = new ArrayList();
  
  public String h;
  
  private File i = null;
  
  private MappedByteBuffer j = null;
  
  private String k = "gbk";
  
  private Bitmap l = null;
  
  private int m;
  
  private int n;
  
  private int[] o = new int[] { 22, 26, 32, 38, 42 };
  
  private int p;
  
  private int q = -24955;
  
  private int r = 30;
  
  private int s = 30;
  
  private float t;
  
  private float u;
  
  private boolean v;
  
  private boolean w;
  
  private Context x;
  
  private Paint y;
  
  private Paint z;
  
  private a(Context paramContext, int paramInt1, int paramInt2) {
    this.x = paramContext;
    String[] arrayOfString2 = paramContext.getResources().getStringArray(2130968578);
    String[] arrayOfString1 = paramContext.getResources().getStringArray(2130968579);
    for (byte b = 0; b < arrayOfString2.length; b++) {
      this.e.add(Integer.valueOf(Color.parseColor(arrayOfString2[b])));
      this.f.add(Integer.valueOf(Color.parseColor(arrayOfString1[b])));
    } 
    this.g.add(Integer.valueOf(2130837560));
    this.g.add(Integer.valueOf(2130837563));
    this.g.add(Integer.valueOf(2130837566));
    this.g.add(Integer.valueOf(2130837570));
    this.g.add(Integer.valueOf(2130837567));
    this.m = paramInt1;
    this.n = paramInt2;
    this.y = new Paint(1);
    this.y.setTextAlign(Paint.Align.LEFT);
    this.y.setTextSize(this.o[2]);
    this.y.setColor(((Integer)this.e.get(0)).intValue());
    this.A = new Paint(1);
    this.A.setTextAlign(Paint.Align.LEFT);
    this.A.setTextSize(this.o[2]);
    this.A.setColor(((Integer)this.e.get(0)).intValue());
    this.A.setFakeBoldText(true);
    Paint.FontMetrics fontMetrics = this.y.getFontMetrics();
    paramInt1 = 7;
    if (this.o[2] > 26)
      paramInt1 = 10; 
    this.p = paramInt1 + (int)(fontMetrics.descent - fontMetrics.ascent);
    this.z = new Paint(1);
    this.z.setTextAlign(Paint.Align.LEFT);
    this.z.setTextSize(20.0F);
    this.z.setColor(((Integer)this.f.get(0)).intValue());
    this.u = (this.m - this.r * 2);
    this.t = (this.n - this.s * 2);
  }
  
  public a(Context paramContext, int paramInt1, int paramInt2, SeekBar paramSeekBar, TextView paramTextView) {
    this(paramContext, paramInt1, paramInt2);
    this.B = paramSeekBar;
    this.C = paramTextView;
  }
  
  private byte[] e(int paramInt) {
    boolean bool = false;
    int i = paramInt - 1;
    while (true) {
      int j = i;
      if (i > 0)
        if (this.j.get(i) == 10 && i != paramInt - 1) {
          j = i + 1;
        } else {
          i--;
          continue;
        }  
      i = j;
      if (j < 0)
        i = 0; 
      j = paramInt - i;
      byte[] arrayOfByte = new byte[j];
      for (paramInt = bool; paramInt < j; paramInt++)
        arrayOfByte[paramInt] = this.j.get(i + paramInt); 
      return arrayOfByte;
    } 
  }
  
  private byte[] f(int paramInt) {
    int i = paramInt;
    while (true) {
      if (i < this.a) {
        MappedByteBuffer mappedByteBuffer = this.j;
        int k = i + 1;
        if (mappedByteBuffer.get(i) == 10) {
          i = k;
        } else {
          i = k;
          continue;
        } 
      } 
      int j = i - paramInt;
      byte[] arrayOfByte = new byte[j];
      for (i = 0; i < j; i++)
        arrayOfByte[i] = this.j.get(paramInt + i); 
      return arrayOfByte;
    } 
  }
  
  private Vector h() {
    // Byte code:
    //   0: ldc ''
    //   2: astore_1
    //   3: new java/util/Vector
    //   6: dup
    //   7: invokespecial <init> : ()V
    //   10: astore_2
    //   11: iconst_0
    //   12: istore_3
    //   13: iconst_0
    //   14: istore #4
    //   16: iload #4
    //   18: i2f
    //   19: aload_0
    //   20: getfield t : F
    //   23: fcmpg
    //   24: ifge -> 347
    //   27: aload_0
    //   28: getfield c : I
    //   31: aload_0
    //   32: getfield a : I
    //   35: if_icmpge -> 347
    //   38: aload_0
    //   39: aload_0
    //   40: getfield c : I
    //   43: invokespecial f : (I)[B
    //   46: astore #5
    //   48: aload_0
    //   49: aload_0
    //   50: getfield c : I
    //   53: aload #5
    //   55: arraylength
    //   56: iadd
    //   57: putfield c : I
    //   60: new java/lang/String
    //   63: astore #6
    //   65: aload #6
    //   67: aload #5
    //   69: aload_0
    //   70: getfield k : Ljava/lang/String;
    //   73: invokespecial <init> : ([BLjava/lang/String;)V
    //   76: aload #6
    //   78: astore_1
    //   79: aload_1
    //   80: ldc '\\r\\n'
    //   82: invokevirtual indexOf : (Ljava/lang/String;)I
    //   85: iconst_m1
    //   86: if_icmpeq -> 224
    //   89: aload_1
    //   90: ldc '\\r\\n'
    //   92: ldc ''
    //   94: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   97: astore_1
    //   98: ldc '\\r\\n'
    //   100: astore #6
    //   102: aload_1
    //   103: ldc '  '
    //   105: ldc '　'
    //   107: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   110: astore_1
    //   111: aload_1
    //   112: invokevirtual length : ()I
    //   115: ifne -> 349
    //   118: iload_3
    //   119: ifne -> 263
    //   122: aload_0
    //   123: aload_0
    //   124: getfield b : I
    //   127: aload #6
    //   129: aload_0
    //   130: getfield k : Ljava/lang/String;
    //   133: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   136: arraylength
    //   137: iadd
    //   138: putfield b : I
    //   141: iload #4
    //   143: istore #7
    //   145: aload_1
    //   146: invokevirtual length : ()I
    //   149: ifle -> 275
    //   152: aload_0
    //   153: getfield y : Landroid/graphics/Paint;
    //   156: aload_1
    //   157: iconst_1
    //   158: aload_0
    //   159: getfield u : F
    //   162: aconst_null
    //   163: invokevirtual breakText : (Ljava/lang/String;ZF[F)I
    //   166: istore #8
    //   168: iload #4
    //   170: aload_0
    //   171: getfield p : I
    //   174: iadd
    //   175: istore #4
    //   177: iload #4
    //   179: istore #7
    //   181: iload #4
    //   183: i2f
    //   184: aload_0
    //   185: getfield t : F
    //   188: fcmpl
    //   189: ifge -> 275
    //   192: aload_2
    //   193: aload_1
    //   194: iconst_0
    //   195: iload #8
    //   197: invokevirtual substring : (II)Ljava/lang/String;
    //   200: invokevirtual add : (Ljava/lang/Object;)Z
    //   203: pop
    //   204: aload_1
    //   205: iload #8
    //   207: invokevirtual substring : (I)Ljava/lang/String;
    //   210: astore_1
    //   211: goto -> 141
    //   214: astore #6
    //   216: aload #6
    //   218: invokevirtual printStackTrace : ()V
    //   221: goto -> 79
    //   224: aload_1
    //   225: ldc_w '\\n'
    //   228: invokevirtual indexOf : (Ljava/lang/String;)I
    //   231: iconst_m1
    //   232: if_icmpeq -> 352
    //   235: aload_1
    //   236: ldc_w '\\n'
    //   239: ldc ''
    //   241: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   244: astore_1
    //   245: ldc_w '\\n'
    //   248: astore #6
    //   250: goto -> 102
    //   253: astore #5
    //   255: aload #5
    //   257: invokevirtual printStackTrace : ()V
    //   260: goto -> 141
    //   263: aload_2
    //   264: aload_1
    //   265: invokevirtual add : (Ljava/lang/Object;)Z
    //   268: pop
    //   269: iinc #4, 20
    //   272: goto -> 141
    //   275: aload_1
    //   276: invokevirtual length : ()I
    //   279: ifeq -> 327
    //   282: aload_0
    //   283: getfield c : I
    //   286: istore #4
    //   288: new java/lang/StringBuilder
    //   291: astore #5
    //   293: aload #5
    //   295: invokespecial <init> : ()V
    //   298: aload_0
    //   299: iload #4
    //   301: aload #5
    //   303: aload_1
    //   304: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   307: aload #6
    //   309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   312: invokevirtual toString : ()Ljava/lang/String;
    //   315: aload_0
    //   316: getfield k : Ljava/lang/String;
    //   319: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   322: arraylength
    //   323: isub
    //   324: putfield c : I
    //   327: iinc #3, 1
    //   330: iload #7
    //   332: istore #4
    //   334: goto -> 16
    //   337: astore #6
    //   339: aload #6
    //   341: invokevirtual printStackTrace : ()V
    //   344: goto -> 327
    //   347: aload_2
    //   348: areturn
    //   349: goto -> 141
    //   352: ldc ''
    //   354: astore #6
    //   356: goto -> 102
    // Exception table:
    //   from	to	target	type
    //   60	76	214	java/io/UnsupportedEncodingException
    //   122	141	253	java/io/UnsupportedEncodingException
    //   282	327	337	java/io/UnsupportedEncodingException
  }
  
  private void i() {
    this.d.clear();
    this.d = h();
  }
  
  public final void a() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : I
    //   4: ifgt -> 18
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield b : I
    //   12: aload_0
    //   13: iconst_1
    //   14: putfield v : Z
    //   17: return
    //   18: aload_0
    //   19: iconst_0
    //   20: putfield v : Z
    //   23: aload_0
    //   24: getfield d : Ljava/util/Vector;
    //   27: invokevirtual clear : ()V
    //   30: aload_0
    //   31: getfield b : I
    //   34: ifge -> 42
    //   37: aload_0
    //   38: iconst_0
    //   39: putfield b : I
    //   42: new java/util/Vector
    //   45: dup
    //   46: invokespecial <init> : ()V
    //   49: astore_1
    //   50: ldc ''
    //   52: astore_2
    //   53: iconst_0
    //   54: istore_3
    //   55: iload_3
    //   56: istore #4
    //   58: iload_3
    //   59: i2f
    //   60: aload_0
    //   61: getfield t : F
    //   64: fcmpg
    //   65: ifge -> 243
    //   68: iload_3
    //   69: istore #4
    //   71: aload_0
    //   72: getfield b : I
    //   75: ifle -> 243
    //   78: new java/util/Vector
    //   81: dup
    //   82: invokespecial <init> : ()V
    //   85: astore #5
    //   87: aload_0
    //   88: aload_0
    //   89: getfield b : I
    //   92: invokespecial e : (I)[B
    //   95: astore #6
    //   97: aload_0
    //   98: aload_0
    //   99: getfield b : I
    //   102: aload #6
    //   104: arraylength
    //   105: isub
    //   106: putfield b : I
    //   109: new java/lang/String
    //   112: astore #7
    //   114: aload #7
    //   116: aload #6
    //   118: aload_0
    //   119: getfield k : Ljava/lang/String;
    //   122: invokespecial <init> : ([BLjava/lang/String;)V
    //   125: aload #7
    //   127: astore_2
    //   128: aload_2
    //   129: ldc '  '
    //   131: ldc '　'
    //   133: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   136: ldc '\\r\\n'
    //   138: ldc ''
    //   140: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   143: ldc_w '\\n'
    //   146: ldc ''
    //   148: invokevirtual replaceAll : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   151: astore_2
    //   152: aload_2
    //   153: invokevirtual length : ()I
    //   156: ifne -> 335
    //   159: aload #5
    //   161: aload_2
    //   162: invokevirtual add : (Ljava/lang/Object;)Z
    //   165: pop
    //   166: iinc #3, 20
    //   169: aload_2
    //   170: invokevirtual length : ()I
    //   173: ifle -> 232
    //   176: aload_0
    //   177: getfield y : Landroid/graphics/Paint;
    //   180: aload_2
    //   181: iconst_1
    //   182: aload_0
    //   183: getfield u : F
    //   186: aconst_null
    //   187: invokevirtual breakText : (Ljava/lang/String;ZF[F)I
    //   190: istore #4
    //   192: aload #5
    //   194: aload_2
    //   195: iconst_0
    //   196: iload #4
    //   198: invokevirtual substring : (II)Ljava/lang/String;
    //   201: invokevirtual add : (Ljava/lang/Object;)Z
    //   204: pop
    //   205: iload_3
    //   206: aload_0
    //   207: getfield p : I
    //   210: iadd
    //   211: istore_3
    //   212: aload_2
    //   213: iload #4
    //   215: invokevirtual substring : (I)Ljava/lang/String;
    //   218: astore_2
    //   219: goto -> 169
    //   222: astore #7
    //   224: aload #7
    //   226: invokevirtual printStackTrace : ()V
    //   229: goto -> 128
    //   232: aload_1
    //   233: iconst_0
    //   234: aload #5
    //   236: invokevirtual addAll : (ILjava/util/Collection;)Z
    //   239: pop
    //   240: goto -> 55
    //   243: iload #4
    //   245: i2f
    //   246: aload_0
    //   247: getfield t : F
    //   250: fcmpl
    //   251: ifle -> 316
    //   254: aload_1
    //   255: iconst_0
    //   256: invokevirtual remove : (I)Ljava/lang/Object;
    //   259: checkcast java/lang/String
    //   262: astore_2
    //   263: aload_0
    //   264: aload_0
    //   265: getfield b : I
    //   268: aload_2
    //   269: aload_0
    //   270: getfield k : Ljava/lang/String;
    //   273: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   276: arraylength
    //   277: iadd
    //   278: putfield b : I
    //   281: aload_2
    //   282: invokevirtual length : ()I
    //   285: ifne -> 294
    //   288: iinc #4, -20
    //   291: goto -> 243
    //   294: aload_0
    //   295: getfield p : I
    //   298: istore_3
    //   299: iload #4
    //   301: iload_3
    //   302: isub
    //   303: istore #4
    //   305: goto -> 243
    //   308: astore_2
    //   309: aload_2
    //   310: invokevirtual printStackTrace : ()V
    //   313: goto -> 243
    //   316: aload_0
    //   317: aload_0
    //   318: getfield b : I
    //   321: putfield c : I
    //   324: aload_0
    //   325: aload_0
    //   326: invokespecial h : ()Ljava/util/Vector;
    //   329: putfield d : Ljava/util/Vector;
    //   332: goto -> 17
    //   335: goto -> 169
    // Exception table:
    //   from	to	target	type
    //   109	125	222	java/io/UnsupportedEncodingException
    //   254	288	308	java/io/UnsupportedEncodingException
    //   294	299	308	java/io/UnsupportedEncodingException
  }
  
  public final void a(int paramInt) {
    b(paramInt);
    this.d.clear();
    this.c = this.b;
    this.d = h();
  }
  
  public final void a(Canvas paramCanvas) {
    if (this.d.size() == 0)
      this.d = h(); 
    if (this.c >= this.a) {
      this.w = true;
    } else {
      this.w = false;
    } 
    if (this.d.size() > 0) {
      if (this.l == null) {
        paramCanvas.drawColor(this.q);
      } else {
        paramCanvas.drawBitmap(this.l, 0.0F, 0.0F, null);
      } 
      Iterator<String> iterator = this.d.iterator();
      int j = 18;
      for (byte b = 0; iterator.hasNext(); b++) {
        String str1 = iterator.next();
        if ("".equals(str1)) {
          j += 20;
          paramCanvas.drawText(str1, this.r, j, this.y);
        } else if (this.b == 0 && !b) {
          j += this.p;
          paramCanvas.drawText(str1, this.r, j, this.A);
        } else {
          j += this.p;
          paramCanvas.drawText(str1, this.r, j, this.y);
        } 
      } 
    } 
    float f = (float)(this.b * 1.0D / this.a);
    if (this.B != null)
      this.B.setProgress(this.b); 
    this.h = this.D.format((f * 100.0F));
    String str = "本书 " + this.h + "%";
    if (this.w == true)
      str = "本章 100%"; 
    if (this.C != null)
      this.C.setText(str); 
    int i = (int)this.z.measureText("999.99%");
    paramCanvas.drawText(str, (this.m - i + 70), (this.n - 16), this.z);
    paramCanvas.drawText(g.a(System.currentTimeMillis(), "MM-dd HH:mm"), 20.0F, (this.n - 16), this.z);
  }
  
  public final void a(File paramFile, int paramInt) {
    this.i = paramFile;
    long l = this.i.length();
    this.a = (int)l;
    this.j = (new RandomAccessFile(this.i, "r")).getChannel().map(FileChannel.MapMode.READ_ONLY, 0L, l);
    this.c = paramInt;
    this.b = paramInt;
    this.d.clear();
    if (this.B != null)
      this.B.setMax(this.a); 
  }
  
  public final void b() {
    if (this.c >= this.a) {
      this.w = true;
      return;
    } 
    this.w = false;
    this.d.clear();
    this.b = this.c;
    this.d = h();
  }
  
  public final void b(int paramInt) {
    this.y.setTextSize(this.o[paramInt]);
    this.A.setTextSize(this.o[paramInt]);
    byte b = 7;
    if (this.o[paramInt] > 26)
      b = 10; 
    Paint.FontMetrics fontMetrics = this.y.getFontMetrics();
    this.p = b + (int)(fontMetrics.descent - fontMetrics.ascent);
  }
  
  public final void c(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = 0; 
    paramInt = i;
    if (i >= this.a)
      paramInt = this.a - 1; 
    this.c = paramInt;
    this.b = paramInt;
    i();
  }
  
  public final boolean c() {
    return this.v;
  }
  
  public final void d(int paramInt) {
    this.y.setColor(((Integer)this.e.get(paramInt)).intValue());
    this.A.setColor(((Integer)this.e.get(paramInt)).intValue());
    this.z.setColor(((Integer)this.f.get(paramInt)).intValue());
    Bitmap bitmap = BitmapFactory.decodeResource(this.x.getResources(), ((Integer)this.g.get(paramInt)).intValue());
    if (this.l != null && !this.l.isRecycled())
      this.l.recycle(); 
    this.l = Bitmap.createScaledBitmap(bitmap, this.m, this.n, true);
    bitmap.recycle();
  }
  
  public final boolean d() {
    return this.w;
  }
  
  public final void e() {
    int i = this.b - this.a / 1000;
    int j = i;
    if (i < 0)
      j = 0; 
    this.c = j;
    this.b = j;
    i();
  }
  
  public final void f() {
    int i = this.b + this.a / 1000;
    int j = i;
    if (i >= this.a)
      j = this.a - 1; 
    this.c = j;
    this.b = j;
    i();
  }
  
  public final void g() {
    if (this.l != null && !this.l.isRecycled())
      this.l.recycle(); 
    this.d.clear();
    if (this.j != null) {
      this.j.clear();
      this.j = null;
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/i/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */