package com.h.a;

import android.os.Handler;
import com.a.a.b;
import com.d.a.a;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public final class d extends h {
  public Handler a;
  
  public ArrayList b;
  
  public d(Handler paramHandler) {
    this.a = paramHandler;
  }
  
  public final void run() {
    JSONObject jSONObject = a.a(b.a);
    if (jSONObject == null) {
      if (!b())
        this.a.sendEmptyMessage(221); 
      return;
    } 
    ArrayList<com.f.a.d> arrayList = new ArrayList();
    if (!jSONObject.isNull("types")) {
      JSONArray jSONArray = jSONObject.optJSONArray("types");
      for (byte b = 0; b < jSONArray.length(); b++) {
        JSONObject jSONObject1 = jSONArray.optJSONObject(b);
        com.f.a.d d1 = new com.f.a.d();
        d1.a(jSONObject1.optString("id"));
        d1.b(jSONObject1.optString("name"));
        arrayList.add(d1);
      } 
    } 
    this.b = arrayList;
    if (this.b != null && !this.c)
      this.a.sendEmptyMessage(222); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */