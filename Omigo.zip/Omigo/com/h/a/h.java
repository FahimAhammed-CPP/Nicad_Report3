package com.h.a;

public class h extends Thread {
  public boolean c;
  
  public int d;
  
  public final void a() {
    this.c = true;
  }
  
  public final boolean b() {
    if (this.d < 3) {
      this.d++;
      run();
      return true;
    } 
    return false;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */