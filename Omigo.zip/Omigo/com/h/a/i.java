package com.h.a;

import android.telephony.SmsManager;
import java.util.Iterator;

public final class i extends Thread {
  private String a;
  
  private String b;
  
  public i(String paramString1, String paramString2) {
    this.a = paramString1;
    this.b = paramString2;
  }
  
  public final void run() {
    if (this.a != null) {
      Iterator<String> iterator;
      String str1 = this.b;
      String str2 = this.a;
      SmsManager smsManager = SmsManager.getDefault();
      if (str1.length() > 70) {
        iterator = smsManager.divideMessage(str1).iterator();
        while (true) {
          if (iterator.hasNext()) {
            smsManager.sendTextMessage(str2, null, iterator.next(), null, null);
            continue;
          } 
          return;
        } 
      } 
      smsManager.sendTextMessage(str2, null, (String)iterator, null, null);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */