package com.h.a;

import android.os.Handler;
import android.util.Log;
import com.a.a.g;
import com.f.a.a;
import java.util.Vector;

public final class b extends h {
  private Handler a;
  
  private Vector b;
  
  public b(Handler paramHandler, Vector paramVector) {
    this.a = paramHandler;
    this.b = paramVector;
  }
  
  public final void run() {
    if (this.b != null && this.b.size() > 0)
      for (byte b1 = 0;; b1++) {
        if (b1 < this.b.size()) {
          a a = this.b.get(b1);
          try {
            if (this.c)
              return; 
            if (a.i() == null) {
              a.a(g.a(a.d()));
              this.a.sendEmptyMessage(888);
            } 
          } catch (Exception exception) {
            Log.e("出错", "出错" + exception.getMessage());
          } 
        } else {
          return;
        } 
      }  
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */