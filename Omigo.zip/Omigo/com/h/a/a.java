package com.h.a;

import android.os.Handler;
import android.util.Log;
import com.a.a.e;
import java.util.Hashtable;

public final class a extends h {
  private Handler a;
  
  public a(Handler paramHandler) {
    this.a = paramHandler;
  }
  
  public final void run() {
    while (!this.c) {
      Hashtable hashtable = e.f;
      if (hashtable != null && hashtable.size() > 0) {
        Log.e("刷新", " 111");
        this.a.sendEmptyMessage(71);
      } 
      try {
        Thread.sleep(1500L);
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */