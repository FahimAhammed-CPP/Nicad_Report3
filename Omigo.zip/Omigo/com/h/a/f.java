package com.h.a;

import android.os.Handler;
import com.a.a.b;
import com.d.a.a;
import com.d.a.b;
import com.f.a.b;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import org.json.JSONObject;

public final class f extends h {
  public Handler a;
  
  public b b;
  
  private int e;
  
  private String f;
  
  public f(Handler paramHandler, String paramString, int paramInt) {
    this.a = paramHandler;
    this.e = paramInt;
    try {
      this.f = URLEncoder.encode(paramString, "utf-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
    } 
  }
  
  public final void run() {
    JSONObject jSONObject = a.a(b.c + "?bookname=" + this.f + "&page=" + this.e);
    if (jSONObject == null) {
      if (!b())
        this.a.sendEmptyMessage(221); 
      return;
    } 
    this.b = b.a(jSONObject);
    this.b = b.a(jSONObject);
    if (this.b != null && !this.c) {
      if (this.e > 1) {
        this.a.sendEmptyMessage(223);
        return;
      } 
      this.a.sendEmptyMessage(222);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/h/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */