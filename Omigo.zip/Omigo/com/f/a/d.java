package com.f.a;

public final class d {
  private String a;
  
  private String b;
  
  public final String a() {
    return this.a;
  }
  
  public final void a(String paramString) {
    this.a = paramString;
  }
  
  public final String b() {
    return this.b;
  }
  
  public final void b(String paramString) {
    this.b = paramString;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/f/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */