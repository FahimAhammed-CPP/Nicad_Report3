package com.f.a;

public final class c {
  private long a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private String e;
  
  private int f;
  
  private String g;
  
  private long h;
  
  public final long a() {
    return this.a;
  }
  
  public final void a(int paramInt) {
    this.f = paramInt;
  }
  
  public final void a(long paramLong) {
    this.a = paramLong;
  }
  
  public final void a(String paramString) {
    this.b = paramString;
  }
  
  public final String b() {
    return this.b;
  }
  
  public final void b(long paramLong) {
    this.h = paramLong;
  }
  
  public final void b(String paramString) {
    this.c = paramString;
  }
  
  public final String c() {
    return this.c;
  }
  
  public final void c(String paramString) {
    this.e = paramString;
  }
  
  public final String d() {
    return this.e;
  }
  
  public final void d(String paramString) {
    this.g = paramString;
  }
  
  public final int e() {
    return this.f;
  }
  
  public final void e(String paramString) {
    this.d = paramString;
  }
  
  public final String f() {
    return this.g;
  }
  
  public final long g() {
    return this.h;
  }
  
  public final String h() {
    return this.d;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/f/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */