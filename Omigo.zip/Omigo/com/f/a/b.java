package com.f.a;

import java.util.Vector;

public final class b {
  private int a;
  
  private boolean b;
  
  private Vector c;
  
  public final int a() {
    return this.a;
  }
  
  public final void a(int paramInt) {
    this.a = paramInt;
  }
  
  public final void a(Vector paramVector) {
    this.c = paramVector;
  }
  
  public final void a(boolean paramBoolean) {
    this.b = paramBoolean;
  }
  
  public final boolean b() {
    return this.b;
  }
  
  public final Vector c() {
    if (this.c == null)
      this.c = new Vector(); 
    return this.c;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/f/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */