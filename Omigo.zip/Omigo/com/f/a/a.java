package com.f.a;

import android.net.Uri;

public final class a {
  private long a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private String e;
  
  private int f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private int l;
  
  private long m;
  
  private Uri n;
  
  public final long a() {
    return this.a;
  }
  
  public final void a(int paramInt) {
    this.f = paramInt;
  }
  
  public final void a(long paramLong) {
    this.a = paramLong;
  }
  
  public final void a(Uri paramUri) {
    this.n = paramUri;
  }
  
  public final void a(String paramString) {
    this.b = paramString;
  }
  
  public final String b() {
    return this.b;
  }
  
  public final void b(int paramInt) {
    this.l = paramInt;
  }
  
  public final void b(long paramLong) {
    this.m = paramLong;
  }
  
  public final void b(String paramString) {
    this.c = paramString;
  }
  
  public final String c() {
    return this.c;
  }
  
  public final void c(String paramString) {
    this.d = paramString;
  }
  
  public final String d() {
    return this.d;
  }
  
  public final void d(String paramString) {
    this.e = paramString;
  }
  
  public final String e() {
    return this.e;
  }
  
  public final void e(String paramString) {
    this.g = paramString;
  }
  
  public final int f() {
    return this.f;
  }
  
  public final void f(String paramString) {
    this.h = paramString;
  }
  
  public final String g() {
    return this.g;
  }
  
  public final void g(String paramString) {
    this.j = paramString;
  }
  
  public final String h() {
    return this.h;
  }
  
  public final void h(String paramString) {
    this.i = paramString;
  }
  
  public final Uri i() {
    return this.n;
  }
  
  public final void i(String paramString) {
    this.k = paramString;
  }
  
  public final String j() {
    return this.j;
  }
  
  public final int k() {
    return this.l;
  }
  
  public final long l() {
    return this.m;
  }
  
  public final String m() {
    return this.i;
  }
  
  public final String n() {
    return this.k;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/f/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */