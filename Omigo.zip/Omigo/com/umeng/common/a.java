package com.umeng.common;

public class a {
  public static final String a = "/download/.um";
  
  public static final String b = "type";
  
  public static final String c = "package";
  
  public static final String d = "channel";
  
  public static final String e = "idmd5";
  
  public static final String f = "version_code";
  
  public static final String g = "appkey";
  
  public static final String h = "sdk_version";
  
  public static final String i = " 下载失败，请检查网络。";
  
  public static final String j = "正在下载应用";
  
  public static final String k = "正在下载中，请稍等 ...";
  
  public static final String l = "下载完成，请点击安装";
  
  public static String m = null;
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */