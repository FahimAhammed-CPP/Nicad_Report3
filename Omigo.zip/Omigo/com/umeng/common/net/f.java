package com.umeng.common.net;

import android.os.AsyncTask;

public class f extends j {
  public h.a a(g paramg) {
    h h = a(paramg, h.class);
    return (h == null) ? h.a.b : h.a;
  }
  
  public void a(g paramg, a parama) {
    (new b(this, paramg, parama)).execute((Object[])new Integer[0]);
  }
  
  public static interface a {
    void a();
    
    void a(h.a param1a);
  }
  
  private class b extends AsyncTask<Integer, Integer, h.a> {
    private g b;
    
    private f.a c;
    
    public b(f this$0, g param1g, f.a param1a) {
      this.b = param1g;
      this.c = param1a;
    }
    
    protected h.a a(Integer... param1VarArgs) {
      return this.a.a(this.b);
    }
    
    protected void a(h.a param1a) {
      if (this.c != null)
        this.c.a(param1a); 
    }
    
    protected void onPreExecute() {
      if (this.c != null)
        this.c.a(); 
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */