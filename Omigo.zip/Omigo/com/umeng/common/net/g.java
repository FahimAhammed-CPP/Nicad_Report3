package com.umeng.common.net;

public abstract class g extends k {
  public g() {
    super("");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */