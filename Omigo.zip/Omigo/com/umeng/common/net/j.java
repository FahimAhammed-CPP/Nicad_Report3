package com.umeng.common.net;

import com.umeng.common.Log;
import com.umeng.common.b.f;
import com.umeng.common.b.g;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.zip.InflaterInputStream;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONException;
import org.json.JSONObject;

public class j {
  private static final String a = j.class.getName();
  
  private Map<String, String> b;
  
  private static String a(InputStream paramInputStream) {
    IOException iOException2 = null;
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream), 8192);
    StringBuilder stringBuilder = new StringBuilder();
    try {
      while (true) {
        String str = bufferedReader.readLine();
        if (str == null) {
          try {
            paramInputStream.close();
            String str1 = stringBuilder.toString();
          } catch (IOException null) {
            Log.b(a, "Caught IOException in convertStreamToString()", iOException1);
            iOException1 = iOException2;
          } 
          return (String)iOException1;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        this(String.valueOf(str));
        stringBuilder.append(stringBuilder1.append("\n").toString());
      } 
    } catch (IOException iOException) {
      Log.b(a, "Caught IOException in convertStreamToString()", iOException);
      try {
        iOException1.close();
        iOException1 = iOException2;
      } catch (IOException iOException1) {
        Log.b(a, "Caught IOException in convertStreamToString()", iOException1);
        iOException1 = iOException2;
      } 
    } finally {
      Exception exception;
    } 
    return (String)iOException1;
  }
  
  private JSONObject a(String paramString) {
    // Byte code:
    //   0: new java/util/Random
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: sipush #1000
    //   10: invokevirtual nextInt : (I)I
    //   13: istore_2
    //   14: ldc 'line.separator'
    //   16: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
    //   19: astore_3
    //   20: aload_1
    //   21: invokevirtual length : ()I
    //   24: iconst_1
    //   25: if_icmpgt -> 66
    //   28: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   31: astore #4
    //   33: new java/lang/StringBuilder
    //   36: astore #5
    //   38: aload #5
    //   40: iload_2
    //   41: invokestatic valueOf : (I)Ljava/lang/String;
    //   44: invokespecial <init> : (Ljava/lang/String;)V
    //   47: aload #4
    //   49: aload #5
    //   51: ldc ':\\tInvalid baseUrl.'
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   62: aconst_null
    //   63: astore_1
    //   64: aload_1
    //   65: areturn
    //   66: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   69: astore #5
    //   71: new java/lang/StringBuilder
    //   74: astore #4
    //   76: aload #4
    //   78: iload_2
    //   79: invokestatic valueOf : (I)Ljava/lang/String;
    //   82: invokespecial <init> : (Ljava/lang/String;)V
    //   85: aload #5
    //   87: aload #4
    //   89: ldc ':\\tget: '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: aload_1
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: invokevirtual toString : ()Ljava/lang/String;
    //   101: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   104: new org/apache/http/client/methods/HttpGet
    //   107: astore #4
    //   109: aload #4
    //   111: aload_1
    //   112: invokespecial <init> : (Ljava/lang/String;)V
    //   115: aload_0
    //   116: getfield b : Ljava/util/Map;
    //   119: ifnull -> 160
    //   122: aload_0
    //   123: getfield b : Ljava/util/Map;
    //   126: invokeinterface size : ()I
    //   131: ifle -> 160
    //   134: aload_0
    //   135: getfield b : Ljava/util/Map;
    //   138: invokeinterface keySet : ()Ljava/util/Set;
    //   143: invokeinterface iterator : ()Ljava/util/Iterator;
    //   148: astore #5
    //   150: aload #5
    //   152: invokeinterface hasNext : ()Z
    //   157: ifne -> 391
    //   160: new org/apache/http/params/BasicHttpParams
    //   163: astore #5
    //   165: aload #5
    //   167: invokespecial <init> : ()V
    //   170: aload #5
    //   172: sipush #10000
    //   175: invokestatic setConnectionTimeout : (Lorg/apache/http/params/HttpParams;I)V
    //   178: aload #5
    //   180: sipush #20000
    //   183: invokestatic setSoTimeout : (Lorg/apache/http/params/HttpParams;I)V
    //   186: new org/apache/http/impl/client/DefaultHttpClient
    //   189: astore #6
    //   191: aload #6
    //   193: aload #5
    //   195: invokespecial <init> : (Lorg/apache/http/params/HttpParams;)V
    //   198: aload #6
    //   200: aload #4
    //   202: invokeinterface execute : (Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    //   207: astore #5
    //   209: aload #5
    //   211: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   216: invokeinterface getStatusCode : ()I
    //   221: sipush #200
    //   224: if_icmpne -> 588
    //   227: aload #5
    //   229: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   234: astore #4
    //   236: aload #4
    //   238: ifnull -> 645
    //   241: aload #4
    //   243: invokeinterface getContent : ()Ljava/io/InputStream;
    //   248: astore #4
    //   250: aload #5
    //   252: ldc 'Content-Encoding'
    //   254: invokeinterface getFirstHeader : (Ljava/lang/String;)Lorg/apache/http/Header;
    //   259: astore #5
    //   261: aload #5
    //   263: ifnull -> 465
    //   266: aload #5
    //   268: invokeinterface getValue : ()Ljava/lang/String;
    //   273: ldc 'gzip'
    //   275: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   278: ifeq -> 465
    //   281: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   284: astore #6
    //   286: new java/lang/StringBuilder
    //   289: astore #5
    //   291: aload #5
    //   293: iload_2
    //   294: invokestatic valueOf : (I)Ljava/lang/String;
    //   297: invokespecial <init> : (Ljava/lang/String;)V
    //   300: aload #6
    //   302: aload #5
    //   304: ldc '  Use GZIPInputStream get data....'
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: invokevirtual toString : ()Ljava/lang/String;
    //   312: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   315: new java/util/zip/GZIPInputStream
    //   318: astore #5
    //   320: aload #5
    //   322: aload #4
    //   324: invokespecial <init> : (Ljava/io/InputStream;)V
    //   327: aload #5
    //   329: astore #4
    //   331: aload #4
    //   333: invokestatic a : (Ljava/io/InputStream;)Ljava/lang/String;
    //   336: astore #4
    //   338: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   341: astore #6
    //   343: new java/lang/StringBuilder
    //   346: astore #5
    //   348: aload #5
    //   350: iload_2
    //   351: invokestatic valueOf : (I)Ljava/lang/String;
    //   354: invokespecial <init> : (Ljava/lang/String;)V
    //   357: aload #6
    //   359: aload #5
    //   361: ldc ':\\tresponse: '
    //   363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   366: aload_3
    //   367: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   370: aload #4
    //   372: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   375: invokevirtual toString : ()Ljava/lang/String;
    //   378: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   381: aload #4
    //   383: ifnonnull -> 571
    //   386: aconst_null
    //   387: astore_1
    //   388: goto -> 64
    //   391: aload #5
    //   393: invokeinterface next : ()Ljava/lang/Object;
    //   398: checkcast java/lang/String
    //   401: astore #6
    //   403: aload #4
    //   405: aload #6
    //   407: aload_0
    //   408: getfield b : Ljava/util/Map;
    //   411: aload #6
    //   413: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   418: checkcast java/lang/String
    //   421: invokevirtual addHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   424: goto -> 150
    //   427: astore #4
    //   429: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   432: new java/lang/StringBuilder
    //   435: dup
    //   436: iload_2
    //   437: invokestatic valueOf : (I)Ljava/lang/String;
    //   440: invokespecial <init> : (Ljava/lang/String;)V
    //   443: ldc ':\\tClientProtocolException,Failed to send message.'
    //   445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   448: aload_1
    //   449: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   452: invokevirtual toString : ()Ljava/lang/String;
    //   455: aload #4
    //   457: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   460: aconst_null
    //   461: astore_1
    //   462: goto -> 64
    //   465: aload #5
    //   467: ifnull -> 650
    //   470: aload #5
    //   472: invokeinterface getValue : ()Ljava/lang/String;
    //   477: ldc 'deflate'
    //   479: invokevirtual equalsIgnoreCase : (Ljava/lang/String;)Z
    //   482: ifeq -> 650
    //   485: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   488: astore #6
    //   490: new java/lang/StringBuilder
    //   493: astore #5
    //   495: aload #5
    //   497: iload_2
    //   498: invokestatic valueOf : (I)Ljava/lang/String;
    //   501: invokespecial <init> : (Ljava/lang/String;)V
    //   504: aload #6
    //   506: aload #5
    //   508: ldc '  Use InflaterInputStream get data....'
    //   510: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   513: invokevirtual toString : ()Ljava/lang/String;
    //   516: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   519: new java/util/zip/InflaterInputStream
    //   522: dup
    //   523: aload #4
    //   525: invokespecial <init> : (Ljava/io/InputStream;)V
    //   528: astore #4
    //   530: goto -> 331
    //   533: astore #4
    //   535: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   538: new java/lang/StringBuilder
    //   541: dup
    //   542: iload_2
    //   543: invokestatic valueOf : (I)Ljava/lang/String;
    //   546: invokespecial <init> : (Ljava/lang/String;)V
    //   549: ldc ':\\tIOException,Failed to send message.'
    //   551: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   554: aload_1
    //   555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   558: invokevirtual toString : ()Ljava/lang/String;
    //   561: aload #4
    //   563: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   566: aconst_null
    //   567: astore_1
    //   568: goto -> 64
    //   571: new org/json/JSONObject
    //   574: dup
    //   575: aload #4
    //   577: invokespecial <init> : (Ljava/lang/String;)V
    //   580: astore #4
    //   582: aload #4
    //   584: astore_1
    //   585: goto -> 64
    //   588: getstatic com/umeng/common/net/j.a : Ljava/lang/String;
    //   591: astore_3
    //   592: new java/lang/StringBuilder
    //   595: astore #4
    //   597: aload #4
    //   599: iload_2
    //   600: invokestatic valueOf : (I)Ljava/lang/String;
    //   603: invokespecial <init> : (Ljava/lang/String;)V
    //   606: aload_3
    //   607: aload #4
    //   609: ldc ':\\tFailed to send message. StatusCode = '
    //   611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   614: aload #5
    //   616: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   621: invokeinterface getStatusCode : ()I
    //   626: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   629: getstatic com/umeng/common/b/g.a : Ljava/lang/String;
    //   632: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   635: aload_1
    //   636: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   639: invokevirtual toString : ()Ljava/lang/String;
    //   642: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
    //   645: aconst_null
    //   646: astore_1
    //   647: goto -> 64
    //   650: goto -> 331
    // Exception table:
    //   from	to	target	type
    //   14	62	427	org/apache/http/client/ClientProtocolException
    //   14	62	533	java/lang/Exception
    //   66	150	427	org/apache/http/client/ClientProtocolException
    //   66	150	533	java/lang/Exception
    //   150	160	427	org/apache/http/client/ClientProtocolException
    //   150	160	533	java/lang/Exception
    //   160	236	427	org/apache/http/client/ClientProtocolException
    //   160	236	533	java/lang/Exception
    //   241	261	427	org/apache/http/client/ClientProtocolException
    //   241	261	533	java/lang/Exception
    //   266	327	427	org/apache/http/client/ClientProtocolException
    //   266	327	533	java/lang/Exception
    //   331	381	427	org/apache/http/client/ClientProtocolException
    //   331	381	533	java/lang/Exception
    //   391	424	427	org/apache/http/client/ClientProtocolException
    //   391	424	533	java/lang/Exception
    //   470	530	427	org/apache/http/client/ClientProtocolException
    //   470	530	533	java/lang/Exception
    //   571	582	427	org/apache/http/client/ClientProtocolException
    //   571	582	533	java/lang/Exception
    //   588	645	427	org/apache/http/client/ClientProtocolException
    //   588	645	533	java/lang/Exception
  }
  
  private JSONObject a(String paramString, JSONObject paramJSONObject) {
    HttpPost httpPost2 = null;
    String str = paramJSONObject.toString();
    int i = (new Random()).nextInt(1000);
    Log.c(a, String.valueOf(i) + ":\trequest: " + paramString + g.a + str);
    HttpPost httpPost1 = new HttpPost(paramString);
    BasicHttpParams basicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, 10000);
    HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, 20000);
    DefaultHttpClient defaultHttpClient = new DefaultHttpClient((HttpParams)basicHttpParams);
    try {
      ByteArrayInputStream byteArrayInputStream;
      String str2;
      if (a()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this("content=");
        byte[] arrayOfByte = f.a(stringBuilder1.append(str).toString(), Charset.defaultCharset().toString());
        httpPost1.addHeader("Content-Encoding", "deflate");
        InputStreamEntity inputStreamEntity = new InputStreamEntity();
        byteArrayInputStream = new ByteArrayInputStream();
        this(arrayOfByte);
        this(byteArrayInputStream, arrayOfByte.length);
        httpPost1.setEntity((HttpEntity)inputStreamEntity);
      } else {
        ArrayList<BasicNameValuePair> arrayList = new ArrayList();
        this(1);
        BasicNameValuePair basicNameValuePair = new BasicNameValuePair();
        this("content", (String)byteArrayInputStream);
        arrayList.add(basicNameValuePair);
        UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity();
        this(arrayList, "UTF-8");
        httpPost1.setEntity((HttpEntity)urlEncodedFormEntity);
      } 
      HttpResponse httpResponse = defaultHttpClient.execute((HttpUriRequest)httpPost1);
      if (httpResponse.getStatusLine().getStatusCode() == 200) {
        HttpEntity httpEntity = httpResponse.getEntity();
        httpPost1 = httpPost2;
        if (httpEntity != null) {
          InputStream inputStream = httpEntity.getContent();
          Header header = httpResponse.getFirstHeader("Content-Encoding");
          if (header != null && header.getValue().equalsIgnoreCase("deflate")) {
            InflaterInputStream inflaterInputStream = new InflaterInputStream();
            this(inputStream);
            inputStream = inflaterInputStream;
          } 
          str2 = a(inputStream);
          String str3 = a;
          StringBuilder stringBuilder1 = new StringBuilder();
          this(String.valueOf(i));
          Log.a(str3, stringBuilder1.append(":\tresponse: ").append(g.a).append(str2).toString());
          if (str2 == null)
            return (JSONObject)httpPost2; 
        } else {
          return (JSONObject)httpPost1;
        } 
        JSONObject jSONObject = new JSONObject();
        this(str2);
        return jSONObject;
      } 
      String str1 = a;
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(i));
      Log.c(str1, stringBuilder.append(":\tFailed to send message. StatusCode = ").append(str2.getStatusLine().getStatusCode()).append(g.a).append(paramString).toString());
      HttpPost httpPost = httpPost2;
    } catch (ClientProtocolException clientProtocolException) {
      Log.c(a, String.valueOf(i) + ":\tClientProtocolException,Failed to send message." + paramString, (Exception)clientProtocolException);
      HttpPost httpPost = httpPost2;
    } catch (IOException iOException) {
      Log.c(a, String.valueOf(i) + ":\tIOException,Failed to send message." + paramString, iOException);
      HttpPost httpPost = httpPost2;
    } catch (JSONException jSONException) {
      Log.c(a, String.valueOf(i) + ":\tIOException,Failed to send message." + paramString, (Exception)jSONException);
      httpPost1 = httpPost2;
    } 
    return (JSONObject)httpPost1;
  }
  
  private void b(String paramString) {
    if (g.c(paramString) || (k.b.equals(paramString.trim()) ^ k.a.equals(paramString.trim())) == 0)
      throw new RuntimeException("验证请求方式失败[" + paramString + "]"); 
  }
  
  public j a(Map<String, String> paramMap) {
    this.b = paramMap;
    return this;
  }
  
  public <T extends l> T a(k paramk, Class<T> paramClass) {
    JSONObject jSONObject;
    String str = paramk.c().trim();
    b(str);
    if (k.b.equals(str)) {
      jSONObject = a(paramk.b());
    } else if (k.a.equals(str)) {
      jSONObject = a(((k)jSONObject).c, jSONObject.a());
    } else {
      jSONObject = null;
    } 
    if (jSONObject == null)
      return null; 
    try {
      l l = paramClass.getConstructor(new Class[] { JSONObject.class }).newInstance(new Object[] { jSONObject });
    } catch (SecurityException securityException) {
      Log.b(a, "SecurityException", securityException);
      securityException = null;
    } catch (NoSuchMethodException noSuchMethodException) {
      Log.b(a, "NoSuchMethodException", noSuchMethodException);
      noSuchMethodException = null;
    } catch (IllegalArgumentException illegalArgumentException) {
      Log.b(a, "IllegalArgumentException", illegalArgumentException);
      illegalArgumentException = null;
    } catch (InstantiationException instantiationException) {
      Log.b(a, "InstantiationException", instantiationException);
      instantiationException = null;
    } catch (IllegalAccessException illegalAccessException) {
      Log.b(a, "IllegalAccessException", illegalAccessException);
      illegalAccessException = null;
    } catch (InvocationTargetException invocationTargetException) {
      Log.b(a, "InvocationTargetException", invocationTargetException);
    } 
    return (T)invocationTargetException;
  }
  
  public boolean a() {
    return false;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */