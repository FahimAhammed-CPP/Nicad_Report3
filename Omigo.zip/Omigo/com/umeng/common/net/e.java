package com.umeng.common.net;

public interface e {
  void a();
  
  void a(int paramInt);
  
  void a(int paramInt, String paramString);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */