package com.umeng.common.net;

import org.json.JSONObject;

public abstract class l {
  public l(JSONObject paramJSONObject) {}
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */