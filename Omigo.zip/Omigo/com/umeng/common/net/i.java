package com.umeng.common.net;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Environment;
import android.view.animation.Animation;
import android.widget.ImageView;
import com.umeng.common.Log;
import com.umeng.common.b.g;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;
import java.util.Stack;

public class i {
  public static boolean a = false;
  
  private static final String b = i.class.getName();
  
  private static final long c = 104857600L;
  
  private static final long d = 10485760L;
  
  static {
    a = false;
  }
  
  private static long a(File paramFile) {
    if (paramFile == null || !paramFile.exists() || !paramFile.isDirectory())
      return 0L; 
    Stack<File> stack = new Stack();
    stack.clear();
    stack.push(paramFile);
    long l = 0L;
    while (true) {
      long l1 = l;
      if (!stack.isEmpty()) {
        File[] arrayOfFile = ((File)stack.pop()).listFiles();
        for (byte b = 0; b < arrayOfFile.length; b++) {
          if (arrayOfFile[b].isDirectory()) {
            stack.push(arrayOfFile[b]);
          } else {
            l = arrayOfFile[b].length() + l;
          } 
        } 
        continue;
      } 
      return l1;
    } 
  }
  
  public static String a(Context paramContext, String paramString) {
    File file;
    if (g.c(paramString))
      return null; 
    try {
      String str1;
      long l;
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(b(paramString)));
      String str2 = stringBuilder.append(".tmp").toString();
      if (com.umeng.common.b.b()) {
        str1 = Environment.getExternalStorageDirectory().getCanonicalPath();
        l = 104857600L;
      } else {
        str1 = str1.getCacheDir().getCanonicalPath();
        l = 10485760L;
      } 
      File file1 = new File();
      stringBuilder = new StringBuilder();
      this(String.valueOf(str1));
      this(stringBuilder.append("/download/.um").toString());
      if (file1.exists()) {
        if (a(file1.getCanonicalFile()) > l)
          b(file1); 
      } else if (!file1.mkdirs()) {
        String str = b;
        StringBuilder stringBuilder1 = new StringBuilder();
        this("Failed to create directory");
        Log.b(str, stringBuilder1.append(file1.getAbsolutePath()).append(". Check permission. Make sure WRITE_EXTERNAL_STORAGE is added in your Manifest.xml").toString());
      } 
      file = new File();
      this(file1, str2);
      try {
        file.createNewFile();
        FileOutputStream fileOutputStream = new FileOutputStream();
        this(file);
        URL uRL = new URL();
        this(paramString);
        InputStream inputStream = (InputStream)uRL.openConnection().getContent();
        byte[] arrayOfByte = new byte[4096];
        while (true) {
          File file2;
          int j = inputStream.read(arrayOfByte);
          if (j == -1) {
            fileOutputStream.flush();
            inputStream.close();
            fileOutputStream.close();
            file2 = new File();
            this(file.getParent(), file.getName().replace(".tmp", ""));
            file.renameTo(file2);
            String str = b;
            StringBuilder stringBuilder1 = new StringBuilder();
            this("download img[");
            Log.a(str, stringBuilder1.append(paramString).append("]  to ").append(file2.getCanonicalPath()).toString());
            return file2.getCanonicalPath();
          } 
          fileOutputStream.write((byte[])file2, 0, j);
        } 
      } catch (Exception null) {}
    } catch (Exception null) {
      file = null;
    } 
    Log.a(b, String.valueOf(null.getStackTrace().toString()) + "\t url:\t" + g.a + paramString);
    if (file != null && file.exists())
      file.deleteOnExit(); 
    return null;
  }
  
  public static void a(Context paramContext, ImageView paramImageView, String paramString, boolean paramBoolean) {
    a(paramContext, paramImageView, paramString, paramBoolean, (a)null, (Animation)null);
  }
  
  public static void a(Context paramContext, ImageView paramImageView, String paramString, boolean paramBoolean, a parama) {
    a(paramContext, paramImageView, paramString, paramBoolean, parama, (Animation)null);
  }
  
  public static void a(Context paramContext, ImageView paramImageView, String paramString, boolean paramBoolean, a parama, Animation paramAnimation) {
    if (paramImageView != null) {
      try {
        File file = b(paramContext, paramString);
        if (file != null && file.exists() && !a) {
          if (parama != null)
            parama.a(b.a); 
          b(paramContext, paramImageView, c(file.getAbsolutePath()), paramBoolean, parama, paramAnimation);
          return;
        } 
      } catch (IOException iOException) {
        if (parama != null)
          parama.a(h.a.b); 
        return;
      } 
      c c = new c();
      this((Context)iOException, paramImageView, paramString, b.b, paramBoolean, parama, paramAnimation);
      c.execute(new Object[0]);
    } 
  }
  
  protected static File b(Context paramContext, String paramString) throws IOException {
    String str;
    paramString = b(paramString);
    if (com.umeng.common.b.b()) {
      str = Environment.getExternalStorageDirectory().getCanonicalPath();
    } else {
      str = str.getCacheDir().getCanonicalPath();
    } 
    File file = new File(new File(String.valueOf(str) + "/download/.um"), paramString);
    if (!file.exists())
      file = null; 
    return file;
  }
  
  private static String b(String paramString) {
    int j = paramString.lastIndexOf(".");
    String str = "";
    if (j >= 0)
      str = paramString.substring(j); 
    return String.valueOf(g.a(paramString)) + str;
  }
  
  private static void b(Context paramContext, ImageView paramImageView, Drawable paramDrawable, boolean paramBoolean, a parama, Animation paramAnimation) {
    // Byte code:
    //   0: ldc com/umeng/common/net/i
    //   2: monitorenter
    //   3: aload_2
    //   4: ifnull -> 11
    //   7: aload_1
    //   8: ifnonnull -> 75
    //   11: aload #4
    //   13: ifnull -> 26
    //   16: aload #4
    //   18: getstatic com/umeng/common/net/h$a.b : Lcom/umeng/common/net/h$a;
    //   21: invokeinterface a : (Lcom/umeng/common/net/h$a;)V
    //   26: getstatic com/umeng/common/net/i.b : Ljava/lang/String;
    //   29: astore #4
    //   31: new java/lang/StringBuilder
    //   34: astore_0
    //   35: aload_0
    //   36: ldc_w 'bind drawable failed. drawable ['
    //   39: invokespecial <init> : (Ljava/lang/String;)V
    //   42: aload #4
    //   44: aload_0
    //   45: aload_2
    //   46: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   49: ldc_w ']  imageView[+'
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: aload_1
    //   56: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   59: ldc_w '+]'
    //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: invokevirtual toString : ()Ljava/lang/String;
    //   68: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)V
    //   71: ldc com/umeng/common/net/i
    //   73: monitorexit
    //   74: return
    //   75: iload_3
    //   76: ifeq -> 119
    //   79: aload_1
    //   80: aload_2
    //   81: invokevirtual setBackgroundDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   84: aload #5
    //   86: ifnull -> 95
    //   89: aload_1
    //   90: aload #5
    //   92: invokevirtual startAnimation : (Landroid/view/animation/Animation;)V
    //   95: aload #4
    //   97: ifnull -> 71
    //   100: aload #4
    //   102: getstatic com/umeng/common/net/h$a.a : Lcom/umeng/common/net/h$a;
    //   105: invokeinterface a : (Lcom/umeng/common/net/h$a;)V
    //   110: goto -> 71
    //   113: astore_0
    //   114: ldc com/umeng/common/net/i
    //   116: monitorexit
    //   117: aload_0
    //   118: athrow
    //   119: aload_1
    //   120: aload_2
    //   121: invokevirtual setImageDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   124: goto -> 84
    // Exception table:
    //   from	to	target	type
    //   16	26	113	finally
    //   26	71	113	finally
    //   79	84	113	finally
    //   89	95	113	finally
    //   100	110	113	finally
    //   119	124	113	finally
  }
  
  private static void b(File paramFile) {
    if (paramFile != null && paramFile.exists() && paramFile.canWrite() && paramFile.isDirectory()) {
      File[] arrayOfFile = paramFile.listFiles();
      byte b = 0;
      while (true) {
        if (b < arrayOfFile.length) {
          if (arrayOfFile[b].isDirectory()) {
            b(arrayOfFile[b]);
          } else if ((new Date()).getTime() - arrayOfFile[b].lastModified() > 1800L) {
            arrayOfFile[b].delete();
          } 
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private static Drawable c(String paramString) {
    OutOfMemoryError outOfMemoryError2 = null;
    try {
      Drawable drawable = Drawable.createFromPath(paramString);
    } catch (OutOfMemoryError outOfMemoryError1) {
      Log.e(b, "Resutil fetchImage OutOfMemoryError:" + outOfMemoryError1.toString());
      outOfMemoryError1 = outOfMemoryError2;
    } 
    return (Drawable)outOfMemoryError1;
  }
  
  public static interface a {
    void a(h.a param1a);
    
    void a(i.b param1b);
  }
  
  public enum b {
    a, b;
  }
  
  static class c extends AsyncTask<Object, Integer, Drawable> {
    private Context a;
    
    private String b;
    
    private ImageView c;
    
    private i.b d;
    
    private boolean e;
    
    private i.a f;
    
    private Animation g;
    
    public c(Context param1Context, ImageView param1ImageView, String param1String, i.b param1b, boolean param1Boolean, i.a param1a, Animation param1Animation) {
      this.a = param1Context;
      this.b = param1String;
      this.f = param1a;
      this.d = param1b;
      this.e = param1Boolean;
      this.g = param1Animation;
      this.c = param1ImageView;
    }
    
    protected Drawable a(Object... param1VarArgs) {
      if (i.a)
        try {
          Thread.sleep(3000L);
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        }  
      i.a(this.a, this.b);
      Object[] arrayOfObject = null;
      try {
        File file = i.b(this.a, this.b);
        param1VarArgs = arrayOfObject;
        if (file != null) {
          param1VarArgs = arrayOfObject;
          if (file.exists())
            Drawable drawable = i.a(file.getAbsolutePath()); 
        } 
      } catch (IOException iOException) {
        Log.e(i.a(), iOException.toString());
        Object[] arrayOfObject1 = arrayOfObject;
      } 
    }
    
    protected void a(Drawable param1Drawable) {
      i.a(this.a, this.c, param1Drawable, this.e, this.f, this.g);
    }
    
    protected void onPreExecute() {
      super.onPreExecute();
      if (this.f != null)
        this.f.a(this.d); 
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */