package com.umeng.common.net;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import com.umeng.common.Log;
import java.io.File;

class d extends Handler {
  d(DownloadingService.a parama) {}
  
  public void handleMessage(Message paramMessage) {
    try {
      String str = paramMessage.getData().getString("filename");
      DownloadingService.a(DownloadingService.a.d(this.a)).cancel(DownloadingService.a.a(this.a));
      Log.c(DownloadingService.a(), "Cancel old notification....");
      Notification notification = new Notification();
      this(17301634, "下载完成，请点击安装", System.currentTimeMillis());
      Intent intent = new Intent();
      this("android.intent.action.VIEW");
      intent.addFlags(268435456);
      File file = new File();
      this(str);
      intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
      PendingIntent pendingIntent = PendingIntent.getActivity(DownloadingService.a.b(this.a), 0, intent, 134217728);
      notification.setLatestEventInfo(DownloadingService.a.b(this.a), (DownloadingService.a.c(this.a)).b, "下载完成，请点击安装", pendingIntent);
      notification.flags = 16;
      DownloadingService.a(DownloadingService.a.d(this.a), (NotificationManager)DownloadingService.a.d(this.a).getSystemService("notification"));
      DownloadingService.a(DownloadingService.a.d(this.a)).notify(DownloadingService.a.a(this.a), notification);
      Log.c(DownloadingService.a(), "Show new  notification....");
      boolean bool = DownloadingService.a(DownloadingService.a.b(this.a));
      Log.c(DownloadingService.a(), String.format("isAppOnForeground = %1$B", new Object[] { Boolean.valueOf(bool) }));
      if (bool) {
        DownloadingService.a(DownloadingService.a.d(this.a)).cancel(DownloadingService.a.a(this.a));
        DownloadingService.a.b(this.a).startActivity(intent);
      } 
      Log.a(DownloadingService.a(), String.format("%1$10s downloaded. Saved to: %2$s", new Object[] { (DownloadingService.a.c(this.a)).b, str }));
    } catch (Exception exception) {
      Log.b(DownloadingService.a(), "can not install. " + exception.getMessage());
      DownloadingService.a(DownloadingService.a.d(this.a)).cancel(DownloadingService.a.a(this.a));
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */