package com.umeng.common.net;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

class b implements ServiceConnection {
  b(a parama) {}
  
  public void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    Log.d(a.b(), "ServiceConnection.onServiceConnected");
    a.a(this.a, new Messenger(paramIBinder));
    if (a.a(this.a) != null)
      a.a(this.a).a(); 
    try {
      Message message = Message.obtain(null, 4);
      a.a a1 = new a.a();
      this(a.b(this.a), a.c(this.a), a.d(this.a));
      message.setData(a1.a());
      message.replyTo = this.a.a;
      a.e(this.a).send(message);
    } catch (RemoteException remoteException) {}
  }
  
  public void onServiceDisconnected(ComponentName paramComponentName) {
    Log.d(a.b(), "ServiceConnection.onServiceDisconnected");
    a.a(this.a, null);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */