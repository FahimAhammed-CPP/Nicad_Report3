package com.umeng.common.net;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.widget.RemoteViews;
import com.umeng.common.Log;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class DownloadingService extends Service {
  static final int a = 3;
  
  static final int b = 4;
  
  static final int c = 5;
  
  static final int d = 0;
  
  static final int e = 1;
  
  static final int f = 100;
  
  static final String g = "filename";
  
  private static final String j = DownloadingService.class.getName();
  
  Map<a.a, Messenger> h = new HashMap<a.a, Messenger>();
  
  final Messenger i = new Messenger(new b(this));
  
  private NotificationManager k;
  
  private void a(a.a parama) {
    Log.c(j, "startDownload([mComponentName:" + parama.a + " mTitle:" + parama.b + " mUrl:" + parama.c + "])");
    (new a(this, getApplicationContext(), parama)).start();
  }
  
  private static boolean b(Context paramContext) {
    List list = ((ActivityManager)paramContext.getSystemService("activity")).getRunningAppProcesses();
    if (list == null)
      return false; 
    String str = paramContext.getPackageName();
    Iterator<ActivityManager.RunningAppProcessInfo> iterator = list.iterator();
    while (true) {
      if (!iterator.hasNext())
        return false; 
      ActivityManager.RunningAppProcessInfo runningAppProcessInfo = iterator.next();
      if (runningAppProcessInfo.importance == 100 && runningAppProcessInfo.processName.equals(str))
        return true; 
    } 
  }
  
  private boolean b(a.a parama) {
    if (this.h == null)
      return false; 
    Iterator iterator = this.h.keySet().iterator();
    while (true) {
      if (!iterator.hasNext())
        return false; 
      if (((a.a)iterator.next()).c.equals(parama.c))
        return true; 
    } 
  }
  
  public IBinder onBind(Intent paramIntent) {
    Log.c(j, "onBind ");
    return this.i.getBinder();
  }
  
  public void onCreate() {
    super.onCreate();
    Log.c(j, "onCreate ");
    this.k = (NotificationManager)getSystemService("notification");
  }
  
  public void onDestroy() {
    try {
      c.a(getApplicationContext()).a(259200);
      c.a(getApplicationContext()).finalize();
    } catch (Exception exception) {
      Log.b(j, exception.getMessage());
    } 
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    Log.c(j, "onStart ");
    super.onStart(paramIntent, paramInt);
  }
  
  class a extends Thread {
    private static final long j = 30000L;
    
    private Context b;
    
    private String c;
    
    private Notification d;
    
    private int e;
    
    private int f = 0;
    
    private int g = -1;
    
    private int h = -1;
    
    private a.a i;
    
    private Handler k = new d(this);
    
    public a(DownloadingService this$0, Context param1Context, a.a param1a) {
      try {
        this.b = param1Context;
        this.i = param1a;
        if (com.umeng.common.b.b()) {
          this.c = Environment.getExternalStorageDirectory().getCanonicalPath();
          File file1 = new File();
          this(this.c);
          file1.mkdirs();
        } else {
          this.c = this.b.getFilesDir().getAbsolutePath();
        } 
        String str = this.c;
        StringBuilder stringBuilder = new StringBuilder();
        this(String.valueOf(str));
        this.c = stringBuilder.append("/download/.um/apk").toString();
        File file = new File();
        this(this.c);
        file.mkdirs();
        Notification notification2 = new Notification();
        this(17301633, "正在下载应用", 1L);
        this.d = notification2;
        RemoteViews remoteViews = new RemoteViews();
        this(this.b.getPackageName(), com.umeng.common.a.b.a(this.b));
        remoteViews.setProgressBar(com.umeng.common.a.a.c(this.b), 100, 0, false);
        remoteViews.setTextViewText(com.umeng.common.a.a.b(this.b), "0%");
        int i = com.umeng.common.a.a.d(this.b);
        stringBuilder = new StringBuilder();
        this("正在下载应用");
        remoteViews.setTextViewText(i, stringBuilder.append(this.i.b).toString());
        remoteViews.setTextViewText(com.umeng.common.a.a.a(this.b), "");
        remoteViews.setImageViewResource(com.umeng.common.a.a.e(this.b), 17301633);
        this.d.contentView = remoteViews;
        Notification notification1 = this.d;
        Context context = this.b;
        Intent intent = new Intent();
        this();
        notification1.contentIntent = PendingIntent.getActivity(context, 0, intent, 134217728);
        this.e = (int)System.currentTimeMillis();
        if (this.e < 0)
          this.e = -this.e; 
        DownloadingService.a(this$0).notify(this.e, this.d);
      } catch (Exception exception) {
        Log.c(DownloadingService.a(), exception.getMessage(), exception);
        DownloadingService.a(this$0).cancel(this.e);
      } 
    }
    
    private void a(Exception param1Exception) {
      Log.b(DownloadingService.a(), "can not install. " + param1Exception.getMessage());
      this.d.contentView.setTextViewText(com.umeng.common.a.a.d(this.b), String.valueOf(this.i.b) + " 下载失败，请检查网络。");
      DownloadingService.a(this.a).notify(this.e, this.d);
      DownloadingService.a(this.a).cancel(this.e);
    }
    
    private void a(boolean param1Boolean) {
      // Byte code:
      //   0: aconst_null
      //   1: astore_2
      //   2: aconst_null
      //   3: astore_3
      //   4: aconst_null
      //   5: astore #4
      //   7: aconst_null
      //   8: astore #5
      //   10: aconst_null
      //   11: astore #6
      //   13: aconst_null
      //   14: astore #7
      //   16: aload #7
      //   18: astore #8
      //   20: aload #4
      //   22: astore #9
      //   24: aload #5
      //   26: astore #10
      //   28: aload_2
      //   29: astore #11
      //   31: aload #6
      //   33: astore #12
      //   35: aload_3
      //   36: astore #13
      //   38: new java/lang/StringBuilder
      //   41: astore #14
      //   43: aload #7
      //   45: astore #8
      //   47: aload #4
      //   49: astore #9
      //   51: aload #5
      //   53: astore #10
      //   55: aload_2
      //   56: astore #11
      //   58: aload #6
      //   60: astore #12
      //   62: aload_3
      //   63: astore #13
      //   65: aload #14
      //   67: aload_0
      //   68: getfield i : Lcom/umeng/common/net/a$a;
      //   71: getfield c : Ljava/lang/String;
      //   74: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
      //   77: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   80: invokespecial <init> : (Ljava/lang/String;)V
      //   83: aload #7
      //   85: astore #8
      //   87: aload #4
      //   89: astore #9
      //   91: aload #5
      //   93: astore #10
      //   95: aload_2
      //   96: astore #11
      //   98: aload #6
      //   100: astore #12
      //   102: aload_3
      //   103: astore #13
      //   105: aload #14
      //   107: ldc '.apk.tmp'
      //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   112: invokevirtual toString : ()Ljava/lang/String;
      //   115: astore #14
      //   117: aload #7
      //   119: astore #8
      //   121: aload #4
      //   123: astore #9
      //   125: aload #5
      //   127: astore #10
      //   129: aload_2
      //   130: astore #11
      //   132: aload #6
      //   134: astore #12
      //   136: aload_3
      //   137: astore #13
      //   139: invokestatic b : ()Z
      //   142: ifeq -> 1397
      //   145: aload #7
      //   147: astore #8
      //   149: aload #4
      //   151: astore #9
      //   153: aload #5
      //   155: astore #10
      //   157: aload_2
      //   158: astore #11
      //   160: aload #6
      //   162: astore #12
      //   164: aload_3
      //   165: astore #13
      //   167: new java/io/File
      //   170: astore #15
      //   172: aload #7
      //   174: astore #8
      //   176: aload #4
      //   178: astore #9
      //   180: aload #5
      //   182: astore #10
      //   184: aload_2
      //   185: astore #11
      //   187: aload #6
      //   189: astore #12
      //   191: aload_3
      //   192: astore #13
      //   194: aload #15
      //   196: aload_0
      //   197: getfield c : Ljava/lang/String;
      //   200: aload #14
      //   202: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
      //   205: aload #7
      //   207: astore #8
      //   209: aload #4
      //   211: astore #9
      //   213: aload #5
      //   215: astore #10
      //   217: aload_2
      //   218: astore #11
      //   220: aload #6
      //   222: astore #12
      //   224: aload_3
      //   225: astore #13
      //   227: new java/io/FileOutputStream
      //   230: astore #14
      //   232: aload #7
      //   234: astore #8
      //   236: aload #4
      //   238: astore #9
      //   240: aload #5
      //   242: astore #10
      //   244: aload_2
      //   245: astore #11
      //   247: aload #6
      //   249: astore #12
      //   251: aload_3
      //   252: astore #13
      //   254: aload #14
      //   256: aload #15
      //   258: iconst_1
      //   259: invokespecial <init> : (Ljava/io/File;Z)V
      //   262: aload #15
      //   264: astore #5
      //   266: aload #14
      //   268: astore #7
      //   270: aload #7
      //   272: astore #8
      //   274: aload #4
      //   276: astore #9
      //   278: aload #7
      //   280: astore #10
      //   282: aload_2
      //   283: astore #11
      //   285: aload #7
      //   287: astore #12
      //   289: aload_3
      //   290: astore #13
      //   292: invokestatic a : ()Ljava/lang/String;
      //   295: ldc 'saveAPK: url = %1$15s\\t|\\tfilename = %2$15s'
      //   297: iconst_2
      //   298: anewarray java/lang/Object
      //   301: dup
      //   302: iconst_0
      //   303: aload_0
      //   304: getfield i : Lcom/umeng/common/net/a$a;
      //   307: getfield c : Ljava/lang/String;
      //   310: aastore
      //   311: dup
      //   312: iconst_1
      //   313: aload #5
      //   315: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   318: aastore
      //   319: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   322: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
      //   325: aload #7
      //   327: astore #8
      //   329: aload #4
      //   331: astore #9
      //   333: aload #7
      //   335: astore #10
      //   337: aload_2
      //   338: astore #11
      //   340: aload #7
      //   342: astore #12
      //   344: aload_3
      //   345: astore #13
      //   347: new java/net/URL
      //   350: astore #6
      //   352: aload #7
      //   354: astore #8
      //   356: aload #4
      //   358: astore #9
      //   360: aload #7
      //   362: astore #10
      //   364: aload_2
      //   365: astore #11
      //   367: aload #7
      //   369: astore #12
      //   371: aload_3
      //   372: astore #13
      //   374: aload #6
      //   376: aload_0
      //   377: getfield i : Lcom/umeng/common/net/a$a;
      //   380: getfield c : Ljava/lang/String;
      //   383: invokespecial <init> : (Ljava/lang/String;)V
      //   386: aload #7
      //   388: astore #8
      //   390: aload #4
      //   392: astore #9
      //   394: aload #7
      //   396: astore #10
      //   398: aload_2
      //   399: astore #11
      //   401: aload #7
      //   403: astore #12
      //   405: aload_3
      //   406: astore #13
      //   408: aload #6
      //   410: invokevirtual openConnection : ()Ljava/net/URLConnection;
      //   413: checkcast java/net/HttpURLConnection
      //   416: astore #6
      //   418: aload #7
      //   420: astore #8
      //   422: aload #4
      //   424: astore #9
      //   426: aload #7
      //   428: astore #10
      //   430: aload_2
      //   431: astore #11
      //   433: aload #7
      //   435: astore #12
      //   437: aload_3
      //   438: astore #13
      //   440: aload #6
      //   442: ldc_w 'GET'
      //   445: invokevirtual setRequestMethod : (Ljava/lang/String;)V
      //   448: aload #7
      //   450: astore #8
      //   452: aload #4
      //   454: astore #9
      //   456: aload #7
      //   458: astore #10
      //   460: aload_2
      //   461: astore #11
      //   463: aload #7
      //   465: astore #12
      //   467: aload_3
      //   468: astore #13
      //   470: aload #6
      //   472: ldc_w 'Accept-Encoding'
      //   475: ldc_w 'identity'
      //   478: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
      //   481: aload #7
      //   483: astore #8
      //   485: aload #4
      //   487: astore #9
      //   489: aload #7
      //   491: astore #10
      //   493: aload_2
      //   494: astore #11
      //   496: aload #7
      //   498: astore #12
      //   500: aload_3
      //   501: astore #13
      //   503: aload #6
      //   505: ldc_w 'Connection'
      //   508: ldc_w 'keep-alive'
      //   511: invokevirtual addRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
      //   514: aload #7
      //   516: astore #8
      //   518: aload #4
      //   520: astore #9
      //   522: aload #7
      //   524: astore #10
      //   526: aload_2
      //   527: astore #11
      //   529: aload #7
      //   531: astore #12
      //   533: aload_3
      //   534: astore #13
      //   536: aload #6
      //   538: sipush #5000
      //   541: invokevirtual setConnectTimeout : (I)V
      //   544: aload #7
      //   546: astore #8
      //   548: aload #4
      //   550: astore #9
      //   552: aload #7
      //   554: astore #10
      //   556: aload_2
      //   557: astore #11
      //   559: aload #7
      //   561: astore #12
      //   563: aload_3
      //   564: astore #13
      //   566: aload #6
      //   568: sipush #10000
      //   571: invokevirtual setReadTimeout : (I)V
      //   574: aload #7
      //   576: astore #8
      //   578: aload #4
      //   580: astore #9
      //   582: aload #7
      //   584: astore #10
      //   586: aload_2
      //   587: astore #11
      //   589: aload #7
      //   591: astore #12
      //   593: aload_3
      //   594: astore #13
      //   596: aload #5
      //   598: invokevirtual exists : ()Z
      //   601: ifeq -> 742
      //   604: aload #7
      //   606: astore #8
      //   608: aload #4
      //   610: astore #9
      //   612: aload #7
      //   614: astore #10
      //   616: aload_2
      //   617: astore #11
      //   619: aload #7
      //   621: astore #12
      //   623: aload_3
      //   624: astore #13
      //   626: aload #5
      //   628: invokevirtual length : ()J
      //   631: lconst_0
      //   632: lcmp
      //   633: ifle -> 742
      //   636: aload #7
      //   638: astore #8
      //   640: aload #4
      //   642: astore #9
      //   644: aload #7
      //   646: astore #10
      //   648: aload_2
      //   649: astore #11
      //   651: aload #7
      //   653: astore #12
      //   655: aload_3
      //   656: astore #13
      //   658: new java/lang/StringBuilder
      //   661: astore #14
      //   663: aload #7
      //   665: astore #8
      //   667: aload #4
      //   669: astore #9
      //   671: aload #7
      //   673: astore #10
      //   675: aload_2
      //   676: astore #11
      //   678: aload #7
      //   680: astore #12
      //   682: aload_3
      //   683: astore #13
      //   685: aload #14
      //   687: ldc_w 'bytes='
      //   690: invokespecial <init> : (Ljava/lang/String;)V
      //   693: aload #7
      //   695: astore #8
      //   697: aload #4
      //   699: astore #9
      //   701: aload #7
      //   703: astore #10
      //   705: aload_2
      //   706: astore #11
      //   708: aload #7
      //   710: astore #12
      //   712: aload_3
      //   713: astore #13
      //   715: aload #6
      //   717: ldc_w 'Range'
      //   720: aload #14
      //   722: aload #5
      //   724: invokevirtual length : ()J
      //   727: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   730: ldc_w '-'
      //   733: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   736: invokevirtual toString : ()Ljava/lang/String;
      //   739: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
      //   742: aload #7
      //   744: astore #8
      //   746: aload #4
      //   748: astore #9
      //   750: aload #7
      //   752: astore #10
      //   754: aload_2
      //   755: astore #11
      //   757: aload #7
      //   759: astore #12
      //   761: aload_3
      //   762: astore #13
      //   764: aload #6
      //   766: invokevirtual connect : ()V
      //   769: aload #7
      //   771: astore #8
      //   773: aload #4
      //   775: astore #9
      //   777: aload #7
      //   779: astore #10
      //   781: aload_2
      //   782: astore #11
      //   784: aload #7
      //   786: astore #12
      //   788: aload_3
      //   789: astore #13
      //   791: aload #6
      //   793: invokevirtual getInputStream : ()Ljava/io/InputStream;
      //   796: astore #4
      //   798: iload_1
      //   799: ifne -> 914
      //   802: aload #7
      //   804: astore #8
      //   806: aload #4
      //   808: astore #9
      //   810: aload #7
      //   812: astore #10
      //   814: aload #4
      //   816: astore #11
      //   818: aload #7
      //   820: astore #12
      //   822: aload #4
      //   824: astore #13
      //   826: aload_0
      //   827: iconst_0
      //   828: putfield g : I
      //   831: aload #7
      //   833: astore #8
      //   835: aload #4
      //   837: astore #9
      //   839: aload #7
      //   841: astore #10
      //   843: aload #4
      //   845: astore #11
      //   847: aload #7
      //   849: astore #12
      //   851: aload #4
      //   853: astore #13
      //   855: aload_0
      //   856: aload #6
      //   858: invokevirtual getContentLength : ()I
      //   861: putfield h : I
      //   864: aload #7
      //   866: astore #8
      //   868: aload #4
      //   870: astore #9
      //   872: aload #7
      //   874: astore #10
      //   876: aload #4
      //   878: astore #11
      //   880: aload #7
      //   882: astore #12
      //   884: aload #4
      //   886: astore #13
      //   888: invokestatic a : ()Ljava/lang/String;
      //   891: ldc_w 'getContentLength: %1$15s'
      //   894: iconst_1
      //   895: anewarray java/lang/Object
      //   898: dup
      //   899: iconst_0
      //   900: aload_0
      //   901: getfield h : I
      //   904: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   907: aastore
      //   908: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   911: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
      //   914: aload #7
      //   916: astore #8
      //   918: aload #4
      //   920: astore #9
      //   922: aload #7
      //   924: astore #10
      //   926: aload #4
      //   928: astore #11
      //   930: aload #7
      //   932: astore #12
      //   934: aload #4
      //   936: astore #13
      //   938: sipush #4096
      //   941: newarray byte
      //   943: astore_2
      //   944: iconst_0
      //   945: istore #16
      //   947: aload #7
      //   949: astore #8
      //   951: aload #4
      //   953: astore #9
      //   955: aload #7
      //   957: astore #10
      //   959: aload #4
      //   961: astore #11
      //   963: aload #7
      //   965: astore #12
      //   967: aload #4
      //   969: astore #13
      //   971: invokestatic a : ()Ljava/lang/String;
      //   974: astore_3
      //   975: aload #7
      //   977: astore #8
      //   979: aload #4
      //   981: astore #9
      //   983: aload #7
      //   985: astore #10
      //   987: aload #4
      //   989: astore #11
      //   991: aload #7
      //   993: astore #12
      //   995: aload #4
      //   997: astore #13
      //   999: new java/lang/StringBuilder
      //   1002: astore #6
      //   1004: aload #7
      //   1006: astore #8
      //   1008: aload #4
      //   1010: astore #9
      //   1012: aload #7
      //   1014: astore #10
      //   1016: aload #4
      //   1018: astore #11
      //   1020: aload #7
      //   1022: astore #12
      //   1024: aload #4
      //   1026: astore #13
      //   1028: aload #6
      //   1030: aload_0
      //   1031: getfield i : Lcom/umeng/common/net/a$a;
      //   1034: getfield b : Ljava/lang/String;
      //   1037: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   1040: invokespecial <init> : (Ljava/lang/String;)V
      //   1043: aload #7
      //   1045: astore #8
      //   1047: aload #4
      //   1049: astore #9
      //   1051: aload #7
      //   1053: astore #10
      //   1055: aload #4
      //   1057: astore #11
      //   1059: aload #7
      //   1061: astore #12
      //   1063: aload #4
      //   1065: astore #13
      //   1067: aload_3
      //   1068: aload #6
      //   1070: ldc_w 'saveAPK getContentLength '
      //   1073: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1076: aload_0
      //   1077: getfield h : I
      //   1080: invokestatic valueOf : (I)Ljava/lang/String;
      //   1083: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1086: invokevirtual toString : ()Ljava/lang/String;
      //   1089: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
      //   1092: aload #7
      //   1094: astore #8
      //   1096: aload #4
      //   1098: astore #9
      //   1100: aload #7
      //   1102: astore #10
      //   1104: aload #4
      //   1106: astore #11
      //   1108: aload #7
      //   1110: astore #12
      //   1112: aload #4
      //   1114: astore #13
      //   1116: aload_0
      //   1117: getfield b : Landroid/content/Context;
      //   1120: invokestatic a : (Landroid/content/Context;)Lcom/umeng/common/net/c;
      //   1123: aload_0
      //   1124: getfield i : Lcom/umeng/common/net/a$a;
      //   1127: getfield a : Ljava/lang/String;
      //   1130: aload_0
      //   1131: getfield i : Lcom/umeng/common/net/a$a;
      //   1134: getfield c : Ljava/lang/String;
      //   1137: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Z
      //   1140: pop
      //   1141: aload #7
      //   1143: astore #8
      //   1145: aload #4
      //   1147: astore #9
      //   1149: aload #7
      //   1151: astore #10
      //   1153: aload #4
      //   1155: astore #11
      //   1157: aload #7
      //   1159: astore #12
      //   1161: aload #4
      //   1163: astore #13
      //   1165: aload #4
      //   1167: aload_2
      //   1168: invokevirtual read : ([B)I
      //   1171: istore #17
      //   1173: iload #17
      //   1175: ifgt -> 1505
      //   1178: iconst_1
      //   1179: istore #16
      //   1181: aload #7
      //   1183: astore #8
      //   1185: aload #4
      //   1187: astore #9
      //   1189: aload #7
      //   1191: astore #10
      //   1193: aload #4
      //   1195: astore #11
      //   1197: aload #7
      //   1199: astore #12
      //   1201: aload #4
      //   1203: astore #13
      //   1205: aload #4
      //   1207: invokevirtual close : ()V
      //   1210: aload #7
      //   1212: astore #8
      //   1214: aload #4
      //   1216: astore #9
      //   1218: aload #7
      //   1220: astore #10
      //   1222: aload #4
      //   1224: astore #11
      //   1226: aload #7
      //   1228: astore #12
      //   1230: aload #4
      //   1232: astore #13
      //   1234: aload #7
      //   1236: invokevirtual close : ()V
      //   1239: iload #16
      //   1241: ifne -> 2411
      //   1244: aload #7
      //   1246: astore #8
      //   1248: aload #4
      //   1250: astore #9
      //   1252: aload #7
      //   1254: astore #10
      //   1256: aload #4
      //   1258: astore #11
      //   1260: aload #7
      //   1262: astore #12
      //   1264: aload #4
      //   1266: astore #13
      //   1268: aload_0
      //   1269: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   1272: invokestatic a : (Lcom/umeng/common/net/DownloadingService;)Landroid/app/NotificationManager;
      //   1275: aload_0
      //   1276: getfield e : I
      //   1279: invokevirtual cancel : (I)V
      //   1282: aload #7
      //   1284: astore #8
      //   1286: aload #4
      //   1288: astore #9
      //   1290: aload #7
      //   1292: astore #10
      //   1294: aload #4
      //   1296: astore #11
      //   1298: aload #7
      //   1300: astore #12
      //   1302: aload #4
      //   1304: astore #13
      //   1306: aload_0
      //   1307: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   1310: getfield h : Ljava/util/Map;
      //   1313: aload_0
      //   1314: getfield i : Lcom/umeng/common/net/a$a;
      //   1317: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   1322: checkcast android/os/Messenger
      //   1325: aconst_null
      //   1326: iconst_5
      //   1327: iconst_0
      //   1328: iconst_0
      //   1329: invokestatic obtain : (Landroid/os/Handler;III)Landroid/os/Message;
      //   1332: invokevirtual send : (Landroid/os/Message;)V
      //   1335: aload #7
      //   1337: astore #8
      //   1339: aload #4
      //   1341: astore #9
      //   1343: aload #7
      //   1345: astore #10
      //   1347: aload #4
      //   1349: astore #11
      //   1351: aload #7
      //   1353: astore #12
      //   1355: aload #4
      //   1357: astore #13
      //   1359: aload_0
      //   1360: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   1363: getfield h : Ljava/util/Map;
      //   1366: aload_0
      //   1367: getfield i : Lcom/umeng/common/net/a$a;
      //   1370: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   1375: pop
      //   1376: aload #4
      //   1378: ifnull -> 1386
      //   1381: aload #4
      //   1383: invokevirtual close : ()V
      //   1386: aload #7
      //   1388: ifnull -> 1396
      //   1391: aload #7
      //   1393: invokevirtual close : ()V
      //   1396: return
      //   1397: aload #7
      //   1399: astore #8
      //   1401: aload #4
      //   1403: astore #9
      //   1405: aload #5
      //   1407: astore #10
      //   1409: aload_2
      //   1410: astore #11
      //   1412: aload #6
      //   1414: astore #12
      //   1416: aload_3
      //   1417: astore #13
      //   1419: aload_0
      //   1420: aload_0
      //   1421: getfield b : Landroid/content/Context;
      //   1424: invokevirtual getFilesDir : ()Ljava/io/File;
      //   1427: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   1430: putfield c : Ljava/lang/String;
      //   1433: aload #7
      //   1435: astore #8
      //   1437: aload #4
      //   1439: astore #9
      //   1441: aload #5
      //   1443: astore #10
      //   1445: aload_2
      //   1446: astore #11
      //   1448: aload #6
      //   1450: astore #12
      //   1452: aload_3
      //   1453: astore #13
      //   1455: aload_0
      //   1456: getfield b : Landroid/content/Context;
      //   1459: aload #14
      //   1461: ldc_w 32771
      //   1464: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
      //   1467: astore #7
      //   1469: aload #7
      //   1471: astore #8
      //   1473: aload #4
      //   1475: astore #9
      //   1477: aload #7
      //   1479: astore #10
      //   1481: aload_2
      //   1482: astore #11
      //   1484: aload #7
      //   1486: astore #12
      //   1488: aload_3
      //   1489: astore #13
      //   1491: aload_0
      //   1492: getfield b : Landroid/content/Context;
      //   1495: aload #14
      //   1497: invokevirtual getFileStreamPath : (Ljava/lang/String;)Ljava/io/File;
      //   1500: astore #5
      //   1502: goto -> 270
      //   1505: aload #7
      //   1507: astore #8
      //   1509: aload #4
      //   1511: astore #9
      //   1513: aload #7
      //   1515: astore #10
      //   1517: aload #4
      //   1519: astore #11
      //   1521: aload #7
      //   1523: astore #12
      //   1525: aload #4
      //   1527: astore #13
      //   1529: aload #7
      //   1531: aload_2
      //   1532: iconst_0
      //   1533: iload #17
      //   1535: invokevirtual write : ([BII)V
      //   1538: aload #7
      //   1540: astore #8
      //   1542: aload #4
      //   1544: astore #9
      //   1546: aload #7
      //   1548: astore #10
      //   1550: aload #4
      //   1552: astore #11
      //   1554: aload #7
      //   1556: astore #12
      //   1558: aload #4
      //   1560: astore #13
      //   1562: aload_0
      //   1563: iload #17
      //   1565: aload_0
      //   1566: getfield g : I
      //   1569: iadd
      //   1570: putfield g : I
      //   1573: iload #16
      //   1575: bipush #50
      //   1577: irem
      //   1578: ifne -> 2137
      //   1581: aload #7
      //   1583: astore #8
      //   1585: aload #4
      //   1587: astore #9
      //   1589: aload #7
      //   1591: astore #10
      //   1593: aload #4
      //   1595: astore #11
      //   1597: aload #7
      //   1599: astore #12
      //   1601: aload #4
      //   1603: astore #13
      //   1605: aload_0
      //   1606: getfield b : Landroid/content/Context;
      //   1609: invokestatic m : (Landroid/content/Context;)Z
      //   1612: ifne -> 1621
      //   1615: iconst_0
      //   1616: istore #16
      //   1618: goto -> 1181
      //   1621: aload #7
      //   1623: astore #8
      //   1625: aload #4
      //   1627: astore #9
      //   1629: aload #7
      //   1631: astore #10
      //   1633: aload #4
      //   1635: astore #11
      //   1637: aload #7
      //   1639: astore #12
      //   1641: aload #4
      //   1643: astore #13
      //   1645: aload_0
      //   1646: getfield g : I
      //   1649: i2f
      //   1650: ldc_w 100.0
      //   1653: fmul
      //   1654: aload_0
      //   1655: getfield h : I
      //   1658: i2f
      //   1659: fdiv
      //   1660: f2i
      //   1661: istore #18
      //   1663: aload #7
      //   1665: astore #8
      //   1667: aload #4
      //   1669: astore #9
      //   1671: aload #7
      //   1673: astore #10
      //   1675: aload #4
      //   1677: astore #11
      //   1679: aload #7
      //   1681: astore #12
      //   1683: aload #4
      //   1685: astore #13
      //   1687: aload_0
      //   1688: getfield d : Landroid/app/Notification;
      //   1691: getfield contentView : Landroid/widget/RemoteViews;
      //   1694: aload_0
      //   1695: getfield b : Landroid/content/Context;
      //   1698: invokestatic c : (Landroid/content/Context;)I
      //   1701: bipush #100
      //   1703: iload #18
      //   1705: iconst_0
      //   1706: invokevirtual setProgressBar : (IIIZ)V
      //   1709: aload #7
      //   1711: astore #8
      //   1713: aload #4
      //   1715: astore #9
      //   1717: aload #7
      //   1719: astore #10
      //   1721: aload #4
      //   1723: astore #11
      //   1725: aload #7
      //   1727: astore #12
      //   1729: aload #4
      //   1731: astore #13
      //   1733: aload_0
      //   1734: getfield d : Landroid/app/Notification;
      //   1737: getfield contentView : Landroid/widget/RemoteViews;
      //   1740: astore #6
      //   1742: aload #7
      //   1744: astore #8
      //   1746: aload #4
      //   1748: astore #9
      //   1750: aload #7
      //   1752: astore #10
      //   1754: aload #4
      //   1756: astore #11
      //   1758: aload #7
      //   1760: astore #12
      //   1762: aload #4
      //   1764: astore #13
      //   1766: aload_0
      //   1767: getfield b : Landroid/content/Context;
      //   1770: invokestatic b : (Landroid/content/Context;)I
      //   1773: istore #17
      //   1775: aload #7
      //   1777: astore #8
      //   1779: aload #4
      //   1781: astore #9
      //   1783: aload #7
      //   1785: astore #10
      //   1787: aload #4
      //   1789: astore #11
      //   1791: aload #7
      //   1793: astore #12
      //   1795: aload #4
      //   1797: astore #13
      //   1799: new java/lang/StringBuilder
      //   1802: astore_3
      //   1803: aload #7
      //   1805: astore #8
      //   1807: aload #4
      //   1809: astore #9
      //   1811: aload #7
      //   1813: astore #10
      //   1815: aload #4
      //   1817: astore #11
      //   1819: aload #7
      //   1821: astore #12
      //   1823: aload #4
      //   1825: astore #13
      //   1827: aload_3
      //   1828: iload #18
      //   1830: invokestatic valueOf : (I)Ljava/lang/String;
      //   1833: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   1836: invokespecial <init> : (Ljava/lang/String;)V
      //   1839: aload #7
      //   1841: astore #8
      //   1843: aload #4
      //   1845: astore #9
      //   1847: aload #7
      //   1849: astore #10
      //   1851: aload #4
      //   1853: astore #11
      //   1855: aload #7
      //   1857: astore #12
      //   1859: aload #4
      //   1861: astore #13
      //   1863: aload #6
      //   1865: iload #17
      //   1867: aload_3
      //   1868: ldc_w '%'
      //   1871: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   1874: invokevirtual toString : ()Ljava/lang/String;
      //   1877: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   1880: aload #7
      //   1882: astore #8
      //   1884: aload #4
      //   1886: astore #9
      //   1888: aload #7
      //   1890: astore #10
      //   1892: aload #4
      //   1894: astore #11
      //   1896: aload #7
      //   1898: astore #12
      //   1900: aload #4
      //   1902: astore #13
      //   1904: aload_0
      //   1905: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   1908: invokestatic a : (Lcom/umeng/common/net/DownloadingService;)Landroid/app/NotificationManager;
      //   1911: aload_0
      //   1912: getfield e : I
      //   1915: aload_0
      //   1916: getfield d : Landroid/app/Notification;
      //   1919: invokevirtual notify : (ILandroid/app/Notification;)V
      //   1922: aload #7
      //   1924: astore #8
      //   1926: aload #4
      //   1928: astore #9
      //   1930: aload #7
      //   1932: astore #10
      //   1934: aload #4
      //   1936: astore #11
      //   1938: aload #7
      //   1940: astore #12
      //   1942: aload #4
      //   1944: astore #13
      //   1946: invokestatic a : ()Ljava/lang/String;
      //   1949: ldc_w '%3$10s Notification: mNotificationId = %1$15s\\t|\\tprogress = %2$15s'
      //   1952: iconst_3
      //   1953: anewarray java/lang/Object
      //   1956: dup
      //   1957: iconst_0
      //   1958: aload_0
      //   1959: getfield e : I
      //   1962: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   1965: aastore
      //   1966: dup
      //   1967: iconst_1
      //   1968: iload #18
      //   1970: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   1973: aastore
      //   1974: dup
      //   1975: iconst_2
      //   1976: aload_0
      //   1977: getfield i : Lcom/umeng/common/net/a$a;
      //   1980: getfield b : Ljava/lang/String;
      //   1983: aastore
      //   1984: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   1987: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
      //   1990: aload #7
      //   1992: astore #8
      //   1994: aload #4
      //   1996: astore #9
      //   1998: aload #7
      //   2000: astore #10
      //   2002: aload #4
      //   2004: astore #11
      //   2006: aload #7
      //   2008: astore #12
      //   2010: aload #4
      //   2012: astore #13
      //   2014: aload_0
      //   2015: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   2018: getfield h : Ljava/util/Map;
      //   2021: aload_0
      //   2022: getfield i : Lcom/umeng/common/net/a$a;
      //   2025: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   2030: ifnull -> 2087
      //   2033: aload #7
      //   2035: astore #8
      //   2037: aload #4
      //   2039: astore #9
      //   2041: aload #7
      //   2043: astore #10
      //   2045: aload #4
      //   2047: astore #11
      //   2049: aload #7
      //   2051: astore #12
      //   2053: aload #4
      //   2055: astore #13
      //   2057: aload_0
      //   2058: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   2061: getfield h : Ljava/util/Map;
      //   2064: aload_0
      //   2065: getfield i : Lcom/umeng/common/net/a$a;
      //   2068: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   2073: checkcast android/os/Messenger
      //   2076: aconst_null
      //   2077: iconst_3
      //   2078: iload #18
      //   2080: iconst_0
      //   2081: invokestatic obtain : (Landroid/os/Handler;III)Landroid/os/Message;
      //   2084: invokevirtual send : (Landroid/os/Message;)V
      //   2087: aload #7
      //   2089: astore #8
      //   2091: aload #4
      //   2093: astore #9
      //   2095: aload #7
      //   2097: astore #10
      //   2099: aload #4
      //   2101: astore #11
      //   2103: aload #7
      //   2105: astore #12
      //   2107: aload #4
      //   2109: astore #13
      //   2111: aload_0
      //   2112: getfield b : Landroid/content/Context;
      //   2115: invokestatic a : (Landroid/content/Context;)Lcom/umeng/common/net/c;
      //   2118: aload_0
      //   2119: getfield i : Lcom/umeng/common/net/a$a;
      //   2122: getfield a : Ljava/lang/String;
      //   2125: aload_0
      //   2126: getfield i : Lcom/umeng/common/net/a$a;
      //   2129: getfield c : Ljava/lang/String;
      //   2132: iload #18
      //   2134: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;I)V
      //   2137: iinc #16, 1
      //   2140: goto -> 1141
      //   2143: astore #10
      //   2145: aload #7
      //   2147: astore #8
      //   2149: aload #4
      //   2151: astore #9
      //   2153: aload #7
      //   2155: astore #10
      //   2157: aload #4
      //   2159: astore #11
      //   2161: aload #7
      //   2163: astore #12
      //   2165: aload #4
      //   2167: astore #13
      //   2169: invokestatic a : ()Ljava/lang/String;
      //   2172: ldc_w 'Service Client for downloading %1$15s is dead. Removing messenger from the service'
      //   2175: iconst_1
      //   2176: anewarray java/lang/Object
      //   2179: dup
      //   2180: iconst_0
      //   2181: aload_0
      //   2182: getfield i : Lcom/umeng/common/net/a$a;
      //   2185: getfield b : Ljava/lang/String;
      //   2188: aastore
      //   2189: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
      //   2192: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
      //   2195: aload #7
      //   2197: astore #8
      //   2199: aload #4
      //   2201: astore #9
      //   2203: aload #7
      //   2205: astore #10
      //   2207: aload #4
      //   2209: astore #11
      //   2211: aload #7
      //   2213: astore #12
      //   2215: aload #4
      //   2217: astore #13
      //   2219: aload_0
      //   2220: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   2223: getfield h : Ljava/util/Map;
      //   2226: aload_0
      //   2227: getfield i : Lcom/umeng/common/net/a$a;
      //   2230: aconst_null
      //   2231: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   2236: pop
      //   2237: goto -> 2087
      //   2240: astore #7
      //   2242: aload #8
      //   2244: astore #10
      //   2246: aload #9
      //   2248: astore #11
      //   2250: invokestatic a : ()Ljava/lang/String;
      //   2253: aload #7
      //   2255: invokevirtual getMessage : ()Ljava/lang/String;
      //   2258: aload #7
      //   2260: invokestatic c : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
      //   2263: aload #8
      //   2265: astore #10
      //   2267: aload #9
      //   2269: astore #11
      //   2271: aload_0
      //   2272: getfield f : I
      //   2275: iconst_1
      //   2276: iadd
      //   2277: istore #16
      //   2279: aload #8
      //   2281: astore #10
      //   2283: aload #9
      //   2285: astore #11
      //   2287: aload_0
      //   2288: iload #16
      //   2290: putfield f : I
      //   2293: iload #16
      //   2295: iconst_3
      //   2296: if_icmple -> 3284
      //   2299: aload #8
      //   2301: astore #10
      //   2303: aload #9
      //   2305: astore #11
      //   2307: aload_0
      //   2308: aload #7
      //   2310: invokespecial a : (Ljava/lang/Exception;)V
      //   2313: aload #9
      //   2315: ifnull -> 2323
      //   2318: aload #9
      //   2320: invokevirtual close : ()V
      //   2323: aload #8
      //   2325: ifnull -> 1396
      //   2328: aload #8
      //   2330: invokevirtual close : ()V
      //   2333: goto -> 1396
      //   2336: astore #10
      //   2338: aload #10
      //   2340: invokevirtual printStackTrace : ()V
      //   2343: goto -> 1396
      //   2346: astore #10
      //   2348: aload #10
      //   2350: invokevirtual printStackTrace : ()V
      //   2353: aload #7
      //   2355: ifnull -> 1396
      //   2358: aload #7
      //   2360: invokevirtual close : ()V
      //   2363: goto -> 1396
      //   2366: astore #10
      //   2368: aload #10
      //   2370: invokevirtual printStackTrace : ()V
      //   2373: goto -> 1396
      //   2376: astore #10
      //   2378: aload #7
      //   2380: ifnull -> 2388
      //   2383: aload #7
      //   2385: invokevirtual close : ()V
      //   2388: aload #10
      //   2390: athrow
      //   2391: astore #7
      //   2393: aload #7
      //   2395: invokevirtual printStackTrace : ()V
      //   2398: goto -> 2388
      //   2401: astore #10
      //   2403: aload #10
      //   2405: invokevirtual printStackTrace : ()V
      //   2408: goto -> 1396
      //   2411: aload #7
      //   2413: astore #8
      //   2415: aload #4
      //   2417: astore #9
      //   2419: aload #7
      //   2421: astore #10
      //   2423: aload #4
      //   2425: astore #11
      //   2427: aload #7
      //   2429: astore #12
      //   2431: aload #4
      //   2433: astore #13
      //   2435: aload_0
      //   2436: getfield d : Landroid/app/Notification;
      //   2439: getfield contentView : Landroid/widget/RemoteViews;
      //   2442: astore_3
      //   2443: aload #7
      //   2445: astore #8
      //   2447: aload #4
      //   2449: astore #9
      //   2451: aload #7
      //   2453: astore #10
      //   2455: aload #4
      //   2457: astore #11
      //   2459: aload #7
      //   2461: astore #12
      //   2463: aload #4
      //   2465: astore #13
      //   2467: aload_0
      //   2468: getfield b : Landroid/content/Context;
      //   2471: invokestatic b : (Landroid/content/Context;)I
      //   2474: istore #16
      //   2476: aload #7
      //   2478: astore #8
      //   2480: aload #4
      //   2482: astore #9
      //   2484: aload #7
      //   2486: astore #10
      //   2488: aload #4
      //   2490: astore #11
      //   2492: aload #7
      //   2494: astore #12
      //   2496: aload #4
      //   2498: astore #13
      //   2500: new java/lang/StringBuilder
      //   2503: astore_2
      //   2504: aload #7
      //   2506: astore #8
      //   2508: aload #4
      //   2510: astore #9
      //   2512: aload #7
      //   2514: astore #10
      //   2516: aload #4
      //   2518: astore #11
      //   2520: aload #7
      //   2522: astore #12
      //   2524: aload #4
      //   2526: astore #13
      //   2528: aload_2
      //   2529: bipush #100
      //   2531: invokestatic valueOf : (I)Ljava/lang/String;
      //   2534: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
      //   2537: invokespecial <init> : (Ljava/lang/String;)V
      //   2540: aload #7
      //   2542: astore #8
      //   2544: aload #4
      //   2546: astore #9
      //   2548: aload #7
      //   2550: astore #10
      //   2552: aload #4
      //   2554: astore #11
      //   2556: aload #7
      //   2558: astore #12
      //   2560: aload #4
      //   2562: astore #13
      //   2564: aload_3
      //   2565: iload #16
      //   2567: aload_2
      //   2568: ldc_w '%'
      //   2571: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   2574: invokevirtual toString : ()Ljava/lang/String;
      //   2577: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   2580: aload #7
      //   2582: astore #8
      //   2584: aload #4
      //   2586: astore #9
      //   2588: aload #7
      //   2590: astore #10
      //   2592: aload #4
      //   2594: astore #11
      //   2596: aload #7
      //   2598: astore #12
      //   2600: aload #4
      //   2602: astore #13
      //   2604: aload_0
      //   2605: getfield b : Landroid/content/Context;
      //   2608: invokestatic a : (Landroid/content/Context;)Lcom/umeng/common/net/c;
      //   2611: aload_0
      //   2612: getfield i : Lcom/umeng/common/net/a$a;
      //   2615: getfield a : Ljava/lang/String;
      //   2618: aload_0
      //   2619: getfield i : Lcom/umeng/common/net/a$a;
      //   2622: getfield c : Ljava/lang/String;
      //   2625: bipush #100
      //   2627: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;I)V
      //   2630: aload #7
      //   2632: astore #8
      //   2634: aload #4
      //   2636: astore #9
      //   2638: aload #7
      //   2640: astore #10
      //   2642: aload #4
      //   2644: astore #11
      //   2646: aload #7
      //   2648: astore #12
      //   2650: aload #4
      //   2652: astore #13
      //   2654: new java/io/File
      //   2657: astore_2
      //   2658: aload #7
      //   2660: astore #8
      //   2662: aload #4
      //   2664: astore #9
      //   2666: aload #7
      //   2668: astore #10
      //   2670: aload #4
      //   2672: astore #11
      //   2674: aload #7
      //   2676: astore #12
      //   2678: aload #4
      //   2680: astore #13
      //   2682: aload_2
      //   2683: aload #5
      //   2685: invokevirtual getParent : ()Ljava/lang/String;
      //   2688: aload #5
      //   2690: invokevirtual getName : ()Ljava/lang/String;
      //   2693: ldc_w '.tmp'
      //   2696: ldc ''
      //   2698: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
      //   2701: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
      //   2704: aload #7
      //   2706: astore #8
      //   2708: aload #4
      //   2710: astore #9
      //   2712: aload #7
      //   2714: astore #10
      //   2716: aload #4
      //   2718: astore #11
      //   2720: aload #7
      //   2722: astore #12
      //   2724: aload #4
      //   2726: astore #13
      //   2728: aload #5
      //   2730: aload_2
      //   2731: invokevirtual renameTo : (Ljava/io/File;)Z
      //   2734: pop
      //   2735: aload #7
      //   2737: astore #8
      //   2739: aload #4
      //   2741: astore #9
      //   2743: aload #7
      //   2745: astore #10
      //   2747: aload #4
      //   2749: astore #11
      //   2751: aload #7
      //   2753: astore #12
      //   2755: aload #4
      //   2757: astore #13
      //   2759: aload_2
      //   2760: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   2763: astore_2
      //   2764: aload #7
      //   2766: astore #8
      //   2768: aload #4
      //   2770: astore #9
      //   2772: aload #7
      //   2774: astore #10
      //   2776: aload #4
      //   2778: astore #11
      //   2780: aload #7
      //   2782: astore #12
      //   2784: aload #4
      //   2786: astore #13
      //   2788: new android/os/Bundle
      //   2791: astore #5
      //   2793: aload #7
      //   2795: astore #8
      //   2797: aload #4
      //   2799: astore #9
      //   2801: aload #7
      //   2803: astore #10
      //   2805: aload #4
      //   2807: astore #11
      //   2809: aload #7
      //   2811: astore #12
      //   2813: aload #4
      //   2815: astore #13
      //   2817: aload #5
      //   2819: invokespecial <init> : ()V
      //   2822: aload #7
      //   2824: astore #8
      //   2826: aload #4
      //   2828: astore #9
      //   2830: aload #7
      //   2832: astore #10
      //   2834: aload #4
      //   2836: astore #11
      //   2838: aload #7
      //   2840: astore #12
      //   2842: aload #4
      //   2844: astore #13
      //   2846: aload #5
      //   2848: ldc_w 'filename'
      //   2851: aload_2
      //   2852: invokevirtual putString : (Ljava/lang/String;Ljava/lang/String;)V
      //   2855: aload #7
      //   2857: astore #8
      //   2859: aload #4
      //   2861: astore #9
      //   2863: aload #7
      //   2865: astore #10
      //   2867: aload #4
      //   2869: astore #11
      //   2871: aload #7
      //   2873: astore #12
      //   2875: aload #4
      //   2877: astore #13
      //   2879: invokestatic obtain : ()Landroid/os/Message;
      //   2882: astore_2
      //   2883: aload #7
      //   2885: astore #8
      //   2887: aload #4
      //   2889: astore #9
      //   2891: aload #7
      //   2893: astore #10
      //   2895: aload #4
      //   2897: astore #11
      //   2899: aload #7
      //   2901: astore #12
      //   2903: aload #4
      //   2905: astore #13
      //   2907: aload_2
      //   2908: iconst_5
      //   2909: putfield what : I
      //   2912: aload #7
      //   2914: astore #8
      //   2916: aload #4
      //   2918: astore #9
      //   2920: aload #7
      //   2922: astore #10
      //   2924: aload #4
      //   2926: astore #11
      //   2928: aload #7
      //   2930: astore #12
      //   2932: aload #4
      //   2934: astore #13
      //   2936: aload_2
      //   2937: iconst_1
      //   2938: putfield arg1 : I
      //   2941: aload #7
      //   2943: astore #8
      //   2945: aload #4
      //   2947: astore #9
      //   2949: aload #7
      //   2951: astore #10
      //   2953: aload #4
      //   2955: astore #11
      //   2957: aload #7
      //   2959: astore #12
      //   2961: aload #4
      //   2963: astore #13
      //   2965: aload_2
      //   2966: aload #5
      //   2968: invokevirtual setData : (Landroid/os/Bundle;)V
      //   2971: aload #7
      //   2973: astore #8
      //   2975: aload #4
      //   2977: astore #9
      //   2979: aload #7
      //   2981: astore #10
      //   2983: aload #4
      //   2985: astore #11
      //   2987: aload #7
      //   2989: astore #12
      //   2991: aload #4
      //   2993: astore #13
      //   2995: aload_0
      //   2996: getfield k : Landroid/os/Handler;
      //   2999: aload_2
      //   3000: invokevirtual sendMessage : (Landroid/os/Message;)Z
      //   3003: pop
      //   3004: aload #7
      //   3006: astore #8
      //   3008: aload #4
      //   3010: astore #9
      //   3012: aload #7
      //   3014: astore #10
      //   3016: aload #4
      //   3018: astore #11
      //   3020: aload #7
      //   3022: astore #12
      //   3024: aload #4
      //   3026: astore #13
      //   3028: invokestatic obtain : ()Landroid/os/Message;
      //   3031: astore_2
      //   3032: aload #7
      //   3034: astore #8
      //   3036: aload #4
      //   3038: astore #9
      //   3040: aload #7
      //   3042: astore #10
      //   3044: aload #4
      //   3046: astore #11
      //   3048: aload #7
      //   3050: astore #12
      //   3052: aload #4
      //   3054: astore #13
      //   3056: aload_2
      //   3057: iconst_5
      //   3058: putfield what : I
      //   3061: aload #7
      //   3063: astore #8
      //   3065: aload #4
      //   3067: astore #9
      //   3069: aload #7
      //   3071: astore #10
      //   3073: aload #4
      //   3075: astore #11
      //   3077: aload #7
      //   3079: astore #12
      //   3081: aload #4
      //   3083: astore #13
      //   3085: aload_2
      //   3086: iconst_1
      //   3087: putfield arg1 : I
      //   3090: aload #7
      //   3092: astore #8
      //   3094: aload #4
      //   3096: astore #9
      //   3098: aload #7
      //   3100: astore #10
      //   3102: aload #4
      //   3104: astore #11
      //   3106: aload #7
      //   3108: astore #12
      //   3110: aload #4
      //   3112: astore #13
      //   3114: aload_2
      //   3115: aload #5
      //   3117: invokevirtual setData : (Landroid/os/Bundle;)V
      //   3120: aload #7
      //   3122: astore #8
      //   3124: aload #4
      //   3126: astore #9
      //   3128: aload #7
      //   3130: astore #10
      //   3132: aload #4
      //   3134: astore #11
      //   3136: aload #7
      //   3138: astore #12
      //   3140: aload #4
      //   3142: astore #13
      //   3144: aload_0
      //   3145: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   3148: getfield h : Ljava/util/Map;
      //   3151: aload_0
      //   3152: getfield i : Lcom/umeng/common/net/a$a;
      //   3155: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   3160: ifnull -> 3210
      //   3163: aload #7
      //   3165: astore #8
      //   3167: aload #4
      //   3169: astore #9
      //   3171: aload #7
      //   3173: astore #10
      //   3175: aload #4
      //   3177: astore #11
      //   3179: aload #7
      //   3181: astore #12
      //   3183: aload #4
      //   3185: astore #13
      //   3187: aload_0
      //   3188: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   3191: getfield h : Ljava/util/Map;
      //   3194: aload_0
      //   3195: getfield i : Lcom/umeng/common/net/a$a;
      //   3198: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   3203: checkcast android/os/Messenger
      //   3206: aload_2
      //   3207: invokevirtual send : (Landroid/os/Message;)V
      //   3210: aload #7
      //   3212: astore #8
      //   3214: aload #4
      //   3216: astore #9
      //   3218: aload #7
      //   3220: astore #10
      //   3222: aload #4
      //   3224: astore #11
      //   3226: aload #7
      //   3228: astore #12
      //   3230: aload #4
      //   3232: astore #13
      //   3234: aload_0
      //   3235: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   3238: getfield h : Ljava/util/Map;
      //   3241: aload_0
      //   3242: getfield i : Lcom/umeng/common/net/a$a;
      //   3245: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   3250: pop
      //   3251: aload #4
      //   3253: ifnull -> 3261
      //   3256: aload #4
      //   3258: invokevirtual close : ()V
      //   3261: aload #7
      //   3263: ifnull -> 1396
      //   3266: aload #7
      //   3268: invokevirtual close : ()V
      //   3271: goto -> 1396
      //   3274: astore #10
      //   3276: aload #10
      //   3278: invokevirtual printStackTrace : ()V
      //   3281: goto -> 1396
      //   3284: aload #8
      //   3286: astore #10
      //   3288: aload #9
      //   3290: astore #11
      //   3292: invokestatic a : ()Ljava/lang/String;
      //   3295: astore #7
      //   3297: aload #8
      //   3299: astore #10
      //   3301: aload #9
      //   3303: astore #11
      //   3305: new java/lang/StringBuilder
      //   3308: astore #12
      //   3310: aload #8
      //   3312: astore #10
      //   3314: aload #9
      //   3316: astore #11
      //   3318: aload #12
      //   3320: ldc_w 'wait for repeating Test network repeat count='
      //   3323: invokespecial <init> : (Ljava/lang/String;)V
      //   3326: aload #8
      //   3328: astore #10
      //   3330: aload #9
      //   3332: astore #11
      //   3334: aload #7
      //   3336: aload #12
      //   3338: aload_0
      //   3339: getfield f : I
      //   3342: invokevirtual append : (I)Ljava/lang/StringBuilder;
      //   3345: invokevirtual toString : ()Ljava/lang/String;
      //   3348: invokestatic c : (Ljava/lang/String;Ljava/lang/String;)V
      //   3351: aload #8
      //   3353: astore #10
      //   3355: aload #9
      //   3357: astore #11
      //   3359: ldc2_w 30000
      //   3362: invokestatic sleep : (J)V
      //   3365: aload #8
      //   3367: astore #10
      //   3369: aload #9
      //   3371: astore #11
      //   3373: aload_0
      //   3374: getfield h : I
      //   3377: iconst_1
      //   3378: if_icmpge -> 3441
      //   3381: aload #8
      //   3383: astore #10
      //   3385: aload #9
      //   3387: astore #11
      //   3389: aload_0
      //   3390: iconst_0
      //   3391: invokespecial a : (Z)V
      //   3394: goto -> 2313
      //   3397: astore #7
      //   3399: aload #8
      //   3401: astore #10
      //   3403: aload #9
      //   3405: astore #11
      //   3407: aload_0
      //   3408: aload #7
      //   3410: invokespecial a : (Ljava/lang/Exception;)V
      //   3413: goto -> 2313
      //   3416: astore #7
      //   3418: aload #11
      //   3420: ifnull -> 3428
      //   3423: aload #11
      //   3425: invokevirtual close : ()V
      //   3428: aload #10
      //   3430: ifnull -> 3438
      //   3433: aload #10
      //   3435: invokevirtual close : ()V
      //   3438: aload #7
      //   3440: athrow
      //   3441: aload #8
      //   3443: astore #10
      //   3445: aload #9
      //   3447: astore #11
      //   3449: aload_0
      //   3450: iconst_1
      //   3451: invokespecial a : (Z)V
      //   3454: goto -> 2313
      //   3457: astore #10
      //   3459: aload #10
      //   3461: invokevirtual printStackTrace : ()V
      //   3464: aload #8
      //   3466: ifnull -> 1396
      //   3469: aload #8
      //   3471: invokevirtual close : ()V
      //   3474: goto -> 1396
      //   3477: astore #10
      //   3479: aload #10
      //   3481: invokevirtual printStackTrace : ()V
      //   3484: goto -> 1396
      //   3487: astore #10
      //   3489: aload #8
      //   3491: ifnull -> 3499
      //   3494: aload #8
      //   3496: invokevirtual close : ()V
      //   3499: aload #10
      //   3501: athrow
      //   3502: astore #7
      //   3504: aload #7
      //   3506: invokevirtual printStackTrace : ()V
      //   3509: goto -> 3499
      //   3512: astore #7
      //   3514: aload #12
      //   3516: astore #10
      //   3518: aload #13
      //   3520: astore #11
      //   3522: aload_0
      //   3523: getfield a : Lcom/umeng/common/net/DownloadingService;
      //   3526: getfield h : Ljava/util/Map;
      //   3529: aload_0
      //   3530: getfield i : Lcom/umeng/common/net/a$a;
      //   3533: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
      //   3538: pop
      //   3539: aload #12
      //   3541: astore #10
      //   3543: aload #13
      //   3545: astore #11
      //   3547: aload #7
      //   3549: invokevirtual printStackTrace : ()V
      //   3552: aload #13
      //   3554: ifnull -> 3562
      //   3557: aload #13
      //   3559: invokevirtual close : ()V
      //   3562: aload #12
      //   3564: ifnull -> 1396
      //   3567: aload #12
      //   3569: invokevirtual close : ()V
      //   3572: goto -> 1396
      //   3575: astore #10
      //   3577: aload #10
      //   3579: invokevirtual printStackTrace : ()V
      //   3582: goto -> 1396
      //   3585: astore #10
      //   3587: aload #10
      //   3589: invokevirtual printStackTrace : ()V
      //   3592: aload #12
      //   3594: ifnull -> 1396
      //   3597: aload #12
      //   3599: invokevirtual close : ()V
      //   3602: goto -> 1396
      //   3605: astore #10
      //   3607: aload #10
      //   3609: invokevirtual printStackTrace : ()V
      //   3612: goto -> 1396
      //   3615: astore #10
      //   3617: aload #12
      //   3619: ifnull -> 3627
      //   3622: aload #12
      //   3624: invokevirtual close : ()V
      //   3627: aload #10
      //   3629: athrow
      //   3630: astore #7
      //   3632: aload #7
      //   3634: invokevirtual printStackTrace : ()V
      //   3637: goto -> 3627
      //   3640: astore #8
      //   3642: aload #8
      //   3644: invokevirtual printStackTrace : ()V
      //   3647: aload #10
      //   3649: ifnull -> 3438
      //   3652: aload #10
      //   3654: invokevirtual close : ()V
      //   3657: goto -> 3438
      //   3660: astore #10
      //   3662: aload #10
      //   3664: invokevirtual printStackTrace : ()V
      //   3667: goto -> 3438
      //   3670: astore #7
      //   3672: aload #10
      //   3674: ifnull -> 3682
      //   3677: aload #10
      //   3679: invokevirtual close : ()V
      //   3682: aload #7
      //   3684: athrow
      //   3685: astore #10
      //   3687: aload #10
      //   3689: invokevirtual printStackTrace : ()V
      //   3692: goto -> 3682
      //   3695: astore #10
      //   3697: aload #10
      //   3699: invokevirtual printStackTrace : ()V
      //   3702: goto -> 3438
      //   3705: astore #10
      //   3707: aload #10
      //   3709: invokevirtual printStackTrace : ()V
      //   3712: aload #7
      //   3714: ifnull -> 1396
      //   3717: aload #7
      //   3719: invokevirtual close : ()V
      //   3722: goto -> 1396
      //   3725: astore #10
      //   3727: aload #10
      //   3729: invokevirtual printStackTrace : ()V
      //   3732: goto -> 1396
      //   3735: astore #10
      //   3737: aload #7
      //   3739: ifnull -> 3747
      //   3742: aload #7
      //   3744: invokevirtual close : ()V
      //   3747: aload #10
      //   3749: athrow
      //   3750: astore #7
      //   3752: aload #7
      //   3754: invokevirtual printStackTrace : ()V
      //   3757: goto -> 3747
      // Exception table:
      //   from	to	target	type
      //   38	43	2240	java/io/IOException
      //   38	43	3512	android/os/RemoteException
      //   38	43	3416	finally
      //   65	83	2240	java/io/IOException
      //   65	83	3512	android/os/RemoteException
      //   65	83	3416	finally
      //   105	117	2240	java/io/IOException
      //   105	117	3512	android/os/RemoteException
      //   105	117	3416	finally
      //   139	145	2240	java/io/IOException
      //   139	145	3512	android/os/RemoteException
      //   139	145	3416	finally
      //   167	172	2240	java/io/IOException
      //   167	172	3512	android/os/RemoteException
      //   167	172	3416	finally
      //   194	205	2240	java/io/IOException
      //   194	205	3512	android/os/RemoteException
      //   194	205	3416	finally
      //   227	232	2240	java/io/IOException
      //   227	232	3512	android/os/RemoteException
      //   227	232	3416	finally
      //   254	262	2240	java/io/IOException
      //   254	262	3512	android/os/RemoteException
      //   254	262	3416	finally
      //   292	325	2240	java/io/IOException
      //   292	325	3512	android/os/RemoteException
      //   292	325	3416	finally
      //   347	352	2240	java/io/IOException
      //   347	352	3512	android/os/RemoteException
      //   347	352	3416	finally
      //   374	386	2240	java/io/IOException
      //   374	386	3512	android/os/RemoteException
      //   374	386	3416	finally
      //   408	418	2240	java/io/IOException
      //   408	418	3512	android/os/RemoteException
      //   408	418	3416	finally
      //   440	448	2240	java/io/IOException
      //   440	448	3512	android/os/RemoteException
      //   440	448	3416	finally
      //   470	481	2240	java/io/IOException
      //   470	481	3512	android/os/RemoteException
      //   470	481	3416	finally
      //   503	514	2240	java/io/IOException
      //   503	514	3512	android/os/RemoteException
      //   503	514	3416	finally
      //   536	544	2240	java/io/IOException
      //   536	544	3512	android/os/RemoteException
      //   536	544	3416	finally
      //   566	574	2240	java/io/IOException
      //   566	574	3512	android/os/RemoteException
      //   566	574	3416	finally
      //   596	604	2240	java/io/IOException
      //   596	604	3512	android/os/RemoteException
      //   596	604	3416	finally
      //   626	636	2240	java/io/IOException
      //   626	636	3512	android/os/RemoteException
      //   626	636	3416	finally
      //   658	663	2240	java/io/IOException
      //   658	663	3512	android/os/RemoteException
      //   658	663	3416	finally
      //   685	693	2240	java/io/IOException
      //   685	693	3512	android/os/RemoteException
      //   685	693	3416	finally
      //   715	742	2240	java/io/IOException
      //   715	742	3512	android/os/RemoteException
      //   715	742	3416	finally
      //   764	769	2240	java/io/IOException
      //   764	769	3512	android/os/RemoteException
      //   764	769	3416	finally
      //   791	798	2240	java/io/IOException
      //   791	798	3512	android/os/RemoteException
      //   791	798	3416	finally
      //   826	831	2240	java/io/IOException
      //   826	831	3512	android/os/RemoteException
      //   826	831	3416	finally
      //   855	864	2240	java/io/IOException
      //   855	864	3512	android/os/RemoteException
      //   855	864	3416	finally
      //   888	914	2240	java/io/IOException
      //   888	914	3512	android/os/RemoteException
      //   888	914	3416	finally
      //   938	944	2240	java/io/IOException
      //   938	944	3512	android/os/RemoteException
      //   938	944	3416	finally
      //   971	975	2240	java/io/IOException
      //   971	975	3512	android/os/RemoteException
      //   971	975	3416	finally
      //   999	1004	2240	java/io/IOException
      //   999	1004	3512	android/os/RemoteException
      //   999	1004	3416	finally
      //   1028	1043	2240	java/io/IOException
      //   1028	1043	3512	android/os/RemoteException
      //   1028	1043	3416	finally
      //   1067	1092	2240	java/io/IOException
      //   1067	1092	3512	android/os/RemoteException
      //   1067	1092	3416	finally
      //   1116	1141	2240	java/io/IOException
      //   1116	1141	3512	android/os/RemoteException
      //   1116	1141	3416	finally
      //   1165	1173	2240	java/io/IOException
      //   1165	1173	3512	android/os/RemoteException
      //   1165	1173	3416	finally
      //   1205	1210	2240	java/io/IOException
      //   1205	1210	3512	android/os/RemoteException
      //   1205	1210	3416	finally
      //   1234	1239	2240	java/io/IOException
      //   1234	1239	3512	android/os/RemoteException
      //   1234	1239	3416	finally
      //   1268	1282	2240	java/io/IOException
      //   1268	1282	3512	android/os/RemoteException
      //   1268	1282	3416	finally
      //   1306	1335	2240	java/io/IOException
      //   1306	1335	3512	android/os/RemoteException
      //   1306	1335	3416	finally
      //   1359	1376	2240	java/io/IOException
      //   1359	1376	3512	android/os/RemoteException
      //   1359	1376	3416	finally
      //   1381	1386	2346	java/io/IOException
      //   1381	1386	2376	finally
      //   1391	1396	2401	java/io/IOException
      //   1419	1433	2240	java/io/IOException
      //   1419	1433	3512	android/os/RemoteException
      //   1419	1433	3416	finally
      //   1455	1469	2240	java/io/IOException
      //   1455	1469	3512	android/os/RemoteException
      //   1455	1469	3416	finally
      //   1491	1502	2240	java/io/IOException
      //   1491	1502	3512	android/os/RemoteException
      //   1491	1502	3416	finally
      //   1529	1538	2240	java/io/IOException
      //   1529	1538	3512	android/os/RemoteException
      //   1529	1538	3416	finally
      //   1562	1573	2240	java/io/IOException
      //   1562	1573	3512	android/os/RemoteException
      //   1562	1573	3416	finally
      //   1605	1615	2240	java/io/IOException
      //   1605	1615	3512	android/os/RemoteException
      //   1605	1615	3416	finally
      //   1645	1663	2240	java/io/IOException
      //   1645	1663	3512	android/os/RemoteException
      //   1645	1663	3416	finally
      //   1687	1709	2240	java/io/IOException
      //   1687	1709	3512	android/os/RemoteException
      //   1687	1709	3416	finally
      //   1733	1742	2240	java/io/IOException
      //   1733	1742	3512	android/os/RemoteException
      //   1733	1742	3416	finally
      //   1766	1775	2240	java/io/IOException
      //   1766	1775	3512	android/os/RemoteException
      //   1766	1775	3416	finally
      //   1799	1803	2240	java/io/IOException
      //   1799	1803	3512	android/os/RemoteException
      //   1799	1803	3416	finally
      //   1827	1839	2240	java/io/IOException
      //   1827	1839	3512	android/os/RemoteException
      //   1827	1839	3416	finally
      //   1863	1880	2240	java/io/IOException
      //   1863	1880	3512	android/os/RemoteException
      //   1863	1880	3416	finally
      //   1904	1922	2240	java/io/IOException
      //   1904	1922	3512	android/os/RemoteException
      //   1904	1922	3416	finally
      //   1946	1990	2240	java/io/IOException
      //   1946	1990	3512	android/os/RemoteException
      //   1946	1990	3416	finally
      //   2014	2033	2143	android/os/DeadObjectException
      //   2014	2033	2240	java/io/IOException
      //   2014	2033	3512	android/os/RemoteException
      //   2014	2033	3416	finally
      //   2057	2087	2143	android/os/DeadObjectException
      //   2057	2087	2240	java/io/IOException
      //   2057	2087	3512	android/os/RemoteException
      //   2057	2087	3416	finally
      //   2111	2137	2240	java/io/IOException
      //   2111	2137	3512	android/os/RemoteException
      //   2111	2137	3416	finally
      //   2169	2195	2240	java/io/IOException
      //   2169	2195	3512	android/os/RemoteException
      //   2169	2195	3416	finally
      //   2219	2237	2240	java/io/IOException
      //   2219	2237	3512	android/os/RemoteException
      //   2219	2237	3416	finally
      //   2250	2263	3416	finally
      //   2271	2279	3416	finally
      //   2287	2293	3416	finally
      //   2307	2313	3416	finally
      //   2318	2323	3457	java/io/IOException
      //   2318	2323	3487	finally
      //   2328	2333	2336	java/io/IOException
      //   2348	2353	2376	finally
      //   2358	2363	2366	java/io/IOException
      //   2383	2388	2391	java/io/IOException
      //   2435	2443	2240	java/io/IOException
      //   2435	2443	3512	android/os/RemoteException
      //   2435	2443	3416	finally
      //   2467	2476	2240	java/io/IOException
      //   2467	2476	3512	android/os/RemoteException
      //   2467	2476	3416	finally
      //   2500	2504	2240	java/io/IOException
      //   2500	2504	3512	android/os/RemoteException
      //   2500	2504	3416	finally
      //   2528	2540	2240	java/io/IOException
      //   2528	2540	3512	android/os/RemoteException
      //   2528	2540	3416	finally
      //   2564	2580	2240	java/io/IOException
      //   2564	2580	3512	android/os/RemoteException
      //   2564	2580	3416	finally
      //   2604	2630	2240	java/io/IOException
      //   2604	2630	3512	android/os/RemoteException
      //   2604	2630	3416	finally
      //   2654	2658	2240	java/io/IOException
      //   2654	2658	3512	android/os/RemoteException
      //   2654	2658	3416	finally
      //   2682	2704	2240	java/io/IOException
      //   2682	2704	3512	android/os/RemoteException
      //   2682	2704	3416	finally
      //   2728	2735	2240	java/io/IOException
      //   2728	2735	3512	android/os/RemoteException
      //   2728	2735	3416	finally
      //   2759	2764	2240	java/io/IOException
      //   2759	2764	3512	android/os/RemoteException
      //   2759	2764	3416	finally
      //   2788	2793	2240	java/io/IOException
      //   2788	2793	3512	android/os/RemoteException
      //   2788	2793	3416	finally
      //   2817	2822	2240	java/io/IOException
      //   2817	2822	3512	android/os/RemoteException
      //   2817	2822	3416	finally
      //   2846	2855	2240	java/io/IOException
      //   2846	2855	3512	android/os/RemoteException
      //   2846	2855	3416	finally
      //   2879	2883	2240	java/io/IOException
      //   2879	2883	3512	android/os/RemoteException
      //   2879	2883	3416	finally
      //   2907	2912	2240	java/io/IOException
      //   2907	2912	3512	android/os/RemoteException
      //   2907	2912	3416	finally
      //   2936	2941	2240	java/io/IOException
      //   2936	2941	3512	android/os/RemoteException
      //   2936	2941	3416	finally
      //   2965	2971	2240	java/io/IOException
      //   2965	2971	3512	android/os/RemoteException
      //   2965	2971	3416	finally
      //   2995	3004	2240	java/io/IOException
      //   2995	3004	3512	android/os/RemoteException
      //   2995	3004	3416	finally
      //   3028	3032	2240	java/io/IOException
      //   3028	3032	3512	android/os/RemoteException
      //   3028	3032	3416	finally
      //   3056	3061	2240	java/io/IOException
      //   3056	3061	3512	android/os/RemoteException
      //   3056	3061	3416	finally
      //   3085	3090	2240	java/io/IOException
      //   3085	3090	3512	android/os/RemoteException
      //   3085	3090	3416	finally
      //   3114	3120	2240	java/io/IOException
      //   3114	3120	3512	android/os/RemoteException
      //   3114	3120	3416	finally
      //   3144	3163	2240	java/io/IOException
      //   3144	3163	3512	android/os/RemoteException
      //   3144	3163	3416	finally
      //   3187	3210	2240	java/io/IOException
      //   3187	3210	3512	android/os/RemoteException
      //   3187	3210	3416	finally
      //   3234	3251	2240	java/io/IOException
      //   3234	3251	3512	android/os/RemoteException
      //   3234	3251	3416	finally
      //   3256	3261	3705	java/io/IOException
      //   3256	3261	3735	finally
      //   3266	3271	3274	java/io/IOException
      //   3292	3297	3416	finally
      //   3305	3310	3416	finally
      //   3318	3326	3416	finally
      //   3334	3351	3416	finally
      //   3359	3365	3397	java/lang/InterruptedException
      //   3359	3365	3416	finally
      //   3373	3381	3397	java/lang/InterruptedException
      //   3373	3381	3416	finally
      //   3389	3394	3397	java/lang/InterruptedException
      //   3389	3394	3416	finally
      //   3407	3413	3416	finally
      //   3423	3428	3640	java/io/IOException
      //   3423	3428	3670	finally
      //   3433	3438	3695	java/io/IOException
      //   3449	3454	3397	java/lang/InterruptedException
      //   3449	3454	3416	finally
      //   3459	3464	3487	finally
      //   3469	3474	3477	java/io/IOException
      //   3494	3499	3502	java/io/IOException
      //   3522	3539	3416	finally
      //   3547	3552	3416	finally
      //   3557	3562	3585	java/io/IOException
      //   3557	3562	3615	finally
      //   3567	3572	3575	java/io/IOException
      //   3587	3592	3615	finally
      //   3597	3602	3605	java/io/IOException
      //   3622	3627	3630	java/io/IOException
      //   3642	3647	3670	finally
      //   3652	3657	3660	java/io/IOException
      //   3677	3682	3685	java/io/IOException
      //   3707	3712	3735	finally
      //   3717	3722	3725	java/io/IOException
      //   3742	3747	3750	java/io/IOException
    }
    
    public void run() {
      this.f = 0;
      try {
        a(false);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    }
  }
  
  class b extends Handler {
    b(DownloadingService this$0) {}
    
    public void handleMessage(Message param1Message) {
      Log.c(DownloadingService.a(), "IncomingHandler(msg.what:" + param1Message.what + " msg.arg1:" + param1Message.arg1 + " msg.arg2:" + param1Message.arg2 + " msg.replyTo:" + param1Message.replyTo);
      switch (param1Message.what) {
        default:
          super.handleMessage(param1Message);
          return;
        case 4:
          break;
      } 
      Bundle bundle = param1Message.getData();
      Log.c(DownloadingService.a(), "IncomingHandler(msg.getData():" + bundle);
      a.a a = a.a.a(bundle);
      if (DownloadingService.a(this.a, a)) {
        Log.a(DownloadingService.a(), String.valueOf(a.b) + " is already in downloading list. ");
        return;
      } 
      this.a.h.put(a, param1Message.replyTo);
      DownloadingService.b(this.a, a);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/DownloadingService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */