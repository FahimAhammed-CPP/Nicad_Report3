package com.umeng.common.net;

import org.json.JSONObject;

public class h extends l {
  public a a;
  
  public h(JSONObject paramJSONObject) {
    super(paramJSONObject);
    if ("ok".equalsIgnoreCase(paramJSONObject.optString("status")) || "ok".equalsIgnoreCase(paramJSONObject.optString("success"))) {
      this.a = a.a;
      return;
    } 
    this.a = a.b;
  }
  
  public enum a {
    a, b;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */