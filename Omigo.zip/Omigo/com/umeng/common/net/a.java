package com.umeng.common.net;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;

public class a {
  private static final String b = a.class.getName();
  
  final Messenger a = new Messenger(new b(this));
  
  private Context c;
  
  private e d;
  
  private Messenger e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private ServiceConnection i = new b(this);
  
  public a(Context paramContext, String paramString1, String paramString2, String paramString3, e parame) {
    this.c = paramContext;
    this.f = paramString1;
    this.g = paramString2;
    this.h = paramString3;
    this.d = parame;
  }
  
  public void a() {
    this.c.bindService(new Intent(this.c, DownloadingService.class), this.i, 1);
  }
  
  static class a {
    public String a;
    
    public String b;
    
    public String c;
    
    public a(String param1String1, String param1String2, String param1String3) {
      this.a = param1String1;
      this.b = param1String2;
      this.c = param1String3;
    }
    
    public static a a(Bundle param1Bundle) {
      return new a(param1Bundle.getString("mComponentName"), param1Bundle.getString("mTitle"), param1Bundle.getString("mUrl"));
    }
    
    public Bundle a() {
      Bundle bundle = new Bundle();
      bundle.putString("mComponentName", this.a);
      bundle.putString("mTitle", this.b);
      bundle.putString("mUrl", this.c);
      return bundle;
    }
  }
  
  class b extends Handler {
    b(a this$0) {}
    
    public void handleMessage(Message param1Message) {
      try {
        switch (param1Message.what) {
          default:
            super.handleMessage(param1Message);
            return;
          case 3:
            if (a.a(this.a) != null)
              a.a(this.a).a(param1Message.arg1); 
            return;
          case 5:
            break;
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        Log.d(a.b(), "DownloadAgent.handleMessage(" + param1Message.what + "): " + exception.getMessage());
        return;
      } 
      a.f(this.a).unbindService(a.g(this.a));
      if (a.a(this.a) != null) {
        if (param1Message.arg1 == 1) {
          a.a(this.a).a(param1Message.arg1, param1Message.getData().getString("filename"));
          return;
        } 
        a.a(this.a).a(0, null);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */