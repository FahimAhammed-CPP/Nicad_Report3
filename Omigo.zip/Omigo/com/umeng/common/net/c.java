package com.umeng.common.net;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.umeng.common.Log;
import com.umeng.common.b.g;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class c {
  private static final String a = c.class.getName();
  
  private static final String b = "umeng_download_task_list";
  
  private static final String c = "UMENG_DATA";
  
  private static final String d = "cp";
  
  private static final String e = "url";
  
  private static final String f = "progress";
  
  private static final String g = "last_modified";
  
  private static final String h = "extra";
  
  private static Context i;
  
  private static final String j = "yyyy-MM-dd HH:mm:ss";
  
  private a k = new a(this, i);
  
  private c() {}
  
  public static c a(Context paramContext) {
    if (i == null && paramContext == null)
      throw new NullPointerException(); 
    if (i == null)
      i = paramContext; 
    return b.a;
  }
  
  public List<String> a(String paramString) {
    Cursor cursor = this.k.getReadableDatabase().query("umeng_download_task_list", new String[] { "url" }, "cp=?", new String[] { paramString }, null, null, null, "1");
    ArrayList<String> arrayList = new ArrayList();
    cursor.moveToFirst();
    while (true) {
      if (cursor.isAfterLast()) {
        cursor.close();
        return arrayList;
      } 
      arrayList.add(cursor.getString(0));
      cursor.moveToNext();
    } 
  }
  
  public void a(int paramInt) {
    try {
      Date date1 = new Date();
      Date date2 = new Date();
      this();
      this(date2.getTime() - (paramInt * 1000));
      SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss");
      String str = simpleDateFormat1.format(date1);
      StringBuilder stringBuilder = new StringBuilder();
      this(" DELETE FROM umeng_download_task_list WHERE strftime('yyyy-MM-dd HH:mm:ss', last_modified)<=strftime('yyyy-MM-dd HH:mm:ss', '");
      str = stringBuilder.append(str).append("')").toString();
      this.k.getWritableDatabase().execSQL(str);
      str = a;
      stringBuilder = new StringBuilder();
      this("clearOverdueTasks(");
      stringBuilder = stringBuilder.append(paramInt).append(")").append(" remove all tasks before ");
      SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss");
      Log.c(str, stringBuilder.append(simpleDateFormat2.format(date1)).toString());
    } catch (Exception exception) {
      Log.b(a, exception.getMessage());
    } 
  }
  
  public void a(String paramString1, String paramString2, int paramInt) {
    ContentValues contentValues = new ContentValues();
    contentValues.put("progress", Integer.valueOf(paramInt));
    contentValues.put("last_modified", g.a());
    this.k.getWritableDatabase().update("umeng_download_task_list", contentValues, "cp=? and url=?", new String[] { paramString1, paramString2 });
    Log.c(a, "updateProgress(" + paramString1 + ", " + paramString2 + ", " + paramInt + ")");
  }
  
  public void a(String paramString1, String paramString2, String paramString3) {
    ContentValues contentValues = new ContentValues();
    contentValues.put("extra", paramString3);
    contentValues.put("last_modified", g.a());
    this.k.getWritableDatabase().update("umeng_download_task_list", contentValues, "cp=? and url=?", new String[] { paramString1, paramString2 });
    Log.c(a, "updateExtra(" + paramString1 + ", " + paramString2 + ", " + paramString3 + ")");
  }
  
  public boolean a(String paramString1, String paramString2) {
    ContentValues contentValues = new ContentValues();
    contentValues.put("cp", paramString1);
    contentValues.put("url", paramString2);
    contentValues.put("progress", Integer.valueOf(0));
    contentValues.put("last_modified", g.a());
    try {
      StringBuilder stringBuilder;
      boolean bool;
      Cursor cursor = this.k.getReadableDatabase().query("umeng_download_task_list", new String[] { "progress" }, "cp=? and url=?", new String[] { paramString1, paramString2 }, null, null, null, "1");
      if (cursor.getCount() > 0) {
        String str = a;
        stringBuilder = new StringBuilder();
        this("insert(");
        Log.c(str, stringBuilder.append(paramString1).append(", ").append(paramString2).append("): ").append(" already exists in the db. Insert is cancelled.").toString());
        bool = false;
      } else {
        long l = this.k.getWritableDatabase().insert("umeng_download_task_list", null, (ContentValues)stringBuilder);
        if (l == -1L) {
          bool = false;
        } else {
          bool = true;
        } 
        try {
          String str = a;
          StringBuilder stringBuilder1 = new StringBuilder();
          this("insert(");
          Log.c(str, stringBuilder1.append(paramString1).append(", ").append(paramString2).append("): ").append("rowid=").append(l).toString());
          try {
            cursor.close();
            return bool;
          } catch (Exception null) {}
        } catch (Exception null) {}
        return bool;
      } 
      try {
        exception.close();
        return bool;
      } catch (Exception exception1) {}
    } catch (Exception exception) {
      boolean bool = false;
    } 
    Log.c(a, "insert(" + paramString1 + ", " + paramString2 + "): " + exception.getMessage(), exception);
  }
  
  public int b(String paramString1, String paramString2) {
    Cursor cursor = this.k.getReadableDatabase().query("umeng_download_task_list", new String[] { "progress" }, "cp=? and url=?", new String[] { paramString1, paramString2 }, null, null, null, "1");
    if (cursor.getCount() > 0) {
      cursor.moveToFirst();
      int i = cursor.getInt(0);
      cursor.close();
      return i;
    } 
    byte b = -1;
    cursor.close();
    return b;
  }
  
  public String c(String paramString1, String paramString2) {
    String str = null;
    Cursor cursor = this.k.getReadableDatabase().query("umeng_download_task_list", new String[] { "extra" }, "cp=? and url=?", new String[] { paramString1, paramString2 }, null, null, null, "1");
    paramString1 = str;
    if (cursor.getCount() > 0) {
      cursor.moveToFirst();
      paramString1 = cursor.getString(0);
    } 
    cursor.close();
    return paramString1;
  }
  
  public Date d(String paramString1, String paramString2) {
    String str1 = null;
    Cursor cursor = this.k.getReadableDatabase().query("umeng_download_task_list", new String[] { "last_modified" }, "cp=? and url=?", new String[] { paramString1, paramString2 }, null, null, null, null);
    String str2 = str1;
    if (cursor.getCount() > 0) {
      cursor.moveToFirst();
      str2 = cursor.getString(0);
      Log.c(a, "getLastModified(" + paramString1 + ", " + paramString2 + "): " + str2);
      try {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
        this("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(str2);
      } catch (Exception exception) {
        Log.c(a, exception.getMessage());
        str2 = str1;
      } 
    } 
    cursor.close();
    return (Date)str2;
  }
  
  public void e(String paramString1, String paramString2) {
    this.k.getWritableDatabase().delete("umeng_download_task_list", "cp=? and url=?", new String[] { paramString1, paramString2 });
    Log.c(a, "delete(" + paramString1 + ", " + paramString2 + ")");
  }
  
  public void finalize() {
    this.k.close();
  }
  
  class a extends SQLiteOpenHelper {
    private static final int b = 2;
    
    private static final String c = "CREATE TABLE umeng_download_task_list (cp TEXT, url TEXT, progress INTEGER, extra TEXT, last_modified TEXT, UNIQUE (cp,url) ON CONFLICT ABORT);";
    
    a(c this$0, Context param1Context) {
      super(param1Context, "UMENG_DATA", null, 2);
    }
    
    public void onCreate(SQLiteDatabase param1SQLiteDatabase) {
      Log.c(c.a(), "CREATE TABLE umeng_download_task_list (cp TEXT, url TEXT, progress INTEGER, extra TEXT, last_modified TEXT, UNIQUE (cp,url) ON CONFLICT ABORT);");
      param1SQLiteDatabase.execSQL("CREATE TABLE umeng_download_task_list (cp TEXT, url TEXT, progress INTEGER, extra TEXT, last_modified TEXT, UNIQUE (cp,url) ON CONFLICT ABORT);");
    }
    
    public void onUpgrade(SQLiteDatabase param1SQLiteDatabase, int param1Int1, int param1Int2) {}
  }
  
  private static class b {
    public static final c a = new c(null);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/net/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */