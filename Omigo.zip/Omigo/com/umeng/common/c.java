package com.umeng.common;

import android.content.Context;

public class c {
  private static final String a = c.class.getName();
  
  private static c b;
  
  private static Class d = null;
  
  private static Class e = null;
  
  private static Class f = null;
  
  private static Class g = null;
  
  private static Class h = null;
  
  private static Class i = null;
  
  private static Class j = null;
  
  private Context c;
  
  private c(Context paramContext) {
    this.c = paramContext;
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      e = Class.forName(stringBuilder.append(".R$drawable").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      f = Class.forName(stringBuilder.append(".R$layout").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      d = Class.forName(stringBuilder.append(".R$id").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      g = Class.forName(stringBuilder.append(".R$anim").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      h = Class.forName(stringBuilder.append(".R$style").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      i = Class.forName(stringBuilder.append(".R$string").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(this.c.getPackageName()));
      j = Class.forName(stringBuilder.append(".R$array").toString());
    } catch (ClassNotFoundException classNotFoundException) {
      Log.b(a, classNotFoundException.getMessage());
    } 
  }
  
  private int a(Class<?> paramClass, String paramString) {
    byte b;
    if (paramClass == null) {
      Log.b(a, "getRes(null," + paramString + ")");
      throw new IllegalArgumentException("ResClass is not initialized.");
    } 
    try {
      b = paramClass.getField(paramString).getInt(paramString);
    } catch (Exception exception) {
      exception.printStackTrace();
      Log.b(a, exception.getMessage());
      b = -1;
    } 
    return b;
  }
  
  public static c a(Context paramContext) {
    if (b == null)
      b = new c(paramContext); 
    return b;
  }
  
  public int a(String paramString) {
    return a(g, paramString);
  }
  
  public int b(String paramString) {
    return a(d, paramString);
  }
  
  public int c(String paramString) {
    return a(e, paramString);
  }
  
  public int d(String paramString) {
    return a(f, paramString);
  }
  
  public int e(String paramString) {
    return a(h, paramString);
  }
  
  public int f(String paramString) {
    return a(i, paramString);
  }
  
  public int g(String paramString) {
    return a(j, paramString);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */