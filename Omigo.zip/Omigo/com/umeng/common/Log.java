package com.umeng.common;

public class Log {
  public static boolean LOG = false;
  
  public static void a(String paramString1, String paramString2) {
    if (LOG)
      android.util.Log.i(paramString1, paramString2); 
  }
  
  public static void a(String paramString1, String paramString2, Exception paramException) {
    if (LOG)
      android.util.Log.i(paramString1, String.valueOf(paramException.toString()) + ":  [" + paramString2 + "]"); 
  }
  
  public static void b(String paramString1, String paramString2) {
    if (LOG)
      android.util.Log.e(paramString1, paramString2); 
  }
  
  public static void b(String paramString1, String paramString2, Exception paramException) {
    if (LOG) {
      android.util.Log.e(paramString1, String.valueOf(paramException.toString()) + ":  [" + paramString2 + "]");
      StackTraceElement[] arrayOfStackTraceElement = paramException.getStackTrace();
      int i = arrayOfStackTraceElement.length;
      byte b = 0;
      while (true) {
        if (b < i) {
          StackTraceElement stackTraceElement = arrayOfStackTraceElement[b];
          android.util.Log.e(paramString1, "        at\t " + stackTraceElement.toString());
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public static void c(String paramString1, String paramString2) {
    if (LOG)
      android.util.Log.d(paramString1, paramString2); 
  }
  
  public static void c(String paramString1, String paramString2, Exception paramException) {
    if (LOG)
      android.util.Log.d(paramString1, String.valueOf(paramException.toString()) + ":  [" + paramString2 + "]"); 
  }
  
  public static void d(String paramString1, String paramString2) {
    if (LOG)
      android.util.Log.v(paramString1, paramString2); 
  }
  
  public static void d(String paramString1, String paramString2, Exception paramException) {
    if (LOG)
      android.util.Log.v(paramString1, String.valueOf(paramException.toString()) + ":  [" + paramString2 + "]"); 
  }
  
  public static void e(String paramString1, String paramString2) {
    if (LOG)
      android.util.Log.w(paramString1, paramString2); 
  }
  
  public static void e(String paramString1, String paramString2, Exception paramException) {
    if (LOG) {
      android.util.Log.w(paramString1, String.valueOf(paramException.toString()) + ":  [" + paramString2 + "]");
      StackTraceElement[] arrayOfStackTraceElement = paramException.getStackTrace();
      int i = arrayOfStackTraceElement.length;
      byte b = 0;
      while (true) {
        if (b < i) {
          StackTraceElement stackTraceElement = arrayOfStackTraceElement[b];
          android.util.Log.w(paramString1, "        at\t " + stackTraceElement.toString());
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/Log.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */