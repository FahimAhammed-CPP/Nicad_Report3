package com.umeng.common;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;
import com.umeng.common.b.g;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import javax.microedition.khronos.opengles.GL10;

public class b {
  protected static final String a = b.class.getName();
  
  protected static final String b = "Unknown";
  
  public static final int c = 8;
  
  private static final String d = "2G/3G";
  
  private static final String e = "Wi-Fi";
  
  public static int a(Date paramDate1, Date paramDate2) {
    if (paramDate1.after(paramDate2)) {
      Date date1 = paramDate2;
      paramDate2 = paramDate1;
      long l1 = date1.getTime();
      return (int)((paramDate2.getTime() - l1) / 1000L);
    } 
    Date date = paramDate1;
    long l = date.getTime();
    return (int)((paramDate2.getTime() - l) / 1000L);
  }
  
  public static String a() {
    String str1 = null;
    String str2 = null;
    String str3 = str1;
    try {
      FileReader fileReader = new FileReader();
      str3 = str1;
      this("/proc/cpuinfo");
      if (fileReader != null) {
        String str = str2;
        str3 = str1;
        try {
          BufferedReader bufferedReader = new BufferedReader();
          str = str2;
          str3 = str1;
          this(fileReader, 1024);
          str = str2;
          str3 = str1;
          str2 = bufferedReader.readLine();
          str = str2;
          str3 = str2;
          bufferedReader.close();
          str = str2;
          str3 = str2;
          fileReader.close();
          str3 = str2;
        } catch (IOException iOException) {
          str3 = str;
        } 
      } else {
        str3 = null;
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      Log.e(a, "Could not open file /proc/cpuinfo", fileNotFoundException);
    } 
    String str4 = str3;
    if (str3 != null)
      str4 = str3.substring(str3.indexOf(':') + 1); 
    return str4.trim();
  }
  
  public static String a(Date paramDate) {
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(paramDate);
  }
  
  public static Date a(String paramString) {
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss");
      Date date = simpleDateFormat.parse(paramString);
    } catch (Exception exception) {
      exception = null;
    } 
    return (Date)exception;
  }
  
  public static boolean a(Context paramContext) {
    return (paramContext.getResources().getConfiguration()).locale.toString().equals(Locale.CHINA.toString());
  }
  
  public static boolean a(Context paramContext, String paramString) {
    return !(paramContext.getPackageManager().checkPermission(paramString, paramContext.getPackageName()) != 0);
  }
  
  public static boolean a(String paramString, Context paramContext) {
    boolean bool = true;
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      packageManager.getPackageInfo(paramString, 1);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      bool = false;
    } 
    return bool;
  }
  
  public static String[] a(GL10 paramGL10) {
    String[] arrayOfString;
    try {
      String[] arrayOfString1 = new String[2];
      String str2 = paramGL10.glGetString(7936);
      String str1 = paramGL10.glGetString(7937);
      arrayOfString1[0] = str2;
      arrayOfString1[1] = str1;
      arrayOfString = arrayOfString1;
    } catch (Exception exception) {
      Log.e(a, "Could not read gpu infor:", exception);
      arrayOfString = new String[0];
    } 
    return arrayOfString;
  }
  
  public static Set<String> b(Context paramContext) {
    HashSet<String> hashSet = new HashSet();
    List list = paramContext.getPackageManager().getInstalledPackages(0);
    for (byte b1 = 0;; b1++) {
      if (b1 >= list.size())
        return hashSet; 
      hashSet.add(((PackageInfo)list.get(b1)).packageName);
    } 
  }
  
  public static boolean b() {
    return Environment.getExternalStorageState().equals("mounted");
  }
  
  public static String c() {
    Date date = new Date();
    return (new SimpleDateFormat("yyyy-MM-dd")).format(date);
  }
  
  public static boolean c(Context paramContext) {
    boolean bool = true;
    if ((paramContext.getResources().getConfiguration()).orientation != 1)
      bool = false; 
    return bool;
  }
  
  public static String d(Context paramContext) {
    String str;
    try {
      int i = (paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0)).versionCode;
      str = String.valueOf(i);
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      str = "Unknown";
    } 
    return str;
  }
  
  public static String e(Context paramContext) {
    String str;
    try {
      str = (paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0)).versionName;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      str = "Unknown";
    } 
    return str;
  }
  
  public static String f(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: ldc 'phone'
    //   3: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   6: checkcast android/telephony/TelephonyManager
    //   9: astore_1
    //   10: aload_1
    //   11: ifnonnull -> 23
    //   14: getstatic com/umeng/common/b.a : Ljava/lang/String;
    //   17: ldc 'No IMEI.'
    //   19: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   22: pop
    //   23: aload_0
    //   24: ldc 'android.permission.READ_PHONE_STATE'
    //   26: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Z
    //   29: ifeq -> 126
    //   32: aload_1
    //   33: invokevirtual getDeviceId : ()Ljava/lang/String;
    //   36: astore_2
    //   37: aload_2
    //   38: astore_1
    //   39: aload_2
    //   40: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   43: ifeq -> 113
    //   46: getstatic com/umeng/common/b.a : Ljava/lang/String;
    //   49: ldc 'No IMEI.'
    //   51: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   54: pop
    //   55: aload_0
    //   56: invokestatic v : (Landroid/content/Context;)Ljava/lang/String;
    //   59: astore_2
    //   60: aload_2
    //   61: astore_1
    //   62: aload_2
    //   63: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   66: ifeq -> 113
    //   69: getstatic com/umeng/common/b.a : Ljava/lang/String;
    //   72: ldc 'Failed to take mac as IMEI. Try to use Secure.ANDROID_ID instead.'
    //   74: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   77: pop
    //   78: aload_0
    //   79: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   82: ldc_w 'android_id'
    //   85: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   88: astore_1
    //   89: getstatic com/umeng/common/b.a : Ljava/lang/String;
    //   92: new java/lang/StringBuilder
    //   95: dup
    //   96: ldc_w 'getDeviceId: Secure.ANDROID_ID: '
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: aload_1
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: invokevirtual toString : ()Ljava/lang/String;
    //   109: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   112: pop
    //   113: aload_1
    //   114: areturn
    //   115: astore_1
    //   116: getstatic com/umeng/common/b.a : Ljava/lang/String;
    //   119: ldc 'No IMEI.'
    //   121: aload_1
    //   122: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   125: pop
    //   126: ldc_w ''
    //   129: astore_2
    //   130: goto -> 37
    // Exception table:
    //   from	to	target	type
    //   23	37	115	java/lang/Exception
  }
  
  public static String g(Context paramContext) {
    return g.b(f(paramContext));
  }
  
  public static String h(Context paramContext) {
    String str;
    try {
      TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
      if (telephonyManager == null)
        return "Unknown"; 
      str = telephonyManager.getNetworkOperatorName();
    } catch (Exception exception) {
      exception.printStackTrace();
      str = "Unknown";
    } 
    return str;
  }
  
  public static String i(Context paramContext) {
    String str;
    try {
      DisplayMetrics displayMetrics = new DisplayMetrics();
      this();
      ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
      int i = displayMetrics.widthPixels;
      int j = displayMetrics.heightPixels;
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(String.valueOf(j)));
      str = stringBuilder.append("*").append(String.valueOf(i)).toString();
    } catch (Exception exception) {
      exception.printStackTrace();
      str = "Unknown";
    } 
    return str;
  }
  
  public static String[] j(Context paramContext) {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = "Unknown";
    arrayOfString[1] = "Unknown";
    if (paramContext.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", paramContext.getPackageName()) != 0) {
      arrayOfString[0] = "Unknown";
      return arrayOfString;
    } 
    ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    if (connectivityManager == null) {
      arrayOfString[0] = "Unknown";
      return arrayOfString;
    } 
    if (connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
      arrayOfString[0] = "Wi-Fi";
      return arrayOfString;
    } 
    NetworkInfo networkInfo = connectivityManager.getNetworkInfo(0);
    if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
      arrayOfString[0] = "2G/3G";
      arrayOfString[1] = networkInfo.getSubtypeName();
    } 
    return arrayOfString;
  }
  
  public static boolean k(Context paramContext) {
    return "Wi-Fi".equals(j(paramContext)[0]);
  }
  
  public static Location l(Context paramContext) {
    try {
      StringBuilder stringBuilder;
      LocationManager locationManager = (LocationManager)paramContext.getSystemService("location");
      if (a(paramContext, "android.permission.ACCESS_FINE_LOCATION")) {
        Location location = locationManager.getLastKnownLocation("gps");
        if (location != null) {
          String str = a;
          stringBuilder = new StringBuilder();
          this("get location from gps:");
          Log.i(str, stringBuilder.append(location.getLatitude()).append(",").append(location.getLongitude()).toString());
          return location;
        } 
      } 
      if (a(paramContext, "android.permission.ACCESS_COARSE_LOCATION")) {
        Location location = stringBuilder.getLastKnownLocation("network");
        if (location != null) {
          String str = a;
          stringBuilder = new StringBuilder();
          this("get location from network:");
          Log.i(str, stringBuilder.append(location.getLatitude()).append(",").append(location.getLongitude()).toString());
          return location;
        } 
      } 
    } catch (Exception null) {
      Log.e(a, null.getMessage());
      return null;
    } 
    Log.i(a, "Could not get location from GPS or Cell-id, lack ACCESS_COARSE_LOCATION or ACCESS_COARSE_LOCATION permission?");
    return null;
  }
  
  public static boolean m(Context paramContext) {
    boolean bool;
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null)
        return networkInfo.isConnectedOrConnecting(); 
      bool = false;
    } catch (Exception exception) {
      bool = true;
    } 
    return bool;
  }
  
  public static int n(Context paramContext) {
    try {
      Locale locale2 = Locale.getDefault();
      Configuration configuration = new Configuration();
      this();
      Settings.System.getConfiguration(paramContext.getContentResolver(), configuration);
      Locale locale1 = locale2;
      if (configuration != null) {
        locale1 = locale2;
        if (configuration.locale != null)
          locale1 = configuration.locale; 
      } 
      Calendar calendar = Calendar.getInstance(locale1);
      if (calendar != null)
        return calendar.getTimeZone().getRawOffset() / 3600000; 
    } catch (Exception exception) {
      Log.i(a, "error in getTimeZone", exception);
    } 
    return 8;
  }
  
  public static String[] o(Context paramContext) {
    String[] arrayOfString = new String[2];
    arrayOfString[0] = "Unknown";
    arrayOfString[1] = "Unknown";
    try {
      Configuration configuration = new Configuration();
      this();
      Settings.System.getConfiguration(paramContext.getContentResolver(), configuration);
      if (configuration != null && configuration.locale != null) {
        arrayOfString[0] = configuration.locale.getCountry();
        arrayOfString[1] = configuration.locale.toString();
      } else {
        Locale locale = Locale.getDefault();
        if (locale != null) {
          arrayOfString[0] = locale.getCountry();
          arrayOfString[1] = locale.getLanguage();
        } 
      } 
      if (TextUtils.isEmpty(arrayOfString[0]))
        arrayOfString[0] = "Unknown"; 
      if (TextUtils.isEmpty(arrayOfString[1]))
        arrayOfString[1] = "Unknown"; 
    } catch (Exception exception) {
      Log.e(a, "error in getLocaleInfo", exception);
    } 
    return arrayOfString;
  }
  
  public static String p(Context paramContext) {
    try {
      ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      if (applicationInfo != null) {
        String str = applicationInfo.metaData.getString("UMENG_APPKEY");
        if (str != null)
          return str.trim(); 
        Log.e(a, "Could not read UMENG_APPKEY meta-data from AndroidManifest.xml.");
      } 
    } catch (Exception exception) {
      Log.e(a, "Could not read UMENG_APPKEY meta-data from AndroidManifest.xml.", exception);
    } 
    return null;
  }
  
  public static String q(Context paramContext) {
    String str;
    try {
      DisplayMetrics displayMetrics = new DisplayMetrics();
      this();
      ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
      int i = displayMetrics.widthPixels;
      int j = displayMetrics.heightPixels;
      StringBuffer stringBuffer = new StringBuffer();
      this();
      stringBuffer.append(i);
      stringBuffer.append("*");
      stringBuffer.append(j);
      str = stringBuffer.toString();
    } catch (Exception exception) {
      Log.e(a, "read resolution fail", exception);
      str = "Unknown";
    } 
    return str;
  }
  
  public static String r(Context paramContext) {
    String str;
    try {
      str = ((TelephonyManager)paramContext.getSystemService("phone")).getNetworkOperatorName();
    } catch (Exception exception) {
      Log.i(a, "read carrier fail", exception);
      str = "Unknown";
    } 
    return str;
  }
  
  public static String s(Context paramContext) {
    try {
      ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      if (applicationInfo != null && applicationInfo.metaData != null) {
        Object object = applicationInfo.metaData.get("UMENG_CHANNEL");
        if (object != null) {
          object = object.toString();
          if (object == null) {
            Log.i(a, "Could not read UMENG_CHANNEL meta-data from AndroidManifest.xml.");
            object = "Unknown";
          } 
          return (String)object;
        } 
      } 
    } catch (Exception exception) {
      Log.i(a, "Could not read UMENG_CHANNEL meta-data from AndroidManifest.xml.");
      exception.printStackTrace();
    } 
    return "Unknown";
  }
  
  public static String t(Context paramContext) {
    return paramContext.getPackageName();
  }
  
  public static String u(Context paramContext) {
    return paramContext.getPackageManager().getApplicationLabel(paramContext.getApplicationInfo()).toString();
  }
  
  private static String v(Context paramContext) {
    String str;
    try {
      str = ((WifiManager)paramContext.getSystemService("wifi")).getConnectionInfo().getMacAddress();
    } catch (Exception exception) {
      Log.i(a, "Could not read MAC, forget to include ACCESS_WIFI_STATE permission?", exception);
      str = "";
    } 
    return str;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */