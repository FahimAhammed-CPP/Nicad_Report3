package com.umeng.common.b;

import java.math.BigInteger;

public class c extends d {
  static final byte[] a = new byte[] { 13, 10 };
  
  private static final int m = 6;
  
  private static final int n = 3;
  
  private static final int o = 4;
  
  private static final byte[] p = new byte[] { 
      65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
      75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
      85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
      101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
      111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
      121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
      56, 57, 43, 47 };
  
  private static final byte[] q = new byte[] { 
      65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
      75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
      85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
      101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
      111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
      121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
      56, 57, 45, 95 };
  
  private static final byte[] r;
  
  private static final int s = 63;
  
  private final byte[] t;
  
  private final byte[] u;
  
  private final byte[] v;
  
  private final int w;
  
  private final int x;
  
  private int y;
  
  static {
    byte[] arrayOfByte = new byte[123];
    arrayOfByte[0] = (byte)-1;
    arrayOfByte[1] = (byte)-1;
    arrayOfByte[2] = (byte)-1;
    arrayOfByte[3] = (byte)-1;
    arrayOfByte[4] = (byte)-1;
    arrayOfByte[5] = (byte)-1;
    arrayOfByte[6] = (byte)-1;
    arrayOfByte[7] = (byte)-1;
    arrayOfByte[8] = (byte)-1;
    arrayOfByte[9] = (byte)-1;
    arrayOfByte[10] = (byte)-1;
    arrayOfByte[11] = (byte)-1;
    arrayOfByte[12] = (byte)-1;
    arrayOfByte[13] = (byte)-1;
    arrayOfByte[14] = (byte)-1;
    arrayOfByte[15] = (byte)-1;
    arrayOfByte[16] = (byte)-1;
    arrayOfByte[17] = (byte)-1;
    arrayOfByte[18] = (byte)-1;
    arrayOfByte[19] = (byte)-1;
    arrayOfByte[20] = (byte)-1;
    arrayOfByte[21] = (byte)-1;
    arrayOfByte[22] = (byte)-1;
    arrayOfByte[23] = (byte)-1;
    arrayOfByte[24] = (byte)-1;
    arrayOfByte[25] = (byte)-1;
    arrayOfByte[26] = (byte)-1;
    arrayOfByte[27] = (byte)-1;
    arrayOfByte[28] = (byte)-1;
    arrayOfByte[29] = (byte)-1;
    arrayOfByte[30] = (byte)-1;
    arrayOfByte[31] = (byte)-1;
    arrayOfByte[32] = (byte)-1;
    arrayOfByte[33] = (byte)-1;
    arrayOfByte[34] = (byte)-1;
    arrayOfByte[35] = (byte)-1;
    arrayOfByte[36] = (byte)-1;
    arrayOfByte[37] = (byte)-1;
    arrayOfByte[38] = (byte)-1;
    arrayOfByte[39] = (byte)-1;
    arrayOfByte[40] = (byte)-1;
    arrayOfByte[41] = (byte)-1;
    arrayOfByte[42] = (byte)-1;
    arrayOfByte[43] = (byte)62;
    arrayOfByte[44] = (byte)-1;
    arrayOfByte[45] = (byte)62;
    arrayOfByte[46] = (byte)-1;
    arrayOfByte[47] = (byte)63;
    arrayOfByte[48] = (byte)52;
    arrayOfByte[49] = (byte)53;
    arrayOfByte[50] = (byte)54;
    arrayOfByte[51] = (byte)55;
    arrayOfByte[52] = (byte)56;
    arrayOfByte[53] = (byte)57;
    arrayOfByte[54] = (byte)58;
    arrayOfByte[55] = (byte)59;
    arrayOfByte[56] = (byte)60;
    arrayOfByte[57] = (byte)61;
    arrayOfByte[58] = (byte)-1;
    arrayOfByte[59] = (byte)-1;
    arrayOfByte[60] = (byte)-1;
    arrayOfByte[61] = (byte)-1;
    arrayOfByte[62] = (byte)-1;
    arrayOfByte[63] = (byte)-1;
    arrayOfByte[64] = (byte)-1;
    arrayOfByte[66] = (byte)1;
    arrayOfByte[67] = (byte)2;
    arrayOfByte[68] = (byte)3;
    arrayOfByte[69] = (byte)4;
    arrayOfByte[70] = (byte)5;
    arrayOfByte[71] = (byte)6;
    arrayOfByte[72] = (byte)7;
    arrayOfByte[73] = (byte)8;
    arrayOfByte[74] = (byte)9;
    arrayOfByte[75] = (byte)10;
    arrayOfByte[76] = (byte)11;
    arrayOfByte[77] = (byte)12;
    arrayOfByte[78] = (byte)13;
    arrayOfByte[79] = (byte)14;
    arrayOfByte[80] = (byte)15;
    arrayOfByte[81] = (byte)16;
    arrayOfByte[82] = (byte)17;
    arrayOfByte[83] = (byte)18;
    arrayOfByte[84] = (byte)19;
    arrayOfByte[85] = (byte)20;
    arrayOfByte[86] = (byte)21;
    arrayOfByte[87] = (byte)22;
    arrayOfByte[88] = (byte)23;
    arrayOfByte[89] = (byte)24;
    arrayOfByte[90] = (byte)25;
    arrayOfByte[91] = (byte)-1;
    arrayOfByte[92] = (byte)-1;
    arrayOfByte[93] = (byte)-1;
    arrayOfByte[94] = (byte)-1;
    arrayOfByte[95] = (byte)63;
    arrayOfByte[96] = (byte)-1;
    arrayOfByte[97] = (byte)26;
    arrayOfByte[98] = (byte)27;
    arrayOfByte[99] = (byte)28;
    arrayOfByte[100] = (byte)29;
    arrayOfByte[101] = (byte)30;
    arrayOfByte[102] = (byte)31;
    arrayOfByte[103] = (byte)32;
    arrayOfByte[104] = (byte)33;
    arrayOfByte[105] = (byte)34;
    arrayOfByte[106] = (byte)35;
    arrayOfByte[107] = (byte)36;
    arrayOfByte[108] = (byte)37;
    arrayOfByte[109] = (byte)38;
    arrayOfByte[110] = (byte)39;
    arrayOfByte[111] = (byte)40;
    arrayOfByte[112] = (byte)41;
    arrayOfByte[113] = (byte)42;
    arrayOfByte[114] = (byte)43;
    arrayOfByte[115] = (byte)44;
    arrayOfByte[116] = (byte)45;
    arrayOfByte[117] = (byte)46;
    arrayOfByte[118] = (byte)47;
    arrayOfByte[119] = (byte)48;
    arrayOfByte[120] = (byte)49;
    arrayOfByte[121] = (byte)50;
    arrayOfByte[122] = (byte)51;
    r = arrayOfByte;
  }
  
  public c() {
    this(0);
  }
  
  public c(int paramInt) {
    this(paramInt, a);
  }
  
  public c(int paramInt, byte[] paramArrayOfbyte) {
    this(paramInt, paramArrayOfbyte, false);
  }
  
  public c(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) {
    super(3, 4, paramInt, i);
    int i;
    this.u = r;
    if (paramArrayOfbyte != null) {
      String str;
      if (n(paramArrayOfbyte)) {
        str = a.f(paramArrayOfbyte);
        throw new IllegalArgumentException("lineSeparator must not contain base64 characters: [" + str + "]");
      } 
      if (paramInt > 0) {
        this.x = str.length + 4;
        this.v = new byte[str.length];
        System.arraycopy(str, 0, this.v, 0, str.length);
      } else {
        this.x = 4;
        this.v = null;
      } 
    } else {
      this.x = 4;
      this.v = null;
    } 
    this.w = this.x - 1;
    if (paramBoolean) {
      paramArrayOfbyte = q;
    } else {
      paramArrayOfbyte = p;
    } 
    this.t = paramArrayOfbyte;
  }
  
  public c(boolean paramBoolean) {
    this(76, a, paramBoolean);
  }
  
  public static boolean a(byte paramByte) {
    return !(paramByte != 61 && (paramByte < 0 || paramByte >= r.length || r[paramByte] == -1));
  }
  
  public static boolean a(String paramString) {
    return b(a.f(paramString));
  }
  
  public static boolean a(byte[] paramArrayOfbyte) {
    return b(paramArrayOfbyte);
  }
  
  public static byte[] a(BigInteger paramBigInteger) {
    if (paramBigInteger == null)
      throw new NullPointerException("encodeInteger called with null parameter"); 
    return a(b(paramBigInteger), false);
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, boolean paramBoolean) {
    return a(paramArrayOfbyte, paramBoolean, false);
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2) {
    return a(paramArrayOfbyte, paramBoolean1, paramBoolean2, 2147483647);
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, boolean paramBoolean1, boolean paramBoolean2, int paramInt) {
    c c1;
    byte[] arrayOfByte = paramArrayOfbyte;
    if (paramArrayOfbyte != null) {
      if (paramArrayOfbyte.length == 0)
        return paramArrayOfbyte; 
    } else {
      return arrayOfByte;
    } 
    if (paramBoolean1) {
      c1 = new c(paramBoolean2);
    } else {
      c1 = new c(0, a, paramBoolean2);
    } 
    long l = c1.o(paramArrayOfbyte);
    if (l > paramInt)
      throw new IllegalArgumentException("Input array too big, the output array would be bigger (" + l + ") than the specified maximum size of " + paramInt); 
    return c1.l(paramArrayOfbyte);
  }
  
  public static boolean b(byte[] paramArrayOfbyte) {
    boolean bool = false;
    for (byte b = 0;; b++) {
      if (b >= paramArrayOfbyte.length)
        return true; 
      if (!a(paramArrayOfbyte[b])) {
        boolean bool1 = bool;
        if (c(paramArrayOfbyte[b]))
          continue; 
        return bool1;
      } 
      continue;
    } 
  }
  
  public static byte[] b(String paramString) {
    return (new c()).c(paramString);
  }
  
  static byte[] b(BigInteger paramBigInteger) {
    int i = paramBigInteger.bitLength() + 7 >> 3 << 3;
    byte[] arrayOfByte2 = paramBigInteger.toByteArray();
    if (paramBigInteger.bitLength() % 8 != 0 && paramBigInteger.bitLength() / 8 + 1 == i / 8)
      return arrayOfByte2; 
    boolean bool = false;
    int j = arrayOfByte2.length;
    int k = j;
    if (paramBigInteger.bitLength() % 8 == 0) {
      bool = true;
      k = j - 1;
    } 
    j = i / 8;
    byte[] arrayOfByte1 = new byte[i / 8];
    System.arraycopy(arrayOfByte2, bool, arrayOfByte1, j - k, k);
    return arrayOfByte1;
  }
  
  public static byte[] c(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, false);
  }
  
  public static String d(byte[] paramArrayOfbyte) {
    return a.f(a(paramArrayOfbyte, false));
  }
  
  public static byte[] e(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, false, true);
  }
  
  public static String f(byte[] paramArrayOfbyte) {
    return a.f(a(paramArrayOfbyte, false, true));
  }
  
  public static byte[] g(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, true);
  }
  
  public static byte[] h(byte[] paramArrayOfbyte) {
    return (new c()).k(paramArrayOfbyte);
  }
  
  public static BigInteger i(byte[] paramArrayOfbyte) {
    return new BigInteger(1, h(paramArrayOfbyte));
  }
  
  void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (!this.j) {
      if (paramInt2 < 0) {
        this.j = true;
        if (this.l != 0 || this.g != 0) {
          a(this.x);
          paramInt1 = this.i;
          switch (this.l) {
            default:
              paramInt2 = this.k;
              this.k = this.i - paramInt1 + paramInt2;
              if (this.g > 0 && this.k > 0) {
                System.arraycopy(this.v, 0, this.h, this.i, this.v.length);
                this.i += this.v.length;
              } 
              return;
            case 1:
              paramArrayOfbyte = this.h;
              paramInt2 = this.i;
              this.i = paramInt2 + 1;
              paramArrayOfbyte[paramInt2] = (byte)this.t[this.y >> 2 & 0x3F];
              paramArrayOfbyte = this.h;
              paramInt2 = this.i;
              this.i = paramInt2 + 1;
              paramArrayOfbyte[paramInt2] = (byte)this.t[this.y << 4 & 0x3F];
              if (this.t == p) {
                paramArrayOfbyte = this.h;
                paramInt2 = this.i;
                this.i = paramInt2 + 1;
                paramArrayOfbyte[paramInt2] = (byte)61;
                paramArrayOfbyte = this.h;
                paramInt2 = this.i;
                this.i = paramInt2 + 1;
                paramArrayOfbyte[paramInt2] = (byte)61;
              } 
            case 2:
              break;
          } 
          paramArrayOfbyte = this.h;
          paramInt2 = this.i;
          this.i = paramInt2 + 1;
          paramArrayOfbyte[paramInt2] = (byte)this.t[this.y >> 10 & 0x3F];
          paramArrayOfbyte = this.h;
          paramInt2 = this.i;
          this.i = paramInt2 + 1;
          paramArrayOfbyte[paramInt2] = (byte)this.t[this.y >> 4 & 0x3F];
          paramArrayOfbyte = this.h;
          paramInt2 = this.i;
          this.i = paramInt2 + 1;
          paramArrayOfbyte[paramInt2] = (byte)this.t[this.y << 2 & 0x3F];
          if (this.t == p) {
            paramArrayOfbyte = this.h;
            paramInt2 = this.i;
            this.i = paramInt2 + 1;
            paramArrayOfbyte[paramInt2] = (byte)61;
          } 
        } 
        return;
      } 
      byte b = 0;
      while (true) {
        if (b < paramInt2) {
          a(this.x);
          this.l = (this.l + 1) % 3;
          byte b1 = paramArrayOfbyte[paramInt1];
          int i = b1;
          if (b1 < 0)
            i = b1 + 256; 
          this.y = i + (this.y << 8);
          if (this.l == 0) {
            byte[] arrayOfByte = this.h;
            i = this.i;
            this.i = i + 1;
            arrayOfByte[i] = (byte)this.t[this.y >> 18 & 0x3F];
            arrayOfByte = this.h;
            i = this.i;
            this.i = i + 1;
            arrayOfByte[i] = (byte)this.t[this.y >> 12 & 0x3F];
            arrayOfByte = this.h;
            i = this.i;
            this.i = i + 1;
            arrayOfByte[i] = (byte)this.t[this.y >> 6 & 0x3F];
            arrayOfByte = this.h;
            i = this.i;
            this.i = i + 1;
            arrayOfByte[i] = (byte)this.t[this.y & 0x3F];
            this.k += 4;
            if (this.g > 0 && this.g <= this.k) {
              System.arraycopy(this.v, 0, this.h, this.i, this.v.length);
              this.i += this.v.length;
              this.k = 0;
            } 
          } 
          b++;
          paramInt1++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public boolean a() {
    return (this.t == q);
  }
  
  void b(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (this.j);
    if (paramInt2 < 0)
      this.j = true; 
    byte b = 0;
    while (true) {
      if (b < paramInt2) {
        a(this.w);
        byte b1 = paramArrayOfbyte[paramInt1];
        if (b1 == 61) {
          this.j = true;
        } else {
          if (b1 >= 0 && b1 < r.length) {
            b1 = r[b1];
            if (b1 >= 0) {
              this.l = (this.l + 1) % 4;
              this.y = b1 + (this.y << 6);
              if (this.l == 0) {
                byte[] arrayOfByte = this.h;
                int i = this.i;
                this.i = i + 1;
                arrayOfByte[i] = (byte)(byte)(this.y >> 16 & 0xFF);
                arrayOfByte = this.h;
                i = this.i;
                this.i = i + 1;
                arrayOfByte[i] = (byte)(byte)(this.y >> 8 & 0xFF);
                arrayOfByte = this.h;
                i = this.i;
                this.i = i + 1;
                arrayOfByte[i] = (byte)(byte)(this.y & 0xFF);
              } 
            } 
          } 
          b++;
          paramInt1++;
          continue;
        } 
      } 
      if (this.j && this.l != 0) {
        a(this.w);
        switch (this.l) {
          default:
            return;
          case 2:
            this.y >>= 4;
            paramArrayOfbyte = this.h;
            paramInt1 = this.i;
            this.i = paramInt1 + 1;
            paramArrayOfbyte[paramInt1] = (byte)(byte)(this.y & 0xFF);
          case 3:
            break;
        } 
        this.y >>= 2;
        paramArrayOfbyte = this.h;
        paramInt1 = this.i;
        this.i = paramInt1 + 1;
        paramArrayOfbyte[paramInt1] = (byte)(byte)(this.y >> 8 & 0xFF);
        paramArrayOfbyte = this.h;
        paramInt1 = this.i;
        this.i = paramInt1 + 1;
        paramArrayOfbyte[paramInt1] = (byte)(byte)(this.y & 0xFF);
      } 
    } 
  }
  
  protected boolean b(byte paramByte) {
    return (paramByte >= 0 && paramByte < this.u.length && this.u[paramByte] != -1);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */