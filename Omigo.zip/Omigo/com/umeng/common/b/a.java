package com.umeng.common.b;

import java.io.UnsupportedEncodingException;

public class a {
  private static IllegalStateException a(String paramString, UnsupportedEncodingException paramUnsupportedEncodingException) {
    return new IllegalStateException(String.valueOf(paramString) + ": " + paramUnsupportedEncodingException);
  }
  
  public static String a(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "ISO-8859-1");
  }
  
  public static String a(byte[] paramArrayOfbyte, String paramString) {
    if (paramArrayOfbyte == null)
      return null; 
    try {
      return new String(paramArrayOfbyte, paramString);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw a(paramString, unsupportedEncodingException);
    } 
  }
  
  public static byte[] a(String paramString) {
    return a(paramString, "ISO-8859-1");
  }
  
  public static byte[] a(String paramString1, String paramString2) {
    if (paramString1 == null)
      return null; 
    try {
      return paramString1.getBytes(paramString2);
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw a(paramString2, unsupportedEncodingException);
    } 
  }
  
  public static String b(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "US-ASCII");
  }
  
  public static byte[] b(String paramString) {
    return a(paramString, "US-ASCII");
  }
  
  public static String c(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "UTF-16");
  }
  
  public static byte[] c(String paramString) {
    return a(paramString, "UTF-16");
  }
  
  public static String d(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "UTF-16BE");
  }
  
  public static byte[] d(String paramString) {
    return a(paramString, "UTF-16BE");
  }
  
  public static String e(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "UTF-16LE");
  }
  
  public static byte[] e(String paramString) {
    return a(paramString, "UTF-16LE");
  }
  
  public static String f(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, "UTF-8");
  }
  
  public static byte[] f(String paramString) {
    return a(paramString, "UTF-8");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */