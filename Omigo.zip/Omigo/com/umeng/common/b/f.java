package com.umeng.common.b;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public class f {
  public static int a;
  
  public static String a(byte[] paramArrayOfbyte, String paramString) throws UnsupportedEncodingException, DataFormatException {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0)
      return null; 
    Inflater inflater = new Inflater();
    byte[] arrayOfByte = new byte[100];
    inflater.setInput(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    StringBuilder stringBuilder = new StringBuilder();
    while (true) {
      if (inflater.needsInput()) {
        inflater.end();
        return stringBuilder.toString();
      } 
      stringBuilder.append(new String(arrayOfByte, 0, inflater.inflate(arrayOfByte), paramString));
    } 
  }
  
  public static byte[] a(String paramString1, String paramString2) throws IOException {
    String str = null;
    if (g.c(paramString1))
      return (byte[])str; 
    Deflater deflater = new Deflater();
    deflater.setInput(paramString1.getBytes(paramString2));
    deflater.finish();
    byte[] arrayOfByte = new byte[8192];
    a = 0;
    try {
      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
      this();
    } finally {
      arrayOfByte = null;
    } 
    if (paramString2 != null)
      paramString2.close(); 
    throw arrayOfByte;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */