package com.umeng.common.b;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class g {
  public static final String a = System.getProperty("line.separator");
  
  private static final String b = "helper";
  
  public static String a() {
    return a(new Date());
  }
  
  public static String a(Context paramContext, long paramLong) {
    return (paramLong < 1000L) ? (String.valueOf((int)paramLong) + "B") : ((paramLong < 1000000L) ? (String.valueOf(Math.round((float)paramLong / 1000.0D)) + "K") : ((paramLong < 1000000000L) ? (String.valueOf((new DecimalFormat("#0.0")).format((float)paramLong / 1000000.0D)) + "M") : (String.valueOf((new DecimalFormat("#0.00")).format((float)paramLong / 1.0E9D)) + "G")));
  }
  
  public static String a(String paramString) {
    byte b = 0;
    if (paramString == null)
      return null; 
    try {
      byte[] arrayOfByte1 = paramString.getBytes();
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      messageDigest.reset();
      messageDigest.update(arrayOfByte1);
      byte[] arrayOfByte2 = messageDigest.digest();
      StringBuffer stringBuffer = new StringBuffer();
      this();
      while (true) {
        String str;
        if (b >= arrayOfByte2.length) {
          str = stringBuffer.toString();
          return str;
        } 
        str.append(String.format("%02X", new Object[] { Byte.valueOf(arrayOfByte2[b]) }));
        b++;
      } 
    } catch (Exception exception) {
      paramString = paramString.replaceAll("[^[a-z][A-Z][0-9][.][_]]", "");
    } 
    return paramString;
  }
  
  public static String a(Date paramDate) {
    return (paramDate == null) ? "" : (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(paramDate);
  }
  
  public static void a(Context paramContext, String paramString) {
    paramContext.startActivity(paramContext.getPackageManager().getLaunchIntentForPackage(paramString));
  }
  
  public static String b(String paramString) {
    String str;
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      messageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = messageDigest.digest();
      StringBuffer stringBuffer = new StringBuffer();
      this();
      for (byte b = 0;; b++) {
        if (b >= arrayOfByte.length)
          return stringBuffer.toString(); 
        stringBuffer.append(Integer.toHexString(arrayOfByte[b] & 0xFF));
      } 
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      Log.i("helper", "getMD5 error", noSuchAlgorithmException);
      str = "";
    } 
    return str;
  }
  
  public static boolean b(Context paramContext, String paramString) {
    boolean bool;
    try {
      Intent intent = new Intent();
      this("android.intent.action.VIEW", Uri.parse(paramString));
      paramContext.startActivity(intent);
      bool = true;
    } catch (Exception exception) {
      exception.printStackTrace();
      bool = false;
    } 
    return bool;
  }
  
  public static boolean c(String paramString) {
    return !(paramString != null && paramString.length() != 0);
  }
  
  public static boolean d(String paramString) {
    boolean bool = false;
    if (!c(paramString)) {
      paramString = paramString.trim().toLowerCase();
      if (paramString.startsWith("http://") || paramString.startsWith("https://"))
        bool = true; 
    } 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */