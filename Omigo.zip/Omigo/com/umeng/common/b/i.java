package com.umeng.common.b;

import android.content.Context;

public class i {
  private static float a = 1.0F;
  
  public i(Context paramContext) {
    a(paramContext);
  }
  
  public static int a(float paramFloat) {
    return (int)(a * paramFloat + 0.5F);
  }
  
  public static void a(Context paramContext) {
    a = (paramContext.getResources().getDisplayMetrics()).density;
  }
  
  public static int b(float paramFloat) {
    return (int)(paramFloat / a + 0.5F);
  }
  
  public static int c(float paramFloat) {
    return (int)(a * paramFloat + 0.5F);
  }
  
  public static int d(float paramFloat) {
    return (int)(paramFloat / a + 0.5F);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */