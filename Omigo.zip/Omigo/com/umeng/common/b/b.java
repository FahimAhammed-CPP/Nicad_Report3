package com.umeng.common.b;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class b {
  private static byte[] a = "uLi4/f4+Pb39.T19".getBytes();
  
  private static byte[] b = "nmeug.f9/Om+L823".getBytes();
  
  public static String a(String paramString1, String paramString2) throws Exception {
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(1, new SecretKeySpec(a, "AES"), new IvParameterSpec(b));
    return c.d(cipher.doFinal(paramString1.getBytes(paramString2)));
  }
  
  public static String b(String paramString1, String paramString2) throws Exception {
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(2, new SecretKeySpec(a, "AES"), new IvParameterSpec(b));
    return new String(cipher.doFinal(c.b(paramString1)), paramString2);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */