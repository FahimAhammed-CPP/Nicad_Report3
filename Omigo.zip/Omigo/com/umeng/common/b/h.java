package com.umeng.common.b;

import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class h {
  public static String a(Map<String, Object> paramMap, String paramString) {
    String str = paramString;
    if (paramMap != null) {
      if (paramMap.isEmpty())
        return paramString; 
    } else {
      return str;
    } 
    StringBuilder stringBuilder = new StringBuilder(paramString);
    Set<String> set = paramMap.keySet();
    if (!paramString.endsWith("?"))
      stringBuilder.append("?"); 
    Iterator<String> iterator = set.iterator();
    while (true) {
      if (!iterator.hasNext()) {
        stringBuilder.deleteCharAt(stringBuilder.length() - 1);
        return stringBuilder.toString();
      } 
      paramString = iterator.next();
      StringBuilder stringBuilder1 = (new StringBuilder(String.valueOf(URLEncoder.encode(paramString)))).append("=");
      if (paramMap.get(paramString) == null) {
        paramString = "";
      } else {
        paramString = paramMap.get(paramString).toString();
      } 
      stringBuilder.append(stringBuilder1.append(URLEncoder.encode(paramString)).append("&").toString());
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */