package com.umeng.common.b;

public class e {
  public static final String a = "ISO-8859-1";
  
  public static final String b = "US-ASCII";
  
  public static final String c = "UTF-16";
  
  public static final String d = "UTF-16BE";
  
  public static final String e = "UTF-16LE";
  
  public static final String f = "UTF-8";
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */