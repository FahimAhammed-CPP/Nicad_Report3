package com.umeng.common.b;

public abstract class d {
  private static final int a = 2;
  
  public static final int b = 76;
  
  public static final int c = 64;
  
  protected static final int d = 255;
  
  protected static final byte e = 61;
  
  private static final int m = 8192;
  
  protected final byte f = (byte)61;
  
  protected final int g;
  
  protected byte[] h;
  
  protected int i;
  
  protected boolean j;
  
  protected int k;
  
  protected int l;
  
  private final int n;
  
  private final int o;
  
  private final int p;
  
  private int q;
  
  protected d(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.n = paramInt1;
    this.o = paramInt2;
    if (paramInt3 > 0 && paramInt4 > 0) {
      paramInt1 = paramInt3 / paramInt2 * paramInt2;
    } else {
      paramInt1 = 0;
    } 
    this.g = paramInt1;
    this.p = paramInt4;
  }
  
  private void a() {
    if (this.h == null) {
      this.h = new byte[d()];
      this.i = 0;
      this.q = 0;
      return;
    } 
    byte[] arrayOfByte = new byte[this.h.length * 2];
    System.arraycopy(this.h, 0, arrayOfByte, 0, this.h.length);
    this.h = arrayOfByte;
  }
  
  protected static boolean c(byte paramByte) {
    switch (paramByte) {
      default:
        return false;
      case 9:
      case 10:
      case 13:
      case 32:
        break;
    } 
    return true;
  }
  
  private void e() {
    this.h = null;
    this.i = 0;
    this.q = 0;
    this.k = 0;
    this.l = 0;
    this.j = false;
  }
  
  public Object a(Object paramObject) throws Exception {
    if (!(paramObject instanceof byte[]))
      throw new Exception("Parameter supplied to Base-N encode is not a byte[]"); 
    return l((byte[])paramObject);
  }
  
  protected void a(int paramInt) {
    if (this.h == null || this.h.length < this.i + paramInt)
      a(); 
  }
  
  abstract void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  public Object b(Object paramObject) throws Exception {
    if (paramObject instanceof byte[])
      return k((byte[])paramObject); 
    if (paramObject instanceof String)
      return c((String)paramObject); 
    throw new Exception("Parameter supplied to Base-N decode is not a byte[] or a String");
  }
  
  abstract void b(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  boolean b() {
    return (this.h != null);
  }
  
  protected abstract boolean b(byte paramByte);
  
  public boolean b(byte[] paramArrayOfbyte, boolean paramBoolean) {
    boolean bool = false;
    for (byte b = 0;; b++) {
      if (b >= paramArrayOfbyte.length)
        return true; 
      if (!b(paramArrayOfbyte[b])) {
        boolean bool1 = bool;
        if (paramBoolean) {
          if (paramArrayOfbyte[b] != 61) {
            bool1 = bool;
            if (c(paramArrayOfbyte[b]))
              continue; 
            return bool1;
          } 
          continue;
        } 
        return bool1;
      } 
      continue;
    } 
  }
  
  int c() {
    return (this.h != null) ? (this.i - this.q) : 0;
  }
  
  int c(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    if (this.h != null) {
      paramInt2 = Math.min(c(), paramInt2);
      System.arraycopy(this.h, this.q, paramArrayOfbyte, paramInt1, paramInt2);
      this.q += paramInt2;
      paramInt1 = paramInt2;
      if (this.q >= this.i) {
        this.h = null;
        paramInt1 = paramInt2;
      } 
      return paramInt1;
    } 
    return this.j ? -1 : 0;
  }
  
  public byte[] c(String paramString) {
    return k(a.f(paramString));
  }
  
  protected int d() {
    return 8192;
  }
  
  public boolean d(String paramString) {
    return b(a.f(paramString), true);
  }
  
  public String j(byte[] paramArrayOfbyte) {
    return a.f(l(paramArrayOfbyte));
  }
  
  public byte[] k(byte[] paramArrayOfbyte) {
    e();
    byte[] arrayOfByte = paramArrayOfbyte;
    if (paramArrayOfbyte != null) {
      if (paramArrayOfbyte.length == 0)
        return paramArrayOfbyte; 
    } else {
      return arrayOfByte;
    } 
    b(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    b(paramArrayOfbyte, 0, -1);
    arrayOfByte = new byte[this.i];
    c(arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public byte[] l(byte[] paramArrayOfbyte) {
    e();
    byte[] arrayOfByte = paramArrayOfbyte;
    if (paramArrayOfbyte != null) {
      if (paramArrayOfbyte.length == 0)
        return paramArrayOfbyte; 
    } else {
      return arrayOfByte;
    } 
    a(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    a(paramArrayOfbyte, 0, -1);
    arrayOfByte = new byte[this.i - this.q];
    c(arrayOfByte, 0, arrayOfByte.length);
    return arrayOfByte;
  }
  
  public String m(byte[] paramArrayOfbyte) {
    return a.f(l(paramArrayOfbyte));
  }
  
  protected boolean n(byte[] paramArrayOfbyte) {
    boolean bool = false;
    if (paramArrayOfbyte == null)
      return bool; 
    byte b = 0;
    while (true) {
      boolean bool1 = bool;
      if (b < paramArrayOfbyte.length) {
        if (61 == paramArrayOfbyte[b] || b(paramArrayOfbyte[b]))
          return true; 
        b++;
        continue;
      } 
      return bool1;
    } 
  }
  
  public long o(byte[] paramArrayOfbyte) {
    long l1 = ((paramArrayOfbyte.length + this.n - 1) / this.n) * this.o;
    long l2 = l1;
    if (this.g > 0)
      l2 = l1 + (this.g + l1 - 1L) / this.g * this.p; 
    return l2;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */