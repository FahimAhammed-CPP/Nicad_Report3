package com.umeng.common.a;

import android.content.Context;
import com.umeng.common.c;

public class a {
  public static int a(Context paramContext) {
    return c.a(paramContext).b("umeng_common_description");
  }
  
  public static int b(Context paramContext) {
    return c.a(paramContext).b("umeng_common_progress_text");
  }
  
  public static int c(Context paramContext) {
    return c.a(paramContext).b("umeng_common_progress_bar");
  }
  
  public static int d(Context paramContext) {
    return c.a(paramContext).b("umeng_common_title");
  }
  
  public static int e(Context paramContext) {
    return c.a(paramContext).b("umeng_common_appIcon");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */