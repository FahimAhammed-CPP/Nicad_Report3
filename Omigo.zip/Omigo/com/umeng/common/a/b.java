package com.umeng.common.a;

import android.content.Context;
import com.umeng.common.c;

public class b {
  public static int a(Context paramContext) {
    return c.a(paramContext).d("umeng_common_download_notification");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/common/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */