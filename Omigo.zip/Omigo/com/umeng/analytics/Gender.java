package com.umeng.analytics;

public enum Gender {
  Female, Male, Unknown;
  
  static {
    Female = new Gender("Female", 1);
    Unknown = new Gender("Unknown", 2);
    a = new Gender[] { Male, Female, Unknown };
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/Gender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */