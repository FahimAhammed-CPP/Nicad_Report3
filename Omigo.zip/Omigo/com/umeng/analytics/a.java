package com.umeng.analytics;

class a {
  static final String A = "umeng_net_report_policy";
  
  static final String B = "umeng_last_config_time";
  
  static final String a = "Android";
  
  static final String b = "Android";
  
  static final String c = "4.0";
  
  static long d = 30000L;
  
  static final int e = 8;
  
  static final int f = 10;
  
  static boolean g = true;
  
  static boolean h = true;
  
  static boolean i = true;
  
  static boolean j = true;
  
  static boolean k = true;
  
  static String l = null;
  
  static String m = "last_send_time";
  
  static final Object n = new Object();
  
  static final String o = "MobclickAgent";
  
  static final String[] p = new String[] { "http://www.umeng.com/app_logs", "http://www.umeng.co/app_logs" };
  
  static final String q = "http://www.umeng.com/check_config_update";
  
  static final String r = "http://www.umeng.co/check_config_update";
  
  static boolean s = true;
  
  static final String t = "age";
  
  static final String u = "gender";
  
  static final String v = "user_id";
  
  static final String w = "id_source";
  
  static final String x = "traffics_up";
  
  static final String y = "traffics_down";
  
  static final String z = "umeng_local_report_policy";
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */