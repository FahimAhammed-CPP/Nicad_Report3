package com.umeng.analytics;

public class ReportPolicy {
  public static final int BATCH_AT_LAUNCH = 1;
  
  public static final int DAILY = 4;
  
  public static final int REALTIME = 0;
  
  public static final int WIFIONLY = 5;
  
  static final int a = 2;
  
  static final int b = 3;
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/ReportPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */