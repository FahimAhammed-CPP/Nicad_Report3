package com.umeng.analytics;

import android.content.Context;

class b {
  public static String a(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   4: ldc 'android.permission.ACCESS_NETWORK_STATE'
    //   6: aload_0
    //   7: invokevirtual getPackageName : ()Ljava/lang/String;
    //   10: invokevirtual checkPermission : (Ljava/lang/String;Ljava/lang/String;)I
    //   13: ifeq -> 20
    //   16: aconst_null
    //   17: astore_0
    //   18: aload_0
    //   19: areturn
    //   20: aload_0
    //   21: ldc 'connectivity'
    //   23: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   26: checkcast android/net/ConnectivityManager
    //   29: invokevirtual getActiveNetworkInfo : ()Landroid/net/NetworkInfo;
    //   32: astore_0
    //   33: aload_0
    //   34: ifnonnull -> 42
    //   37: aconst_null
    //   38: astore_0
    //   39: goto -> 18
    //   42: aload_0
    //   43: invokevirtual getType : ()I
    //   46: iconst_1
    //   47: if_icmpne -> 55
    //   50: aconst_null
    //   51: astore_0
    //   52: goto -> 18
    //   55: aload_0
    //   56: invokevirtual getExtraInfo : ()Ljava/lang/String;
    //   59: astore_0
    //   60: getstatic com/umeng/analytics/a.g : Z
    //   63: ifeq -> 90
    //   66: new java/lang/StringBuilder
    //   69: astore_1
    //   70: aload_1
    //   71: ldc 'net type:'
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: ldc 'TAG'
    //   78: aload_1
    //   79: aload_0
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual toString : ()Ljava/lang/String;
    //   86: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   89: pop
    //   90: aload_0
    //   91: ifnonnull -> 99
    //   94: aconst_null
    //   95: astore_0
    //   96: goto -> 18
    //   99: aload_0
    //   100: ldc 'cmwap'
    //   102: invokevirtual equals : (Ljava/lang/Object;)Z
    //   105: ifne -> 128
    //   108: aload_0
    //   109: ldc '3gwap'
    //   111: invokevirtual equals : (Ljava/lang/Object;)Z
    //   114: ifne -> 128
    //   117: aload_0
    //   118: ldc 'uniwap'
    //   120: invokevirtual equals : (Ljava/lang/Object;)Z
    //   123: istore_2
    //   124: iload_2
    //   125: ifeq -> 139
    //   128: ldc '10.0.0.172'
    //   130: astore_0
    //   131: goto -> 18
    //   134: astore_0
    //   135: aload_0
    //   136: invokevirtual printStackTrace : ()V
    //   139: aconst_null
    //   140: astore_0
    //   141: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   20	33	134	java/lang/Exception
    //   42	50	134	java/lang/Exception
    //   55	90	134	java/lang/Exception
    //   99	124	134	java/lang/Exception
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */