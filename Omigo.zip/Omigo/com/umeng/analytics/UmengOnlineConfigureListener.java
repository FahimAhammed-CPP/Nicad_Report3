package com.umeng.analytics;

import org.json.JSONObject;

public interface UmengOnlineConfigureListener {
  void onDataReceived(JSONObject paramJSONObject);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/UmengOnlineConfigureListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */