package com.umeng.analytics;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import com.umeng.common.Log;
import com.umeng.common.b.f;
import com.umeng.common.b.g;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import javax.microedition.khronos.opengles.GL10;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MobclickAgent {
  private static final String A = "appkey";
  
  private static final String B = "body";
  
  private static final String C = "session_id";
  
  private static final String D = "date";
  
  private static final String E = "time";
  
  private static final String F = "start_millis";
  
  private static final String G = "end_millis";
  
  private static final String H = "duration";
  
  private static final String I = "activities";
  
  private static final String J = "header";
  
  private static final String K = "uptr";
  
  private static final String L = "dntr";
  
  private static final String M = "acc";
  
  private static final String N = "tag";
  
  private static final String O = "label";
  
  private static final String P = "id";
  
  private static final String Q = "ts";
  
  private static final String R = "du";
  
  private static final String S = "context";
  
  private static final String T = "last_config_time";
  
  private static final String U = "report_policy";
  
  private static final String V = "online_params";
  
  static String a;
  
  static String b;
  
  static boolean c = false;
  
  private static final MobclickAgent d = new MobclickAgent();
  
  private static int e = 1;
  
  private static final int h = 0;
  
  private static final int i = 1;
  
  private static final int j = 2;
  
  private static final int k = 3;
  
  private static final int l = 4;
  
  private static final int m = 5;
  
  private static final int n = 6;
  
  private static UmengOnlineConfigureListener o = null;
  
  private static final String p = "type";
  
  private static final String q = "subtype";
  
  private static final String r = "error";
  
  private static final String s = "event";
  
  private static final String t = "ekv";
  
  private static final String u = "launch";
  
  private static final String v = "flush";
  
  private static final String w = "terminate";
  
  private static final String x = "online_config";
  
  private static final String y = "cache_error";
  
  private static final String z = "send_error";
  
  private Context f;
  
  private final Handler g;
  
  static {
    a = "";
    b = "";
    c = true;
  }
  
  private MobclickAgent() {
    HandlerThread handlerThread = new HandlerThread("MobclickAgent");
    handlerThread.start();
    this.g = new Handler(handlerThread.getLooper());
  }
  
  static SharedPreferences a(Context paramContext) {
    String str = paramContext.getPackageName();
    return paramContext.getSharedPreferences("mobclick_agent_user_" + str, 0);
  }
  
  private String a(Context paramContext, SharedPreferences paramSharedPreferences) {
    long l = System.currentTimeMillis();
    SharedPreferences.Editor editor = paramSharedPreferences.edit();
    editor.putLong("start_millis", Long.valueOf(l).longValue());
    editor.putLong("end_millis", -1L);
    editor.commit();
    return paramSharedPreferences.getString("session_id", null);
  }
  
  private String a(Context paramContext, String paramString, long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramLong).append(paramString).append(g.b(com.umeng.common.b.f(paramContext)));
    return g.a(stringBuilder.toString());
  }
  
  private String a(Context paramContext, String paramString, SharedPreferences paramSharedPreferences) {
    c(paramContext, paramSharedPreferences);
    long l = System.currentTimeMillis();
    String str = a(paramContext, paramString, l);
    SharedPreferences.Editor editor = paramSharedPreferences.edit();
    editor.putString("appkey", paramString);
    editor.putString("session_id", str);
    editor.putLong("start_millis", l);
    editor.putLong("end_millis", -1L);
    editor.putLong("duration", 0L);
    editor.putString("activities", "");
    editor.commit();
    b(paramContext, paramSharedPreferences);
    return str;
  }
  
  private static String a(Context paramContext, JSONObject paramJSONObject, String paramString1, boolean paramBoolean, String paramString2) {
    String str;
    paramString2 = null;
    HttpPost httpPost = new HttpPost(paramString1);
    BasicHttpParams basicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout((HttpParams)basicHttpParams, 10000);
    HttpConnectionParams.setSoTimeout((HttpParams)basicHttpParams, 30000);
    DefaultHttpClient defaultHttpClient = new DefaultHttpClient((HttpParams)basicHttpParams);
    httpPost.addHeader("X-Umeng-Sdk", getUmengHttpHeader(paramContext));
    try {
      InputStreamEntity inputStreamEntity;
      String str1 = b.a(paramContext);
      if (str1 != null) {
        HttpHost httpHost = new HttpHost();
        this(str1, 80);
        defaultHttpClient.getParams().setParameter("http.route.default-proxy", httpHost);
      } 
      String str2 = paramJSONObject.toString();
      Log.a("MobclickAgent", str2);
      if (a.s && !paramBoolean) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        byte[] arrayOfByte = f.a(stringBuilder.append("content=").append(str2).toString(), "utf-8");
        httpPost.addHeader("Content-Encoding", "deflate");
        inputStreamEntity = new InputStreamEntity();
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream();
        this(arrayOfByte);
        this(byteArrayInputStream, f.a);
        httpPost.setEntity((HttpEntity)inputStreamEntity);
      } else {
        ArrayList<BasicNameValuePair> arrayList = new ArrayList();
        this(1);
        BasicNameValuePair basicNameValuePair = new BasicNameValuePair();
        this("content", (String)inputStreamEntity);
        arrayList.add(basicNameValuePair);
        UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity();
        this(arrayList, "UTF-8");
        httpPost.setEntity((HttpEntity)urlEncodedFormEntity);
      } 
      SharedPreferences.Editor editor = i(paramContext).edit();
      Date date1 = new Date();
      this();
      HttpResponse httpResponse = defaultHttpClient.execute((HttpUriRequest)httpPost);
      Date date2 = new Date();
      this();
      long l1 = date2.getTime();
      long l2 = date1.getTime();
      if (httpResponse.getStatusLine().getStatusCode() == 200) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        Log.a("MobclickAgent", stringBuilder.append("Sent message to ").append(paramString1).toString());
        editor.putLong("req_time", l1 - l2);
        editor.commit();
        HttpEntity httpEntity = httpResponse.getEntity();
        str = paramString2;
        if (httpEntity != null)
          str = a(httpEntity.getContent()); 
        return str;
      } 
      str.putLong("req_time", -1L);
      str = paramString2;
    } catch (ClientProtocolException clientProtocolException) {
      Log.a("MobclickAgent", "ClientProtocolException,Failed to send message.", (Exception)clientProtocolException);
      str = paramString2;
    } catch (IOException iOException) {
      Log.a("MobclickAgent", "IOException,Failed to send message.", iOException);
      str = paramString2;
    } 
    return str;
  }
  
  private static String a(InputStream paramInputStream) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: new java/io/BufferedReader
    //   5: dup
    //   6: new java/io/InputStreamReader
    //   9: dup
    //   10: aload_0
    //   11: invokespecial <init> : (Ljava/io/InputStream;)V
    //   14: sipush #8192
    //   17: invokespecial <init> : (Ljava/io/Reader;I)V
    //   20: astore_2
    //   21: new java/lang/StringBuilder
    //   24: dup
    //   25: invokespecial <init> : ()V
    //   28: astore_3
    //   29: aload_2
    //   30: invokevirtual readLine : ()Ljava/lang/String;
    //   33: astore #4
    //   35: aload #4
    //   37: ifnull -> 92
    //   40: new java/lang/StringBuilder
    //   43: astore #5
    //   45: aload #5
    //   47: invokespecial <init> : ()V
    //   50: aload_3
    //   51: aload #5
    //   53: aload #4
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: ldc_w '\\n'
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: pop
    //   71: goto -> 29
    //   74: astore_2
    //   75: ldc 'MobclickAgent'
    //   77: ldc_w 'Caught IOException in convertStreamToString()'
    //   80: aload_2
    //   81: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   84: aload_0
    //   85: invokevirtual close : ()V
    //   88: aload_1
    //   89: astore_0
    //   90: aload_0
    //   91: areturn
    //   92: aload_0
    //   93: invokevirtual close : ()V
    //   96: aload_3
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: astore_0
    //   101: goto -> 90
    //   104: astore_0
    //   105: ldc 'MobclickAgent'
    //   107: ldc_w 'Caught IOException in convertStreamToString()'
    //   110: aload_0
    //   111: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   114: aload_1
    //   115: astore_0
    //   116: goto -> 90
    //   119: astore_0
    //   120: ldc 'MobclickAgent'
    //   122: ldc_w 'Caught IOException in convertStreamToString()'
    //   125: aload_0
    //   126: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   129: aload_1
    //   130: astore_0
    //   131: goto -> 90
    //   134: astore_2
    //   135: aload_0
    //   136: invokevirtual close : ()V
    //   139: aload_2
    //   140: athrow
    //   141: astore_0
    //   142: ldc 'MobclickAgent'
    //   144: ldc_w 'Caught IOException in convertStreamToString()'
    //   147: aload_0
    //   148: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   151: aload_1
    //   152: astore_0
    //   153: goto -> 90
    // Exception table:
    //   from	to	target	type
    //   29	35	74	java/io/IOException
    //   29	35	134	finally
    //   40	71	74	java/io/IOException
    //   40	71	134	finally
    //   75	84	134	finally
    //   84	88	119	java/io/IOException
    //   92	96	104	java/io/IOException
    //   135	139	141	java/io/IOException
  }
  
  private JSONArray a(JSONObject paramJSONObject, JSONArray paramJSONArray) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'tag'
    //   3: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   6: astore_3
    //   7: aload_1
    //   8: ldc 'label'
    //   10: invokevirtual has : (Ljava/lang/String;)Z
    //   13: ifeq -> 133
    //   16: aload_1
    //   17: ldc 'label'
    //   19: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   22: astore #4
    //   24: aload_1
    //   25: ldc 'date'
    //   27: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   30: astore #5
    //   32: aload_2
    //   33: invokevirtual length : ()I
    //   36: iconst_1
    //   37: isub
    //   38: istore #6
    //   40: iload #6
    //   42: iflt -> 248
    //   45: aload_2
    //   46: iload #6
    //   48: invokevirtual get : (I)Ljava/lang/Object;
    //   51: checkcast org/json/JSONObject
    //   54: astore #7
    //   56: aload #4
    //   58: ifnonnull -> 139
    //   61: aload #7
    //   63: ldc 'label'
    //   65: invokevirtual has : (Ljava/lang/String;)Z
    //   68: ifne -> 139
    //   71: aload_3
    //   72: aload #7
    //   74: ldc 'tag'
    //   76: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   79: invokevirtual equals : (Ljava/lang/Object;)Z
    //   82: ifeq -> 221
    //   85: aload #5
    //   87: aload #7
    //   89: ldc 'date'
    //   91: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   94: invokevirtual equals : (Ljava/lang/Object;)Z
    //   97: ifeq -> 221
    //   100: aload #7
    //   102: ldc 'acc'
    //   104: aload #7
    //   106: ldc 'acc'
    //   108: invokevirtual getInt : (Ljava/lang/String;)I
    //   111: iconst_1
    //   112: iadd
    //   113: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   116: pop
    //   117: iconst_1
    //   118: istore #6
    //   120: iload #6
    //   122: ifne -> 131
    //   125: aload_2
    //   126: aload_1
    //   127: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   130: pop
    //   131: aload_2
    //   132: areturn
    //   133: aconst_null
    //   134: astore #4
    //   136: goto -> 24
    //   139: aload #4
    //   141: ifnull -> 221
    //   144: aload #7
    //   146: ldc 'label'
    //   148: invokevirtual has : (Ljava/lang/String;)Z
    //   151: ifeq -> 221
    //   154: aload_3
    //   155: aload #7
    //   157: ldc 'tag'
    //   159: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   162: invokevirtual equals : (Ljava/lang/Object;)Z
    //   165: ifeq -> 221
    //   168: aload #4
    //   170: aload #7
    //   172: ldc 'label'
    //   174: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   177: invokevirtual equals : (Ljava/lang/Object;)Z
    //   180: ifeq -> 221
    //   183: aload #5
    //   185: aload #7
    //   187: ldc 'date'
    //   189: invokevirtual get : (Ljava/lang/String;)Ljava/lang/Object;
    //   192: invokevirtual equals : (Ljava/lang/Object;)Z
    //   195: ifeq -> 221
    //   198: aload #7
    //   200: ldc 'acc'
    //   202: aload #7
    //   204: ldc 'acc'
    //   206: invokevirtual getInt : (Ljava/lang/String;)I
    //   209: iconst_1
    //   210: iadd
    //   211: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   214: pop
    //   215: iconst_1
    //   216: istore #6
    //   218: goto -> 120
    //   221: iinc #6, -1
    //   224: goto -> 40
    //   227: astore #4
    //   229: ldc 'MobclickAgent'
    //   231: ldc_w 'custom log merge error in tryToSendMessage'
    //   234: aload #4
    //   236: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   239: aload_2
    //   240: aload_1
    //   241: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   244: pop
    //   245: goto -> 131
    //   248: iconst_0
    //   249: istore #6
    //   251: goto -> 120
    // Exception table:
    //   from	to	target	type
    //   0	24	227	java/lang/Exception
    //   24	40	227	java/lang/Exception
    //   45	56	227	java/lang/Exception
    //   61	117	227	java/lang/Exception
    //   125	131	227	java/lang/Exception
    //   144	215	227	java/lang/Exception
  }
  
  private static void a(Context paramContext, int paramInt) {
    if (paramInt < 0 || paramInt > 5) {
      Log.b("MobclickAgent", "Illegal value of report policy");
      return;
    } 
    null = n(paramContext);
    synchronized (a.n) {
      null.edit().putInt("umeng_local_report_policy", paramInt).commit();
      return;
    } 
  }
  
  private void a(Context paramContext, SharedPreferences paramSharedPreferences, String paramString1, String paramString2, long paramLong, int paramInt) {
    String str1 = paramSharedPreferences.getString("session_id", "");
    String str2 = b();
    String str3 = str2.split(" ")[0];
    String str4 = str2.split(" ")[1];
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("type", "event");
      jSONObject.put("session_id", str1);
      jSONObject.put("date", str3);
      jSONObject.put("time", str4);
      jSONObject.put("tag", paramString1);
      if (paramString2 != null)
        jSONObject.put("label", paramString2); 
      if (paramLong > 0L)
        jSONObject.put("du", paramLong); 
      jSONObject.put("acc", paramInt);
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.a("MobclickAgent", "json error in emitCustomLogReport", (Exception)jSONException);
    } 
  }
  
  private void a(Context paramContext, SharedPreferences paramSharedPreferences, String paramString, JSONObject paramJSONObject) {
    String str = paramSharedPreferences.getString("session_id", "");
    JSONObject jSONObject = new JSONObject();
    JSONArray jSONArray = new JSONArray();
    try {
      paramJSONObject.put("id", paramString);
      paramJSONObject.put("ts", System.currentTimeMillis() / 1000L);
      jSONArray.put(paramJSONObject);
      jSONObject.put("type", "ekv");
      jSONObject.put(str, jSONArray);
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.a("MobclickAgent", "json error in emitCustomLogReport", (Exception)jSONException);
      jSONException.printStackTrace();
    } 
  }
  
  private void a(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic b : (Landroid/content/Context;)Ljava/lang/String;
    //   6: astore_2
    //   7: aload_2
    //   8: ldc ''
    //   10: if_acmpeq -> 25
    //   13: aload_2
    //   14: invokevirtual length : ()I
    //   17: istore_3
    //   18: iload_3
    //   19: sipush #10240
    //   22: if_icmple -> 28
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: aload_0
    //   29: aload_1
    //   30: aload_2
    //   31: ldc 'cache_error'
    //   33: invokespecial c : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   36: goto -> 25
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	39	finally
    //   13	18	39	finally
    //   28	36	39	finally
  }
  
  private void a(Context paramContext, String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield f : Landroid/content/Context;
    //   7: aload_1
    //   8: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   11: astore_3
    //   12: aload_3
    //   13: ifnonnull -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: aload_3
    //   21: invokespecial a : (Landroid/content/SharedPreferences;)Z
    //   24: ifeq -> 70
    //   27: aload_0
    //   28: aload_1
    //   29: aload_2
    //   30: aload_3
    //   31: invokespecial a : (Landroid/content/Context;Ljava/lang/String;Landroid/content/SharedPreferences;)Ljava/lang/String;
    //   34: astore_1
    //   35: new java/lang/StringBuilder
    //   38: astore_2
    //   39: aload_2
    //   40: invokespecial <init> : ()V
    //   43: ldc 'MobclickAgent'
    //   45: aload_2
    //   46: ldc_w 'Start new session: '
    //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: aload_1
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   62: goto -> 16
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: athrow
    //   70: aload_0
    //   71: aload_1
    //   72: aload_3
    //   73: invokespecial a : (Landroid/content/Context;Landroid/content/SharedPreferences;)Ljava/lang/String;
    //   76: astore_2
    //   77: new java/lang/StringBuilder
    //   80: astore_1
    //   81: aload_1
    //   82: invokespecial <init> : ()V
    //   85: ldc 'MobclickAgent'
    //   87: aload_1
    //   88: ldc_w 'Extend current session: '
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: aload_2
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: invokevirtual toString : ()Ljava/lang/String;
    //   101: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   104: goto -> 16
    // Exception table:
    //   from	to	target	type
    //   2	12	65	finally
    //   19	62	65	finally
    //   70	104	65	finally
  }
  
  private static void a(Context paramContext, String paramString1, String paramString2, long paramLong, int paramInt) {
    if (paramContext != null) {
      try {
        if (TextUtils.isEmpty(paramString1) || paramInt <= 0) {
          a("invalid params in onEvent");
          return;
        } 
        a a = new a();
        this(paramContext, paramString1, paramString2, paramLong, paramInt, 3);
        a.start();
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in Mobclick.onEvent(). ", exception);
      } 
      return;
    } 
    a("invalid params in onEvent");
  }
  
  private static void a(Context paramContext, String paramString, Map<String, String> paramMap, long paramLong) {
    if (paramContext != null) {
      try {
        if (TextUtils.isEmpty(paramString)) {
          a("invalid params in onKVEventEnd");
          return;
        } 
        if (paramMap == null || paramMap.isEmpty()) {
          a("map is null or empty in onEvent");
          return;
        } 
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in Mobclick.onEvent(). ", exception);
        return;
      } 
      a a = new a();
      this((Context)exception, paramString, paramMap, paramLong, 4);
      a.start();
      return;
    } 
    a("invalid params in onKVEventEnd");
  }
  
  private void a(Context paramContext, String paramString1, Map<String, String> paramMap, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   6: astore #5
    //   8: aload #5
    //   10: ifnonnull -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: new java/lang/StringBuilder
    //   19: astore #6
    //   21: aload #6
    //   23: invokespecial <init> : ()V
    //   26: aload_1
    //   27: aload #6
    //   29: ldc_w '_kvts'
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: aload_2
    //   36: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: aload #4
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokevirtual toString : ()Ljava/lang/String;
    //   47: invokestatic d : (Landroid/content/Context;Ljava/lang/String;)V
    //   50: new org/json/JSONObject
    //   53: astore_1
    //   54: aload_1
    //   55: invokespecial <init> : ()V
    //   58: aload_3
    //   59: invokeinterface entrySet : ()Ljava/util/Set;
    //   64: invokeinterface iterator : ()Ljava/util/Iterator;
    //   69: astore_3
    //   70: iconst_0
    //   71: istore #7
    //   73: aload_3
    //   74: invokeinterface hasNext : ()Z
    //   79: ifne -> 89
    //   82: iload #7
    //   84: bipush #10
    //   86: if_icmple -> 131
    //   89: aload_3
    //   90: invokeinterface next : ()Ljava/lang/Object;
    //   95: checkcast java/util/Map$Entry
    //   98: astore #6
    //   100: aload_1
    //   101: aload #6
    //   103: invokeinterface getKey : ()Ljava/lang/Object;
    //   108: checkcast java/lang/String
    //   111: aload #6
    //   113: invokeinterface getValue : ()Ljava/lang/Object;
    //   118: checkcast java/lang/String
    //   121: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   124: pop
    //   125: iinc #7, 1
    //   128: goto -> 73
    //   131: aload #5
    //   133: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   138: astore_3
    //   139: new java/lang/StringBuilder
    //   142: astore #5
    //   144: aload #5
    //   146: invokespecial <init> : ()V
    //   149: aload_3
    //   150: aload #5
    //   152: ldc_w '_kvvl'
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_2
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: aload #4
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: invokevirtual toString : ()Ljava/lang/String;
    //   170: aload_1
    //   171: invokevirtual toString : ()Ljava/lang/String;
    //   174: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   179: invokeinterface commit : ()Z
    //   184: pop
    //   185: goto -> 13
    //   188: astore_1
    //   189: aload_1
    //   190: invokevirtual printStackTrace : ()V
    //   193: goto -> 13
    //   196: astore_1
    //   197: aload_0
    //   198: monitorexit
    //   199: aload_1
    //   200: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	196	finally
    //   16	70	188	java/lang/Exception
    //   16	70	196	finally
    //   73	82	188	java/lang/Exception
    //   73	82	196	finally
    //   89	125	188	java/lang/Exception
    //   89	125	196	finally
    //   131	185	188	java/lang/Exception
    //   131	185	196	finally
    //   189	193	196	finally
  }
  
  private void a(Context paramContext, JSONObject paramJSONObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_1
    //   3: invokestatic i : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   6: astore #4
    //   8: aload_1
    //   9: invokestatic e : (Landroid/content/Context;)Lorg/json/JSONObject;
    //   12: astore #5
    //   14: aload #4
    //   16: ldc_w 'req_time'
    //   19: lconst_0
    //   20: invokeinterface getLong : (Ljava/lang/String;J)J
    //   25: lstore #6
    //   27: lload #6
    //   29: lconst_0
    //   30: lcmp
    //   31: ifeq -> 45
    //   34: aload #5
    //   36: ldc_w 'req_time'
    //   39: lload #6
    //   41: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   44: pop
    //   45: aload #4
    //   47: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   52: ldc 'header'
    //   54: aload #5
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   64: invokeinterface commit : ()Z
    //   69: pop
    //   70: aload_1
    //   71: invokestatic g : (Landroid/content/Context;)Lorg/json/JSONObject;
    //   74: astore #8
    //   76: new org/json/JSONObject
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore #9
    //   85: aload_2
    //   86: ldc 'type'
    //   88: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   91: astore #10
    //   93: aload #10
    //   95: ifnonnull -> 114
    //   98: return
    //   99: astore #11
    //   101: ldc 'MobclickAgent'
    //   103: ldc_w 'json error in tryToSendMessage'
    //   106: aload #11
    //   108: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   111: goto -> 45
    //   114: aload_2
    //   115: ldc 'subtype'
    //   117: invokevirtual has : (Ljava/lang/String;)Z
    //   120: ifeq -> 487
    //   123: aload_2
    //   124: ldc 'subtype'
    //   126: invokevirtual remove : (Ljava/lang/String;)Ljava/lang/Object;
    //   129: checkcast java/lang/String
    //   132: astore #4
    //   134: aload #8
    //   136: astore #11
    //   138: aload #10
    //   140: ldc 'flush'
    //   142: if_acmpeq -> 198
    //   145: aload_2
    //   146: ldc 'type'
    //   148: invokevirtual remove : (Ljava/lang/String;)Ljava/lang/Object;
    //   151: pop
    //   152: aload #8
    //   154: ifnull -> 279
    //   157: aload #8
    //   159: aload #10
    //   161: invokevirtual isNull : (Ljava/lang/String;)Z
    //   164: ifeq -> 231
    //   167: new org/json/JSONArray
    //   170: astore #11
    //   172: aload #11
    //   174: invokespecial <init> : ()V
    //   177: aload #11
    //   179: aload_2
    //   180: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   183: pop
    //   184: aload #8
    //   186: aload #10
    //   188: aload #11
    //   190: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   193: pop
    //   194: aload #8
    //   196: astore #11
    //   198: aload #11
    //   200: ifnonnull -> 319
    //   203: ldc 'MobclickAgent'
    //   205: ldc_w 'No cache message to flush in tryToSendMessage'
    //   208: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)V
    //   211: goto -> 98
    //   214: astore_2
    //   215: ldc 'MobclickAgent'
    //   217: ldc_w 'Fail to construct json message in tryToSendMessage.'
    //   220: aload_2
    //   221: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   224: aload_1
    //   225: invokestatic h : (Landroid/content/Context;)V
    //   228: goto -> 98
    //   231: aload #8
    //   233: aload #10
    //   235: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   238: astore #11
    //   240: ldc 'ekv'
    //   242: aload #10
    //   244: invokevirtual equals : (Ljava/lang/Object;)Z
    //   247: ifeq -> 265
    //   250: aload_0
    //   251: aload_2
    //   252: aload #11
    //   254: invokespecial b : (Lorg/json/JSONObject;Lorg/json/JSONArray;)Lorg/json/JSONArray;
    //   257: pop
    //   258: aload #8
    //   260: astore #11
    //   262: goto -> 198
    //   265: aload #11
    //   267: aload_2
    //   268: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   271: pop
    //   272: aload #8
    //   274: astore #11
    //   276: goto -> 198
    //   279: new org/json/JSONObject
    //   282: astore #11
    //   284: aload #11
    //   286: invokespecial <init> : ()V
    //   289: new org/json/JSONArray
    //   292: astore #8
    //   294: aload #8
    //   296: invokespecial <init> : ()V
    //   299: aload #8
    //   301: aload_2
    //   302: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   305: pop
    //   306: aload #11
    //   308: aload #10
    //   310: aload #8
    //   312: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   315: pop
    //   316: goto -> 198
    //   319: aload #9
    //   321: ldc 'header'
    //   323: aload #5
    //   325: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   328: pop
    //   329: aload #9
    //   331: ldc 'body'
    //   333: aload #11
    //   335: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   338: pop
    //   339: aload #10
    //   341: aload_1
    //   342: iconst_1
    //   343: anewarray java/lang/String
    //   346: dup
    //   347: iconst_0
    //   348: aload #4
    //   350: aastore
    //   351: invokestatic a : (Ljava/lang/String;Landroid/content/Context;[Ljava/lang/String;)Z
    //   354: ifeq -> 478
    //   357: iconst_0
    //   358: istore #12
    //   360: aload_3
    //   361: astore_2
    //   362: iload #12
    //   364: getstatic com/umeng/analytics/a.p : [Ljava/lang/String;
    //   367: arraylength
    //   368: if_icmpge -> 391
    //   371: aload_1
    //   372: aload #9
    //   374: getstatic com/umeng/analytics/a.p : [Ljava/lang/String;
    //   377: iload #12
    //   379: aaload
    //   380: iconst_0
    //   381: aload #10
    //   383: invokestatic a : (Landroid/content/Context;Lorg/json/JSONObject;Ljava/lang/String;ZLjava/lang/String;)Ljava/lang/String;
    //   386: astore_2
    //   387: aload_2
    //   388: ifnull -> 464
    //   391: aload_2
    //   392: ifnull -> 470
    //   395: ldc 'MobclickAgent'
    //   397: new java/lang/StringBuilder
    //   400: dup
    //   401: invokespecial <init> : ()V
    //   404: ldc_w 'send applog succeed :'
    //   407: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   410: aload_2
    //   411: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   414: invokevirtual toString : ()Ljava/lang/String;
    //   417: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   420: aload_1
    //   421: invokestatic h : (Landroid/content/Context;)V
    //   424: getstatic com/umeng/analytics/MobclickAgent.e : I
    //   427: iconst_4
    //   428: if_icmpne -> 98
    //   431: aload_1
    //   432: invokestatic j : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   435: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   440: astore_1
    //   441: aload_1
    //   442: invokestatic c : ()Ljava/lang/String;
    //   445: ldc_w 'true'
    //   448: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   453: pop
    //   454: aload_1
    //   455: invokeinterface commit : ()Z
    //   460: pop
    //   461: goto -> 98
    //   464: iinc #12, 1
    //   467: goto -> 362
    //   470: ldc 'MobclickAgent'
    //   472: ldc_w 'send applog failed'
    //   475: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   478: aload_1
    //   479: aload #11
    //   481: invokestatic b : (Landroid/content/Context;Lorg/json/JSONObject;)V
    //   484: goto -> 98
    //   487: aconst_null
    //   488: astore #4
    //   490: goto -> 134
    // Exception table:
    //   from	to	target	type
    //   34	45	99	org/json/JSONException
    //   85	93	214	org/json/JSONException
    //   114	134	214	org/json/JSONException
    //   145	152	214	org/json/JSONException
    //   157	194	214	org/json/JSONException
    //   203	211	214	org/json/JSONException
    //   231	258	214	org/json/JSONException
    //   265	272	214	org/json/JSONException
    //   279	316	214	org/json/JSONException
    //   319	339	214	org/json/JSONException
  }
  
  private static void a(String paramString) {
    Log.a("MobclickAgent", paramString);
  }
  
  private boolean a(SharedPreferences paramSharedPreferences) {
    long l = paramSharedPreferences.getLong("end_millis", -1L);
    return (System.currentTimeMillis() - l > a.d);
  }
  
  private static boolean a(String paramString, Context paramContext, String... paramVarArgs) {
    boolean bool = false;
    if (paramContext.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", paramContext.getPackageName()) == 0 && !com.umeng.common.b.m(paramContext))
      return bool; 
    if (paramString == "online_config")
      return true; 
    if (com.umeng.common.b.k(paramContext))
      return true; 
    e = o(paramContext);
    if (e == 3) {
      boolean bool1 = bool;
      if (paramString == "flush")
        bool1 = true; 
      return bool1;
    } 
    if (paramString == "error") {
      if (paramVarArgs != null && paramVarArgs.length > 0) {
        boolean bool1 = bool;
        return !paramVarArgs[0].equals("send_error") ? true : bool1;
      } 
    } else {
      if (e == 1 && paramString == "launch")
        return true; 
      if (e == 2 && paramString == "terminate")
        return true; 
      if (e == 0)
        return true; 
      if (e == 4) {
        boolean bool2 = bool;
        if (!j(paramContext).getString(com.umeng.common.b.c(), "false").equals("true")) {
          bool2 = bool;
          if (paramString.equals("launch"))
            bool2 = true; 
        } 
        return bool2;
      } 
      boolean bool1 = bool;
      if (e == 5)
        bool1 = com.umeng.common.b.k(paramContext); 
      return bool1;
    } 
    return true;
  }
  
  private static String b() {
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
  }
  
  private static String b(Context paramContext) {
    String str;
    try {
      String str1 = paramContext.getPackageName();
      ArrayList<String> arrayList = new ArrayList();
      this();
      arrayList.add("logcat");
      arrayList.add("-d");
      arrayList.add("-v");
      arrayList.add("raw");
      arrayList.add("-s");
      arrayList.add("AndroidRuntime:E");
      arrayList.add("-p");
      arrayList.add(str1);
      Process process = Runtime.getRuntime().exec(arrayList.<String>toArray(new String[arrayList.size()]));
      BufferedReader bufferedReader = new BufferedReader();
      InputStreamReader inputStreamReader = new InputStreamReader();
      this(process.getInputStream());
      this(inputStreamReader, 1024);
      String str2 = bufferedReader.readLine();
      boolean bool1 = false;
      str = "";
      boolean bool2;
      for (bool2 = false; str2 != null; bool2 = bool) {
        if (str2.indexOf("thread attach failed") < 0) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          str = stringBuilder.append(str).append(str2).append('\n').toString();
        } 
        boolean bool = bool2;
        if (!bool2) {
          bool = bool2;
          if (str2.toLowerCase().indexOf("exception") >= 0)
            bool = true; 
        } 
        if (!bool1 && str2.indexOf(str1) >= 0)
          bool1 = true; 
        str2 = bufferedReader.readLine();
      } 
      int i = str.length();
      if (i <= 0 || !bool2 || !bool1)
        str = ""; 
      try {
        Runtime.getRuntime().exec("logcat -c");
      } catch (Exception exception) {}
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  private JSONArray b(JSONObject paramJSONObject, JSONArray paramJSONArray) {
    // Byte code:
    //   0: aload_2
    //   1: ifnull -> 8
    //   4: aload_1
    //   5: ifnonnull -> 10
    //   8: aload_2
    //   9: areturn
    //   10: aload_1
    //   11: invokevirtual keys : ()Ljava/util/Iterator;
    //   14: invokeinterface next : ()Ljava/lang/Object;
    //   19: checkcast java/lang/String
    //   22: astore_3
    //   23: aload_2
    //   24: invokevirtual length : ()I
    //   27: iconst_1
    //   28: isub
    //   29: istore #4
    //   31: iload #4
    //   33: iflt -> 102
    //   36: aload_2
    //   37: iload #4
    //   39: invokevirtual get : (I)Ljava/lang/Object;
    //   42: checkcast org/json/JSONObject
    //   45: astore #5
    //   47: aload #5
    //   49: aload_3
    //   50: invokevirtual has : (Ljava/lang/String;)Z
    //   53: ifeq -> 96
    //   56: aload_1
    //   57: aload_3
    //   58: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   61: astore_1
    //   62: aload #5
    //   64: aload_3
    //   65: invokevirtual getJSONArray : (Ljava/lang/String;)Lorg/json/JSONArray;
    //   68: aload_1
    //   69: iconst_0
    //   70: invokevirtual get : (I)Ljava/lang/Object;
    //   73: checkcast org/json/JSONObject
    //   76: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   79: pop
    //   80: goto -> 8
    //   83: astore_1
    //   84: ldc 'MobclickAgent'
    //   86: ldc_w 'custom log merge error in tryToSendMessage'
    //   89: aload_1
    //   90: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   93: goto -> 8
    //   96: iinc #4, -1
    //   99: goto -> 31
    //   102: aload_2
    //   103: aload_1
    //   104: invokevirtual put : (Ljava/lang/Object;)Lorg/json/JSONArray;
    //   107: pop
    //   108: goto -> 8
    // Exception table:
    //   from	to	target	type
    //   10	31	83	java/lang/Exception
    //   36	80	83	java/lang/Exception
    //   102	108	83	java/lang/Exception
  }
  
  private void b(Context paramContext, SharedPreferences paramSharedPreferences) {
    String str1 = paramSharedPreferences.getString("session_id", null);
    if (str1 == null) {
      Log.a("MobclickAgent", "Missing session_id, ignore message");
      return;
    } 
    String str2 = b();
    String str3 = str2.split(" ")[0];
    str2 = str2.split(" ")[1];
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("type", "launch");
      jSONObject.put("session_id", str1);
      jSONObject.put("date", str3);
      jSONObject.put("time", str2);
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.b("MobclickAgent", "json error in emitNewSessionReport", (Exception)jSONException);
    } 
  }
  
  private static void b(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic n : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   4: astore_2
    //   5: getstatic com/umeng/analytics/a.n : Ljava/lang/Object;
    //   8: astore_3
    //   9: aload_3
    //   10: monitorenter
    //   11: new org/json/JSONObject
    //   14: astore #4
    //   16: aload #4
    //   18: aload_1
    //   19: invokespecial <init> : (Ljava/lang/String;)V
    //   22: aload #4
    //   24: ldc 'last_config_time'
    //   26: invokevirtual has : (Ljava/lang/String;)Z
    //   29: ifeq -> 59
    //   32: aload_2
    //   33: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   38: ldc_w 'umeng_last_config_time'
    //   41: aload #4
    //   43: ldc 'last_config_time'
    //   45: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   48: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   53: invokeinterface commit : ()Z
    //   58: pop
    //   59: aload #4
    //   61: ldc 'report_policy'
    //   63: invokevirtual has : (Ljava/lang/String;)Z
    //   66: ifeq -> 96
    //   69: aload_2
    //   70: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   75: ldc_w 'umeng_net_report_policy'
    //   78: aload #4
    //   80: ldc 'report_policy'
    //   82: invokevirtual getInt : (Ljava/lang/String;)I
    //   85: invokeinterface putInt : (Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;
    //   90: invokeinterface commit : ()Z
    //   95: pop
    //   96: aconst_null
    //   97: astore_0
    //   98: aload #4
    //   100: ldc 'online_params'
    //   102: invokevirtual has : (Ljava/lang/String;)Z
    //   105: ifeq -> 265
    //   108: new org/json/JSONObject
    //   111: astore_0
    //   112: aload_0
    //   113: aload #4
    //   115: ldc 'online_params'
    //   117: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   120: invokespecial <init> : (Ljava/lang/String;)V
    //   123: aload_0
    //   124: invokevirtual keys : ()Ljava/util/Iterator;
    //   127: astore_1
    //   128: aload_2
    //   129: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   134: astore #4
    //   136: aload_1
    //   137: invokeinterface hasNext : ()Z
    //   142: ifeq -> 230
    //   145: aload_1
    //   146: invokeinterface next : ()Ljava/lang/Object;
    //   151: checkcast java/lang/String
    //   154: astore_2
    //   155: aload #4
    //   157: aload_2
    //   158: aload_0
    //   159: aload_2
    //   160: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   163: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   168: pop
    //   169: goto -> 136
    //   172: astore_0
    //   173: ldc 'MobclickAgent'
    //   175: ldc_w 'save online config params'
    //   178: aload_0
    //   179: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   182: aload_3
    //   183: monitorexit
    //   184: return
    //   185: astore_0
    //   186: ldc 'MobclickAgent'
    //   188: ldc_w 'not json string'
    //   191: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   194: aload_3
    //   195: monitorexit
    //   196: goto -> 184
    //   199: astore_0
    //   200: aload_3
    //   201: monitorexit
    //   202: aload_0
    //   203: athrow
    //   204: astore_0
    //   205: ldc 'MobclickAgent'
    //   207: ldc_w 'save online config time'
    //   210: aload_0
    //   211: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   214: goto -> 59
    //   217: astore_0
    //   218: ldc 'MobclickAgent'
    //   220: ldc_w 'save online config policy'
    //   223: aload_0
    //   224: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V
    //   227: goto -> 96
    //   230: aload #4
    //   232: invokeinterface commit : ()Z
    //   237: pop
    //   238: new java/lang/StringBuilder
    //   241: astore_1
    //   242: aload_1
    //   243: invokespecial <init> : ()V
    //   246: ldc 'MobclickAgent'
    //   248: aload_1
    //   249: ldc_w 'get online setting params: '
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: aload_0
    //   256: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   259: invokevirtual toString : ()Ljava/lang/String;
    //   262: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   265: getstatic com/umeng/analytics/MobclickAgent.o : Lcom/umeng/analytics/UmengOnlineConfigureListener;
    //   268: ifnull -> 182
    //   271: getstatic com/umeng/analytics/MobclickAgent.o : Lcom/umeng/analytics/UmengOnlineConfigureListener;
    //   274: aload_0
    //   275: invokeinterface onDataReceived : (Lorg/json/JSONObject;)V
    //   280: goto -> 182
    // Exception table:
    //   from	to	target	type
    //   11	22	185	java/lang/Exception
    //   11	22	199	finally
    //   22	59	204	java/lang/Exception
    //   22	59	199	finally
    //   59	96	217	java/lang/Exception
    //   59	96	199	finally
    //   98	136	172	java/lang/Exception
    //   98	136	199	finally
    //   136	169	172	java/lang/Exception
    //   136	169	199	finally
    //   173	182	199	finally
    //   182	184	199	finally
    //   186	196	199	finally
    //   200	202	199	finally
    //   205	214	199	finally
    //   218	227	199	finally
    //   230	265	172	java/lang/Exception
    //   230	265	199	finally
    //   265	280	172	java/lang/Exception
    //   265	280	199	finally
  }
  
  private void b(Context paramContext, String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   6: astore #4
    //   8: aload #4
    //   10: ifnonnull -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: new java/lang/StringBuilder
    //   19: astore #5
    //   21: aload #5
    //   23: invokespecial <init> : ()V
    //   26: aload_1
    //   27: aload #5
    //   29: ldc_w '_kvts'
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: aload_2
    //   36: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   39: aload_3
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: invokevirtual toString : ()Ljava/lang/String;
    //   46: invokestatic e : (Landroid/content/Context;Ljava/lang/String;)I
    //   49: istore #6
    //   51: iload #6
    //   53: ifge -> 80
    //   56: ldc_w 'event duration less than 0 in ekvEvnetEnd'
    //   59: invokestatic a : (Ljava/lang/String;)V
    //   62: goto -> 13
    //   65: astore_1
    //   66: ldc_w 'exception in onLogDurationInternalEnd'
    //   69: invokestatic a : (Ljava/lang/String;)V
    //   72: goto -> 13
    //   75: astore_1
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    //   80: new org/json/JSONObject
    //   83: astore #5
    //   85: new java/lang/StringBuilder
    //   88: astore #7
    //   90: aload #7
    //   92: invokespecial <init> : ()V
    //   95: aload #5
    //   97: aload #4
    //   99: aload #7
    //   101: ldc_w '_kvvl'
    //   104: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: aload_2
    //   108: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: aload_3
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: invokevirtual toString : ()Ljava/lang/String;
    //   118: aconst_null
    //   119: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   124: invokespecial <init> : (Ljava/lang/String;)V
    //   127: aload #5
    //   129: ldc 'du'
    //   131: iload #6
    //   133: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   136: pop
    //   137: aload_0
    //   138: aload_1
    //   139: aload #4
    //   141: aload_2
    //   142: aload #5
    //   144: invokespecial a : (Landroid/content/Context;Landroid/content/SharedPreferences;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   147: goto -> 13
    // Exception table:
    //   from	to	target	type
    //   2	8	75	finally
    //   16	51	65	java/lang/Exception
    //   16	51	75	finally
    //   56	62	65	java/lang/Exception
    //   56	62	75	finally
    //   66	72	75	finally
    //   80	147	65	java/lang/Exception
    //   80	147	75	finally
  }
  
  private void b(Context paramContext, String paramString1, String paramString2, long paramLong, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   6: astore #7
    //   8: aload #7
    //   10: ifnonnull -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: aload_0
    //   17: aload_1
    //   18: aload #7
    //   20: aload_2
    //   21: aload_3
    //   22: lload #4
    //   24: iload #6
    //   26: invokespecial a : (Landroid/content/Context;Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/String;JI)V
    //   29: goto -> 13
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	32	finally
    //   16	29	32	finally
  }
  
  private void b(Context paramContext, String paramString, Map<String, String> paramMap, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   6: astore #6
    //   8: aload #6
    //   10: ifnonnull -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: new org/json/JSONObject
    //   19: astore #7
    //   21: aload #7
    //   23: invokespecial <init> : ()V
    //   26: aload_3
    //   27: invokeinterface entrySet : ()Ljava/util/Set;
    //   32: invokeinterface iterator : ()Ljava/util/Iterator;
    //   37: astore_3
    //   38: iconst_0
    //   39: istore #8
    //   41: aload_3
    //   42: invokeinterface hasNext : ()Z
    //   47: ifne -> 57
    //   50: iload #8
    //   52: bipush #10
    //   54: if_icmple -> 100
    //   57: aload_3
    //   58: invokeinterface next : ()Ljava/lang/Object;
    //   63: checkcast java/util/Map$Entry
    //   66: astore #9
    //   68: aload #7
    //   70: aload #9
    //   72: invokeinterface getKey : ()Ljava/lang/Object;
    //   77: checkcast java/lang/String
    //   80: aload #9
    //   82: invokeinterface getValue : ()Ljava/lang/Object;
    //   87: checkcast java/lang/String
    //   90: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   93: pop
    //   94: iinc #8, 1
    //   97: goto -> 41
    //   100: lload #4
    //   102: lconst_0
    //   103: lcmp
    //   104: ifle -> 117
    //   107: aload #7
    //   109: ldc 'du'
    //   111: lload #4
    //   113: invokevirtual put : (Ljava/lang/String;J)Lorg/json/JSONObject;
    //   116: pop
    //   117: aload_0
    //   118: aload_1
    //   119: aload #6
    //   121: aload_2
    //   122: aload #7
    //   124: invokespecial a : (Landroid/content/Context;Landroid/content/SharedPreferences;Ljava/lang/String;Lorg/json/JSONObject;)V
    //   127: goto -> 13
    //   130: astore_1
    //   131: ldc 'MobclickAgent'
    //   133: ldc_w 'exception when convert map to json'
    //   136: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)V
    //   139: goto -> 13
    //   142: astore_1
    //   143: aload_0
    //   144: monitorexit
    //   145: aload_1
    //   146: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	142	finally
    //   16	38	130	java/lang/Exception
    //   16	38	142	finally
    //   41	50	130	java/lang/Exception
    //   41	50	142	finally
    //   57	94	130	java/lang/Exception
    //   57	94	142	finally
    //   107	117	130	java/lang/Exception
    //   107	117	142	finally
    //   117	127	130	java/lang/Exception
    //   117	127	142	finally
    //   131	139	142	finally
  }
  
  private static void b(Context paramContext, JSONObject paramJSONObject) {
    String str = m(paramContext);
    try {
      FileOutputStream fileOutputStream = paramContext.openFileOutput(str, 0);
      fileOutputStream.write(paramJSONObject.toString().getBytes());
      fileOutputStream.close();
    } catch (FileNotFoundException fileNotFoundException) {
      Log.b("MobclickAgent", "cache message error", fileNotFoundException);
    } catch (IOException iOException) {
      Log.b("MobclickAgent", "cache message error", iOException);
    } 
  }
  
  private void c(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Landroid/content/Context;
    //   6: aload_1
    //   7: if_acmpeq -> 21
    //   10: ldc 'MobclickAgent'
    //   12: ldc_w 'onPause() called without context from corresponding onResume()'
    //   15: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   18: aload_0
    //   19: monitorexit
    //   20: return
    //   21: aload_0
    //   22: aload_1
    //   23: putfield f : Landroid/content/Context;
    //   26: aload_1
    //   27: invokestatic k : (Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   30: astore_2
    //   31: aload_2
    //   32: ifnull -> 18
    //   35: aload_2
    //   36: ldc 'start_millis'
    //   38: ldc2_w -1
    //   41: invokeinterface getLong : (Ljava/lang/String;J)J
    //   46: lstore_3
    //   47: lload_3
    //   48: ldc2_w -1
    //   51: lcmp
    //   52: ifne -> 71
    //   55: ldc 'MobclickAgent'
    //   57: ldc_w 'onEndSession called before onStartSession'
    //   60: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   63: goto -> 18
    //   66: astore_1
    //   67: aload_0
    //   68: monitorexit
    //   69: aload_1
    //   70: athrow
    //   71: invokestatic currentTimeMillis : ()J
    //   74: lstore #5
    //   76: lload #5
    //   78: lload_3
    //   79: lsub
    //   80: lstore_3
    //   81: aload_2
    //   82: ldc 'duration'
    //   84: lconst_0
    //   85: invokeinterface getLong : (Ljava/lang/String;J)J
    //   90: lstore #7
    //   92: aload_2
    //   93: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   98: astore #9
    //   100: getstatic com/umeng/analytics/a.i : Z
    //   103: ifeq -> 229
    //   106: aload_2
    //   107: ldc 'activities'
    //   109: ldc ''
    //   111: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   116: astore_2
    //   117: aload_1
    //   118: invokevirtual getClass : ()Ljava/lang/Class;
    //   121: invokevirtual getName : ()Ljava/lang/String;
    //   124: astore #10
    //   126: aload_2
    //   127: astore_1
    //   128: ldc ''
    //   130: aload_2
    //   131: invokevirtual equals : (Ljava/lang/Object;)Z
    //   134: ifne -> 160
    //   137: new java/lang/StringBuilder
    //   140: astore_1
    //   141: aload_1
    //   142: invokespecial <init> : ()V
    //   145: aload_1
    //   146: aload_2
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: ldc_w ';'
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: astore_1
    //   160: new java/lang/StringBuilder
    //   163: astore_2
    //   164: aload_2
    //   165: invokespecial <init> : ()V
    //   168: aload_2
    //   169: aload_1
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: ldc_w '['
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: aload #10
    //   181: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: ldc_w ','
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: lload_3
    //   191: ldc2_w 1000
    //   194: ldiv
    //   195: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   198: ldc_w ']'
    //   201: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   204: invokevirtual toString : ()Ljava/lang/String;
    //   207: astore_1
    //   208: aload #9
    //   210: ldc 'activities'
    //   212: invokeinterface remove : (Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   217: pop
    //   218: aload #9
    //   220: ldc 'activities'
    //   222: aload_1
    //   223: invokeinterface putString : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    //   228: pop
    //   229: aload #9
    //   231: ldc 'start_millis'
    //   233: ldc2_w -1
    //   236: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   241: pop
    //   242: aload #9
    //   244: ldc 'end_millis'
    //   246: lload #5
    //   248: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   253: pop
    //   254: aload #9
    //   256: ldc 'duration'
    //   258: lload_3
    //   259: lload #7
    //   261: ladd
    //   262: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   267: pop
    //   268: aload #9
    //   270: invokeinterface commit : ()Z
    //   275: pop
    //   276: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   2	18	66	finally
    //   21	31	66	finally
    //   35	47	66	finally
    //   55	63	66	finally
    //   71	76	66	finally
    //   81	126	66	finally
    //   128	160	66	finally
    //   160	229	66	finally
    //   229	276	66	finally
  }
  
  private void c(Context paramContext, SharedPreferences paramSharedPreferences) {
    String str1 = paramSharedPreferences.getString("session_id", null);
    if (str1 == null) {
      a("Missing session_id, ignore message in emitLastEndSessionReport");
      return;
    } 
    Long long_1 = Long.valueOf(paramSharedPreferences.getLong("duration", -1L));
    Long long_2 = long_1;
    if (long_1.longValue() <= 0L)
      long_2 = Long.valueOf(0L); 
    String str2 = b();
    String str3 = str2.split(" ")[0];
    String str4 = str2.split(" ")[1];
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("type", "terminate");
      jSONObject.put("session_id", str1);
      jSONObject.put("date", str3);
      jSONObject.put("time", str4);
      jSONObject.put("duration", String.valueOf(long_2.longValue() / 1000L));
      if (a.i) {
        String str = paramSharedPreferences.getString("activities", "");
        if (!"".equals(str)) {
          String[] arrayOfString = str.split(";");
          JSONArray jSONArray = new JSONArray();
          this();
          for (byte b = 0; b < arrayOfString.length; b++) {
            str = arrayOfString[b];
            JSONArray jSONArray1 = new JSONArray();
            this(str);
            jSONArray.put(jSONArray1);
          } 
          jSONObject.put("activities", jSONArray);
        } 
      } 
      long[] arrayOfLong = d(paramContext, paramSharedPreferences);
      if (arrayOfLong != null) {
        jSONObject.put("uptr", arrayOfLong[1]);
        jSONObject.put("dntr", arrayOfLong[0]);
      } 
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.b("MobclickAgent", "json error in emitLastEndSessionReport", (Exception)jSONException);
    } 
  }
  
  private void c(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new org/json/JSONObject
    //   5: astore_3
    //   6: aload_3
    //   7: invokespecial <init> : ()V
    //   10: aload_3
    //   11: ldc 'type'
    //   13: ldc 'online_config'
    //   15: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   18: pop
    //   19: aload_3
    //   20: ldc 'appkey'
    //   22: aload_1
    //   23: invokestatic p : (Landroid/content/Context;)Ljava/lang/String;
    //   26: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   29: pop
    //   30: aload_3
    //   31: ldc_w 'version_code'
    //   34: aload_1
    //   35: invokestatic d : (Landroid/content/Context;)Ljava/lang/String;
    //   38: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   41: pop
    //   42: aload_3
    //   43: ldc_w 'package'
    //   46: aload_1
    //   47: invokestatic t : (Landroid/content/Context;)Ljava/lang/String;
    //   50: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   53: pop
    //   54: aload_3
    //   55: ldc_w 'sdk_version'
    //   58: ldc_w '4.0'
    //   61: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   64: pop
    //   65: aload_3
    //   66: ldc_w 'idmd5'
    //   69: aload_1
    //   70: invokestatic f : (Landroid/content/Context;)Ljava/lang/String;
    //   73: invokestatic b : (Ljava/lang/String;)Ljava/lang/String;
    //   76: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   79: pop
    //   80: aload_3
    //   81: ldc_w 'channel'
    //   84: aload_1
    //   85: invokestatic s : (Landroid/content/Context;)Ljava/lang/String;
    //   88: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   91: pop
    //   92: aload_3
    //   93: ldc 'report_policy'
    //   95: aload_1
    //   96: invokestatic o : (Landroid/content/Context;)I
    //   99: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   102: pop
    //   103: aload_3
    //   104: ldc 'last_config_time'
    //   106: aload_1
    //   107: invokestatic p : (Landroid/content/Context;)Ljava/lang/String;
    //   110: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   113: pop
    //   114: aload_0
    //   115: getfield g : Landroid/os/Handler;
    //   118: astore_2
    //   119: new com/umeng/analytics/MobclickAgent$b
    //   122: astore #4
    //   124: aload #4
    //   126: aload_0
    //   127: aload_1
    //   128: aload_3
    //   129: invokespecial <init> : (Lcom/umeng/analytics/MobclickAgent;Landroid/content/Context;Lorg/json/JSONObject;)V
    //   132: aload_2
    //   133: aload #4
    //   135: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   138: pop
    //   139: aload_0
    //   140: monitorexit
    //   141: return
    //   142: astore_1
    //   143: ldc 'MobclickAgent'
    //   145: ldc_w 'exception in onlineConfigInternal'
    //   148: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)V
    //   151: goto -> 139
    //   154: astore_1
    //   155: aload_0
    //   156: monitorexit
    //   157: aload_1
    //   158: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	154	finally
    //   10	114	142	java/lang/Exception
    //   10	114	154	finally
    //   114	139	154	finally
    //   143	151	154	finally
  }
  
  private void c(Context paramContext, String paramString1, String paramString2) {
    String str1 = b();
    String str2 = str1.split(" ")[0];
    str1 = str1.split(" ")[1];
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("type", "error");
      jSONObject.put("context", paramString1);
      jSONObject.put("date", str2);
      jSONObject.put("time", str1);
      jSONObject.put("subtype", paramString2);
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.a("MobclickAgent", "json error in emitErrorReport", (Exception)jSONException);
    } 
  }
  
  private void c(Context paramContext, JSONObject paramJSONObject) {
    if (a("online_config", paramContext, new String[0])) {
      Log.a("MobclickAgent", "start to check onlineConfig info ...");
      String str1 = a(paramContext, paramJSONObject, "http://www.umeng.com/check_config_update", true, "online_config");
      String str2 = str1;
      if (str1 == null)
        str2 = a(paramContext, paramJSONObject, "http://www.umeng.co/check_config_update", true, "online_config"); 
      if (str2 != null) {
        Log.a("MobclickAgent", "get onlineConfig info succeed !");
        b(paramContext, str2);
        return;
      } 
    } else {
      return;
    } 
    Log.a("MobclickAgent", "get onlineConfig info failed !");
  }
  
  private void d(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial f : (Landroid/content/Context;)V
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  private static void d(Context paramContext, String paramString) {
    SharedPreferences sharedPreferences = k(paramContext);
    String[] arrayOfString = sharedPreferences.getString(paramString, "").split(",");
    StringBuilder stringBuilder = new StringBuilder();
    if (arrayOfString != null)
      for (byte b = 0; b < arrayOfString.length; b++) {
        if (b >= arrayOfString.length - 3) {
          stringBuilder.append(",");
          stringBuilder.append(arrayOfString[b]);
        } 
      }  
    stringBuilder.append(",");
    stringBuilder.append(System.currentTimeMillis());
    sharedPreferences.edit().putString(paramString, stringBuilder.toString()).commit();
  }
  
  private long[] d(Context paramContext, SharedPreferences paramSharedPreferences) {
    try {
      Class<?> clazz = Class.forName("android.net.TrafficStats");
      Method method2 = clazz.getMethod("getUidRxBytes", new Class[] { int.class });
      Method method1 = clazz.getMethod("getUidTxBytes", new Class[] { int.class });
      int i = (paramContext.getApplicationInfo()).uid;
      if (i == -1)
        return null; 
      long[] arrayOfLong = new long[2];
      arrayOfLong[0] = ((Long)method2.invoke(null, new Object[] { Integer.valueOf(i) })).longValue();
      arrayOfLong[1] = ((Long)method1.invoke(null, new Object[] { Integer.valueOf(i) })).longValue();
      if (arrayOfLong[0] <= 0L || arrayOfLong[1] <= 0L)
        return null; 
      long l1 = paramSharedPreferences.getLong("traffics_up", -1L);
      long l2 = paramSharedPreferences.getLong("traffics_down", -1L);
      paramSharedPreferences.edit().putLong("traffics_up", arrayOfLong[1]).putLong("traffics_down", arrayOfLong[0]).commit();
      if (l1 <= 0L || l2 <= 0L)
        return null; 
      arrayOfLong[0] = arrayOfLong[0] - l2;
      arrayOfLong[1] = arrayOfLong[1] - l1;
      if (arrayOfLong[0] > 0L) {
        l1 = arrayOfLong[1];
        if (l1 <= 0L)
          arrayOfLong = null; 
        return arrayOfLong;
      } 
      arrayOfLong = null;
    } catch (Exception exception) {
      a("sdk less than 2.2 has get no traffic");
      exception = null;
    } 
    return (long[])exception;
  }
  
  private static int e(Context paramContext, String paramString) {
    byte b2;
    byte b1 = -1;
    SharedPreferences sharedPreferences = k(paramContext);
    try {
      String str = sharedPreferences.getString(paramString, "");
      int i = str.lastIndexOf(",");
      b2 = b1;
      if (i >= 0) {
        sharedPreferences.edit().putString(paramString, str.substring(0, i)).commit();
        long l1 = System.currentTimeMillis();
        long l2 = Long.valueOf(str.substring(i + 1)).longValue();
        b2 = (int)(l1 - l2);
      } 
    } catch (Exception exception) {
      Log.b("MobclickAgent", "exception in getting event duration", exception);
      b2 = b1;
    } 
    return b2;
  }
  
  private static JSONObject e(Context paramContext) {
    String str1;
    String str2;
    Context context = null;
    JSONObject jSONObject = new JSONObject();
    try {
      str1 = com.umeng.common.b.f(paramContext);
      if (str1 == null || str1.equals("")) {
        Log.b("MobclickAgent", "No device id");
        return (JSONObject)context;
      } 
      str2 = com.umeng.common.b.p(paramContext);
      if (str2 == null) {
        Log.b("MobclickAgent", "No appkey");
        return (JSONObject)context;
      } 
    } catch (Exception exception) {
      Log.b("MobclickAgent", "getMessageHeader error", exception);
      return (JSONObject)context;
    } 
    jSONObject.put("device_id", str1);
    jSONObject.put("idmd5", g.b(str1));
    jSONObject.put("device_model", Build.MODEL);
    jSONObject.put("appkey", str2);
    if (a.l != null) {
      str1 = a.l;
    } else {
      str1 = com.umeng.common.b.s(paramContext);
    } 
    jSONObject.put("channel", str1);
    jSONObject.put("app_version", com.umeng.common.b.e(paramContext));
    jSONObject.put("version_code", com.umeng.common.b.d(paramContext));
    jSONObject.put("sdk_type", "Android");
    jSONObject.put("sdk_version", "4.0");
    jSONObject.put("os", "Android");
    jSONObject.put("os_version", Build.VERSION.RELEASE);
    jSONObject.put("timezone", com.umeng.common.b.n(paramContext));
    String[] arrayOfString = com.umeng.common.b.o(paramContext);
    if (arrayOfString != null) {
      jSONObject.put("country", arrayOfString[0]);
      jSONObject.put("language", arrayOfString[1]);
    } 
    jSONObject.put("resolution", com.umeng.common.b.q(paramContext));
    arrayOfString = com.umeng.common.b.j(paramContext);
    if (arrayOfString != null && arrayOfString[0].equals("2G/3G")) {
      jSONObject.put("access", arrayOfString[0]);
      jSONObject.put("access_subtype", arrayOfString[1]);
    } else if (arrayOfString != null) {
      jSONObject.put("access", arrayOfString[0]);
    } else {
      jSONObject.put("access", "Unknown");
    } 
    jSONObject.put("carrier", com.umeng.common.b.r(paramContext));
    if (a.h) {
      Location location = com.umeng.common.b.l(paramContext);
      if (location != null) {
        jSONObject.put("lat", String.valueOf(location.getLatitude()));
        jSONObject.put("lng", String.valueOf(location.getLongitude()));
      } else {
        jSONObject.put("lat", 0.0D);
        jSONObject.put("lng", 0.0D);
      } 
    } 
    jSONObject.put("cpu", com.umeng.common.b.a());
    if (!a.equals(""))
      jSONObject.put("gpu_vender", a); 
    if (!b.equals(""))
      jSONObject.put("gpu_renderer", b); 
    if (a.j) {
      JSONObject jSONObject1 = q(paramContext);
      if (jSONObject1 != null)
        jSONObject.put("uinfo", jSONObject1); 
    } 
    jSONObject.put("package", com.umeng.common.b.t(paramContext));
    return jSONObject;
  }
  
  public static void enterPage(Context paramContext, String paramString) {
    onEvent(paramContext, "_PAGE_", paramString);
  }
  
  private void f(Context paramContext) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("type", "flush");
      this.g.post(new b(this, paramContext, jSONObject));
    } catch (JSONException jSONException) {
      Log.b("MobclickAgent", "json error in emitCache");
    } 
  }
  
  public static void flush(Context paramContext) {
    if (paramContext == null) {
      try {
        Log.b("MobclickAgent", "unexpected null context in flush");
        d.d(paramContext);
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in Mobclick.flush(). ", exception);
      } 
      return;
    } 
    d.d((Context)exception);
  }
  
  private static JSONObject g(Context paramContext) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: invokestatic m : (Landroid/content/Context;)Ljava/lang/String;
    //   6: astore_2
    //   7: aload_0
    //   8: aload_2
    //   9: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   12: astore_3
    //   13: sipush #16384
    //   16: newarray byte
    //   18: astore #4
    //   20: ldc ''
    //   22: astore_2
    //   23: aload_3
    //   24: aload #4
    //   26: invokevirtual read : ([B)I
    //   29: istore #5
    //   31: iload #5
    //   33: iconst_m1
    //   34: if_icmpeq -> 82
    //   37: new java/lang/StringBuilder
    //   40: astore #6
    //   42: aload #6
    //   44: invokespecial <init> : ()V
    //   47: aload #6
    //   49: aload_2
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: astore_2
    //   54: new java/lang/String
    //   57: astore #6
    //   59: aload #6
    //   61: aload #4
    //   63: iconst_0
    //   64: iload #5
    //   66: invokespecial <init> : ([BII)V
    //   69: aload_2
    //   70: aload #6
    //   72: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: invokevirtual toString : ()Ljava/lang/String;
    //   78: astore_2
    //   79: goto -> 23
    //   82: aload_2
    //   83: invokevirtual length : ()I
    //   86: istore #5
    //   88: iload #5
    //   90: ifne -> 97
    //   93: aload_1
    //   94: astore_0
    //   95: aload_0
    //   96: areturn
    //   97: new org/json/JSONObject
    //   100: astore #4
    //   102: aload #4
    //   104: aload_2
    //   105: invokespecial <init> : (Ljava/lang/String;)V
    //   108: aload #4
    //   110: astore_0
    //   111: goto -> 95
    //   114: astore_2
    //   115: aload_3
    //   116: invokevirtual close : ()V
    //   119: aload_0
    //   120: invokestatic h : (Landroid/content/Context;)V
    //   123: aload_2
    //   124: invokevirtual printStackTrace : ()V
    //   127: aload_1
    //   128: astore_0
    //   129: goto -> 95
    //   132: astore_0
    //   133: aload_1
    //   134: astore_0
    //   135: goto -> 95
    //   138: astore_0
    //   139: aload_1
    //   140: astore_0
    //   141: goto -> 95
    // Exception table:
    //   from	to	target	type
    //   7	20	132	java/io/FileNotFoundException
    //   7	20	138	java/io/IOException
    //   23	31	132	java/io/FileNotFoundException
    //   23	31	138	java/io/IOException
    //   37	79	132	java/io/FileNotFoundException
    //   37	79	138	java/io/IOException
    //   82	88	132	java/io/FileNotFoundException
    //   82	88	138	java/io/IOException
    //   97	108	114	org/json/JSONException
    //   97	108	132	java/io/FileNotFoundException
    //   97	108	138	java/io/IOException
    //   115	127	132	java/io/FileNotFoundException
    //   115	127	138	java/io/IOException
  }
  
  public static String getConfigParams(Context paramContext, String paramString) {
    return n(paramContext).getString(paramString, "");
  }
  
  public static String getUmengHttpHeader(Context paramContext) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Android");
    stringBuffer.append("/");
    stringBuffer.append("4.0");
    stringBuffer.append(" ");
    try {
      StringBuffer stringBuffer1 = new StringBuffer();
      this();
      stringBuffer1.append(paramContext.getPackageManager().getApplicationLabel(paramContext.getApplicationInfo()).toString());
      stringBuffer1.append("/");
      stringBuffer1.append((paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0)).versionName);
      stringBuffer1.append(" ");
      stringBuffer1.append(Build.MODEL);
      stringBuffer1.append("/");
      stringBuffer1.append(Build.VERSION.RELEASE);
      stringBuffer1.append(" ");
      stringBuffer1.append(g.b(com.umeng.common.b.f(paramContext)));
      stringBuffer.append(URLEncoder.encode(stringBuffer1.toString()));
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return stringBuffer.toString();
  }
  
  private static void h(Context paramContext) {
    paramContext.deleteFile(l(paramContext));
    paramContext.deleteFile(m(paramContext));
  }
  
  private static SharedPreferences i(Context paramContext) {
    String str = paramContext.getPackageName();
    return paramContext.getSharedPreferences("mobclick_agent_header_" + str, 0);
  }
  
  private static SharedPreferences j(Context paramContext) {
    String str = paramContext.getPackageName();
    return paramContext.getSharedPreferences("mobclick_agent_update_" + str, 0);
  }
  
  private static SharedPreferences k(Context paramContext) {
    String str = paramContext.getPackageName();
    return paramContext.getSharedPreferences("mobclick_agent_state_" + str, 0);
  }
  
  private static String l(Context paramContext) {
    String str = paramContext.getPackageName();
    return "mobclick_agent_header_" + str;
  }
  
  private static String m(Context paramContext) {
    String str = paramContext.getPackageName();
    return "mobclick_agent_cached_" + str;
  }
  
  private static SharedPreferences n(Context paramContext) {
    String str = paramContext.getPackageName();
    return paramContext.getSharedPreferences("mobclick_agent_online_setting_" + str, 0);
  }
  
  private static int o(Context paramContext) {
    SharedPreferences sharedPreferences = n(paramContext);
    return (sharedPreferences.contains("umeng_net_report_policy") && sharedPreferences.getInt("umeng_net_report_policy", -1) != -1) ? sharedPreferences.getInt("umeng_net_report_policy", e) : sharedPreferences.getInt("umeng_local_report_policy", e);
  }
  
  public static void onError(Context paramContext) {
    try {
      str = com.umeng.common.b.p(paramContext);
      if (str == null || str.length() == 0) {
        Log.b("MobclickAgent", "unexpected empty appkey in onError");
        return;
      } 
      if (paramContext == null) {
        Log.b("MobclickAgent", "unexpected null context in onError");
        return;
      } 
    } catch (Exception exception) {
      Log.b("MobclickAgent", "Exception occurred in Mobclick.onError()", exception);
      return;
    } 
    a a = new a();
    this((Context)exception, str, 2);
    String str;
    a.start();
  }
  
  public static void onEvent(Context paramContext, String paramString) {
    onEvent(paramContext, paramString, 1);
  }
  
  public static void onEvent(Context paramContext, String paramString, int paramInt) {
    a(paramContext, paramString, (String)null, -1L, paramInt);
  }
  
  public static void onEvent(Context paramContext, String paramString1, String paramString2) {
    if (TextUtils.isEmpty(paramString2)) {
      a("label is null or empty in onEvent(tag,label)");
      return;
    } 
    a(paramContext, paramString1, paramString2, -1L, 1);
  }
  
  public static void onEvent(Context paramContext, String paramString1, String paramString2, int paramInt) {
    a(paramContext, paramString1, paramString2, -1L, paramInt);
  }
  
  public static void onEvent(Context paramContext, String paramString, Map<String, String> paramMap) {
    a(paramContext, paramString, paramMap, -1L);
  }
  
  public static void onEventBegin(Context paramContext, String paramString) {
    if (paramContext == null || TextUtils.isEmpty(paramString)) {
      a("invalid params in onEventBegin");
      return;
    } 
    d(paramContext, "_t" + paramString);
  }
  
  public static void onEventBegin(Context paramContext, String paramString1, String paramString2) {
    if (paramContext == null || TextUtils.isEmpty(paramString1) || TextUtils.isEmpty(paramString2)) {
      a("invalid params in onEventBegin");
      return;
    } 
    d(paramContext, "_tl" + paramString1 + paramString2);
  }
  
  public static void onEventDuration(Context paramContext, String paramString, long paramLong) {
    if (paramLong <= 0L) {
      a("duration is not valid in onEventDuration");
      return;
    } 
    a(paramContext, paramString, (String)null, paramLong, 1);
  }
  
  public static void onEventDuration(Context paramContext, String paramString1, String paramString2, long paramLong) {
    if (paramLong <= 0L) {
      a("duration is not valid in onEventDuration");
      return;
    } 
    if (TextUtils.isEmpty(paramString2)) {
      a("label is null or empty in onEventDuration");
      return;
    } 
    a(paramContext, paramString1, paramString2, paramLong, 1);
  }
  
  public static void onEventDuration(Context paramContext, String paramString, Map<String, String> paramMap, long paramLong) {
    if (paramLong <= 0L) {
      a("duration is not valid in onEventDuration(map)");
      return;
    } 
    a(paramContext, paramString, paramMap, paramLong);
  }
  
  public static void onEventEnd(Context paramContext, String paramString) {
    int i = e(paramContext, "_t" + paramString);
    if (i < 0) {
      a("event duration less than 0 in onEventEnd");
      return;
    } 
    a(paramContext, paramString, (String)null, i, 1);
  }
  
  public static void onEventEnd(Context paramContext, String paramString1, String paramString2) {
    if (TextUtils.isEmpty(paramString2)) {
      a("invalid params in onEventEnd");
      return;
    } 
    int i = e(paramContext, "_tl" + paramString1 + paramString2);
    if (i < 0) {
      a("event duration less than 0 in onEvnetEnd");
      return;
    } 
    a(paramContext, paramString1, paramString2, i, 1);
  }
  
  public static void onKVEventBegin(Context paramContext, String paramString1, Map<String, String> paramMap, String paramString2) {
    if (paramContext == null || TextUtils.isEmpty(paramString1) || TextUtils.isEmpty(paramString2)) {
      a("invalid params in onKVEventBegin");
      return;
    } 
    if (paramMap == null || paramMap.isEmpty()) {
      a("map is null or empty in onKVEventBegin");
      return;
    } 
    (new a(paramContext, paramString1, paramMap, paramString2, 5)).start();
  }
  
  public static void onKVEventEnd(Context paramContext, String paramString1, String paramString2) {
    if (paramContext == null || TextUtils.isEmpty(paramString1) || TextUtils.isEmpty(paramString2)) {
      a("invalid params in onKVEventEnd");
      return;
    } 
    (new a(paramContext, paramString1, null, paramString2, 6)).start();
  }
  
  public static void onPause(Context paramContext) {
    if (paramContext == null) {
      try {
        Log.b("MobclickAgent", "unexpected null context in onPause");
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in Mobclick.onRause(). ", exception);
      } 
      return;
    } 
    a a = new a();
    this((Context)exception, 0);
    a.start();
  }
  
  public static void onResume(Context paramContext) {
    onResume(paramContext, com.umeng.common.b.p(paramContext), com.umeng.common.b.s(paramContext));
  }
  
  public static void onResume(Context paramContext, String paramString1, String paramString2) {
    try {
      a.l = paramString2;
      if (paramContext == null) {
        Log.b("MobclickAgent", "unexpected null context in onResume");
        return;
      } 
      if (paramString1 == null || paramString1.length() == 0) {
        Log.b("MobclickAgent", "unexpected empty appkey in onResume");
        return;
      } 
    } catch (Exception exception) {
      Log.b("MobclickAgent", "Exception occurred in Mobclick.onResume(). ", exception);
      return;
    } 
    a a = new a();
    this((Context)exception, paramString1, paramString2, 1);
    a.start();
  }
  
  public static void openActivityDurationTrack(boolean paramBoolean) {
    a.i = paramBoolean;
  }
  
  private static String p(Context paramContext) {
    return n(paramContext).getString("umeng_last_config_time", "");
  }
  
  private static JSONObject q(Context paramContext) {
    JSONObject jSONObject = new JSONObject();
    null = a(paramContext);
    try {
      if (null.getInt("gender", -1) != -1)
        jSONObject.put("sex", null.getInt("gender", -1)); 
      if (null.getInt("age", -1) != -1)
        jSONObject.put("age", null.getInt("age", -1)); 
      if (!"".equals(null.getString("user_id", "")))
        jSONObject.put("id", null.getString("user_id", "")); 
      if (!"".equals(null.getString("id_source", "")))
        jSONObject.put("url", URLEncoder.encode(null.getString("id_source", ""))); 
      int i = jSONObject.length();
      if (i > 0)
        return jSONObject; 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return null;
  }
  
  public static void reportError(Context paramContext, String paramString) {
    if (paramString != null && paramString != "" && paramString.length() <= 10240) {
      if (paramContext == null) {
        Log.b("MobclickAgent", "unexpected null context in reportError");
        return;
      } 
      d.c(paramContext, paramString, "send_error");
    } 
  }
  
  public static void setAge(Context paramContext, int paramInt) {
    SharedPreferences sharedPreferences = a(paramContext);
    if (paramInt < 0 || paramInt > 200) {
      a("not a valid age!");
      return;
    } 
    sharedPreferences.edit().putInt("age", paramInt).commit();
  }
  
  public static void setAutoLocation(boolean paramBoolean) {
    c = paramBoolean;
  }
  
  public static void setDebugMode(boolean paramBoolean) {
    a.g = paramBoolean;
  }
  
  public static void setDefaultReportPolicy(Context paramContext, int paramInt) {
    if (paramInt < 0 || paramInt > 5) {
      Log.b("MobclickAgent", "Illegal value of report policy");
      return;
    } 
    e = paramInt;
    a(paramContext, paramInt);
  }
  
  public static void setGender(Context paramContext, Gender paramGender) {
    byte b1 = 0;
    SharedPreferences sharedPreferences = a(paramContext);
    byte b2 = b1;
    switch (null.a[paramGender.ordinal()]) {
      default:
        b2 = b1;
      case 3:
        sharedPreferences.edit().putInt("gender", b2).commit();
        return;
      case 1:
        b2 = 1;
      case 2:
        break;
    } 
    b2 = 2;
  }
  
  public static void setOnlineConfigureListener(UmengOnlineConfigureListener paramUmengOnlineConfigureListener) {
    o = paramUmengOnlineConfigureListener;
  }
  
  public static void setOpenGLContext(GL10 paramGL10) {
    if (paramGL10 != null) {
      String[] arrayOfString = com.umeng.common.b.a(paramGL10);
      if (arrayOfString.length == 2) {
        a = arrayOfString[0];
        b = arrayOfString[1];
      } 
    } 
  }
  
  public static void setSessionContinueMillis(long paramLong) {
    a.d = paramLong;
  }
  
  public static void setUserID(Context paramContext, String paramString1, String paramString2) {
    SharedPreferences sharedPreferences = a(paramContext);
    if (TextUtils.isEmpty(paramString1)) {
      a("userID is null or empty");
      return;
    } 
    sharedPreferences.edit().putString("user_id", paramString1).commit();
    if (TextUtils.isEmpty(paramString2)) {
      a("id source is null or empty");
      return;
    } 
    sharedPreferences.edit().putString("id_source", paramString2).commit();
  }
  
  public static void updateOnlineConfig(Context paramContext) {
    if (paramContext == null) {
      try {
        Log.b("MobclickAgent", "unexpected null context in updateOnlineConfig");
      } catch (Exception exception) {
        Log.b("MobclickAgent", "exception in updateOnlineConfig");
      } 
      return;
    } 
    d.c((Context)exception, com.umeng.common.b.p((Context)exception));
  }
  
  public static void updateOnlineConfig(Context paramContext, String paramString) {
    a.l = paramString;
    updateOnlineConfig(paramContext);
  }
  
  private static final class a extends Thread {
    private static final Object a = new Object();
    
    private Context b;
    
    private int c;
    
    private String d;
    
    private String e;
    
    private String f;
    
    private String g;
    
    private int h;
    
    private long i;
    
    private Map<String, String> j;
    
    private String k;
    
    a(Context param1Context, int param1Int) {
      this.b = param1Context;
      this.c = param1Int;
    }
    
    a(Context param1Context, String param1String, int param1Int) {
      this.b = param1Context;
      this.c = param1Int;
      this.d = param1String;
    }
    
    a(Context param1Context, String param1String1, String param1String2, int param1Int) {
      this.b = param1Context;
      this.c = param1Int;
      this.d = param1String1;
      this.e = param1String2;
    }
    
    a(Context param1Context, String param1String1, String param1String2, long param1Long, int param1Int1, int param1Int2) {
      this.b = param1Context;
      this.f = param1String1;
      this.g = param1String2;
      this.h = param1Int1;
      this.c = param1Int2;
      this.i = param1Long;
    }
    
    a(Context param1Context, String param1String, Map<String, String> param1Map, long param1Long, int param1Int) {
      this.b = param1Context;
      this.f = param1String;
      this.j = param1Map;
      this.c = param1Int;
      this.i = param1Long;
    }
    
    a(Context param1Context, String param1String1, Map<String, String> param1Map, String param1String2, int param1Int) {
      this.b = param1Context;
      this.f = param1String1;
      this.j = param1Map;
      this.k = param1String2;
      this.c = param1Int;
    }
    
    public void run() {
      try {
        synchronized (a) {
          int i = this.c;
          if (i == 0) {
            try {
              if (this.b == null) {
                Log.b("MobclickAgent", "unexpected null context in invokehander flag=0");
                return;
              } 
              MobclickAgent.a(MobclickAgent.a(), this.b);
            } catch (Exception exception) {}
          } else if (this.c == 1) {
            MobclickAgent.a(MobclickAgent.a(), this.b, this.d, this.e);
          } else if (this.c == 2) {
            MobclickAgent.a(MobclickAgent.a(), this.b, this.d);
          } else if (this.c == 3) {
            MobclickAgent.a(MobclickAgent.a(), this.b, this.f, this.g, this.i, this.h);
          } else if (this.c == 4) {
            MobclickAgent.a(MobclickAgent.a(), this.b, this.f, this.j, this.i);
          } else if (this.c == 5) {
            MobclickAgent.a(MobclickAgent.a(), this.b, this.f, this.j, this.k);
          } else if (this.c == 6) {
            MobclickAgent.b(MobclickAgent.a(), this.b, this.f, this.k);
          } 
          return;
        } 
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in invokehander.", exception);
      } 
    }
  }
  
  private static final class b implements Runnable {
    private static final Object a = new Object();
    
    private MobclickAgent b = MobclickAgent.a();
    
    private Context c;
    
    private JSONObject d;
    
    b(MobclickAgent param1MobclickAgent, Context param1Context, JSONObject param1JSONObject) {
      this.c = param1Context;
      this.d = param1JSONObject;
    }
    
    public void run() {
      try {
        if (this.d.getString("type").equals("online_config")) {
          MobclickAgent.a(this.b, this.c, this.d);
          return;
        } 
        synchronized (a) {
          MobclickAgent.b(this.b, this.c, this.d);
          return;
        } 
      } catch (Exception exception) {
        Log.b("MobclickAgent", "Exception occurred in ReportMessageHandler");
        exception.printStackTrace();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/umeng/analytics/MobclickAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */