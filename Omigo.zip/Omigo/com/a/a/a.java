package com.a.a;

import android.app.Activity;
import java.util.LinkedList;

public final class a {
  private static LinkedList a = new LinkedList();
  
  public static void a() {
    while (a.size() != 0) {
      Activity activity = a.poll();
      if (!activity.isFinishing())
        activity.finish(); 
    } 
  }
  
  public static void a(Activity paramActivity) {
    a.add(paramActivity);
  }
  
  public static void b(Activity paramActivity) {
    a.remove(paramActivity);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */