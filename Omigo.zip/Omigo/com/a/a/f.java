package com.a.a;

import android.content.Context;
import android.content.SharedPreferences;

public final class f {
  private static String a = "local_pref";
  
  private static String b = "firstRead";
  
  private static String c = "fontsize";
  
  private static String d = "mrbg";
  
  private static String e = "mrld";
  
  private static String f = "mrnt";
  
  public static void a(Context paramContext) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putInt(b, 1);
    editor.commit();
  }
  
  public static void a(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putInt(c, paramInt);
    editor.commit();
  }
  
  public static int b(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getInt(b, 0);
  }
  
  public static void b(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putInt(d, paramInt);
    editor.commit();
  }
  
  public static int c(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getInt(c, 2);
  }
  
  public static void c(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putInt(e, paramInt);
    editor.commit();
  }
  
  public static int d(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getInt(d, 0);
  }
  
  public static void d(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putInt(f, paramInt);
    editor.commit();
  }
  
  public static int e(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getInt(e, g.a(paramContext) - 20);
  }
  
  public static int f(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getInt(f, 0);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */