package com.a.a;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.WindowManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class g {
  private static final char[] a = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'a', 'b', 'c', 'd', 'e', 'f' };
  
  public static int a() {
    boolean bool2;
    boolean bool1 = false;
    try {
      bool2 = Integer.valueOf(Build.VERSION.SDK).intValue();
    } catch (NumberFormatException numberFormatException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public static int a(Context paramContext) {
    boolean bool2;
    boolean bool1 = false;
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      bool2 = Settings.System.getInt(contentResolver, "screen_brightness");
    } catch (Exception exception) {
      exception.printStackTrace();
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public static Drawable a(Context paramContext, Uri paramUri) {
    Context context1;
    Context context2 = null;
    if (paramUri == null)
      return (Drawable)context2; 
    try {
      Drawable drawable = Drawable.createFromStream(paramContext.getContentResolver().openInputStream(paramUri), null);
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
      context1 = context2;
    } 
    return (Drawable)context1;
  }
  
  public static Uri a(String paramString) {
    Uri uri1 = null;
    Uri uri2 = uri1;
    if (paramString != null) {
      if (paramString.equals(""))
        return uri1; 
    } else {
      return uri2;
    } 
    File file1 = new File(b.f);
    file1.mkdirs();
    File file2 = new File(file1, b(paramString));
    try {
      Uri uri;
      if (file2.exists()) {
        uri = Uri.fromFile(file2);
      } else {
        HttpURLConnection httpURLConnection;
        Uri uri3;
        FileOutputStream fileOutputStream = new FileOutputStream();
        this(file2);
        Proxy proxy = b(e.e);
        if (proxy != null) {
          URL uRL = new URL();
          this((String)uri);
          httpURLConnection = (HttpURLConnection)uRL.openConnection(proxy);
        } else {
          URL uRL = new URL();
          this((String)httpURLConnection);
          httpURLConnection = (HttpURLConnection)uRL.openConnection();
        } 
        httpURLConnection.setConnectTimeout(10000);
        if (httpURLConnection.getResponseCode() == 200) {
          InputStream inputStream = httpURLConnection.getInputStream();
          byte[] arrayOfByte = new byte[1024];
          while (true) {
            int i = inputStream.read(arrayOfByte);
            if (i != -1) {
              fileOutputStream.write(arrayOfByte, 0, i);
              continue;
            } 
            fileOutputStream.close();
            inputStream.close();
            uri3 = Uri.fromFile(file2);
            if (file2.length() < 10L) {
              file2.delete();
              Uri uri5 = uri1;
              // Byte code: goto -> 19
            } 
            break;
          } 
        } else {
          Uri uri5 = uri1;
          return uri5;
        } 
        Uri uri4 = uri3;
      } 
      break;
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      this("getFileURL error = ");
      Log.d("getFileURL", stringBuilder.append(exception.getMessage()).toString());
      exception.printStackTrace();
    } finally {
      if (file2.length() < 10L) {
        file2.delete();
        return uri1;
      } 
    } 
    paramString = null;
    String str = paramString;
  }
  
  public static String a(long paramLong) {
    return a(paramLong, "yyyy-MM-dd HH:mm");
  }
  
  public static String a(long paramLong, String paramString) {
    Date date = new Date(paramLong);
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(paramString);
    simpleDateFormat.format(date);
    return simpleDateFormat.format(date);
  }
  
  public static void a(Activity paramActivity, int paramInt) {
    WindowManager.LayoutParams layoutParams = paramActivity.getWindow().getAttributes();
    layoutParams.screenBrightness = Float.valueOf(paramInt).floatValue() * 0.003921569F;
    paramActivity.getWindow().setAttributes(layoutParams);
  }
  
  private static String b(String paramString) {
    String str;
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      messageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = messageDigest.digest();
      StringBuilder stringBuilder = new StringBuilder();
      this(arrayOfByte.length * 2);
      for (byte b = 0; b < arrayOfByte.length; b++) {
        stringBuilder.append(a[(arrayOfByte[b] & 0xF0) >>> 4]);
        stringBuilder.append(a[arrayOfByte[b] & 0xF]);
      } 
      str = stringBuilder.toString();
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
      noSuchAlgorithmException.printStackTrace();
      str = "";
    } 
    return str;
  }
  
  public static Proxy b(Context paramContext) {
    String str;
    ConnectivityManager connectivityManager1 = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo.State state = connectivityManager1.getNetworkInfo(1).getState();
    if (state == NetworkInfo.State.CONNECTED || state == NetworkInfo.State.CONNECTING) {
      str = "wifi";
    } else {
      str = connectivityManager1.getNetworkInfo(0).getExtraInfo();
    } 
    ConnectivityManager connectivityManager2 = null;
    connectivityManager1 = connectivityManager2;
    if (str != null)
      try {
        InetSocketAddress inetSocketAddress2;
        if (str.contains("3gwap") || str.contains("cmwap") || str.contains("3GWAP") || str.contains("CMWAP")) {
          Proxy proxy1 = new Proxy();
          Proxy.Type type1 = Proxy.Type.HTTP;
          inetSocketAddress2 = new InetSocketAddress();
          this("10.0.0.172", 80);
          this(type1, inetSocketAddress2);
          return proxy1;
        } 
        if (!inetSocketAddress2.contains("ctwap")) {
          Proxy proxy1;
          connectivityManager1 = connectivityManager2;
          if (inetSocketAddress2.contains("CTWAP")) {
            Proxy.Type type1 = Proxy.Type.HTTP;
            InetSocketAddress inetSocketAddress = new InetSocketAddress();
            this("10.0.0.120", 80);
            proxy1 = new Proxy(type1, inetSocketAddress);
          } 
          return proxy1;
        } 
        Proxy.Type type = Proxy.Type.HTTP;
        InetSocketAddress inetSocketAddress1 = new InetSocketAddress();
        this("10.0.0.120", 80);
        Proxy proxy = new Proxy(type, inetSocketAddress1);
      } catch (Exception exception) {
        connectivityManager1 = connectivityManager2;
      }  
    return (Proxy)connectivityManager1;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */