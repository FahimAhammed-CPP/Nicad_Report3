package com.a.a;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.b.a.c;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

final class d extends Thread {
  d(c paramc) {}
  
  public final void run() {
    try {
      HttpURLConnection httpURLConnection;
      Log.e("下载", "下载中");
      URL uRL = new URL();
      this(this.a.a);
      Proxy proxy = g.b(e.e);
      if (proxy != null) {
        httpURLConnection = (HttpURLConnection)uRL.openConnection(proxy);
      } else {
        httpURLConnection = (HttpURLConnection)httpURLConnection.openConnection();
      } 
      httpURLConnection.setRequestProperty("Content-Type", "text/plain");
      httpURLConnection.setRequestProperty("charset", "utf-8");
      this.a.c = httpURLConnection.getContentLength();
      StringBuilder stringBuilder = new StringBuilder();
      this(" ");
      Log.e("下载", stringBuilder.append(this.a.c).toString());
      File file = new File();
      this(b.g, this.a.b);
      this.a.g = file.getPath();
      this.a.f.g(this.a.g);
      file.getParentFile().mkdirs();
      if (file.exists())
        file.delete(); 
      file.createNewFile();
      if (!c.a(this.a)) {
        InputStream inputStream = httpURLConnection.getInputStream();
        if (inputStream == null) {
          this.a.e = -1;
          return;
        } 
        FileOutputStream fileOutputStream = new FileOutputStream();
        this(file);
        byte[] arrayOfByte = new byte[1024];
        int i = inputStream.read(arrayOfByte, 0, arrayOfByte.length);
        while (i != -1) {
          c c1 = this.a;
          c1.d += i;
          fileOutputStream.write(arrayOfByte, 0, i);
          i = inputStream.read(arrayOfByte, 0, arrayOfByte.length);
          if (c.a(this.a)) {
            inputStream.close();
            fileOutputStream.close();
            // Byte code: goto -> 181
          } 
        } 
        inputStream.close();
        fileOutputStream.close();
        if (!c.a(this.a)) {
          Log.e("下载", "下载完成");
          c c1 = new c();
          this(e.e);
          c1.a();
          String str1 = this.a.f.b();
          String str2 = this.a.g;
          ContentValues contentValues = new ContentValues();
          this();
          contentValues.put("localURL", str2);
          SQLiteDatabase sQLiteDatabase = c1.a;
          StringBuilder stringBuilder1 = new StringBuilder();
          this("novelId='");
          sQLiteDatabase.update("booktable", contentValues, stringBuilder1.append(str1).append("'").toString(), null);
          this.a.e = 1;
        } 
      } 
    } catch (Exception exception) {
      Log.e("downBook", "error :" + exception.getMessage());
      this.a.e = -1;
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */