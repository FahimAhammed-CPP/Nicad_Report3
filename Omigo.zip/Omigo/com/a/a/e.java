package com.a.a;

import android.content.Context;
import com.f.a.a;
import com.f.a.b;
import com.g.g.GroupPaihangActivity;
import java.util.ArrayList;
import java.util.Hashtable;

public final class e {
  public static b a;
  
  public static b b;
  
  public static ArrayList c;
  
  public static a d;
  
  public static Context e;
  
  public static Hashtable f = new Hashtable<Object, Object>();
  
  public static Class g = GroupPaihangActivity.class;
  
  public static void a() {
    a = null;
    b = null;
    c = null;
    d = null;
    e = null;
    g = null;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */