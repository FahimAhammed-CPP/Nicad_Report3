package com.a.a;

import com.f.a.a;

public final class c {
  public String a;
  
  public String b;
  
  public int c;
  
  public int d;
  
  public int e;
  
  public a f;
  
  public String g;
  
  private boolean h;
  
  public c() {}
  
  public c(a parama) {
    this.f = parama;
    this.b = parama.c() + ".txt";
    this.a = parama.h();
  }
  
  public final void a() {
    this.h = true;
  }
  
  public final void b() {
    (new d(this)).start();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */