package com.a.a;

import android.os.Environment;

public final class b {
  public static String a = "http://42.121.121.142:8080/novel/types.php";
  
  public static String b = "http://42.121.121.142:8080/novel/novel_list.php";
  
  public static String c = "http://42.121.121.142:8080/novel/novel_search.php";
  
  public static String d = "http://42.121.121.142:8080/novel/newbook.php";
  
  public static String e = "http://42.121.121.142:8080/novel/video.php";
  
  public static String f = Environment.getExternalStorageDirectory() + "/readtool/imgCache";
  
  public static String g = Environment.getExternalStorageDirectory() + "/readtool/downBook";
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/a/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */