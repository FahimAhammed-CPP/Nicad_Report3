package com.c.c;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.g.g.SearchResultActivity;

final class b implements View.OnClickListener {
  b(BaseActivity paramBaseActivity) {}
  
  public final void onClick(View paramView) {
    Intent intent = new Intent((Context)this.a, SearchResultActivity.class);
    this.a.startActivity(intent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/c/c/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */