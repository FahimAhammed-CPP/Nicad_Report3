package com.c.c;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;
import com.f.a.a;
import com.g.g.ReadbookDown;

final class c implements View.OnClickListener {
  c(BaseActivity paramBaseActivity) {}
  
  public final void onClick(View paramView) {
    com.b.a.c c1 = new com.b.a.c((Context)this.a);
    c1.a();
    a a = c1.c();
    if (a != null && a.j() != null) {
      Intent intent = new Intent((Context)this.a, ReadbookDown.class);
      intent.putExtra("url", a.j());
      intent.putExtra("aid", a.b());
      intent.putExtra("beg", a.k());
      this.a.startActivity(intent);
      return;
    } 
    Toast.makeText((Context)this.a, "没有最后次阅读记录", 0).show();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/c/c/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */