package com.c.c;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.a.a.a;
import com.a.a.e;
import com.b.a.c;
import com.umeng.analytics.MobclickAgent;
import java.util.HashSet;

public class BaseActivity extends Activity {
  public LinearLayout a = null;
  
  public Button b = null;
  
  public LinearLayout c = null;
  
  public boolean d;
  
  public AbsListView.OnScrollListener e = new a(this);
  
  public HashSet f = new HashSet();
  
  public Button g;
  
  public Button h;
  
  public TextView i;
  
  public final LinearLayout a() {
    this.a = new LinearLayout((Context)this);
    this.a.setOrientation(0);
    ProgressBar progressBar = new ProgressBar((Context)this);
    progressBar.setPadding(0, 0, 15, 0);
    this.a.addView((View)progressBar, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
    TextView textView = new TextView((Context)this);
    textView.setText("加载中...");
    textView.setGravity(16);
    this.a.addView((View)textView, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
    this.a.setGravity(17);
    this.b = new Button(getApplicationContext());
    this.b.setText("更多...");
    this.b.setBackgroundDrawable(null);
    this.b.setTextSize(15.0F);
    this.c = new LinearLayout((Context)this);
    this.c.addView((View)this.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
    this.c.setGravity(17);
    return this.c;
  }
  
  public final void a(String paramString) {
    this.h = (Button)findViewById(2131230843);
    this.g = (Button)findViewById(2131230844);
    this.i = (TextView)findViewById(2131230842);
    this.h.setOnClickListener(new b(this));
    this.g.setOnClickListener(new c(this));
    this.i.setText(paramString);
  }
  
  public final void a(boolean paramBoolean) {
    if (!paramBoolean) {
      this.d = true;
      this.c.removeAllViews();
    } 
  }
  
  public void b() {
    finish();
  }
  
  public void c() {}
  
  public final void d() {
    HashSet<String> hashSet = null;
    c c = new c((Context)this);
    c.a();
    Cursor cursor = c.a.query("booktable", new String[] { "novelId" }, null, null, null, null, null);
    if (cursor == null || !cursor.moveToFirst()) {
      c.a(cursor);
    } else {
      hashSet = new HashSet();
      for (byte b = 0; b < cursor.getCount(); b++) {
        cursor.moveToPosition(b);
        hashSet.add(cursor.getString(cursor.getColumnIndex("novelId")));
      } 
      c.a(cursor);
    } 
    this.f.clear();
    if (hashSet != null)
      this.f.addAll(hashSet); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    a.a(this);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    a.b(this);
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (4 == paramInt) {
      b();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onPause() {
    super.onPause();
    MobclickAgent.onPause((Context)this);
  }
  
  protected void onResume() {
    e.e = (Context)this;
    super.onResume();
    MobclickAgent.onResume((Context)this);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/c/c/BaseActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */