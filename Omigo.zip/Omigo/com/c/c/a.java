package com.c.c;

import android.widget.AbsListView;

final class a implements AbsListView.OnScrollListener {
  a(BaseActivity paramBaseActivity) {}
  
  public final void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3) {}
  
  public final void onScrollStateChanged(AbsListView paramAbsListView, int paramInt) {
    if (paramInt == 0 && paramAbsListView.getLastVisiblePosition() == paramAbsListView.getCount() - 1)
      this.a.c(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/c/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */