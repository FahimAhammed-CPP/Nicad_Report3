package com.g.g;

import com.a.a.g;
import java.io.IOException;

final class b extends Thread {
  b(BookDetailActivity paramBookDetailActivity) {}
  
  public final void run() {
    if (BookDetailActivity.a(this.a).i() == null)
      try {
        BookDetailActivity.a(this.a).a(g.a(BookDetailActivity.a(this.a).d()));
      } catch (IOException iOException) {
        iOException.printStackTrace();
      }  
    BookDetailActivity.c(this.a).sendEmptyMessage(888);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */