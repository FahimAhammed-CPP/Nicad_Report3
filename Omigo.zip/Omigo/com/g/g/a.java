package com.g.g;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import com.a.a.g;

final class a extends Handler {
  a(BookDetailActivity paramBookDetailActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 888 && BookDetailActivity.a(this.a).i() != null)
      BookDetailActivity.b(this.a).setImageDrawable(g.a((Context)this.a, BookDetailActivity.a(this.a).i())); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */