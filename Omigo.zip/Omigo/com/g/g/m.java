package com.g.g;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import com.a.a.e;
import com.e.a.c;

final class m extends Handler {
  m(GroupPaihangActivity paramGroupPaihangActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 221) {
      if (GroupPaihangActivity.a(this.a).c() == null || GroupPaihangActivity.a(this.a).c().size() == 0) {
        GroupPaihangActivity.b(this.a).setVisibility(0);
        GroupPaihangActivity.c(this.a).setVisibility(8);
        GroupPaihangActivity.d(this.a).setVisibility(0);
      } 
      if (this.a.c != null) {
        this.a.c.removeAllViews();
        if (GroupPaihangActivity.a(this.a).b()) {
          this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
          this.a.d = false;
        } 
      } 
      return;
    } 
    if (paramMessage.what == 222) {
      GroupPaihangActivity.e(this.a).addFooterView((View)this.a.a());
      GroupPaihangActivity.a(this.a).c().clear();
      if (GroupPaihangActivity.f(this.a) == null) {
        GroupPaihangActivity.a(this.a, e.a);
      } else {
        GroupPaihangActivity.a(this.a).a((GroupPaihangActivity.f(this.a)).b.a());
        GroupPaihangActivity.a(this.a).a((GroupPaihangActivity.f(this.a)).b.b());
        GroupPaihangActivity.a(this.a).c().addAll((GroupPaihangActivity.f(this.a)).b.c());
      } 
      GroupPaihangActivity.a(this.a, new c((Context)this.a, GroupPaihangActivity.a(this.a).c(), this.a.f));
      GroupPaihangActivity.e(this.a).setAdapter((ListAdapter)GroupPaihangActivity.g(this.a));
      GroupPaihangActivity.b(this.a).setVisibility(8);
      e.a = GroupPaihangActivity.a(this.a);
      GroupPaihangActivity.a(this.a, GroupPaihangActivity.a(this.a).c());
      this.a.a(GroupPaihangActivity.a(this.a).b());
      return;
    } 
    if (paramMessage.what == 223) {
      GroupPaihangActivity.a(this.a).a((GroupPaihangActivity.f(this.a)).b.a());
      GroupPaihangActivity.a(this.a).a((GroupPaihangActivity.f(this.a)).b.b());
      GroupPaihangActivity.a(this.a).c().addAll((GroupPaihangActivity.f(this.a)).b.c());
      this.a.c.removeAllViews();
      if (GroupPaihangActivity.a(this.a).b()) {
        this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
        this.a.d = false;
      } 
      GroupPaihangActivity.g(this.a).notifyDataSetChanged();
      GroupPaihangActivity.a(this.a, GroupPaihangActivity.a(this.a).c());
      this.a.a(GroupPaihangActivity.a(this.a).b());
      GroupPaihangActivity.b(this.a).setVisibility(8);
      return;
    } 
    if (paramMessage.what == 888 && GroupPaihangActivity.g(this.a) != null)
      GroupPaihangActivity.g(this.a).notifyDataSetChanged(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */