package com.g.g;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;

final class c extends Handler {
  c(BookMarkActivity paramBookMarkActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    com.f.a.c c1;
    if (paramMessage.what == 62) {
      c1 = BookMarkActivity.a(this.a).get(paramMessage.arg1);
      if (BookMarkActivity.b(this.a) == true) {
        Intent intent1 = new Intent((Context)this.a, ReadbookDown.class);
        intent1.putExtra("url", c1.c());
        intent1.putExtra("aid", c1.b());
        intent1.putExtra("beg", c1.e());
        intent1.putExtra("bname", c1.h());
        this.a.startActivity(intent1);
        this.a.finish();
        return;
      } 
      Intent intent = new Intent();
      intent.putExtra("beg", c1.e());
      this.a.setResult(-1, intent);
      this.a.finish();
      return;
    } 
    if (((Message)c1).what == 63) {
      int i = ((Message)c1).arg1;
      c1 = BookMarkActivity.a(this.a).get(i);
      (new AlertDialog.Builder((Context)this.a)).setTitle("温馨提示").setMessage("是否删除？").setPositiveButton("确定", new e(this, c1, i)).setNegativeButton("取消", new d(this)).show();
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */