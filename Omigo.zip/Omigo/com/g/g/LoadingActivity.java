package com.g.g;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import com.c.c.BaseActivity;

public class LoadingActivity extends BaseActivity {
  private Boolean j = Boolean.valueOf(true);
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ImageView imageView = new ImageView((Context)this);
    imageView.setBackgroundResource(2130837535);
    setContentView((View)imageView);
    (new r(this)).start();
  }
  
  protected void onPause() {
    super.onPause();
    this.j = Boolean.valueOf(false);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/LoadingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */