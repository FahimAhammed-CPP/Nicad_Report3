package com.g.g;

import android.view.animation.Animation;

final class ae implements Animation.AnimationListener {
  ae(ad paramad) {}
  
  public final void onAnimationEnd(Animation paramAnimation) {
    if (ReadbookDown.e(this.a.a) == 1) {
      ReadbookDown.d(this.a.a).setVisibility(0);
      ReadbookDown.a(this.a.a, 0);
    } 
  }
  
  public final void onAnimationRepeat(Animation paramAnimation) {}
  
  public final void onAnimationStart(Animation paramAnimation) {
    if (ReadbookDown.d(this.a.a).isShown()) {
      ReadbookDown.d(this.a.a).setVisibility(8);
      ReadbookDown.a(this.a.a, 1);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */