package com.g.g;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.a.a.c;
import com.a.a.e;
import com.b.a.a;
import com.b.a.c;
import com.c.c.BaseActivity;
import com.f.a.a;
import java.io.File;

public class BookDetailActivity extends BaseActivity implements View.OnClickListener {
  private TextView j;
  
  private TextView k;
  
  private TextView l;
  
  private TextView m;
  
  private TextView n;
  
  private TextView o;
  
  private RelativeLayout p;
  
  private Button q;
  
  private Button r;
  
  private a s;
  
  private ImageView t;
  
  private ProgressBar u;
  
  private String v;
  
  private c w;
  
  private Handler x = new a(this);
  
  public void onClick(View paramView) {
    a a1;
    if (paramView.getId() == this.r.getId()) {
      if ("进入阅读".equals(this.r.getText().toString())) {
        Intent intent = new Intent((Context)this, ReadbookDown.class);
        intent.putExtra("url", this.v);
        intent.putExtra("aid", this.s.b());
        a a2 = this.w.a(this.s.b());
        if (a2 != null)
          intent.putExtra("beg", a2.k()); 
        intent.putExtra("bname", this.s.c());
        startActivity(intent);
        return;
      } 
      if ("下载".equals(this.r.getText().toString())) {
        Toast.makeText((Context)this, "已加入书架，请到我的书架查看下载进度", 0).show();
        this.r.setText("正在下载");
        c c1 = new c(this.s);
        c1.b();
        String str = this.s.b();
        Log.e("加入 ", str + " ");
        e.f.put(this.s.b(), c1);
        if (this.w.a(this.s.b()) == null) {
          c c2 = this.w;
          a1 = this.s;
          ContentValues contentValues = new ContentValues();
          contentValues.put("novelId", a1.b());
          contentValues.put("novelName", a1.c());
          contentValues.put("novelImageUrl", a1.d());
          contentValues.put("novelAuthor", a1.e());
          contentValues.put("novelType", a1.g());
          contentValues.put("novelUrl", a1.h());
          contentValues.put("novelJJ", a1.m());
          contentValues.put("localURL", a1.j());
          contentValues.put("posi", Integer.valueOf(a1.k()));
          contentValues.put("jindu", a1.n());
          contentValues.put("date", Long.valueOf(System.currentTimeMillis()));
          c2.a.insert("booktable", null, contentValues);
        } 
      } 
      return;
    } 
    if (a1.getId() == this.q.getId()) {
      Intent intent = new Intent((Context)this, BookMarkActivity.class);
      intent.putExtra("aid", this.s.b());
      intent.putExtra("bname", this.s.c());
      intent.putExtra("intentflag", true);
      startActivity(intent);
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903049);
    this.j = (TextView)findViewById(2131230796);
    this.k = (TextView)findViewById(2131230801);
    this.l = (TextView)findViewById(2131230803);
    this.m = (TextView)findViewById(2131230805);
    this.n = (TextView)findViewById(2131230814);
    this.o = (TextView)findViewById(2131230812);
    this.p = (RelativeLayout)findViewById(2131230810);
    this.u = (ProgressBar)findViewById(2131230811);
    this.q = (Button)findViewById(2131230808);
    this.r = (Button)findViewById(2131230809);
    this.t = (ImageView)findViewById(2131230799);
    this.r.setOnClickListener(this);
    this.q.setOnClickListener(this);
    this.s = e.d;
    this.j.setText(this.s.c());
    this.k.setText(this.s.e());
    this.l.setText(this.s.g());
    this.m.setText(this.s.f());
    if (this.s.m() != null) {
      Log.e("BookDetailActivity", "jianjie:::" + this.s.m());
      this.n.setText(this.s.m());
    } else {
      this.n.setText("暂无");
    } 
    if (this.s.d() != null)
      (new b(this)).start(); 
    this.w = new c((Context)this);
    this.w.a();
    a a1 = this.w.a(this.s.b());
    c c1 = (c)e.f.get(this.s.b());
    if (c1 != null) {
      if (c1.e == 1) {
        this.r.setText("进入阅读");
        e.f.remove(this.s.b());
        return;
      } 
      this.r.setText("正在下载");
      return;
    } 
    if (a1 != null && a1.j() != null && (new File(a1.j())).exists()) {
      this.v = a1.j();
      e.d.g(this.v);
      this.p.setVisibility(8);
      this.r.setText("进入阅读");
    } 
  }
  
  protected void onDestroy() {
    super.onDestroy();
  }
  
  protected void onPause() {
    super.onPause();
  }
  
  protected void onResume() {
    super.onResume();
    if (!((a)this.w).a.isOpen())
      this.w.a(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/BookDetailActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */