package com.g.g;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.widget.ListAdapter;
import com.a.a.e;
import com.e.a.a;

final class k extends Handler {
  k(GroupFenleiActivity paramGroupFenleiActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 221) {
      if (GroupFenleiActivity.a(this.a) == null || GroupFenleiActivity.a(this.a).size() == 0) {
        GroupFenleiActivity.b(this.a).setVisibility(0);
        GroupFenleiActivity.c(this.a).setVisibility(8);
        GroupFenleiActivity.d(this.a).setVisibility(0);
      } 
      return;
    } 
    if (paramMessage.what == 222) {
      GroupFenleiActivity.a(this.a).clear();
      if (GroupFenleiActivity.e(this.a) == null) {
        GroupFenleiActivity.a(this.a, e.c);
      } else {
        GroupFenleiActivity.a(this.a).addAll((GroupFenleiActivity.e(this.a)).b);
      } 
      GroupFenleiActivity.a(this.a, new a((Context)this.a, GroupFenleiActivity.a(this.a)));
      GroupFenleiActivity.g(this.a).setAdapter((ListAdapter)GroupFenleiActivity.f(this.a));
      e.c = GroupFenleiActivity.a(this.a);
      GroupFenleiActivity.b(this.a).setVisibility(8);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */