package com.g.g;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ShareActivity extends Activity {
  private EditText a;
  
  private EditText b;
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903060);
    Button button = (Button)findViewById(2131230840);
    this.a = (EditText)findViewById(2131230839);
    this.b = (EditText)findViewById(2131230841);
    button.setOnClickListener(new ao(this));
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ShareActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */