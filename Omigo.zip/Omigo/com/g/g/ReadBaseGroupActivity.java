package com.g.g;

import android.app.AlertDialog;
import android.content.Context;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import com.c.c.BaseActivity;

public class ReadBaseGroupActivity extends BaseActivity {
  public RadioGroup j;
  
  public RadioButton k;
  
  public RadioButton l;
  
  public RadioButton m;
  
  public RadioButton n;
  
  public int o = -1;
  
  public boolean p;
  
  RelativeLayout q;
  
  RelativeLayout r;
  
  public View.OnClickListener s = new w(this);
  
  private View.OnClickListener t = new s(this);
  
  public final void a(int paramInt) {
    this.o = paramInt;
    this.j.check(paramInt);
  }
  
  public final void b() {
    (new AlertDialog.Builder((Context)this)).setTitle("温馨提示").setMessage("您确定退出精品小说？").setPositiveButton("确定", new y(this)).setNegativeButton("取消", new x(this)).show();
  }
  
  public final void e() {
    this.j = (RadioGroup)findViewById(2131230720);
    this.k = (RadioButton)findViewById(2131230721);
    this.l = (RadioButton)findViewById(2131230722);
    this.m = (RadioButton)findViewById(2131230723);
    this.n = (RadioButton)findViewById(2131230724);
    this.k.setOnClickListener(this.t);
    this.l.setOnClickListener(this.t);
    this.m.setOnClickListener(this.t);
    this.n.setOnClickListener(this.t);
    this.p = false;
  }
  
  public final void f() {
    this.q = (RelativeLayout)findViewById(2131230823);
    this.r = (RelativeLayout)findViewById(2131230824);
    this.r.setVisibility(8);
    this.q.setVisibility(8);
    Button button1 = (Button)findViewById(2131230848);
    Button button2 = (Button)findViewById(2131230849);
    this.q.setOnClickListener(new t(this));
    button1.setOnClickListener(new u(this));
    button2.setOnClickListener(new v(this));
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    null = true;
    if (4 == paramInt) {
      if (this.r.isShown()) {
        this.q.setVisibility(8);
        this.r.setVisibility(8);
        return null;
      } 
      b();
      return null;
    } 
    if (paramInt == 82) {
      if (this.r.isShown()) {
        this.q.setVisibility(8);
        this.r.setVisibility(8);
        return null;
      } 
      this.q.setVisibility(0);
      this.r.setVisibility(0);
      return null;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ReadBaseGroupActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */