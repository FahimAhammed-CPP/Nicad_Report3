package com.g.g;

import android.content.Context;
import android.content.Intent;
import android.view.View;

final class an implements View.OnClickListener {
  an(SearchResultActivity paramSearchResultActivity) {}
  
  public final void onClick(View paramView) {
    Intent intent = new Intent((Context)this.a, SearchResultActivity.class);
    intent.putExtra("bookname", SearchResultActivity.b(this.a).getText().toString());
    this.a.startActivity(intent);
    this.a.overridePendingTransition(0, 0);
    this.a.finish();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */