package com.g.g;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import com.a.a.e;
import com.e.a.c;

final class p extends Handler {
  p(GroupXinShuActivity paramGroupXinShuActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 221) {
      if (GroupXinShuActivity.a(this.a).c() == null || GroupXinShuActivity.a(this.a).c().size() == 0) {
        GroupXinShuActivity.b(this.a).setVisibility(0);
        GroupXinShuActivity.c(this.a).setVisibility(8);
        GroupXinShuActivity.d(this.a).setVisibility(0);
      } 
      if (this.a.c != null) {
        this.a.c.removeAllViews();
        if (GroupXinShuActivity.a(this.a).b()) {
          this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
          this.a.d = false;
        } 
      } 
      return;
    } 
    if (paramMessage.what == 222) {
      GroupXinShuActivity.e(this.a).addFooterView((View)this.a.a());
      GroupXinShuActivity.a(this.a).c().clear();
      if (GroupXinShuActivity.f(this.a) == null) {
        GroupXinShuActivity.a(this.a, e.b);
      } else {
        GroupXinShuActivity.a(this.a).a((GroupXinShuActivity.f(this.a)).b.a());
        GroupXinShuActivity.a(this.a).a((GroupXinShuActivity.f(this.a)).b.b());
        GroupXinShuActivity.a(this.a).c().addAll((GroupXinShuActivity.f(this.a)).b.c());
      } 
      GroupXinShuActivity.a(this.a, new c((Context)this.a, GroupXinShuActivity.a(this.a).c(), this.a.f));
      GroupXinShuActivity.e(this.a).setAdapter((ListAdapter)GroupXinShuActivity.g(this.a));
      GroupXinShuActivity.b(this.a).setVisibility(8);
      e.b = GroupXinShuActivity.a(this.a);
      GroupXinShuActivity.a(this.a, GroupXinShuActivity.a(this.a).c());
      this.a.a(GroupXinShuActivity.a(this.a).b());
      return;
    } 
    if (paramMessage.what == 223) {
      GroupXinShuActivity.a(this.a).a((GroupXinShuActivity.f(this.a)).b.a());
      GroupXinShuActivity.a(this.a).a((GroupXinShuActivity.f(this.a)).b.b());
      GroupXinShuActivity.a(this.a).c().addAll((GroupXinShuActivity.f(this.a)).b.c());
      this.a.c.removeAllViews();
      if (GroupXinShuActivity.a(this.a).b()) {
        this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
        this.a.d = false;
      } 
      GroupXinShuActivity.g(this.a).notifyDataSetChanged();
      GroupXinShuActivity.a(this.a, GroupXinShuActivity.a(this.a).c());
      this.a.a(GroupXinShuActivity.a(this.a).b());
      return;
    } 
    if (paramMessage.what == 888 && GroupXinShuActivity.g(this.a) != null)
      GroupXinShuActivity.g(this.a).notifyDataSetChanged(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */