package com.g.g;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.b.a.b;
import com.c.c.BaseActivity;
import com.e.a.f;
import java.util.ArrayList;

public class BookMarkActivity extends BaseActivity {
  private ArrayList j = new ArrayList();
  
  private f k;
  
  private b l;
  
  private Button m;
  
  private ListView n;
  
  private TextView o;
  
  private ImageView p;
  
  private String q;
  
  private boolean r;
  
  private Handler s = new c(this);
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903046);
    a(getIntent().getStringExtra("bname"));
    this.g.setVisibility(8);
    this.h.setVisibility(8);
    this.m = (Button)findViewById(2131230779);
    this.n = (ListView)findViewById(2131230781);
    this.o = (TextView)findViewById(2131230782);
    this.p = (ImageView)findViewById(2131230783);
    this.r = getIntent().getBooleanExtra("intentflag", false);
    this.q = getIntent().getStringExtra("aid");
    this.l = new b((Context)this);
    this.l.a();
    ArrayList arrayList = this.l.a(this.q);
    this.j.clear();
    if (arrayList != null)
      this.j.addAll(arrayList); 
    this.k = new f((Context)this, this.j, this.s);
    this.n.setAdapter((ListAdapter)this.k);
    this.m.setOnClickListener(new f(this));
    if (this.j != null && this.j.size() > 0) {
      this.o.setVisibility(8);
      this.p.setVisibility(8);
      return;
    } 
    this.o.setVisibility(0);
    this.p.setVisibility(0);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/BookMarkActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */