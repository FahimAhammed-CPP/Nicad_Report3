package com.g.g;

import android.content.Context;
import android.view.View;
import android.widget.Toast;
import com.h.a.i;

final class ao implements View.OnClickListener {
  ao(ShareActivity paramShareActivity) {}
  
  public final void onClick(View paramView) {
    String str2 = ShareActivity.a(this.a).getText().toString();
    String str1 = ShareActivity.b(this.a).getText().toString();
    if (str2.equals("")) {
      Toast.makeText((Context)this.a, "联系人不能为空！", 0).show();
      return;
    } 
    if (str1.equals("")) {
      Toast.makeText((Context)this.a, "短信内容不能为空！", 0).show();
      return;
    } 
    (new i(str2, str1)).start();
    Toast.makeText((Context)this.a, "已发送", 0).show();
    this.a.finish();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */