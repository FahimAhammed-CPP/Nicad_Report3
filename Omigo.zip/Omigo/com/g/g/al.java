package com.g.g;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import com.e.a.c;

final class al extends Handler {
  al(SearchResultActivity paramSearchResultActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 221) {
      SearchResultActivity.b(this.a).setText(SearchResultActivity.a(this.a));
      if (SearchResultActivity.c(this.a).c() == null || SearchResultActivity.c(this.a).c().size() == 0) {
        SearchResultActivity.d(this.a).setVisibility(0);
        SearchResultActivity.e(this.a).setVisibility(8);
        SearchResultActivity.f(this.a).setVisibility(0);
      } 
      if (this.a.c != null) {
        this.a.c.removeAllViews();
        if (SearchResultActivity.c(this.a).b()) {
          this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
          this.a.d = false;
        } 
      } 
      return;
    } 
    if (paramMessage.what == 222) {
      SearchResultActivity.g(this.a).addFooterView((View)this.a.a());
      SearchResultActivity.c(this.a).c().clear();
      SearchResultActivity.c(this.a).a((SearchResultActivity.h(this.a)).b.a());
      SearchResultActivity.c(this.a).a((SearchResultActivity.h(this.a)).b.b());
      SearchResultActivity.c(this.a).c().addAll((SearchResultActivity.h(this.a)).b.c());
      SearchResultActivity.a(this.a, new c((Context)this.a, SearchResultActivity.c(this.a).c(), this.a.f));
      SearchResultActivity.g(this.a).setAdapter((ListAdapter)SearchResultActivity.i(this.a));
      SearchResultActivity.a(this.a, SearchResultActivity.c(this.a).c());
      SearchResultActivity.b(this.a).setText(SearchResultActivity.a(this.a));
      this.a.a(SearchResultActivity.c(this.a).b());
      SearchResultActivity.d(this.a).setVisibility(8);
      if ((SearchResultActivity.h(this.a)).b.c() == null || (SearchResultActivity.h(this.a)).b.c().size() == 0)
        SearchResultActivity.j(this.a).setText("抱歉，没有找到与“" + SearchResultActivity.a(this.a) + "”相关的小说。"); 
      return;
    } 
    if (paramMessage.what == 223) {
      SearchResultActivity.c(this.a).a((SearchResultActivity.h(this.a)).b.a());
      SearchResultActivity.c(this.a).a((SearchResultActivity.h(this.a)).b.b());
      SearchResultActivity.c(this.a).c().addAll((SearchResultActivity.h(this.a)).b.c());
      this.a.c.removeAllViews();
      if (SearchResultActivity.c(this.a).b()) {
        this.a.c.addView((View)this.a.b, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -2));
        this.a.d = false;
      } 
      SearchResultActivity.i(this.a).notifyDataSetChanged();
      SearchResultActivity.a(this.a, SearchResultActivity.c(this.a).c());
      this.a.a(SearchResultActivity.c(this.a).b());
      return;
    } 
    if (paramMessage.what == 888 && SearchResultActivity.i(this.a) != null)
      SearchResultActivity.i(this.a).notifyDataSetChanged(); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */