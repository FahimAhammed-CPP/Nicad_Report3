package com.g.g;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.c.c.BaseActivity;
import com.e.a.c;
import com.f.a.b;
import com.h.a.b;
import com.h.a.f;
import java.util.Vector;

public class SearchResultActivity extends BaseActivity {
  private ListView j;
  
  private f k;
  
  private b l = new b();
  
  private c m;
  
  private String n;
  
  private EditText o;
  
  private ImageView p;
  
  private b q;
  
  private LinearLayout r;
  
  private LinearLayout s;
  
  private LinearLayout t;
  
  private TextView u;
  
  private Handler v = new al(this);
  
  public final void c() {
    if (!this.d) {
      this.c.removeAllViews();
      if (this.l.b()) {
        this.c.addView((View)this.a, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.d = true;
        this.k = new f(this.v, this.n, this.l.a() + 1);
        this.k.start();
      } 
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903059);
    this.u = (TextView)findViewById(2131230837);
    this.r = (LinearLayout)findViewById(2131230833);
    this.s = (LinearLayout)findViewById(2131230834);
    this.t = (LinearLayout)findViewById(2131230835);
    ((Button)findViewById(2131230836)).setOnClickListener(new am(this));
    this.o = (EditText)findViewById(2131230846);
    this.j = (ListView)findViewById(2131230838);
    this.p = (ImageView)findViewById(2131230847);
    this.n = getIntent().getStringExtra("bookname");
    if (this.n != null && !"".equals(this.n)) {
      this.k = new f(this.v, this.n, 1);
      this.k.start();
    } else {
      this.r.setVisibility(8);
    } 
    this.p.setOnClickListener(new an(this));
  }
  
  protected void onDestroy() {
    super.onDestroy();
    if (this.k != null)
      this.k.a(); 
  }
  
  protected void onResume() {
    super.onResume();
    d();
    this.v.sendEmptyMessage(888);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/SearchResultActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */