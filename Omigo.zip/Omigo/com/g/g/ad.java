package com.g.g;

import android.view.View;

final class ad implements View.OnClickListener {
  ad(ReadbookDown paramReadbookDown) {}
  
  public final void onClick(View paramView) {
    ReadbookDown.c(this.a);
    ReadbookDown.f(this.a).setAnimationListener(new ae(this));
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */