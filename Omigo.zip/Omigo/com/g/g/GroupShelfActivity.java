package com.g.g;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.b.a.c;
import com.e.a.j;
import com.h.a.a;
import com.h.a.b;
import java.util.List;
import java.util.Vector;

public class GroupShelfActivity extends ReadBaseGroupActivity {
  private Handler A = new o(this);
  
  private ListView t;
  
  private j u;
  
  private b v;
  
  private Vector w = new Vector();
  
  private c x;
  
  private a y;
  
  private TextView z;
  
  private void a(Vector paramVector) {
    if (paramVector != null && paramVector.size() != 0) {
      if (this.v != null)
        this.v.a(); 
      this.v = new b(this.A, paramVector);
      this.v.start();
    } 
  }
  
  private void g() {
    this.w.clear();
    List list = this.x.b();
    if (list != null) {
      this.w.addAll(list);
      this.z.setVisibility(8);
      return;
    } 
    this.z.setVisibility(0);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903054);
    e();
    a("书架");
    f();
    this.t = (ListView)findViewById(2131230828);
    this.z = (TextView)findViewById(2131230826);
  }
  
  protected void onPause() {
    super.onPause();
    this.y.a();
  }
  
  protected void onResume() {
    super.onResume();
    a(this.n.getId());
    this.x = new c((Context)this);
    this.x.a();
    g();
    this.u = new j((Context)this, this.w, this.A);
    this.t.setAdapter((ListAdapter)this.u);
    a(this.w);
    this.y = new a(this.A);
    this.y.start();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/GroupShelfActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */