package com.g.g;

import android.view.View;
import com.h.a.d;

final class l implements View.OnClickListener {
  l(GroupFenleiActivity paramGroupFenleiActivity) {}
  
  public final void onClick(View paramView) {
    if (GroupFenleiActivity.e(this.a) != null)
      GroupFenleiActivity.e(this.a).a(); 
    GroupFenleiActivity.a(this.a, new d(GroupFenleiActivity.h(this.a)));
    GroupFenleiActivity.e(this.a).start();
    GroupFenleiActivity.b(this.a).setVisibility(0);
    GroupFenleiActivity.c(this.a).setVisibility(0);
    GroupFenleiActivity.d(this.a).setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */