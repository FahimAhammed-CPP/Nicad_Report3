package com.g.g;

import android.view.View;
import com.h.a.g;

final class q implements View.OnClickListener {
  q(GroupXinShuActivity paramGroupXinShuActivity) {}
  
  public final void onClick(View paramView) {
    if (GroupXinShuActivity.f(this.a) != null)
      GroupXinShuActivity.f(this.a).a(); 
    GroupXinShuActivity.a(this.a, new g(GroupXinShuActivity.h(this.a), 1));
    GroupXinShuActivity.f(this.a).start();
    GroupXinShuActivity.b(this.a).setVisibility(0);
    GroupXinShuActivity.c(this.a).setVisibility(0);
    GroupXinShuActivity.d(this.a).setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */