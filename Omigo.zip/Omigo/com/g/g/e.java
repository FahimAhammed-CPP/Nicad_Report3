package com.g.g;

import android.content.DialogInterface;
import com.b.a.b;
import com.f.a.c;

final class e implements DialogInterface.OnClickListener {
  e(c paramc, c paramc1, int paramInt) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    b b = BookMarkActivity.c(this.c.a);
    long l = this.a.a();
    b.a.delete("bookmark", "_id=" + l, null);
    BookMarkActivity.a(this.c.a).remove(this.b);
    BookMarkActivity.d(this.c.a).notifyDataSetChanged();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */