package com.g.g;

import android.os.Handler;
import android.os.Message;

final class o extends Handler {
  o(GroupShelfActivity paramGroupShelfActivity) {}
  
  public final void handleMessage(Message paramMessage) {
    if (paramMessage.what == 888) {
      GroupShelfActivity.a(this.a);
      return;
    } 
    if (paramMessage.what == 777) {
      GroupShelfActivity.b(this.a);
      GroupShelfActivity.a(this.a);
      GroupShelfActivity.a(this.a, GroupShelfActivity.c(this.a));
      return;
    } 
    if (paramMessage.what == 71)
      GroupShelfActivity.a(this.a); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */