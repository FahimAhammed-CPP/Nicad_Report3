package com.g.g;

import android.app.Activity;
import android.content.Context;
import android.widget.SeekBar;
import com.a.a.f;
import com.a.a.g;

final class ah implements SeekBar.OnSeekBarChangeListener {
  ah(ReadbookDown paramReadbookDown) {}
  
  public final void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean) {}
  
  public final void onStartTrackingTouch(SeekBar paramSeekBar) {}
  
  public final void onStopTrackingTouch(SeekBar paramSeekBar) {
    g.a((Activity)this.a, ReadbookDown.p(this.a).getProgress() + 20);
    f.c((Context)this.a, ReadbookDown.p(this.a).getProgress());
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */