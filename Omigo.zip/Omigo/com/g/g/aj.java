package com.g.g;

import android.view.View;

final class aj implements View.OnClickListener {
  aj(ReadbookDown paramReadbookDown) {}
  
  public final void onClick(View paramView) {
    this.a.j.e();
    ReadbookDown.i(this.a);
    ReadbookDown.o(this.a);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */