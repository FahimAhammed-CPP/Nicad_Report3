package com.g.g;

import android.view.View;

final class t implements View.OnClickListener {
  t(ReadBaseGroupActivity paramReadBaseGroupActivity) {}
  
  public final void onClick(View paramView) {
    this.a.q.setVisibility(8);
    this.a.r.setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */