package com.g.g;

import android.view.View;

final class ac implements View.OnClickListener {
  ac(ReadbookDown paramReadbookDown) {}
  
  public final void onClick(View paramView) {
    ReadbookDown.b(this.a);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */