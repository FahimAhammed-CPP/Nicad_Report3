package com.g.g;

import android.view.View;
import com.h.a.c;

final class j implements View.OnClickListener {
  j(FenleiItemListActivity paramFenleiItemListActivity) {}
  
  public final void onClick(View paramView) {
    if (FenleiItemListActivity.f(this.a) != null)
      FenleiItemListActivity.f(this.a).a(); 
    FenleiItemListActivity.a(this.a, new c(FenleiItemListActivity.h(this.a), 1, FenleiItemListActivity.i(this.a)));
    FenleiItemListActivity.f(this.a).start();
    FenleiItemListActivity.b(this.a).setVisibility(0);
    FenleiItemListActivity.c(this.a).setVisibility(0);
    FenleiItemListActivity.d(this.a).setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */