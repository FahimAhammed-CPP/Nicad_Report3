package com.g.g;

import android.widget.SeekBar;

final class ai implements SeekBar.OnSeekBarChangeListener {
  ai(ReadbookDown paramReadbookDown) {}
  
  public final void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean) {}
  
  public final void onStartTrackingTouch(SeekBar paramSeekBar) {}
  
  public final void onStopTrackingTouch(SeekBar paramSeekBar) {
    this.a.j.c(ReadbookDown.q(this.a).getProgress() - 100);
    ReadbookDown.i(this.a);
    ReadbookDown.o(this.a);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */