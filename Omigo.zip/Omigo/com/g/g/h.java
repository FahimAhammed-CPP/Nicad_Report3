package com.g.g;

import android.content.DialogInterface;
import com.b.a.b;

final class h implements DialogInterface.OnClickListener {
  h(BookMarkActivity paramBookMarkActivity) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    b b = BookMarkActivity.c(this.a);
    String str = BookMarkActivity.f(this.a);
    b.a.delete("bookmark", "novelId='" + str + "'", null);
    BookMarkActivity.a(this.a).clear();
    BookMarkActivity.d(this.a).notifyDataSetChanged();
    BookMarkActivity.g(this.a).setVisibility(0);
    BookMarkActivity.h(this.a).setVisibility(0);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */