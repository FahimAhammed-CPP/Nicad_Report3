package com.g.g;

import android.content.Context;
import android.widget.SeekBar;
import com.a.a.f;

final class ag implements SeekBar.OnSeekBarChangeListener {
  ag(ReadbookDown paramReadbookDown) {}
  
  public final void onProgressChanged(SeekBar paramSeekBar, int paramInt, boolean paramBoolean) {}
  
  public final void onStartTrackingTouch(SeekBar paramSeekBar) {
    ReadbookDown.b(this.a, paramSeekBar.getProgress());
  }
  
  public final void onStopTrackingTouch(SeekBar paramSeekBar) {
    if (ReadbookDown.m(this.a) != ReadbookDown.n(this.a).getProgress()) {
      this.a.j.a(ReadbookDown.n(this.a).getProgress());
      ReadbookDown.o(this.a);
      f.a((Context)this.a, ReadbookDown.n(this.a).getProgress());
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */