package com.g.g;

import android.content.DialogInterface;
import com.a.a.a;
import com.a.a.e;

final class y implements DialogInterface.OnClickListener {
  y(ReadBaseGroupActivity paramReadBaseGroupActivity) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {
    e.a();
    a.a();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */