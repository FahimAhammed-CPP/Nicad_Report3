package com.g.g;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.c.c.BaseActivity;
import com.e.a.c;
import com.f.a.b;
import com.h.a.b;
import com.h.a.c;
import java.util.Vector;

public class FenleiItemListActivity extends BaseActivity {
  private ListView j;
  
  private c k;
  
  private b l = new b();
  
  private c m;
  
  private b n;
  
  private LinearLayout o;
  
  private LinearLayout p;
  
  private LinearLayout q;
  
  private String r;
  
  private Handler s = new i(this);
  
  public final void c() {
    if (!this.d) {
      this.c.removeAllViews();
      if (this.l.b()) {
        this.c.addView((View)this.a, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.d = true;
        this.k = new c(this.s, this.l.a() + 1, this.r);
        this.k.start();
      } 
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903052);
    this.j = (ListView)findViewById(2131230820);
    this.o = (LinearLayout)findViewById(2131230833);
    this.p = (LinearLayout)findViewById(2131230834);
    this.q = (LinearLayout)findViewById(2131230835);
    ((Button)findViewById(2131230836)).setOnClickListener(new j(this));
    a(getIntent().getStringExtra("typeName"));
    this.h.setVisibility(8);
    this.g.setVisibility(8);
    this.j.setOnScrollListener(this.e);
    this.r = getIntent().getStringExtra("typeId");
    String str = this.r;
    Log.e(getClass().replace("class ", ""), str);
    this.k = new c(this.s, 1, this.r);
    this.k.start();
  }
  
  protected void onResume() {
    super.onResume();
    d();
    this.s.sendEmptyMessage(888);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/FenleiItemListActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */