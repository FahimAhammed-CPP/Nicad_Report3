package com.g.g;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import com.a.a.g;
import java.io.IOException;

final class af implements View.OnTouchListener {
  af(ReadbookDown paramReadbookDown) {}
  
  public final boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    boolean bool = false;
    null = bool;
    if (paramView == ReadbookDown.g(this.a)) {
      if (paramMotionEvent.getAction() == 0) {
        ReadbookDown.g(this.a).a(paramMotionEvent.getX(), paramMotionEvent.getY());
        this.a.j.a(ReadbookDown.h(this.a));
        if (ReadbookDown.g(this.a).b()) {
          try {
            this.a.j.a();
            if (this.a.j.c())
              return bool; 
          } catch (IOException iOException) {
            iOException.printStackTrace();
            if (this.a.j.c())
              return bool; 
          } 
          ReadbookDown.i(this.a);
          this.a.j.a(ReadbookDown.j(this.a));
        } else {
          try {
            this.a.j.b();
            if (this.a.j.d()) {
              Toast.makeText((Context)this.a, "当前为最后一页", 0).show();
              return bool;
            } 
          } catch (IOException iOException) {
            iOException.printStackTrace();
            if (this.a.j.d()) {
              Toast.makeText((Context)this.a, "当前为最后一页", 0).show();
              return bool;
            } 
          } 
          ReadbookDown.i(this.a);
          this.a.j.a(ReadbookDown.j(this.a));
        } 
        ReadbookDown.g(this.a).a(ReadbookDown.k(this.a), ReadbookDown.l(this.a));
      } 
    } else {
      return null;
    } 
    ReadbookDown.g(this.a).a();
    ReadbookDown.g(this.a).a(paramMotionEvent);
    if (g.a() < 8)
      this.a.j.a(ReadbookDown.h(this.a)); 
    return true;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */