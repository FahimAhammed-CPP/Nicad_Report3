package com.g.g;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import com.a.a.e;
import com.e.a.a;
import com.h.a.d;
import java.util.ArrayList;

public class GroupFenleiActivity extends ReadBaseGroupActivity {
  private Handler A = new k(this);
  
  private GridView t;
  
  private a u;
  
  private d v;
  
  private ArrayList w = new ArrayList();
  
  private LinearLayout x;
  
  private LinearLayout y;
  
  private LinearLayout z;
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903053);
    e();
    a("分类");
    f();
    this.x = (LinearLayout)findViewById(2131230833);
    this.y = (LinearLayout)findViewById(2131230834);
    this.z = (LinearLayout)findViewById(2131230835);
    ((Button)findViewById(2131230836)).setOnClickListener(new l(this));
    this.t = (GridView)findViewById(2131230822);
    if (e.c == null || e.c.size() == 0) {
      this.v = new d(this.A);
      this.v.start();
      return;
    } 
    this.A.sendEmptyMessage(222);
  }
  
  protected void onResume() {
    super.onResume();
    a(this.m.getId());
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/GroupFenleiActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */