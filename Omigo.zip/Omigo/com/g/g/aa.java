package com.g.g;

import android.content.Context;
import android.widget.RadioGroup;
import com.a.a.f;

final class aa implements RadioGroup.OnCheckedChangeListener {
  aa(ReadbookDown paramReadbookDown) {}
  
  public final void onCheckedChanged(RadioGroup paramRadioGroup, int paramInt) {
    if (paramInt == ReadbookDown.r(this.a).getId()) {
      if (ReadbookDown.r(this.a).isChecked()) {
        ReadbookDown.s(this.a).setVisibility(8);
        ReadbookDown.t(this.a).setVisibility(0);
        ReadbookDown.t(this.a).startAnimation(ReadbookDown.u(this.a));
        ReadbookDown.a(this.a, ReadbookDown.t(this.a));
        ReadbookDown.o(this.a);
      } 
      return;
    } 
    if (paramInt == ReadbookDown.v(this.a).getId()) {
      if (ReadbookDown.v(this.a).isChecked()) {
        ReadbookDown.s(this.a).setVisibility(8);
        ReadbookDown.w(this.a).setVisibility(0);
        ReadbookDown.w(this.a).startAnimation(ReadbookDown.u(this.a));
        ReadbookDown.a(this.a, ReadbookDown.w(this.a));
        ReadbookDown.o(this.a);
      } 
      return;
    } 
    if (paramInt == ReadbookDown.x(this.a).getId()) {
      if (ReadbookDown.x(this.a).isChecked()) {
        ReadbookDown.s(this.a).setVisibility(8);
        ReadbookDown.y(this.a).setVisibility(0);
        ReadbookDown.y(this.a).startAnimation(ReadbookDown.u(this.a));
        ReadbookDown.a(this.a, ReadbookDown.y(this.a));
        ReadbookDown.o(this.a);
      } 
      return;
    } 
    if (paramInt == ReadbookDown.z(this.a).getId()) {
      ReadbookDown.s(this.a).setVisibility(8);
      paramRadioGroup.clearCheck();
      if ("夜晚".equals(ReadbookDown.z(this.a).getText().toString())) {
        ReadbookDown.z(this.a).setCompoundDrawablesWithIntrinsicBounds(null, this.a.getResources().getDrawable(2130837549), null, null);
        ReadbookDown.z(this.a).setText("白天");
        this.a.j.d(4);
        ReadbookDown.o(this.a);
        f.d((Context)this.a, 1);
        return;
      } 
      ReadbookDown.z(this.a).setCompoundDrawablesWithIntrinsicBounds(null, this.a.getResources().getDrawable(2130837548), null, null);
      ReadbookDown.z(this.a).setText("夜晚");
      this.a.j.d(ReadbookDown.A(this.a));
      ReadbookDown.o(this.a);
      f.d((Context)this.a, 0);
      return;
    } 
    if (paramInt == ReadbookDown.B(this.a).getId() && ReadbookDown.B(this.a).isChecked()) {
      ReadbookDown.s(this.a).setVisibility(8);
      ReadbookDown.C(this.a).setVisibility(0);
      ReadbookDown.C(this.a).startAnimation(ReadbookDown.u(this.a));
      ReadbookDown.a(this.a, ReadbookDown.C(this.a));
      ReadbookDown.o(this.a);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */