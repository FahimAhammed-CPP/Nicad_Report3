package com.g.g;

import android.content.DialogInterface;

final class x implements DialogInterface.OnClickListener {
  x(ReadBaseGroupActivity paramReadBaseGroupActivity) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */