package com.g.g;

import android.content.DialogInterface;

final class d implements DialogInterface.OnClickListener {
  d(c paramc) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */