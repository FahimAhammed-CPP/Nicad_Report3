package com.g.g;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.a.a.f;
import com.a.a.g;
import com.b.a.a;
import com.b.a.b;
import com.b.a.c;
import com.c.c.BaseActivity;
import com.f.a.c;
import com.i.a.a;
import com.i.a.b;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public class ReadbookDown extends BaseActivity implements View.OnClickListener {
  private RadioGroup A;
  
  private RadioGroup B;
  
  private int C = 0;
  
  private Button D;
  
  private Button E;
  
  private Button F;
  
  private Button G;
  
  private Button H;
  
  private Button I;
  
  private Button J;
  
  private Button K;
  
  private ImageView L;
  
  private RadioButton M;
  
  private RadioButton N;
  
  private RadioButton O;
  
  private RadioButton P;
  
  private RadioButton Q;
  
  private RadioButton R;
  
  private RadioButton S;
  
  private RadioButton T;
  
  private RadioButton U;
  
  private LinearLayout V;
  
  private LinearLayout W;
  
  private LinearLayout X;
  
  private LinearLayout Y;
  
  private LinearLayout Z;
  
  private File aa;
  
  private TextView ab;
  
  private String ac;
  
  private String ad;
  
  private int ae;
  
  private String af;
  
  private Animation ag;
  
  private Animation ah;
  
  private Animation ai;
  
  private Animation aj;
  
  private Animation ak;
  
  private HashMap al = null;
  
  private AlphaAnimation am;
  
  private RelativeLayout an;
  
  private int ao = 0;
  
  private c ap;
  
  private b aq;
  
  a j;
  
  private b k;
  
  private Bitmap l;
  
  private Bitmap m;
  
  private Canvas n;
  
  private Canvas o;
  
  private RelativeLayout p;
  
  private RelativeLayout q;
  
  private RelativeLayout r;
  
  private RelativeLayout s;
  
  private RelativeLayout t;
  
  private int u;
  
  private int v;
  
  private SeekBar w;
  
  private SeekBar x;
  
  private SeekBar y;
  
  private int z = 0;
  
  private void e() {
    this.j.a(this.n);
    this.j.a(this.o);
    this.k.a(this.l, this.m);
    this.k.postInvalidate();
  }
  
  private void f() {
    this.Z.setVisibility(8);
    this.A.clearCheck();
    this.p.setVisibility(8);
    this.r.setVisibility(8);
    this.t.setVisibility(8);
    this.r.startAnimation(this.ag);
    this.t.startAnimation(this.aj);
  }
  
  private void g() {
    this.p.setVisibility(0);
    this.r.setVisibility(0);
    this.t.setVisibility(0);
    this.r.startAnimation(this.ah);
    this.t.startAnimation(this.ai);
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt2 == -1 && paramInt1 == 222) {
      paramInt1 = paramIntent.getIntExtra("beg", 0);
      a a1 = this.j;
      this.j.c = paramInt1;
      a1.b = paramInt1;
      this.j.d.clear();
      e();
    } 
  }
  
  public void onClick(View paramView) {
    if (paramView.getId() == this.J.getId()) {
      int i = this.y.getProgress();
      if (i != 0) {
        this.y.setProgress(i - 10);
        f.c((Context)this, i - 10);
        g.a((Activity)this, i + 10);
      } 
      return;
    } 
    if (paramView.getId() == this.K.getId()) {
      int i = this.y.getProgress();
      if (i != 235) {
        this.y.setProgress(i + 10);
        f.c((Context)this, i + 10);
        g.a((Activity)this, i + 30);
      } 
      return;
    } 
    if (paramView.getId() == this.H.getId()) {
      int i = this.w.getProgress();
      if (i != 0) {
        this.w.setProgress(i - 1);
        f.a((Context)this, i - 1);
        this.j.a(i - 1);
      } else {
        return;
      } 
    } else if (paramView.getId() == this.I.getId()) {
      int i = this.w.getProgress();
      if (i != 4) {
        this.w.setProgress(i + 1);
        f.a((Context)this, i + 1);
        this.j.a(i + 1);
      } else {
        return;
      } 
    } else {
      Intent intent;
      if (paramView.getId() == this.D.getId()) {
        intent = new Intent((Context)this, BookMarkActivity.class);
        intent.putExtra("aid", this.ac);
        intent.putExtra("bname", this.ad);
        startActivityForResult(intent, 222);
        return;
      } 
      if (intent.getId() == this.L.getId()) {
        this.aq.a(this.ac, this.j.b);
        this.al = this.aq.b(this.ac);
        this.L.setVisibility(8);
        this.L.startAnimation((Animation)this.am);
      } else if (intent.getId() == this.E.getId()) {
        if (this.L.getVisibility() == 8) {
          String str;
          c c1 = new c();
          c1.a(this.ac);
          a a1 = this.j;
          if (a1.d != null && a1.d.size() > 0) {
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append(a1.d.get(0));
            if (a1.d.size() > 1)
              stringBuffer.append(a1.d.get(1)); 
            str = stringBuffer.toString();
          } else {
            str = "";
          } 
          c1.d(str);
          c1.a(this.j.b);
          c1.b(System.currentTimeMillis());
          c1.b(this.af);
          c1.e(this.ad);
          c1.c(this.j.h);
          b b1 = this.aq;
          ContentValues contentValues = new ContentValues();
          contentValues.put("novelId", c1.b());
          contentValues.put("novelName", c1.h());
          contentValues.put("localURL", c1.c());
          contentValues.put("posi", Integer.valueOf(c1.e()));
          contentValues.put("jindu", c1.d());
          contentValues.put("jj", c1.f());
          contentValues.put("time", Long.valueOf(c1.g()));
          b1.a.insert("bookmark", null, contentValues);
          this.al = this.aq.b(this.ac);
          this.L.setVisibility(0);
          this.L.startAnimation(this.ak);
        } else {
          this.aq.a(this.ac, this.j.b);
          this.al = this.aq.b(this.ac);
          this.L.setVisibility(8);
          this.L.startAnimation((Animation)this.am);
        } 
      } else {
        return;
      } 
    } 
    e();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    setContentView(2130903042);
    if (f.b((Context)this) == 0) {
      f.a((Context)this);
      this.an = (RelativeLayout)findViewById(2131230756);
      this.an.setVisibility(0);
      this.an.setOnClickListener(new z(this));
    } 
    Display display = getWindowManager().getDefaultDisplay();
    this.u = display.getWidth();
    this.v = display.getHeight();
    this.ah = AnimationUtils.loadAnimation((Context)this, 2130837537);
    this.ag = AnimationUtils.loadAnimation((Context)this, 2130837540);
    this.ai = AnimationUtils.loadAnimation((Context)this, 2130837538);
    this.aj = AnimationUtils.loadAnimation((Context)this, 2130837541);
    this.ak = (Animation)new AlphaAnimation(0.0F, 1.0F);
    this.ak.setDuration(200L);
    this.am = new AlphaAnimation(1.0F, 0.0F);
    this.am.setDuration(200L);
    this.af = getIntent().getStringExtra("url");
    this.C = getIntent().getIntExtra("beg", 0);
    this.ac = getIntent().getStringExtra("aid");
    this.ad = getIntent().getStringExtra("bname");
    this.p = (RelativeLayout)findViewById(2131230731);
    this.q = (RelativeLayout)findViewById(2131230730);
    this.r = (RelativeLayout)findViewById(2131230735);
    this.t = (RelativeLayout)findViewById(2131230732);
    LinearLayout linearLayout = (LinearLayout)findViewById(2131230742);
    this.V = linearLayout;
    this.Z = linearLayout;
    this.W = (LinearLayout)findViewById(2131230736);
    this.X = (LinearLayout)findViewById(2131230746);
    this.Y = (LinearLayout)findViewById(2131230750);
    this.ab = (TextView)findViewById(2131230752);
    this.D = (Button)findViewById(2131230728);
    this.E = (Button)findViewById(2131230727);
    this.F = (Button)findViewById(2131230753);
    this.G = (Button)findViewById(2131230754);
    this.H = (Button)findViewById(2131230743);
    this.I = (Button)findViewById(2131230745);
    this.J = (Button)findViewById(2131230747);
    this.K = (Button)findViewById(2131230749);
    this.s = (RelativeLayout)findViewById(2131230729);
    this.w = (SeekBar)findViewById(2131230744);
    this.x = (SeekBar)findViewById(2131230751);
    this.y = (SeekBar)findViewById(2131230748);
    this.L = (ImageView)findViewById(2131230734);
    this.V.setOnClickListener(this);
    this.W.setOnClickListener(this);
    this.X.setOnClickListener(this);
    this.Y.setOnClickListener(this);
    this.D.setOnClickListener(this);
    this.L.setOnClickListener(this);
    this.E.setOnClickListener(this);
    this.t.setOnClickListener(this);
    this.H.setOnClickListener(this);
    this.I.setOnClickListener(this);
    this.J.setOnClickListener(this);
    this.K.setOnClickListener(this);
    this.y.setProgress(f.e((Context)this));
    this.w.setProgress(f.c((Context)this));
    int i = f.e((Context)this);
    int j = i;
    if (i < 20) {
      f.c((Context)this, 20);
      j = 20;
    } 
    g.a((Activity)this, j);
    this.p.setOnClickListener(new ac(this));
    this.q.setOnClickListener(new ad(this));
    this.k = new b((Context)this, this.u, this.v);
    this.l = Bitmap.createBitmap(this.u, this.v, Bitmap.Config.ARGB_8888);
    this.m = Bitmap.createBitmap(this.u, this.v, Bitmap.Config.ARGB_8888);
    this.n = new Canvas(this.l);
    this.o = new Canvas(this.m);
    this.j = new a((Context)this, this.u, this.v, this.x, this.ab);
    this.j.b(f.c((Context)this));
    this.j.d(f.d((Context)this));
    this.w.setOnSeekBarChangeListener(new ag(this));
    this.y.setOnSeekBarChangeListener(new ah(this));
    this.A = (RadioGroup)findViewById(2131230720);
    this.B = (RadioGroup)findViewById(2131230737);
    this.R = (RadioButton)findViewById(2131230738);
    this.S = (RadioButton)findViewById(2131230739);
    this.T = (RadioButton)findViewById(2131230740);
    this.U = (RadioButton)findViewById(2131230741);
    this.M = (RadioButton)findViewById(2131230721);
    this.N = (RadioButton)findViewById(2131230722);
    this.O = (RadioButton)findViewById(2131230723);
    this.P = (RadioButton)findViewById(2131230724);
    this.Q = (RadioButton)findViewById(2131230725);
    this.A.setOnCheckedChangeListener(new aa(this));
    this.B.setOnCheckedChangeListener(new ab(this));
    if (f.f((Context)this) == 1) {
      this.P.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(2130837549), null, null);
      this.P.setText("白天");
      this.j.d(4);
      this.z = f.d((Context)this);
    } else {
      this.j.d(f.d((Context)this));
    } 
    this.k.setOnTouchListener(new af(this));
    this.ap = new c((Context)this);
    this.ap.a();
    if (this.af != null && !"".equals(this.af)) {
      this.aa = new File(this.af);
      c c1 = this.ap;
      String str = this.ac;
      ContentValues contentValues = new ContentValues();
      contentValues.put("date", Long.valueOf(System.currentTimeMillis()));
      contentValues.put("showDate", Long.valueOf(System.currentTimeMillis()));
      c1.a.update("booktable", contentValues, "novelId='" + str + "'", null);
      try {
        this.j.a(this.aa, this.C);
        if (this.x != null) {
          SeekBar seekBar = this.x;
          ai ai = new ai();
          this(this);
          seekBar.setOnSeekBarChangeListener(ai);
        } 
        if (this.F != null) {
          Button button = this.F;
          aj aj = new aj();
          this(this);
          button.setOnClickListener(aj);
        } 
        if (this.G != null) {
          Button button = this.G;
          ak ak = new ak();
          this(this);
          button.setOnClickListener(ak);
        } 
        this.C = 0;
        this.j.a(this.n);
        this.j.a(this.o);
      } catch (IOException iOException) {
        Toast.makeText((Context)this, "获取电子书有错", 1).show();
      } 
      this.k.a(this.l, this.l);
      this.s.removeAllViews();
      this.s.addView((View)this.k);
    } 
  }
  
  protected void onDestroy() {
    super.onDestroy();
    this.o = null;
    this.n = null;
    if (this.l != null && !this.l.isRecycled()) {
      this.l.recycle();
      this.l = null;
    } 
    if (this.m != null && !this.m.isRecycled()) {
      this.m.recycle();
      this.m = null;
    } 
    this.j.g();
    System.gc();
    if (this.aa != null && this.aa.exists()) {
      c c1 = this.ap;
      String str1 = this.ac;
      String str2 = this.j.h;
      int i = this.j.b;
      ContentValues contentValues = new ContentValues();
      contentValues.put("date", Long.valueOf(System.currentTimeMillis()));
      contentValues.put("showDate", Long.valueOf(System.currentTimeMillis()));
      contentValues.put("posi", Integer.valueOf(i));
      contentValues.put("jindu", str2);
      c1.a.update("booktable", contentValues, "novelId='" + str1 + "'", null);
    } 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    null = true;
    if (paramInt == 82) {
      if (this.r.getVisibility() == 0) {
        f();
        return null;
      } 
      g();
      return null;
    } 
    if (paramInt == 4 && this.p.getVisibility() == 0) {
      f();
      return null;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onResume() {
    super.onResume();
    if (this.ap != null && !((a)this.ap).a.isOpen())
      this.ap.a(); 
    this.aq = new b((Context)this);
    this.aq.a();
    this.al = this.aq.b(this.ac);
    if (this.al.containsKey(Integer.valueOf(this.j.b))) {
      this.L.setVisibility(0);
    } else {
      this.L.setVisibility(8);
    } 
    this.Z.setVisibility(8);
    this.A.clearCheck();
    this.p.setVisibility(8);
    this.r.setVisibility(8);
    this.t.setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/ReadbookDown.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */