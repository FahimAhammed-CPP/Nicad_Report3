package com.g.g;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.a.a.e;
import com.e.a.c;
import com.f.a.b;
import com.h.a.b;
import com.h.a.e;
import java.util.Vector;

public class GroupPaihangActivity extends ReadBaseGroupActivity {
  private LinearLayout A;
  
  private Handler B = new m(this);
  
  private ListView t;
  
  private e u;
  
  private b v = new b();
  
  private c w;
  
  private b x;
  
  private LinearLayout y;
  
  private LinearLayout z;
  
  public final void c() {
    if (!this.d) {
      this.c.removeAllViews();
      if (this.v.b()) {
        this.c.addView((View)this.a, (ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        this.d = true;
        this.u = new e(this.B, this.v.a() + 1);
        this.u.start();
      } 
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903055);
    e();
    a("排行");
    f();
    this.y = (LinearLayout)findViewById(2131230833);
    this.z = (LinearLayout)findViewById(2131230834);
    this.A = (LinearLayout)findViewById(2131230835);
    ((Button)findViewById(2131230836)).setOnClickListener(new n(this));
    this.t = (ListView)findViewById(2131230830);
    this.t.setOnScrollListener(this.e);
    if (e.a == null) {
      this.u = new e(this.B, 1);
      this.u.start();
      return;
    } 
    this.B.sendEmptyMessage(222);
  }
  
  protected void onResume() {
    super.onResume();
    a(this.k.getId());
    d();
    this.B.sendEmptyMessage(888);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/GroupPaihangActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */