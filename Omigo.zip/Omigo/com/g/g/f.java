package com.g.g;

import android.content.Context;
import android.view.View;
import android.widget.Toast;

final class f implements View.OnClickListener {
  f(BookMarkActivity paramBookMarkActivity) {}
  
  public final void onClick(View paramView) {
    if (BookMarkActivity.a(this.a).size() > 0) {
      BookMarkActivity.e(this.a);
      return;
    } 
    Toast.makeText((Context)this.a, "当前没有书签", 0).show();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */