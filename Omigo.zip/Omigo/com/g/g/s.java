package com.g.g;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.a.a.e;

final class s implements View.OnClickListener {
  s(ReadBaseGroupActivity paramReadBaseGroupActivity) {}
  
  public final void onClick(View paramView) {
    if (this.a.p || this.a.o != paramView.getId()) {
      Intent intent;
      if (paramView.getId() == 2131230721) {
        this.a.o = paramView.getId();
        intent = new Intent((Context)this.a, GroupPaihangActivity.class);
        intent.addFlags(131072);
        this.a.startActivity(intent);
        e.g = GroupPaihangActivity.class;
        return;
      } 
      if (intent.getId() == 2131230722) {
        this.a.o = intent.getId();
        intent = new Intent((Context)this.a, GroupXinShuActivity.class);
        intent.addFlags(131072);
        this.a.startActivity(intent);
        e.g = GroupXinShuActivity.class;
        return;
      } 
      if (intent.getId() == 2131230723) {
        this.a.o = intent.getId();
        intent = new Intent((Context)this.a, GroupFenleiActivity.class);
        intent.addFlags(131072);
        this.a.startActivity(intent);
        e.g = GroupFenleiActivity.class;
        return;
      } 
      if (intent.getId() == 2131230724) {
        this.a.o = intent.getId();
        intent = new Intent((Context)this.a, GroupShelfActivity.class);
        intent.addFlags(131072);
        this.a.startActivity(intent);
        e.g = GroupShelfActivity.class;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */