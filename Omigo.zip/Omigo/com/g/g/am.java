package com.g.g;

import android.view.View;
import com.h.a.f;

final class am implements View.OnClickListener {
  am(SearchResultActivity paramSearchResultActivity) {}
  
  public final void onClick(View paramView) {
    if (SearchResultActivity.h(this.a) != null)
      SearchResultActivity.h(this.a).a(); 
    SearchResultActivity.a(this.a, new f(SearchResultActivity.k(this.a), SearchResultActivity.a(this.a), 1));
    SearchResultActivity.h(this.a).start();
    SearchResultActivity.d(this.a).setVisibility(0);
    SearchResultActivity.e(this.a).setVisibility(0);
    SearchResultActivity.f(this.a).setVisibility(8);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/g/g/am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */