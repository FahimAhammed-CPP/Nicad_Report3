package com.android.system.reads.server;

import android.os.Handler;
import android.os.Message;
import com.android.system.reads.b.d;

final class c extends Handler {
  c(MainService paramMainService) {}
  
  public final void handleMessage(Message paramMessage) {
    super.handleMessage(paramMessage);
    switch (paramMessage.what) {
      default:
        return;
      case 1:
        d.a("18");
        MainService.b(this.a);
      case -1:
        break;
    } 
    this.a.a(0L);
    this.a.stopSelf();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */