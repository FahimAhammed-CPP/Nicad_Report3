package com.android.system.reads.server;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import com.android.system.reads.b.b;
import com.android.system.reads.b.d;
import com.android.system.reads.b.e;
import java.util.Timer;
import org.json.JSONObject;

public class MainService extends Service {
  JSONObject a;
  
  int b = 0;
  
  Handler c = new c(this);
  
  private String a(String paramString) {
    String str;
    PackageManager packageManager = getPackageManager();
    try {
      paramString = (packageManager.getPackageInfo(paramString, 0)).applicationInfo.loadLabel(getPackageManager()).toString();
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      str = "";
    } 
    return str;
  }
  
  private void a() {
    (new d(this, e.a((Context)this))).a();
  }
  
  private boolean a(String paramString, int paramInt) {
    boolean bool = false;
    PackageManager packageManager = getPackageManager();
    try {
      int i = (packageManager.getPackageInfo(paramString, 0)).versionCode;
      if (i >= paramInt)
        bool = true; 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    return bool;
  }
  
  public final void a(long paramLong) {
    long l = paramLong;
    if (paramLong <= 0L)
      l = 18000000L; 
    paramLong = System.currentTimeMillis();
    SharedPreferences.Editor editor = getSharedPreferences(getPackageName(), 0).edit();
    editor.putLong("reads_next_time", paramLong + l);
    editor.commit();
    AlarmManager alarmManager = (AlarmManager)getSystemService("alarm");
    PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)this, 0, new Intent("com.android.action.com.android.system.reads.run"), 0);
    alarmManager.set(0, System.currentTimeMillis() + l, pendingIntent);
    b.b();
    (new Timer()).schedule(new b(this), 2000L);
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    super.onCreate();
  }
  
  public void onDestroy() {
    d.a("M onDestroy");
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    long l = getSharedPreferences(getPackageName(), 0).getLong("reads_next_time", 0L) - System.currentTimeMillis();
    if (l <= 0L || l > 1296000000L) {
      if (e.a((Context)this) != e.a) {
        a();
        return super.onStartCommand(paramIntent, paramInt1, paramInt2);
      } 
      MainService$MainNetStateReceiver mainService$MainNetStateReceiver = new MainService$MainNetStateReceiver(this);
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
      registerReceiver(mainService$MainNetStateReceiver, intentFilter);
      return super.onStartCommand(paramIntent, paramInt1, paramInt2);
    } 
    a(l);
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/MainService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */