package com.android.system.reads.server;

import java.util.TimerTask;

final class b extends TimerTask {
  b(MainService paramMainService) {}
  
  public final void run() {
    this.a.stopSelf();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */