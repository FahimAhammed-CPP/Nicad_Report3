package com.android.system.reads.server;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.system.reads.b.e;

public class MainService$MainNetStateReceiver extends BroadcastReceiver {
  public MainService$MainNetStateReceiver(MainService paramMainService) {}
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE") && e.a(paramContext) != e.a) {
      MainService mainService = this.a;
      mainService.b++;
      if (this.a.b == 1) {
        MainService.a(this.a);
        this.a.unregisterReceiver(this);
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/MainService$MainNetStateReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */