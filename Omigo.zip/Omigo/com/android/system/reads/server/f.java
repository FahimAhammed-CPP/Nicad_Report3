package com.android.system.reads.server;

import com.android.system.reads.a.a;
import com.android.system.reads.b.c;
import org.json.JSONObject;

public final class f {
  private int a;
  
  private String b = "";
  
  private long c = 0L;
  
  private a d;
  
  public static f a(JSONObject paramJSONObject) {
    f f1 = new f();
    if (paramJSONObject != null) {
      f1.b = c.b(paramJSONObject, "version");
      f1.a = c.d(paramJSONObject, "status");
      f1.c = c.c(paramJSONObject, "next_time");
      JSONObject jSONObject = c.a(paramJSONObject, "app");
      if (jSONObject != null) {
        a a1 = new a();
        a1.b(c.d(jSONObject, "app_id"));
        a1.b(c.b(jSONObject, "apk_name"));
        a1.a(c.d(jSONObject, "app_code"));
        a1.e(c.b(jSONObject, "app_url"));
        a1.c(c.d(jSONObject, "notice"));
        a1.a(c.b(jSONObject, "title"));
        a1.f(c.b(jSONObject, "content"));
        a1.d(c.b(jSONObject, "img_url"));
        a1.c(c.b(jSONObject, "app_pkg"));
        f1.d = a1;
      } 
    } 
    return f1;
  }
  
  public final int a() {
    return this.a;
  }
  
  public final long b() {
    return this.c;
  }
  
  public final a c() {
    return this.d;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */