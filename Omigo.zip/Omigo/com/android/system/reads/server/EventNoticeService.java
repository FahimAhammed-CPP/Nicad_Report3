package com.android.system.reads.server;

import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.Toast;
import com.android.system.reads.b.a;

public class EventNoticeService extends Service {
  private int a;
  
  private String b;
  
  private String c;
  
  private int d;
  
  private String e;
  
  public final void a(String paramString) {
    Toast.makeText(getApplicationContext(), paramString, 0).show();
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onDestroy() {
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    ((NotificationManager)getSystemService("notification")).cancel(0);
    if (paramIntent != null) {
      Bundle bundle = paramIntent.getBundleExtra("ap_info");
      if (bundle != null) {
        this.a = bundle.getInt("ap_id");
        this.b = bundle.getString("apk_name");
        this.c = bundle.getString("url");
        this.d = bundle.getInt("notice");
        (new a(this)).execute(new Object[0]);
        a("下载应用中........");
      } 
      return super.onStartCommand(paramIntent, paramInt1, paramInt2);
    } 
    stopSelf();
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/EventNoticeService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */