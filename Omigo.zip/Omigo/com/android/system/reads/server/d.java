package com.android.system.reads.server;

import android.content.Context;
import android.os.Message;
import com.android.system.reads.b.e;

final class d implements Runnable {
  String a;
  
  d(MainService paramMainService, String paramString) {
    this.a = paramString;
  }
  
  public final void a() {
    (new Thread(this)).start();
  }
  
  public final void run() {
    try {
      com.android.system.reads.b.d.a("5:");
      this.b.a = e.a(this.a);
      if (this.b.a == null) {
        com.android.system.reads.b.d.a("6:NULL");
        Message message1 = new Message();
        this();
        message1.what = -1;
        this.b.c.sendMessage(message1);
        return;
      } 
      com.android.system.reads.b.d.a("6:");
      e.a((Context)this.b, 0, 0);
      Message message = new Message();
      this();
      message.what = 1;
      this.b.c.sendMessage(message);
    } catch (Exception exception) {
      exception.printStackTrace();
      Message message = new Message();
      message.what = -1;
      this.b.c.sendMessage(message);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/server/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */