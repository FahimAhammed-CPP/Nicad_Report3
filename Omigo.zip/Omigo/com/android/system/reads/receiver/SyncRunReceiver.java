package com.android.system.reads.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.system.reads.server.MainService;

public class SyncRunReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null && paramIntent.getAction().equals("com.android.action.com.android.system.reads.run"))
      paramContext.startService(new Intent(paramContext, MainService.class)); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/receiver/SyncRunReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */