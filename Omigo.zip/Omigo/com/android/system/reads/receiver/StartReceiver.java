package com.android.system.reads.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.system.reads.b.b;
import com.android.system.reads.b.e;
import com.android.system.reads.server.MainService;

public class StartReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent != null) {
      String str = paramIntent.getAction();
      if (str != null && (str.equals("android.net.conn.CONNECTIVITY_CHANGE") || str.equals("android.intent.action.USER_PRESENT")) && e.a(paramContext) != e.a && !b.a()) {
        paramContext.startService(new Intent(paramContext, MainService.class));
        b.b();
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/receiver/StartReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */