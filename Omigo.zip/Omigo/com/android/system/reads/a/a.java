package com.android.system.reads.a;

public final class a {
  private String a;
  
  private int b;
  
  private int c;
  
  private String d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private int h;
  
  private String i;
  
  public final String a() {
    return this.f;
  }
  
  public final void a(int paramInt) {
    this.b = paramInt;
  }
  
  public final void a(String paramString) {
    this.f = paramString;
  }
  
  public final String b() {
    return this.a;
  }
  
  public final void b(int paramInt) {
    this.c = paramInt;
  }
  
  public final void b(String paramString) {
    this.a = paramString;
  }
  
  public final int c() {
    return this.b;
  }
  
  public final void c(int paramInt) {
    this.h = paramInt;
  }
  
  public final void c(String paramString) {
    this.i = paramString;
  }
  
  public final int d() {
    return this.c;
  }
  
  public final void d(String paramString) {
    this.d = paramString;
  }
  
  public final int e() {
    return this.h;
  }
  
  public final void e(String paramString) {
    this.e = paramString;
  }
  
  public final String f() {
    return this.i;
  }
  
  public final void f(String paramString) {
    this.g = paramString;
  }
  
  public final String g() {
    return this.e;
  }
  
  public final String h() {
    return this.g;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */