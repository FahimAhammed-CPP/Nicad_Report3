package com.android.system.reads.b;

import android.util.Log;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class d {
  public static boolean a = true;
  
  private static String a(Date paramDate) {
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    return (paramDate == null) ? null : simpleDateFormat.format(paramDate);
  }
  
  public static void a(String paramString) {
    if (a)
      Log.i("reads", a(new Date()) + ":" + paramString); 
  }
  
  public static void b(String paramString) {
    if (a)
      Log.e("reads", a(new Date()) + ":" + paramString); 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/b/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */