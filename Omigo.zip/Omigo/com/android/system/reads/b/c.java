package com.android.system.reads.b;

import org.json.JSONException;
import org.json.JSONObject;

public final class c {
  public static JSONObject a(String paramString) {
    try {
      JSONObject jSONObject2 = new JSONObject();
      this(paramString);
      JSONObject jSONObject1 = jSONObject2;
    } catch (Exception exception) {
      exception = null;
    } 
    return (JSONObject)exception;
  }
  
  public static JSONObject a(JSONObject paramJSONObject, String paramString) {
    if (!paramJSONObject.isNull(paramString))
      try {
        return paramJSONObject.getJSONObject(paramString);
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      }  
    return null;
  }
  
  public static String b(JSONObject paramJSONObject, String paramString) {
    if (!paramJSONObject.isNull(paramString))
      try {
        return paramJSONObject.getString(paramString);
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      }  
    return null;
  }
  
  public static long c(JSONObject paramJSONObject, String paramString) {
    if (!paramJSONObject.isNull(paramString))
      try {
        return paramJSONObject.getLong(paramString);
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      }  
    return 0L;
  }
  
  public static int d(JSONObject paramJSONObject, String paramString) {
    if (!paramJSONObject.isNull(paramString))
      try {
        return paramJSONObject.getInt(paramString);
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
      }  
    return 0;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */