package com.android.system.reads.b;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import org.json.JSONObject;

public final class e {
  public static int a = 0;
  
  public static int b = 1;
  
  public static int c = 2;
  
  public static int a(Context paramContext) {
    ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
    if (networkInfo != null && networkInfo.isAvailable()) {
      if (connectivityManager.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED)
        return b; 
      if (connectivityManager.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED)
        return c; 
    } 
    return a;
  }
  
  public static JSONObject a(String paramString) {
    // Byte code:
    //   0: getstatic com/android/system/reads/b/b.a : [Ljava/lang/String;
    //   3: astore_1
    //   4: aload_1
    //   5: arraylength
    //   6: istore_2
    //   7: iconst_0
    //   8: istore_3
    //   9: iload_3
    //   10: iload_2
    //   11: if_icmpge -> 70
    //   14: aload_1
    //   15: iload_3
    //   16: aaload
    //   17: astore #4
    //   19: aload #4
    //   21: ifnull -> 64
    //   24: aload #4
    //   26: ldc ''
    //   28: invokevirtual equals : (Ljava/lang/Object;)Z
    //   31: ifne -> 64
    //   34: aload #4
    //   36: aload_0
    //   37: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   40: astore #4
    //   42: aload #4
    //   44: ifnull -> 64
    //   47: aload #4
    //   49: invokestatic a : (Ljava/lang/String;)Lorg/json/JSONObject;
    //   52: astore #4
    //   54: aload #4
    //   56: ifnull -> 64
    //   59: aload #4
    //   61: areturn
    //   62: astore #4
    //   64: iinc #3, 1
    //   67: goto -> 9
    //   70: aconst_null
    //   71: astore #4
    //   73: goto -> 59
    // Exception table:
    //   from	to	target	type
    //   34	42	62	java/lang/Exception
    //   47	54	62	java/lang/Exception
  }
  
  public static boolean a(String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: aconst_null
    //   5: astore #4
    //   7: new java/net/URL
    //   10: astore #5
    //   12: aload #5
    //   14: aload_0
    //   15: invokespecial <init> : (Ljava/lang/String;)V
    //   18: aload #5
    //   20: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   23: checkcast java/net/HttpURLConnection
    //   26: astore_0
    //   27: aload_0
    //   28: ldc 200000
    //   30: invokevirtual setConnectTimeout : (I)V
    //   33: aload_0
    //   34: ldc 1000000
    //   36: invokevirtual setReadTimeout : (I)V
    //   39: aload_0
    //   40: iconst_1
    //   41: invokevirtual setAllowUserInteraction : (Z)V
    //   44: aload_0
    //   45: ldc 'User-Agent'
    //   47: ldc 'Mozilla/5.0 (Linux; U; Android; zh-cn; X8 Build/GRK39F) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'
    //   49: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   52: aload_0
    //   53: invokevirtual getContentLength : ()I
    //   56: i2l
    //   57: lstore #6
    //   59: aload_0
    //   60: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   63: astore #5
    //   65: new java/io/File
    //   68: astore #4
    //   70: aload #4
    //   72: aload_1
    //   73: invokespecial <init> : (Ljava/lang/String;)V
    //   76: new java/io/RandomAccessFile
    //   79: astore_1
    //   80: aload_1
    //   81: aload #4
    //   83: ldc 'rw'
    //   85: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   88: lconst_0
    //   89: lstore #8
    //   91: sipush #10240
    //   94: newarray byte
    //   96: astore_3
    //   97: aload #5
    //   99: aload_3
    //   100: invokevirtual read : ([B)I
    //   103: istore #10
    //   105: iload #10
    //   107: iconst_m1
    //   108: if_icmpeq -> 130
    //   111: aload_1
    //   112: aload_3
    //   113: iconst_0
    //   114: iload #10
    //   116: invokevirtual write : ([BII)V
    //   119: lload #8
    //   121: iload #10
    //   123: i2l
    //   124: ladd
    //   125: lstore #8
    //   127: goto -> 97
    //   130: aload #5
    //   132: invokevirtual close : ()V
    //   135: aload_1
    //   136: invokevirtual close : ()V
    //   139: aload_0
    //   140: invokevirtual disconnect : ()V
    //   143: lload #6
    //   145: lload #8
    //   147: lcmp
    //   148: ifne -> 182
    //   151: aload #5
    //   153: ifnull -> 161
    //   156: aload #5
    //   158: invokevirtual close : ()V
    //   161: aload_1
    //   162: invokevirtual close : ()V
    //   165: iload_2
    //   166: istore #11
    //   168: aload_0
    //   169: ifnull -> 179
    //   172: aload_0
    //   173: invokevirtual disconnect : ()V
    //   176: iload_2
    //   177: istore #11
    //   179: iload #11
    //   181: ireturn
    //   182: iconst_0
    //   183: istore_2
    //   184: goto -> 151
    //   187: astore #5
    //   189: aconst_null
    //   190: astore_0
    //   191: aconst_null
    //   192: astore_1
    //   193: aload #4
    //   195: astore_3
    //   196: aload #5
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: invokestatic a : (Ljava/lang/String;)V
    //   204: aload_3
    //   205: ifnull -> 212
    //   208: aload_3
    //   209: invokevirtual close : ()V
    //   212: aload_0
    //   213: ifnull -> 220
    //   216: aload_0
    //   217: invokevirtual close : ()V
    //   220: aload_1
    //   221: ifnull -> 228
    //   224: aload_1
    //   225: invokevirtual disconnect : ()V
    //   228: iconst_0
    //   229: istore #11
    //   231: goto -> 179
    //   234: astore_0
    //   235: aconst_null
    //   236: astore #5
    //   238: aconst_null
    //   239: astore_1
    //   240: aload #5
    //   242: ifnull -> 250
    //   245: aload #5
    //   247: invokevirtual close : ()V
    //   250: aload_3
    //   251: ifnull -> 258
    //   254: aload_3
    //   255: invokevirtual close : ()V
    //   258: aload_1
    //   259: ifnull -> 266
    //   262: aload_1
    //   263: invokevirtual disconnect : ()V
    //   266: aload_0
    //   267: athrow
    //   268: astore #4
    //   270: aconst_null
    //   271: astore #5
    //   273: aload_0
    //   274: astore_1
    //   275: aload #4
    //   277: astore_0
    //   278: goto -> 240
    //   281: astore #4
    //   283: aload_0
    //   284: astore_1
    //   285: aload #4
    //   287: astore_0
    //   288: goto -> 240
    //   291: astore #4
    //   293: aload_1
    //   294: astore_3
    //   295: aload_0
    //   296: astore_1
    //   297: aload #4
    //   299: astore_0
    //   300: goto -> 240
    //   303: astore #4
    //   305: aload_3
    //   306: astore #5
    //   308: aload_0
    //   309: astore_3
    //   310: aload #4
    //   312: astore_0
    //   313: goto -> 240
    //   316: astore #5
    //   318: aload_0
    //   319: astore_1
    //   320: aconst_null
    //   321: astore_0
    //   322: aload #4
    //   324: astore_3
    //   325: goto -> 196
    //   328: astore_3
    //   329: aload_0
    //   330: astore_1
    //   331: aload_3
    //   332: astore_0
    //   333: aconst_null
    //   334: astore #4
    //   336: aload #5
    //   338: astore_3
    //   339: aload_0
    //   340: astore #5
    //   342: aload #4
    //   344: astore_0
    //   345: goto -> 196
    //   348: astore #12
    //   350: aload #5
    //   352: astore_3
    //   353: aload_0
    //   354: astore #4
    //   356: aload #12
    //   358: astore #5
    //   360: aload_1
    //   361: astore_0
    //   362: aload #4
    //   364: astore_1
    //   365: goto -> 196
    // Exception table:
    //   from	to	target	type
    //   7	27	187	java/lang/Exception
    //   7	27	234	finally
    //   27	65	316	java/lang/Exception
    //   27	65	268	finally
    //   65	88	328	java/lang/Exception
    //   65	88	281	finally
    //   91	97	348	java/lang/Exception
    //   91	97	291	finally
    //   97	105	348	java/lang/Exception
    //   97	105	291	finally
    //   111	119	348	java/lang/Exception
    //   111	119	291	finally
    //   130	143	348	java/lang/Exception
    //   130	143	291	finally
    //   196	204	303	finally
  }
  
  private static String b(String paramString1, String paramString2) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: new java/net/URL
    //   5: astore_3
    //   6: aload_3
    //   7: aload_0
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: aload_3
    //   12: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   15: checkcast java/net/HttpURLConnection
    //   18: astore_0
    //   19: aload_0
    //   20: iconst_1
    //   21: invokevirtual setDoInput : (Z)V
    //   24: aload_0
    //   25: iconst_1
    //   26: invokevirtual setDoOutput : (Z)V
    //   29: aload_0
    //   30: ldc 'content-type'
    //   32: ldc 'text/xml'
    //   34: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   37: aload_0
    //   38: ldc 'Accept-Charset'
    //   40: ldc 'UTF-8'
    //   42: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   45: aload_0
    //   46: invokevirtual connect : ()V
    //   49: new java/io/OutputStreamWriter
    //   52: astore_2
    //   53: aload_2
    //   54: aload_0
    //   55: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   58: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   61: aload_2
    //   62: aload_1
    //   63: invokevirtual write : (Ljava/lang/String;)V
    //   66: aload_2
    //   67: invokevirtual flush : ()V
    //   70: aload_2
    //   71: invokevirtual close : ()V
    //   74: new java/io/BufferedReader
    //   77: astore_1
    //   78: new java/io/InputStreamReader
    //   81: astore_2
    //   82: aload_2
    //   83: aload_0
    //   84: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   87: ldc 'UTF-8'
    //   89: invokespecial <init> : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   92: aload_1
    //   93: aload_2
    //   94: invokespecial <init> : (Ljava/io/Reader;)V
    //   97: new java/lang/StringBuilder
    //   100: astore_2
    //   101: aload_2
    //   102: invokespecial <init> : ()V
    //   105: aload_1
    //   106: invokevirtual readLine : ()Ljava/lang/String;
    //   109: astore_3
    //   110: aload_3
    //   111: ifnull -> 143
    //   114: aload_2
    //   115: aload_3
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: goto -> 105
    //   123: astore_1
    //   124: aload_1
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: invokestatic a : (Ljava/lang/String;)V
    //   131: aload_0
    //   132: ifnull -> 139
    //   135: aload_0
    //   136: invokevirtual disconnect : ()V
    //   139: aconst_null
    //   140: astore_0
    //   141: aload_0
    //   142: areturn
    //   143: aload_1
    //   144: invokevirtual close : ()V
    //   147: aload_0
    //   148: invokevirtual disconnect : ()V
    //   151: aload_2
    //   152: invokevirtual toString : ()Ljava/lang/String;
    //   155: astore_1
    //   156: aload_0
    //   157: ifnull -> 164
    //   160: aload_0
    //   161: invokevirtual disconnect : ()V
    //   164: aload_1
    //   165: astore_0
    //   166: goto -> 141
    //   169: astore_0
    //   170: aload_2
    //   171: astore_1
    //   172: aload_1
    //   173: ifnull -> 180
    //   176: aload_1
    //   177: invokevirtual disconnect : ()V
    //   180: aload_0
    //   181: athrow
    //   182: astore_2
    //   183: aload_0
    //   184: astore_1
    //   185: aload_2
    //   186: astore_0
    //   187: goto -> 172
    //   190: astore_2
    //   191: aload_0
    //   192: astore_1
    //   193: aload_2
    //   194: astore_0
    //   195: goto -> 172
    //   198: astore_1
    //   199: aconst_null
    //   200: astore_0
    //   201: goto -> 124
    // Exception table:
    //   from	to	target	type
    //   2	19	198	java/lang/Exception
    //   2	19	169	finally
    //   19	105	123	java/lang/Exception
    //   19	105	182	finally
    //   105	110	123	java/lang/Exception
    //   105	110	182	finally
    //   114	120	123	java/lang/Exception
    //   114	120	182	finally
    //   124	131	190	finally
    //   143	156	123	java/lang/Exception
    //   143	156	182	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/android/system/reads/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */