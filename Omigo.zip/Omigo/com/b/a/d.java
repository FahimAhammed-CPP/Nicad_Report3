package com.b.a;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public final class d extends SQLiteOpenHelper {
  public d(Context paramContext, String paramString) {
    super(paramContext, paramString, null, 7);
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("CREATE TABLE booktable (_id integer primary key autoincrement, novelId text ,novelName text ,novelImageUrl text ,novelAuthor text ,novelType text ,novelJJ text ,jindu text ,novelUrl text ,date integer ,showDate integer ,posi integer ,localURL text);");
    paramSQLiteDatabase.execSQL("CREATE TABLE bookmark (_id integer primary key autoincrement, novelId text ,novelName text ,localURL text ,posi integer ,jindu text ,jj text ,time integer);");
  }
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS booktable");
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS bookmark");
    onCreate(paramSQLiteDatabase);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/b/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */