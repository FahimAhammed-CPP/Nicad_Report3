package com.b.a;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.f.a.c;
import java.util.ArrayList;
import java.util.HashMap;

public final class b extends a {
  public b(Context paramContext) {
    super(paramContext);
  }
  
  private static ArrayList b(Cursor paramCursor) {
    ArrayList<c> arrayList = new ArrayList();
    if (paramCursor == null || !paramCursor.moveToFirst()) {
      a(paramCursor);
      return arrayList;
    } 
    for (byte b1 = 0; b1 < paramCursor.getCount(); b1++) {
      paramCursor.moveToPosition(b1);
      c c = new c();
      c.a(paramCursor.getLong(paramCursor.getColumnIndex("_id")));
      c.a(paramCursor.getString(paramCursor.getColumnIndex("novelId")));
      c.e(paramCursor.getString(paramCursor.getColumnIndex("novelName")));
      c.b(paramCursor.getString(paramCursor.getColumnIndex("localURL")));
      c.a(paramCursor.getInt(paramCursor.getColumnIndex("posi")));
      c.c(paramCursor.getString(paramCursor.getColumnIndex("jindu")));
      c.b(paramCursor.getLong(paramCursor.getColumnIndex("time")));
      c.d(paramCursor.getString(paramCursor.getColumnIndex("jj")));
      arrayList.add(c);
    } 
    a(paramCursor);
    return arrayList;
  }
  
  public final long a(String paramString, int paramInt) {
    return this.a.delete("bookmark", "novelId=" + paramString + " and posi=" + paramInt, null);
  }
  
  public final ArrayList a(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    paramString = "novelId='" + paramString + "'";
    return b(sQLiteDatabase.query("bookmark", new String[] { "_id", "novelId", "localURL", "novelName", "posi", "jindu", "time", "jj" }, paramString, null, null, null, null));
  }
  
  public final HashMap b(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    paramString = "novelId='" + paramString + "'";
    Cursor cursor = sQLiteDatabase.query("bookmark", new String[] { "_id", "posi" }, paramString, null, null, null, null);
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (cursor != null && cursor.moveToFirst())
      for (byte b1 = 0; b1 < cursor.getCount(); b1++) {
        cursor.moveToPosition(b1);
        long l = cursor.getLong(0);
        hashMap.put(Integer.valueOf(cursor.getInt(1)), Long.valueOf(l));
      }  
    a(cursor);
    return hashMap;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/b/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */