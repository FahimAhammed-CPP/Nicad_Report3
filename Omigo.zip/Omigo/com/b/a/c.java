package com.b.a;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.f.a.a;
import java.util.ArrayList;
import java.util.List;

public final class c extends a {
  public c(Context paramContext) {
    super(paramContext);
  }
  
  private static List b(Cursor paramCursor) {
    if (paramCursor == null || !paramCursor.moveToFirst()) {
      a(paramCursor);
      return null;
    } 
    ArrayList<a> arrayList = new ArrayList();
    for (byte b = 0; b < paramCursor.getCount(); b++) {
      paramCursor.moveToPosition(b);
      a a1 = new a();
      a1.a(paramCursor.getLong(paramCursor.getColumnIndex("_id")));
      a1.a(paramCursor.getString(paramCursor.getColumnIndex("novelId")));
      a1.b(paramCursor.getString(paramCursor.getColumnIndex("novelName")));
      a1.c(paramCursor.getString(paramCursor.getColumnIndex("novelImageUrl")));
      a1.d(paramCursor.getString(paramCursor.getColumnIndex("novelAuthor")));
      a1.e(paramCursor.getString(paramCursor.getColumnIndex("novelType")));
      a1.f(paramCursor.getString(paramCursor.getColumnIndex("novelUrl")));
      a1.i(paramCursor.getString(paramCursor.getColumnIndex("jindu")));
      a1.h(paramCursor.getString(paramCursor.getColumnIndex("novelJJ")));
      a1.b(paramCursor.getInt(paramCursor.getColumnIndex("posi")));
      a1.b(paramCursor.getLong(paramCursor.getColumnIndex("showDate")));
      a1.g(paramCursor.getString(paramCursor.getColumnIndex("localURL")));
      arrayList.add(a1);
    } 
    a(paramCursor);
    return arrayList;
  }
  
  public final a a(String paramString) {
    SQLiteDatabase sQLiteDatabase = this.a;
    paramString = "novelId='" + paramString + "'";
    List<a> list = b(sQLiteDatabase.query("booktable", new String[] { 
            "_id", "novelId", "novelName", "novelImageUrl", "novelAuthor", "novelType", "novelUrl", "novelJJ", "posi", "jindu", 
            "showDate", "localURL" }, paramString, null, null, null, null));
    return (list == null || list.size() == 0) ? null : list.get(0);
  }
  
  public final List b() {
    return b(this.a.query("booktable", new String[] { 
            "_id", "novelId", "novelName", "novelImageUrl", "novelAuthor", "novelType", "novelUrl", "novelJJ", "posi", "jindu", 
            "showDate", "localURL" }, null, null, null, null, "date desc"));
  }
  
  public final a c() {
    null = b(this.a.query("booktable", new String[] { 
            "_id", "novelId", "novelName", "novelImageUrl", "novelAuthor", "novelType", "novelUrl", "novelJJ", "posi", "jindu", 
            "showDate", "localURL" }, "showDate is not null", null, null, null, "showDate desc"));
    return (null != null && null.size() > 0) ? null.get(0) : null;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/b/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */