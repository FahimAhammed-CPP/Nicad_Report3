package com.b.a;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class a {
  public SQLiteDatabase a;
  
  private d b;
  
  private Context c;
  
  public a(Context paramContext) {
    this.c = paramContext;
  }
  
  public static void a(Cursor paramCursor) {
    if (paramCursor != null && !paramCursor.isClosed())
      paramCursor.close(); 
  }
  
  public final void a() {
    this.b = new d(this.c, "readtool.db");
    try {
      this.a = this.b.getWritableDatabase();
    } catch (SQLiteException sQLiteException) {
      this.a = this.b.getReadableDatabase();
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckOmigo-dex2jar.jar!/com/b/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */