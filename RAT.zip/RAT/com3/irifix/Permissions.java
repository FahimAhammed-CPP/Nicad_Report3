package com.irifix;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class Permissions {
  private static final Object a = new Object();
  
  private static int b;
  
  private static int c;
  
  private static String d;
  
  private static boolean e;
  
  public static boolean a(Context paramContext) {
    boolean bool = a(paramContext, 2, 165995653, "android.permission.WRITE_EXTERNAL_STORAGE");
    boolean bool1 = true;
    if (!bool || !a(paramContext, 1, 951090487, null))
      bool1 = false; 
    return bool1;
  }
  
  private static boolean a(Context paramContext, int paramInt1, int paramInt2, String paramString) {
    b = paramInt1;
    c = paramInt2;
    d = paramString;
    e = false;
    RequestActivity.a(paramContext);
    synchronized (a) {
      a.wait(10000L);
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{android/content/Context}, name=paramContext} */
    RequestActivity.a();
    return e;
  }
  
  public static class RequestActivity extends Activity {
    private static RequestActivity a;
    
    public static void a() {
      RequestActivity requestActivity = a;
      if (requestActivity != null) {
        requestActivity.finish();
        a = null;
      } 
    }
    
    public static void a(Context param1Context) {
      Intent intent = new Intent(param1Context, RequestActivity.class);
      intent.addFlags(268435456);
      param1Context.startActivity(intent);
    }
    
    public void onActivityResult(int param1Int1, int param1Int2, Intent param1Intent) {
      super.onActivityResult(param1Int1, param1Int2, param1Intent);
      if (param1Int1 == 951090487) {
        boolean bool;
        if (param1Int2 == -1) {
          bool = true;
        } else {
          bool = false;
        } 
        Permissions.a(bool);
      } 
      finish();
    }
    
    protected void onCreate(Bundle param1Bundle) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
      //   5: aload_0
      //   6: putstatic com/irifix/Permissions$RequestActivity.a : Lcom/irifix/Permissions$RequestActivity;
      //   9: invokestatic a : ()I
      //   12: istore_2
      //   13: iconst_0
      //   14: istore_3
      //   15: iconst_0
      //   16: istore #4
      //   18: iload_2
      //   19: iconst_1
      //   20: if_icmpne -> 125
      //   23: aconst_null
      //   24: astore_1
      //   25: invokestatic b : ()I
      //   28: ldc 951090487
      //   30: if_icmpeq -> 36
      //   33: goto -> 110
      //   36: getstatic android/os/Build$VERSION.SDK_INT : I
      //   39: bipush #26
      //   41: if_icmplt -> 107
      //   44: aload_0
      //   45: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
      //   48: invokevirtual canRequestPackageInstalls : ()Z
      //   51: ifne -> 107
      //   54: new android/content/Intent
      //   57: dup
      //   58: ldc 'android.settings.MANAGE_UNKNOWN_APP_SOURCES'
      //   60: invokespecial <init> : (Ljava/lang/String;)V
      //   63: astore_1
      //   64: new java/lang/StringBuilder
      //   67: dup
      //   68: invokespecial <init> : ()V
      //   71: astore #5
      //   73: aload #5
      //   75: ldc 'package:'
      //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   80: pop
      //   81: aload #5
      //   83: aload_0
      //   84: invokevirtual getPackageName : ()Ljava/lang/String;
      //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   90: pop
      //   91: aload_1
      //   92: aload #5
      //   94: invokevirtual toString : ()Ljava/lang/String;
      //   97: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
      //   100: invokevirtual setData : (Landroid/net/Uri;)Landroid/content/Intent;
      //   103: pop
      //   104: goto -> 110
      //   107: iconst_1
      //   108: istore #4
      //   110: aload_1
      //   111: ifnull -> 175
      //   114: aload_0
      //   115: aload_1
      //   116: invokestatic b : ()I
      //   119: invokevirtual startActivityForResult : (Landroid/content/Intent;I)V
      //   122: goto -> 178
      //   125: iload_3
      //   126: istore #4
      //   128: invokestatic a : ()I
      //   131: iconst_2
      //   132: if_icmpne -> 178
      //   135: aload_0
      //   136: invokestatic c : ()Ljava/lang/String;
      //   139: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)I
      //   142: iconst_m1
      //   143: if_icmpne -> 175
      //   146: invokestatic c : ()Ljava/lang/String;
      //   149: astore_1
      //   150: invokestatic b : ()I
      //   153: istore #4
      //   155: aload_0
      //   156: iconst_1
      //   157: anewarray java/lang/String
      //   160: dup
      //   161: iconst_0
      //   162: aload_1
      //   163: aastore
      //   164: iload #4
      //   166: invokestatic a : (Landroid/app/Activity;[Ljava/lang/String;I)V
      //   169: iload_3
      //   170: istore #4
      //   172: goto -> 178
      //   175: iconst_1
      //   176: istore #4
      //   178: iload #4
      //   180: ifeq -> 192
      //   183: iconst_1
      //   184: invokestatic a : (Z)Z
      //   187: pop
      //   188: aload_0
      //   189: invokevirtual finish : ()V
      //   192: return
    }
    
    protected void onDestroy() {
      super.onDestroy();
      a = null;
      synchronized (Permissions.d()) {
        Permissions.d().notify();
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_1} */
    }
    
    public void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint) {
      super.onRequestPermissionsResult(param1Int, param1ArrayOfString, param1ArrayOfint);
      if (param1Int == 165995653 && param1ArrayOfint.length > 0 && param1ArrayOfint[0] == 0)
        Permissions.a(true); 
      finish();
    }
    
    protected void onResume() {
      super.onResume();
    }
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/Permissions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */