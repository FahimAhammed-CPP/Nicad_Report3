package com.irifix;

import android.annotation.SuppressLint;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;

public class g {
  public static String a() {
    String str3;
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1)) {
      str3 = a(str2);
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(a(str1));
      stringBuilder.append(" ");
      stringBuilder.append(str2);
      str3 = stringBuilder.toString();
    } 
    return str3;
  }
  
  @SuppressLint({"HardwareIds"})
  public static String a(Context paramContext) {
    return Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
  }
  
  private static String a(String paramString) {
    if (paramString == null || paramString.length() == 0)
      return ""; 
    char c = paramString.charAt(0);
    if (Character.isUpperCase(c))
      return paramString; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Character.toUpperCase(c));
    stringBuilder.append(paramString.substring(1));
    return stringBuilder.toString();
  }
  
  public static boolean a(Context paramContext, String paramString) {
    boolean bool2;
    boolean bool1 = false;
    try {
      bool2 = Settings.Secure.getInt(paramContext.getContentResolver(), "accessibility_enabled");
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      bool2 = false;
    } 
    boolean bool3 = bool1;
    if (bool2 == true) {
      String str = Settings.Secure.getString(paramContext.getContentResolver(), "enabled_accessibility_services");
      bool3 = bool1;
      if (str != null) {
        TextUtils.SimpleStringSplitter simpleStringSplitter = new TextUtils.SimpleStringSplitter(':');
        simpleStringSplitter.setString(str);
        while (true) {
          bool3 = bool1;
          if (simpleStringSplitter.hasNext()) {
            ComponentName componentName = ComponentName.unflattenFromString(simpleStringSplitter.next());
            if (componentName != null && componentName.getPackageName().equals(paramString)) {
              bool3 = true;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
    } 
    return bool3;
  }
  
  public static String b() {
    return Build.VERSION.RELEASE;
  }
  
  public static boolean b(Context paramContext) {
    return ((PowerManager)paramContext.getSystemService("power")).isInteractive();
  }
  
  public static boolean b(Context paramContext, String paramString) {
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      packageManager.getPackageInfo(paramString, 128);
      return true;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      return false;
    } 
  }
  
  public static int c() {
    return 6;
  }
  
  public static boolean c(Context paramContext) {
    boolean bool;
    KeyguardManager keyguardManager = (KeyguardManager)paramContext.getSystemService("keyguard");
    if (b(paramContext) && !keyguardManager.isKeyguardLocked()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static long d() {
    return SystemClock.elapsedRealtime();
  }
  
  public static void d(Context paramContext) {
    Intent intent = new Intent("android.intent.action.MAIN", null);
    intent.addCategory("android.intent.category.HOME");
    intent.addFlags(268435456);
    paramContext.startActivity(intent);
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */