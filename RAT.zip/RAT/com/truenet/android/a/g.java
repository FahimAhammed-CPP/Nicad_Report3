package com.truenet.android.a;

import a.a.b.b.h;
import a.a.b.b.i;
import a.a.b.b.m;
import android.content.Context;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class g {
  public static final boolean a(@NotNull URL paramURL, @NotNull String paramString, @Nullable Context paramContext) {
    Throwable throwable;
    URLConnection uRLConnection;
    h.b(paramURL, "$receiver");
    h.b(paramString, "data");
    HttpURLConnection httpURLConnection = (HttpURLConnection)null;
    BufferedOutputStream bufferedOutputStream = (BufferedOutputStream)null;
    try {
    
    } catch (Throwable throwable1) {
    
    } finally {
      uRLConnection = httpURLConnection;
      if (throwable != null)
        try {
          throwable.close();
        } catch (Throwable throwable1) {
          Log.e(paramURL.getClass().getCanonicalName(), "stream closed with error!", throwable1);
        }  
      if (uRLConnection != null)
        uRLConnection.disconnect(); 
    } 
    if (throwable != null)
      try {
        throwable.close();
      } catch (Throwable throwable1) {
        Log.e(paramURL.getClass().getCanonicalName(), "stream closed with error!", throwable1);
      }  
    if (uRLConnection != null)
      uRLConnection.disconnect(); 
    return false;
  }
  
  @Nullable
  public static final String b(@NotNull URL paramURL, @NotNull String paramString, @Nullable Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: ldc '$receiver'
    //   3: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: ldc 'data'
    //   9: invokestatic b : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aconst_null
    //   13: checkcast java/net/HttpURLConnection
    //   16: astore_3
    //   17: aconst_null
    //   18: checkcast java/io/BufferedOutputStream
    //   21: astore #4
    //   23: aconst_null
    //   24: checkcast java/io/BufferedInputStream
    //   27: astore #5
    //   29: aload_0
    //   30: invokevirtual openConnection : ()Ljava/net/URLConnection;
    //   33: astore #6
    //   35: aload #6
    //   37: ifnull -> 381
    //   40: aload #6
    //   42: checkcast java/net/HttpURLConnection
    //   45: astore #6
    //   47: aload #6
    //   49: ldc 'Cache-Control'
    //   51: ldc 'no-cache'
    //   53: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   56: aload_2
    //   57: ifnull -> 74
    //   60: aload #6
    //   62: ldc 'User-Agent'
    //   64: getstatic com/truenet/android/a/i.a : Lcom/truenet/android/a/i$a;
    //   67: aload_2
    //   68: invokevirtual a : (Landroid/content/Context;)Ljava/lang/String;
    //   71: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   74: aload #6
    //   76: ldc 'POST'
    //   78: invokevirtual setRequestMethod : (Ljava/lang/String;)V
    //   81: aload #6
    //   83: iconst_1
    //   84: invokevirtual setDoOutput : (Z)V
    //   87: aload #6
    //   89: iconst_1
    //   90: invokevirtual setDoInput : (Z)V
    //   93: aload_1
    //   94: getstatic a/a/e/a.a : Ljava/nio/charset/Charset;
    //   97: invokevirtual getBytes : (Ljava/nio/charset/Charset;)[B
    //   100: astore_2
    //   101: aload_2
    //   102: ldc '(this as java.lang.String).getBytes(charset)'
    //   104: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   107: aload #6
    //   109: aload_2
    //   110: arraylength
    //   111: invokevirtual setFixedLengthStreamingMode : (I)V
    //   114: aload #6
    //   116: ldc 'Content-Type'
    //   118: ldc 'application/json'
    //   120: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   123: aload #6
    //   125: ldc 50000
    //   127: invokevirtual setConnectTimeout : (I)V
    //   130: new java/io/BufferedOutputStream
    //   133: astore_1
    //   134: aload_1
    //   135: aload #6
    //   137: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   140: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   143: aload_1
    //   144: aload_2
    //   145: invokevirtual write : ([B)V
    //   148: aload_1
    //   149: invokevirtual flush : ()V
    //   152: aload #6
    //   154: invokevirtual getResponseCode : ()I
    //   157: sipush #200
    //   160: if_icmpne -> 308
    //   163: new java/lang/StringBuilder
    //   166: astore #4
    //   168: aload #4
    //   170: invokespecial <init> : ()V
    //   173: new java/io/BufferedInputStream
    //   176: astore_2
    //   177: aload_2
    //   178: aload #6
    //   180: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   183: invokespecial <init> : (Ljava/io/InputStream;)V
    //   186: new java/io/BufferedReader
    //   189: astore #5
    //   191: new java/io/InputStreamReader
    //   194: astore_3
    //   195: aload_3
    //   196: aload_2
    //   197: checkcast java/io/InputStream
    //   200: invokespecial <init> : (Ljava/io/InputStream;)V
    //   203: aload #5
    //   205: aload_3
    //   206: checkcast java/io/Reader
    //   209: invokespecial <init> : (Ljava/io/Reader;)V
    //   212: new a/a/b/b/m$a
    //   215: astore #7
    //   217: aload #7
    //   219: invokespecial <init> : ()V
    //   222: aload #7
    //   224: aconst_null
    //   225: checkcast java/lang/String
    //   228: putfield element : Ljava/lang/Object;
    //   231: new com/truenet/android/a/g$a
    //   234: astore_3
    //   235: aload_3
    //   236: aload #7
    //   238: aload #5
    //   240: invokespecial <init> : (La/a/b/b/m$a;Ljava/io/BufferedReader;)V
    //   243: aload_3
    //   244: checkcast a/a/b/a/a
    //   247: invokeinterface a : ()Ljava/lang/Object;
    //   252: ifnull -> 272
    //   255: aload #4
    //   257: aload #7
    //   259: getfield element : Ljava/lang/Object;
    //   262: checkcast java/lang/String
    //   265: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: pop
    //   269: goto -> 231
    //   272: aload #4
    //   274: invokevirtual toString : ()Ljava/lang/String;
    //   277: astore #4
    //   279: aload_2
    //   280: astore #5
    //   282: aload #4
    //   284: astore_2
    //   285: goto -> 310
    //   288: astore #5
    //   290: aload_2
    //   291: astore_3
    //   292: aload_1
    //   293: astore_2
    //   294: aload #5
    //   296: astore_1
    //   297: goto -> 403
    //   300: astore #5
    //   302: aload_2
    //   303: astore #5
    //   305: goto -> 462
    //   308: aconst_null
    //   309: astore_2
    //   310: aload_1
    //   311: invokevirtual close : ()V
    //   314: aload #5
    //   316: ifnull -> 342
    //   319: aload #5
    //   321: invokevirtual close : ()V
    //   324: goto -> 342
    //   327: astore_1
    //   328: aload_0
    //   329: invokevirtual getClass : ()Ljava/lang/Class;
    //   332: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   335: ldc 'stream closed with error!'
    //   337: aload_1
    //   338: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   341: pop
    //   342: aload #6
    //   344: ifnull -> 352
    //   347: aload #6
    //   349: invokevirtual disconnect : ()V
    //   352: aload_2
    //   353: areturn
    //   354: astore #4
    //   356: aload_1
    //   357: astore_2
    //   358: aload #5
    //   360: astore_3
    //   361: aload #4
    //   363: astore_1
    //   364: goto -> 403
    //   367: astore_2
    //   368: goto -> 462
    //   371: astore_1
    //   372: aload #4
    //   374: astore_2
    //   375: aload #5
    //   377: astore_3
    //   378: goto -> 403
    //   381: new a/a/h
    //   384: astore_1
    //   385: aload_1
    //   386: ldc 'null cannot be cast to non-null type java.net.HttpURLConnection'
    //   388: invokespecial <init> : (Ljava/lang/String;)V
    //   391: aload_1
    //   392: athrow
    //   393: astore_1
    //   394: aload_3
    //   395: astore #6
    //   397: aload #5
    //   399: astore_3
    //   400: aload #4
    //   402: astore_2
    //   403: aload_2
    //   404: ifnull -> 418
    //   407: aload_2
    //   408: invokevirtual close : ()V
    //   411: goto -> 418
    //   414: astore_2
    //   415: goto -> 429
    //   418: aload_3
    //   419: ifnull -> 443
    //   422: aload_3
    //   423: invokevirtual close : ()V
    //   426: goto -> 443
    //   429: aload_0
    //   430: invokevirtual getClass : ()Ljava/lang/Class;
    //   433: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   436: ldc 'stream closed with error!'
    //   438: aload_2
    //   439: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   442: pop
    //   443: aload #6
    //   445: ifnull -> 453
    //   448: aload #6
    //   450: invokevirtual disconnect : ()V
    //   453: aload_1
    //   454: athrow
    //   455: astore_1
    //   456: aload_3
    //   457: astore #6
    //   459: aload #4
    //   461: astore_1
    //   462: aload_1
    //   463: ifnull -> 477
    //   466: aload_1
    //   467: invokevirtual close : ()V
    //   470: goto -> 477
    //   473: astore_1
    //   474: goto -> 490
    //   477: aload #5
    //   479: ifnull -> 504
    //   482: aload #5
    //   484: invokevirtual close : ()V
    //   487: goto -> 504
    //   490: aload_0
    //   491: invokevirtual getClass : ()Ljava/lang/Class;
    //   494: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   497: ldc 'stream closed with error!'
    //   499: aload_1
    //   500: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   503: pop
    //   504: aload #6
    //   506: ifnull -> 514
    //   509: aload #6
    //   511: invokevirtual disconnect : ()V
    //   514: aconst_null
    //   515: areturn
    //   516: astore_1
    //   517: aload #4
    //   519: astore_1
    //   520: goto -> 462
    // Exception table:
    //   from	to	target	type
    //   29	35	455	java/lang/Throwable
    //   29	35	393	finally
    //   40	47	455	java/lang/Throwable
    //   40	47	393	finally
    //   47	56	516	java/lang/Throwable
    //   47	56	371	finally
    //   60	74	516	java/lang/Throwable
    //   60	74	371	finally
    //   74	143	516	java/lang/Throwable
    //   74	143	371	finally
    //   143	186	367	java/lang/Throwable
    //   143	186	354	finally
    //   186	231	300	java/lang/Throwable
    //   186	231	288	finally
    //   231	269	300	java/lang/Throwable
    //   231	269	288	finally
    //   272	279	300	java/lang/Throwable
    //   272	279	288	finally
    //   310	314	327	java/lang/Throwable
    //   319	324	327	java/lang/Throwable
    //   381	393	455	java/lang/Throwable
    //   381	393	393	finally
    //   407	411	414	java/lang/Throwable
    //   422	426	414	java/lang/Throwable
    //   466	470	473	java/lang/Throwable
    //   482	487	473	java/lang/Throwable
  }
  
  static final class a extends i implements a.a.b.a.a<String> {
    a(m.a param1a, BufferedReader param1BufferedReader) {
      super(0);
    }
    
    @Nullable
    public final String b() {
      this.$line.element = this.$reader.readLine();
      return (String)this.$line.element;
    }
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */