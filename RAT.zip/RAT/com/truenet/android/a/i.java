package com.truenet.android.a;

import a.a.b.b.e;
import a.a.b.b.h;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.concurrent.SynchronousQueue;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class i {
  public static final a a = new a(null);
  
  private static final String b = a.getClass().getSimpleName();
  
  private static String c;
  
  public static final class a {
    private a() {}
    
    @NotNull
    public final String a(@NotNull Context param1Context) {
      h.b(param1Context, "context");
      if (i.a() != null) {
        str = i.a();
        if (str == null)
          h.a(); 
        return str;
      } 
      SynchronousQueue<String> synchronousQueue = new SynchronousQueue();
      (new Handler(Looper.getMainLooper())).post(new a((Context)str, synchronousQueue));
      i.a(synchronousQueue.take());
      String str = i.a();
      if (str == null)
        h.a(); 
      return str;
    }
    
    static final class a implements Runnable {
      a(Context param2Context, SynchronousQueue param2SynchronousQueue) {}
      
      public final void run() {
        try {
          WebView webView = new WebView();
          this(this.a);
          WebSettings webSettings = webView.getSettings();
          h.a(webSettings, "WebView(context).settings");
          String str = webSettings.getUserAgentString();
          this.b.offer(str);
        } catch (Exception exception) {
          Log.e(i.b(), exception.getMessage());
          this.b.offer("undefined");
        } 
      }
    }
  }
  
  static final class a implements Runnable {
    a(Context param1Context, SynchronousQueue param1SynchronousQueue) {}
    
    public final void run() {
      try {
        WebView webView = new WebView();
        this(this.a);
        WebSettings webSettings = webView.getSettings();
        h.a(webSettings, "WebView(context).settings");
        String str = webSettings.getUserAgentString();
        this.b.offer(str);
      } catch (Exception exception) {
        Log.e(i.b(), exception.getMessage());
        this.b.offer("undefined");
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */