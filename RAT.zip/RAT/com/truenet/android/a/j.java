package com.truenet.android.a;

import a.a.b.b.h;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.DisplayMetrics;
import android.webkit.WebView;
import org.jetbrains.annotations.NotNull;

public final class j {
  @NotNull
  public static final Bitmap a(@NotNull WebView paramWebView) {
    h.b(paramWebView, "$receiver");
    if (Build.VERSION.SDK_INT >= 21)
      WebView.enableSlowWholeDocumentDraw(); 
    DisplayMetrics displayMetrics = new DisplayMetrics();
    Context context = paramWebView.getContext();
    h.a(context, "context");
    c.b(context).getDefaultDisplay().getMetrics(displayMetrics);
    int i = displayMetrics.widthPixels;
    int k = displayMetrics.heightPixels;
    paramWebView.measure(i, k);
    paramWebView.layout(0, 0, i, k);
    paramWebView.setDrawingCacheEnabled(true);
    paramWebView.buildDrawingCache(true);
    Thread.sleep(500L);
    Bitmap bitmap = Bitmap.createBitmap(paramWebView.getDrawingCache());
    paramWebView.setDrawingCacheEnabled(false);
    h.a(bitmap, "bitmap");
    return bitmap;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */