package com.truenet.android.a;

import a.a.b.b.h;
import a.a.h;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.view.WindowManager;
import org.jetbrains.annotations.NotNull;

public final class c {
  @NotNull
  public static final TelephonyManager a(@NotNull Context paramContext) {
    h.b(paramContext, "$receiver");
    Object object = paramContext.getSystemService("phone");
    if (object != null)
      return (TelephonyManager)object; 
    throw new h("null cannot be cast to non-null type android.telephony.TelephonyManager");
  }
  
  @NotNull
  public static final WindowManager b(@NotNull Context paramContext) {
    h.b(paramContext, "$receiver");
    Object object = paramContext.getSystemService("window");
    if (object != null)
      return (WindowManager)object; 
    throw new h("null cannot be cast to non-null type android.view.WindowManager");
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */