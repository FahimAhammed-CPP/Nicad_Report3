package com.truenet.android.a;

import android.content.Context;
import com.startapp.common.a.c;
import org.jetbrains.annotations.NotNull;

public final class h {
  public static final boolean a(@NotNull Context paramContext, @NotNull String paramString) {
    a.a.b.b.h.b(paramContext, "$receiver");
    a.a.b.b.h.b(paramString, "permission");
    return c.a(paramContext, paramString);
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */