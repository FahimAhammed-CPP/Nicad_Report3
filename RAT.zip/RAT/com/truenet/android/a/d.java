package com.truenet.android.a;

import a.a.b.b.h;
import a.a.h;
import android.content.Context;
import android.net.ConnectivityManager;
import org.jetbrains.annotations.NotNull;

public final class d {
  @NotNull
  public static final ConnectivityManager a(@NotNull Context paramContext) {
    h.b(paramContext, "$receiver");
    Object object = paramContext.getSystemService("connectivity");
    if (object != null)
      return (ConnectivityManager)object; 
    throw new h("null cannot be cast to non-null type android.net.ConnectivityManager");
  }
  
  @NotNull
  public static final e b(@NotNull Context paramContext) {
    h.b(paramContext, "$receiver");
    return new e(paramContext);
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */