package com.truenet.android.a;

import android.content.Context;
import android.net.NetworkInfo;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class e {
  @Nullable
  private final NetworkInfo a;
  
  private final boolean b;
  
  private final boolean c;
  
  private final boolean d;
  
  @NotNull
  private final String e;
  
  @NotNull
  private final Context f;
  
  public e(@NotNull Context paramContext) {
    String str;
    this.f = paramContext;
    if (h.a(this.f, "android.permission.ACCESS_NETWORK_STATE")) {
      NetworkInfo networkInfo1 = d.a(this.f).getActiveNetworkInfo();
    } else {
      paramContext = null;
    } 
    this.a = (NetworkInfo)paramContext;
    NetworkInfo networkInfo = this.a;
    boolean bool1 = false;
    if (networkInfo != null) {
      bool2 = networkInfo.isConnected();
    } else {
      bool2 = false;
    } 
    this.b = bool2;
    networkInfo = this.a;
    if (networkInfo != null && this.b && networkInfo.getType() == 1) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.c = bool2;
    networkInfo = this.a;
    boolean bool2 = bool1;
    if (networkInfo != null) {
      bool2 = bool1;
      if (this.b) {
        bool2 = bool1;
        if (networkInfo.getType() == 0)
          bool2 = true; 
      } 
    } 
    this.d = bool2;
    if (this.d) {
      networkInfo = this.a;
      if (networkInfo != null) {
        String str1 = networkInfo.getSubtypeName();
        if (str1 != null) {
          this.e = str1;
          return;
        } 
      } 
      str = "";
    } else if (this.c) {
      networkInfo = this.a;
      if (networkInfo != null) {
        String str1 = networkInfo.getTypeName();
        if (str1 != null) {
          this.e = str1;
          return;
        } 
      } 
      str = "";
    } else {
      str = "";
    } 
    this.e = str;
  }
  
  @NotNull
  public final String a() {
    return this.e;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */