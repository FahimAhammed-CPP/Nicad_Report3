package com.truenet.android.a;

import a.a.a.g;
import a.a.b.b.h;
import android.os.Build;
import android.telephony.CellIdentityCdma;
import android.telephony.CellIdentityGsm;
import android.telephony.CellInfo;
import android.telephony.CellInfoCdma;
import android.telephony.CellInfoGsm;
import android.telephony.CellLocation;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class f {
  public static final int a(@NotNull TelephonyManager paramTelephonyManager) {
    CellIdentityCdma cellIdentityCdma;
    int i;
    h.b(paramTelephonyManager, "$receiver");
    if (Build.VERSION.SDK_INT >= 26) {
      List list = paramTelephonyManager.getAllCellInfo();
      if (list != null) {
        CellInfo cellInfo = (CellInfo)g.d(list);
      } else {
        list = null;
      } 
      if (list instanceof CellInfoGsm) {
        CellIdentityGsm cellIdentityGsm = ((CellInfoGsm)list).getCellIdentity();
        h.a(cellIdentityGsm, "info.cellIdentity");
        i = cellIdentityGsm.getCid();
      } else if (list instanceof CellInfoCdma) {
        cellIdentityCdma = ((CellInfoCdma)list).getCellIdentity();
        h.a(cellIdentityCdma, "info.cellIdentity");
        i = cellIdentityCdma.getBasestationId();
      } else {
        i = c((TelephonyManager)cellIdentityCdma);
      } 
    } else {
      i = c((TelephonyManager)cellIdentityCdma);
    } 
    return i;
  }
  
  public static final int b(@NotNull TelephonyManager paramTelephonyManager) {
    CellIdentityGsm cellIdentityGsm;
    int i;
    h.b(paramTelephonyManager, "$receiver");
    if (Build.VERSION.SDK_INT >= 26) {
      List list = paramTelephonyManager.getAllCellInfo();
      if (list != null) {
        CellInfo cellInfo = (CellInfo)g.d(list);
      } else {
        list = null;
      } 
      if (list instanceof CellInfoGsm) {
        cellIdentityGsm = ((CellInfoGsm)list).getCellIdentity();
        h.a(cellIdentityGsm, "info.cellIdentity");
        i = cellIdentityGsm.getLac();
      } else {
        i = d((TelephonyManager)cellIdentityGsm);
      } 
    } else {
      i = d((TelephonyManager)cellIdentityGsm);
    } 
    return i;
  }
  
  private static final int c(@NotNull TelephonyManager paramTelephonyManager) {
    byte b;
    CellLocation cellLocation = paramTelephonyManager.getCellLocation();
    if (cellLocation instanceof GsmCellLocation) {
      b = ((GsmCellLocation)cellLocation).getCid();
    } else if (cellLocation instanceof CdmaCellLocation) {
      b = ((CdmaCellLocation)cellLocation).getBaseStationId();
    } else {
      b = -1;
    } 
    return b;
  }
  
  private static final int d(@NotNull TelephonyManager paramTelephonyManager) {
    byte b;
    CellLocation cellLocation = paramTelephonyManager.getCellLocation();
    if (cellLocation instanceof GsmCellLocation) {
      b = ((GsmCellLocation)cellLocation).getLac();
    } else {
      b = -1;
    } 
    return b;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */