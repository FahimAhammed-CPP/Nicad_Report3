package com.truenet.android.a;

import a.a.b.b.h;
import android.graphics.Bitmap;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import org.jetbrains.annotations.NotNull;

public final class a {
  public static final boolean a(@NotNull Bitmap paramBitmap, @NotNull String paramString) {
    ByteArrayOutputStream byteArrayOutputStream1;
    ByteArrayOutputStream byteArrayOutputStream3;
    h.b(paramBitmap, "$receiver");
    h.b(paramString, "url");
    HttpURLConnection httpURLConnection = (HttpURLConnection)null;
    ByteArrayOutputStream byteArrayOutputStream2 = (ByteArrayOutputStream)null;
    try {
      URLConnection uRLConnection;
      URL uRL = new URL();
    } catch (Throwable throwable1) {
    
    } finally {
      byteArrayOutputStream3 = byteArrayOutputStream1;
      if (throwable != null)
        try {
          throwable.close();
        } catch (Throwable throwable) {
          Log.e(paramBitmap.getClass().getCanonicalName(), "stream closed with error!", throwable);
        }  
      if (byteArrayOutputStream3 != null)
        byteArrayOutputStream3.disconnect(); 
    } 
    if (throwable != null)
      try {
        throwable.close();
      } catch (Throwable throwable1) {
        Log.e(paramBitmap.getClass().getCanonicalName(), "stream closed with error!", throwable1);
      }  
    if (byteArrayOutputStream3 != null)
      byteArrayOutputStream3.disconnect(); 
    return false;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */