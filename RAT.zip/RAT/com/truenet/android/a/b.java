package com.truenet.android.a;

import a.a.b.b.h;
import android.content.res.Configuration;
import android.os.Build;
import java.util.Locale;
import org.jetbrains.annotations.NotNull;

public final class b {
  public static final Locale a(@NotNull Configuration paramConfiguration) {
    Locale locale;
    h.b(paramConfiguration, "$receiver");
    if (Build.VERSION.SDK_INT >= 24) {
      locale = paramConfiguration.getLocales().get(0);
    } else {
      locale = ((Configuration)locale).locale;
    } 
    return locale;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */