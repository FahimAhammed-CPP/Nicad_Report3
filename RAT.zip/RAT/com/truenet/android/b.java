package com.truenet.android;

import a.a.b.b.h;
import a.a.b.b.i;
import a.a.b.b.k;
import a.a.b.b.l;
import a.a.b.b.m;
import a.a.b.b.n;
import a.a.h;
import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.truenet.android.a.i;
import com.truenet.android.a.j;
import java.io.BufferedReader;
import java.io.InputStream;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class b {
  public static final a b = new a(null);
  
  private static final String n = b.getClass().getSimpleName();
  
  private static final a.a.e.b o = new a.a.e.b("^\\w+(://){1}.+$");
  
  @Nullable
  private Bitmap c;
  
  private long d;
  
  @NotNull
  private String e;
  
  @Nullable
  private String f;
  
  private final List<b> g;
  
  private final a.a.c h;
  
  private final a.a.c i;
  
  private final Context j;
  
  private final String k;
  
  private final int l;
  
  private final long m;
  
  public b(@NotNull Context paramContext, @NotNull String paramString, int paramInt, long paramLong) {
    this.j = paramContext;
    this.k = paramString;
    this.l = paramInt;
    this.m = paramLong;
    this.e = this.k;
    this.g = new ArrayList<b>();
    this.h = a.a.d.a(f.a);
    this.i = a.a.d.a(new g());
  }
  
  private final b a(String paramString, List<String> paramList) {
    this.f = (String)null;
    if (a.a(b, paramString))
      return new b(paramString, 0L, 200, null, null); 
    HttpURLConnection httpURLConnection = (HttpURLConnection)null;
    try {
      URL uRL = new URL();
      this(paramString);
      URLConnection uRLConnection = uRL.openConnection();
      if (uRLConnection != null) {
        HttpURLConnection httpURLConnection1 = (HttpURLConnection)uRLConnection;
        httpURLConnection1.setInstanceFollowRedirects(false);
        httpURLConnection1.setConnectTimeout((int)this.m * 1000);
        httpURLConnection1.setReadTimeout((int)this.m * 1000);
        httpURLConnection1.addRequestProperty("User-Agent", i.a.a(this.j));
        if (paramList != null) {
          CharSequence charSequence = ";";
          List<String> list1 = paramList;
          ArrayList<HttpCookie> arrayList = new ArrayList();
          this(a.a.a.g.a(list1, 10));
          arrayList = arrayList;
          Iterator<String> iterator = list1.iterator();
          while (iterator.hasNext()) {
            List<HttpCookie> list2 = HttpCookie.parse(iterator.next());
            h.a(list2, "HttpCookie.parse(it)");
            arrayList.add((HttpCookie)a.a.a.g.c(list2));
          } 
          httpURLConnection1.setRequestProperty("Cookie", TextUtils.join(charSequence, arrayList));
        } 
        long l1 = System.currentTimeMillis();
        httpURLConnection1.connect();
        long l2 = System.currentTimeMillis();
        String str = httpURLConnection1.getHeaderField("Location");
        if (str != null) {
          a.a.e.b b2 = o;
          h.a(str, "nextUrl");
          if (!b2.a(str)) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            stringBuilder.append(uRL.getProtocol());
            stringBuilder.append("://");
            stringBuilder.append(uRL.getHost());
            h.a(str, "nextUrl");
            if (!a.a.e.c.a(str, "/", false, 2, null)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              this();
              stringBuilder1.append('/');
              stringBuilder1.append(str);
              str = stringBuilder1.toString();
            } 
            stringBuilder.append(str);
            str = stringBuilder.toString();
          } 
        } else {
          str = null;
        } 
        List<String> list = httpURLConnection1.getHeaderFields().get("Set-Cookie");
        b b1 = new b();
        this(paramString, l2 - l1, httpURLConnection1.getResponseCode(), list, str);
        int i = httpURLConnection1.getResponseCode();
        if (200 <= i && 299 >= i) {
          InputStream inputStream = httpURLConnection1.getInputStream();
          h.a(inputStream, "inputStream");
          this.f = a(inputStream);
          l2 = System.currentTimeMillis() - l1;
          Handler handler = new Handler();
          this(Looper.getMainLooper());
          e e1 = new e();
          this(httpURLConnection1, this, paramList, uRL, paramString);
          handler.post(e1);
          paramString = j().take();
          h.a(paramString, "jsRedirectUrl");
          if (((CharSequence)paramString).length() == 0) {
            i = 1;
          } else {
            i = 0;
          } 
          return (i != 0) ? b.a(b1, null, l2, 0, null, null, 29, null) : b.a(b1, null, l2, 0, null, paramString, 13, null);
        } 
        return (300 <= i && 399 >= i) ? b1 : b.a(b1, null, 0L, 0, null, null, 15, null);
      } 
      h h = new h();
      this("null cannot be cast to non-null type java.net.HttpURLConnection");
      throw h;
    } catch (Throwable throwable) {
      return null;
    } finally {}
  }
  
  private final String a(InputStream paramInputStream) {
    // Byte code:
    //   0: aconst_null
    //   1: checkcast java/io/BufferedInputStream
    //   4: astore_2
    //   5: new a/a/b/b/m$a
    //   8: dup
    //   9: invokespecial <init> : ()V
    //   12: astore_3
    //   13: aload_3
    //   14: aconst_null
    //   15: checkcast java/io/BufferedReader
    //   18: putfield element : Ljava/lang/Object;
    //   21: new java/lang/StringBuilder
    //   24: astore #4
    //   26: aload #4
    //   28: invokespecial <init> : ()V
    //   31: new java/io/BufferedInputStream
    //   34: astore #5
    //   36: aload #5
    //   38: aload_1
    //   39: invokespecial <init> : (Ljava/io/InputStream;)V
    //   42: new java/io/BufferedReader
    //   45: astore_2
    //   46: new java/io/InputStreamReader
    //   49: astore_1
    //   50: aload_1
    //   51: aload #5
    //   53: checkcast java/io/InputStream
    //   56: invokespecial <init> : (Ljava/io/InputStream;)V
    //   59: aload_2
    //   60: aload_1
    //   61: checkcast java/io/Reader
    //   64: invokespecial <init> : (Ljava/io/Reader;)V
    //   67: aload_3
    //   68: aload_2
    //   69: putfield element : Ljava/lang/Object;
    //   72: new a/a/b/b/m$a
    //   75: astore_1
    //   76: aload_1
    //   77: invokespecial <init> : ()V
    //   80: aload_1
    //   81: aconst_null
    //   82: checkcast java/lang/String
    //   85: putfield element : Ljava/lang/Object;
    //   88: new com/truenet/android/b$d
    //   91: astore_2
    //   92: aload_2
    //   93: aload_1
    //   94: aload_3
    //   95: invokespecial <init> : (La/a/b/b/m$a;La/a/b/b/m$a;)V
    //   98: aload_2
    //   99: checkcast a/a/b/a/a
    //   102: invokeinterface a : ()Ljava/lang/Object;
    //   107: ifnull -> 126
    //   110: aload #4
    //   112: aload_1
    //   113: getfield element : Ljava/lang/Object;
    //   116: checkcast java/lang/String
    //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: goto -> 88
    //   126: aload #4
    //   128: invokevirtual toString : ()Ljava/lang/String;
    //   131: astore_1
    //   132: aload_1
    //   133: ldc_w 'result.toString()'
    //   136: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)V
    //   139: aload_3
    //   140: getfield element : Ljava/lang/Object;
    //   143: checkcast java/io/BufferedReader
    //   146: astore_2
    //   147: aload_2
    //   148: ifnull -> 155
    //   151: aload_2
    //   152: invokevirtual close : ()V
    //   155: aload #5
    //   157: invokevirtual close : ()V
    //   160: goto -> 181
    //   163: astore #5
    //   165: aload_0
    //   166: invokevirtual getClass : ()Ljava/lang/Class;
    //   169: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   172: ldc_w 'stream closed with error!'
    //   175: aload #5
    //   177: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   180: pop
    //   181: aload_1
    //   182: areturn
    //   183: astore_1
    //   184: goto -> 191
    //   187: astore_1
    //   188: aload_2
    //   189: astore #5
    //   191: aload_3
    //   192: getfield element : Ljava/lang/Object;
    //   195: checkcast java/io/BufferedReader
    //   198: astore_2
    //   199: aload_2
    //   200: ifnull -> 207
    //   203: aload_2
    //   204: invokevirtual close : ()V
    //   207: aload #5
    //   209: ifnull -> 238
    //   212: aload #5
    //   214: invokevirtual close : ()V
    //   217: goto -> 238
    //   220: astore #5
    //   222: aload_0
    //   223: invokevirtual getClass : ()Ljava/lang/Class;
    //   226: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   229: ldc_w 'stream closed with error!'
    //   232: aload #5
    //   234: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   237: pop
    //   238: aload_1
    //   239: athrow
    // Exception table:
    //   from	to	target	type
    //   21	42	187	finally
    //   42	88	183	finally
    //   88	123	183	finally
    //   126	139	183	finally
    //   139	147	163	java/lang/Throwable
    //   151	155	163	java/lang/Throwable
    //   155	160	163	java/lang/Throwable
    //   191	199	220	java/lang/Throwable
    //   203	207	220	java/lang/Throwable
    //   212	217	220	java/lang/Throwable
  }
  
  private final boolean a(long paramLong) {
    boolean bool;
    if ((this.g.size() < this.l || this.l == -1) && System.currentTimeMillis() - paramLong < this.m * 1000L) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private final SynchronousQueue<String> j() {
    a.a.c c1 = this.h;
    a.a.d.e e1 = a[0];
    return (SynchronousQueue<String>)c1.a();
  }
  
  private final WebView k() {
    a.a.c c1 = this.i;
    a.a.d.e e1 = a[1];
    return (WebView)c1.a();
  }
  
  @Nullable
  public final Bitmap a() {
    return this.c;
  }
  
  public final int b() {
    return this.g.size();
  }
  
  public final long c() {
    return this.d;
  }
  
  @NotNull
  public final List<b> d() {
    return a.a.a.g.a(this.g);
  }
  
  @NotNull
  public final String e() {
    return this.e;
  }
  
  @Nullable
  public final String f() {
    return this.f;
  }
  
  public final void g() {
    long l = System.currentTimeMillis();
    String str = this.k;
    b b2 = null;
    b b1 = a(this, str, null, 2, null);
    if (b1 != null) {
      this.g.add(b1);
      while (true) {
        String str1;
        if (b1 != null) {
          str1 = b1.e();
        } else {
          str1 = null;
        } 
        if (str1 != null && a(l)) {
          str1 = b1.e();
          if (str1 == null)
            h.a(); 
          b b3 = a(str1, b1.d());
          b1 = b3;
          if (b3 != null) {
            this.g.add(b3);
            b1 = b3;
          } 
          continue;
        } 
        break;
      } 
      if (b1 != null) {
        int i = b1.c();
        if (200 <= i && 299 >= i && this.f != null) {
          Bitmap bitmap;
          WebView webView = k();
          b1 = b2;
          if (webView != null)
            bitmap = j.a(webView); 
          this.c = bitmap;
        } 
      } 
      List<b> list = this.g;
      long l1 = 0L;
      Iterator<b> iterator = list.iterator();
      while (iterator.hasNext())
        l1 += ((b)iterator.next()).b(); 
      this.d = l1;
      this.e = ((b)a.a.a.g.e(this.g)).a();
    } 
    if (this.g.isEmpty())
      this.d = System.currentTimeMillis() - l; 
  }
  
  public static final class a {
    private a() {}
    
    private final boolean a(String param1String) {
      boolean bool = a.a.e.c.a(param1String, "http://play.google.com", false, 2, null);
      boolean bool1 = true;
      if (!bool && !a.a.e.c.a(param1String, "https://play.google.com", false, 2, null) && !a.a.e.c.a(param1String, "http://itunes.apple.com", false, 2, null) && !a.a.e.c.a(param1String, "https://itunes.apple.com", false, 2, null) && (a.a.e.c.a(param1String, "http://", false, 2, null) || a.a.e.c.a(param1String, "https://", false, 2, null) || !b.i().a(param1String)))
        bool1 = false; 
      return bool1;
    }
  }
  
  public static final class b {
    @NotNull
    private final String a;
    
    private final long b;
    
    private final int c;
    
    @Nullable
    private final List<String> d;
    
    @Nullable
    private final String e;
    
    public b(@NotNull String param1String1, long param1Long, int param1Int, @Nullable List<String> param1List, @Nullable String param1String2) {
      this.a = param1String1;
      this.b = param1Long;
      this.c = param1Int;
      this.d = param1List;
      this.e = param1String2;
    }
    
    @NotNull
    public final b a(@NotNull String param1String1, long param1Long, int param1Int, @Nullable List<String> param1List, @Nullable String param1String2) {
      h.b(param1String1, "url");
      return new b(param1String1, param1Long, param1Int, param1List, param1String2);
    }
    
    @NotNull
    public final String a() {
      return this.a;
    }
    
    public final long b() {
      return this.b;
    }
    
    public final int c() {
      return this.c;
    }
    
    @Nullable
    public final List<String> d() {
      return this.d;
    }
    
    @Nullable
    public final String e() {
      return this.e;
    }
    
    public boolean equals(Object param1Object) {
      if (this != param1Object) {
        if (param1Object instanceof b) {
          param1Object = param1Object;
          if (h.a(this.a, ((b)param1Object).a)) {
            boolean bool;
            if (this.b == ((b)param1Object).b) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              if (this.c == ((b)param1Object).c) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool && h.a(this.d, ((b)param1Object).d) && h.a(this.e, ((b)param1Object).e))
                return true; 
            } 
          } 
        } 
        return false;
      } 
      return true;
    }
    
    public int hashCode() {
      byte b1;
      byte b2;
      String str2 = this.a;
      int i = 0;
      if (str2 != null) {
        b1 = str2.hashCode();
      } else {
        b1 = 0;
      } 
      long l = this.b;
      int j = (int)(l ^ l >>> 32L);
      int k = this.c;
      List<String> list = this.d;
      if (list != null) {
        b2 = list.hashCode();
      } else {
        b2 = 0;
      } 
      String str1 = this.e;
      if (str1 != null)
        i = str1.hashCode(); 
      return (((b1 * 31 + j) * 31 + k) * 31 + b2) * 31 + i;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ConnectionInfo(url=");
      stringBuilder.append(this.a);
      stringBuilder.append(", loadTime=");
      stringBuilder.append(this.b);
      stringBuilder.append(", httpCode=");
      stringBuilder.append(this.c);
      stringBuilder.append(", cookie=");
      stringBuilder.append(this.d);
      stringBuilder.append(", redirectUrl=");
      stringBuilder.append(this.e);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  public final class c extends WebViewClient {
    private ScheduledExecutorService b = Executors.newScheduledThreadPool(1);
    
    private ScheduledFuture<?> c;
    
    public c(b this$0) {}
    
    private final void a() {
      ScheduledFuture<?> scheduledFuture = this.c;
      if (scheduledFuture != null)
        scheduledFuture.cancel(false); 
      this.c = (ScheduledFuture)null;
    }
    
    private final void a(WebView param1WebView, String param1String) {
      a();
      if (param1String != null) {
        if (param1WebView != null)
          param1WebView.stopLoading(); 
        b.a(this.a).offer(param1String);
      } 
    }
    
    public void onPageFinished(@Nullable WebView param1WebView, @Nullable String param1String) {
      a();
      this.c = this.b.schedule(new a(this), 1L, TimeUnit.SECONDS);
      super.onPageFinished(param1WebView, param1String);
    }
    
    public void onReceivedError(@Nullable WebView param1WebView, @Nullable WebResourceRequest param1WebResourceRequest, @Nullable WebResourceError param1WebResourceError) {
      a();
      if (param1WebView != null)
        param1WebView.stopLoading(); 
      b.a(this.a).offer("");
      super.onReceivedError(param1WebView, param1WebResourceRequest, param1WebResourceError);
    }
    
    @TargetApi(24)
    public boolean shouldOverrideUrlLoading(@Nullable WebView param1WebView, @Nullable WebResourceRequest param1WebResourceRequest) {
      if (param1WebResourceRequest != null) {
        Uri uri = param1WebResourceRequest.getUrl();
      } else {
        param1WebResourceRequest = null;
      } 
      a(param1WebView, String.valueOf(param1WebResourceRequest));
      return true;
    }
    
    public boolean shouldOverrideUrlLoading(@Nullable WebView param1WebView, @Nullable String param1String) {
      a(param1WebView, param1String);
      return true;
    }
    
    static final class a implements Runnable {
      a(b.c param2c) {}
      
      public final void run() {
        b.a(this.a.a).offer("");
      }
    }
  }
  
  static final class a implements Runnable {
    a(b.c param1c) {}
    
    public final void run() {
      b.a(this.a.a).offer("");
    }
  }
  
  static final class d extends i implements a.a.b.a.a<String> {
    d(m.a param1a1, m.a param1a2) {
      super(0);
    }
    
    @Nullable
    public final String b() {
      this.$line.element = ((BufferedReader)this.$reader.element).readLine();
      return (String)this.$line.element;
    }
  }
  
  static final class e implements Runnable {
    e(HttpURLConnection param1HttpURLConnection, b param1b, List param1List, URL param1URL, String param1String) {}
    
    public final void run() {
      WebView webView = b.b(this.b);
      if (webView != null)
        webView.loadDataWithBaseURL(this.e, this.b.f(), this.a.getContentType(), this.a.getContentEncoding(), null); 
    }
  }
  
  static final class f extends i implements a.a.b.a.a<SynchronousQueue<String>> {
    public static final f a = new f();
    
    f() {
      super(0);
    }
    
    @NotNull
    public final SynchronousQueue<String> b() {
      return new SynchronousQueue<String>();
    }
  }
  
  static final class g extends i implements a.a.b.a.a<WebView> {
    g() {
      super(0);
    }
    
    @Nullable
    public final WebView b() {
      WebView webView = null;
      try {
        WebView webView1 = new WebView();
        this(b.c(b.this));
        if (Build.VERSION.SDK_INT >= 11)
          webView1.setLayerType(1, null); 
        WebSettings webSettings = webView1.getSettings();
        h.a(webSettings, "settings");
        webSettings.setJavaScriptEnabled(true);
        WebChromeClient webChromeClient = new WebChromeClient();
        this();
        webView1.setWebChromeClient(webChromeClient);
        b.c c = new b.c();
        this();
        webView1.setWebViewClient(c);
        webView = webView1;
      } catch (Exception exception) {
        Log.e(b.h(), exception.getMessage());
      } 
      return webView;
    }
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */