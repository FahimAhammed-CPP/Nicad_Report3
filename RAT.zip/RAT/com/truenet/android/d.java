package com.truenet.android;

import a.a.b.a.b;
import a.a.b.b.h;

final class d implements Thread.UncaughtExceptionHandler {
  d(b paramb) {
    this.a = paramb;
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */