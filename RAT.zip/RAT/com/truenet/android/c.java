package com.truenet.android;

import a.a.b.b.e;
import a.a.b.b.h;
import a.a.b.b.i;
import a.a.j;
import android.content.Context;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import org.jetbrains.annotations.NotNull;

public final class c {
  public static final a a = new a(null);
  
  private final ExecutorService b;
  
  @NotNull
  private a.a.b.a.a<j> c;
  
  private int d;
  
  private final Context e;
  
  private final List<String> f;
  
  private final long g;
  
  private final int h;
  
  public c(@NotNull Context paramContext, @NotNull List<String> paramList, @NotNull ThreadFactory paramThreadFactory, long paramLong, int paramInt1, int paramInt2) {
    this.e = paramContext;
    this.f = paramList;
    this.g = paramLong;
    this.h = paramInt1;
    this.b = Executors.newFixedThreadPool(paramInt2, paramThreadFactory);
    this.c = c.a;
  }
  
  private final int a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield d : I
    //   7: iconst_1
    //   8: iadd
    //   9: putfield d : I
    //   12: aload_0
    //   13: getfield d : I
    //   16: istore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: iload_1
    //   20: ireturn
    //   21: astore_2
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_2
    //   25: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	21	finally
  }
  
  private final void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield d : I
    //   7: iconst_1
    //   8: isub
    //   9: putfield d : I
    //   12: aload_0
    //   13: getfield d : I
    //   16: ifgt -> 29
    //   19: aload_0
    //   20: getfield c : La/a/b/a/a;
    //   23: invokeinterface a : ()Ljava/lang/Object;
    //   28: pop
    //   29: getstatic a/a/j.a : La/a/j;
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore_1
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_1
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	29	36	finally
    //   29	33	36	finally
  }
  
  public final void a(@NotNull a.a.b.a.a<j> parama) {
    h.b(parama, "<set-?>");
    this.c = parama;
  }
  
  public final void a(@NotNull a.a.b.a.b<? super b, ? super Integer, j> paramb) {
    h.b(paramb, "block");
    Iterator<String> iterator = this.f.iterator();
    for (byte b1 = 0; iterator.hasNext(); b1++) {
      String str = iterator.next();
      a();
      b b2 = new b(this.e, str, this.h, this.g);
      this.b.execute(new b(b2, b1, this, paramb));
    } 
  }
  
  public static final class a {
    private a() {}
  }
  
  static final class b implements Runnable {
    b(b param1b, int param1Int, c param1c, a.a.b.a.b param1b1) {}
    
    public final void run() {
      this.a.g();
      this.d.a(this.a, Integer.valueOf(this.b));
      c.a(this.c);
    }
  }
  
  static final class c extends i implements a.a.b.a.a<j> {
    public static final c a = new c();
    
    c() {
      super(0);
    }
    
    public final void b() {}
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */