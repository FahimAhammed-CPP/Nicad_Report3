package com.truenet.android;

import a.a.b.b.h;
import com.startapp.common.c.f;
import java.util.ArrayList;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class ValidationResults {
  @f(b = ArrayList.class, c = ValidationResult.class)
  @NotNull
  private final List<ValidationResult> results;
  
  public ValidationResults(@NotNull List<ValidationResult> paramList) {
    this.results = paramList;
  }
  
  @NotNull
  public final List<ValidationResult> component1() {
    return this.results;
  }
  
  @NotNull
  public final ValidationResults copy(@NotNull List<ValidationResult> paramList) {
    h.b(paramList, "results");
    return new ValidationResults(paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof ValidationResults) {
        paramObject = paramObject;
        if (h.a(this.results, ((ValidationResults)paramObject).results))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  @NotNull
  public final List<ValidationResult> getResults() {
    return this.results;
  }
  
  public int hashCode() {
    boolean bool;
    List<ValidationResult> list = this.results;
    if (list != null) {
      bool = list.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValidationResults(results=");
    stringBuilder.append(this.results);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/ValidationResults.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */