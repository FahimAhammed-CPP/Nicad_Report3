package com.truenet.android;

import a.a.b.b.h;
import com.startapp.common.c.f;
import java.util.ArrayList;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class ValidationResult {
  @NotNull
  private final String instanceId;
  
  @NotNull
  private final String lastHtml;
  
  @NotNull
  private final String lastImage;
  
  @NotNull
  private final String lastUrl;
  
  @NotNull
  private final String metaData;
  
  private final int numOfRedirect;
  
  @NotNull
  private final String publisherId;
  
  @f(b = ArrayList.class, c = RedirectsResult.class)
  @NotNull
  private final List<RedirectsResult> redirectUrls;
  
  private final long sessionTime;
  
  public ValidationResult(@NotNull String paramString1, int paramInt, long paramLong, @NotNull List<RedirectsResult> paramList, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5, @NotNull String paramString6) {
    this.instanceId = paramString1;
    this.numOfRedirect = paramInt;
    this.sessionTime = paramLong;
    this.redirectUrls = paramList;
    this.lastUrl = paramString2;
    this.lastHtml = paramString3;
    this.lastImage = paramString4;
    this.publisherId = paramString5;
    this.metaData = paramString6;
  }
  
  @NotNull
  public final String component1() {
    return this.instanceId;
  }
  
  public final int component2() {
    return this.numOfRedirect;
  }
  
  public final long component3() {
    return this.sessionTime;
  }
  
  @NotNull
  public final List<RedirectsResult> component4() {
    return this.redirectUrls;
  }
  
  @NotNull
  public final String component5() {
    return this.lastUrl;
  }
  
  @NotNull
  public final String component6() {
    return this.lastHtml;
  }
  
  @NotNull
  public final String component7() {
    return this.lastImage;
  }
  
  @NotNull
  public final String component8() {
    return this.publisherId;
  }
  
  @NotNull
  public final String component9() {
    return this.metaData;
  }
  
  @NotNull
  public final ValidationResult copy(@NotNull String paramString1, int paramInt, long paramLong, @NotNull List<RedirectsResult> paramList, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5, @NotNull String paramString6) {
    h.b(paramString1, "instanceId");
    h.b(paramList, "redirectUrls");
    h.b(paramString2, "lastUrl");
    h.b(paramString3, "lastHtml");
    h.b(paramString4, "lastImage");
    h.b(paramString5, "publisherId");
    h.b(paramString6, "metaData");
    return new ValidationResult(paramString1, paramInt, paramLong, paramList, paramString2, paramString3, paramString4, paramString5, paramString6);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof ValidationResult) {
        paramObject = paramObject;
        if (h.a(this.instanceId, ((ValidationResult)paramObject).instanceId)) {
          boolean bool;
          if (this.numOfRedirect == ((ValidationResult)paramObject).numOfRedirect) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            if (this.sessionTime == ((ValidationResult)paramObject).sessionTime) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool && h.a(this.redirectUrls, ((ValidationResult)paramObject).redirectUrls) && h.a(this.lastUrl, ((ValidationResult)paramObject).lastUrl) && h.a(this.lastHtml, ((ValidationResult)paramObject).lastHtml) && h.a(this.lastImage, ((ValidationResult)paramObject).lastImage) && h.a(this.publisherId, ((ValidationResult)paramObject).publisherId) && h.a(this.metaData, ((ValidationResult)paramObject).metaData))
              return true; 
          } 
        } 
      } 
      return false;
    } 
    return true;
  }
  
  @NotNull
  public final String getInstanceId() {
    return this.instanceId;
  }
  
  @NotNull
  public final String getLastHtml() {
    return this.lastHtml;
  }
  
  @NotNull
  public final String getLastImage() {
    return this.lastImage;
  }
  
  @NotNull
  public final String getLastUrl() {
    return this.lastUrl;
  }
  
  @NotNull
  public final String getMetaData() {
    return this.metaData;
  }
  
  public final int getNumOfRedirect() {
    return this.numOfRedirect;
  }
  
  @NotNull
  public final String getPublisherId() {
    return this.publisherId;
  }
  
  @NotNull
  public final List<RedirectsResult> getRedirectUrls() {
    return this.redirectUrls;
  }
  
  public final long getSessionTime() {
    return this.sessionTime;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    byte b5;
    byte b6;
    String str2 = this.instanceId;
    int i = 0;
    if (str2 != null) {
      b1 = str2.hashCode();
    } else {
      b1 = 0;
    } 
    int j = this.numOfRedirect;
    long l = this.sessionTime;
    int k = (int)(l ^ l >>> 32L);
    List<RedirectsResult> list = this.redirectUrls;
    if (list != null) {
      b2 = list.hashCode();
    } else {
      b2 = 0;
    } 
    String str1 = this.lastUrl;
    if (str1 != null) {
      b3 = str1.hashCode();
    } else {
      b3 = 0;
    } 
    str1 = this.lastHtml;
    if (str1 != null) {
      b4 = str1.hashCode();
    } else {
      b4 = 0;
    } 
    str1 = this.lastImage;
    if (str1 != null) {
      b5 = str1.hashCode();
    } else {
      b5 = 0;
    } 
    str1 = this.publisherId;
    if (str1 != null) {
      b6 = str1.hashCode();
    } else {
      b6 = 0;
    } 
    str1 = this.metaData;
    if (str1 != null)
      i = str1.hashCode(); 
    return (((((((b1 * 31 + j) * 31 + k) * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ValidationResult(instanceId=");
    stringBuilder.append(this.instanceId);
    stringBuilder.append(", numOfRedirect=");
    stringBuilder.append(this.numOfRedirect);
    stringBuilder.append(", sessionTime=");
    stringBuilder.append(this.sessionTime);
    stringBuilder.append(", redirectUrls=");
    stringBuilder.append(this.redirectUrls);
    stringBuilder.append(", lastUrl=");
    stringBuilder.append(this.lastUrl);
    stringBuilder.append(", lastHtml=");
    stringBuilder.append(this.lastHtml);
    stringBuilder.append(", lastImage=");
    stringBuilder.append(this.lastImage);
    stringBuilder.append(", publisherId=");
    stringBuilder.append(this.publisherId);
    stringBuilder.append(", metaData=");
    stringBuilder.append(this.metaData);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/ValidationResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */