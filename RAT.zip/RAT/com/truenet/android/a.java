package com.truenet.android;

import a.a.a.g;
import a.a.b.b.e;
import a.a.b.b.h;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Location;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import com.startapp.common.a.b;
import com.startapp.common.c;
import com.truenet.android.a.b;
import com.truenet.android.a.d;
import com.truenet.android.a.f;
import com.truenet.android.a.h;
import com.truenet.android.a.i;
import java.util.List;
import java.util.Locale;
import org.jetbrains.annotations.NotNull;

public final class a {
  @NotNull
  private final Context a;
  
  @NotNull
  private final TelephonyManager b;
  
  public a(@NotNull Context paramContext, @NotNull TelephonyManager paramTelephonyManager) {
    this.a = paramContext;
    this.b = paramTelephonyManager;
    c.c(this.a);
  }
  
  private final boolean b() {
    boolean bool;
    Resources resources = Resources.getSystem();
    h.a(resources, "Resources.getSystem()");
    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
    double d1 = (displayMetrics.widthPixels / displayMetrics.xdpi);
    double d2 = (displayMetrics.heightPixels / displayMetrics.ydpi);
    Double.isNaN(d1);
    Double.isNaN(d1);
    Double.isNaN(d2);
    Double.isNaN(d2);
    if (Math.sqrt(d1 * d1 + d2 * d2) > 6.5D) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  @NotNull
  public final DeviceInfo a() {
    String str1;
    String str6;
    String str7;
    String str8;
    String str9;
    String str10;
    List list = g.a();
    String str2 = "";
    String str3 = "";
    boolean bool = list.isEmpty();
    boolean bool1 = true;
    if ((bool ^ true) != 0) {
      str2 = String.valueOf(((Location)g.c(list)).getLatitude());
      str3 = String.valueOf(((Location)g.c(list)).getLongitude());
    } 
    Resources resources = this.a.getResources();
    h.a(resources, "context.resources");
    Configuration configuration = resources.getConfiguration();
    h.a(configuration, "context.resources.configuration");
    Locale locale = b.a(configuration);
    b.c c = b.a().a(this.a);
    h.a(c, "AdvertisingIdSingleton.g…getAdvertisingId(context)");
    String str5 = c.a();
    int i = this.b.getPhoneType();
    if (i != 0 && i != 2) {
      str1 = this.b.getNetworkOperatorName();
      if (str1 == null)
        str1 = ""; 
    } else {
      str1 = "";
    } 
    TelephonyManager telephonyManager1 = this.b;
    if (telephonyManager1.getSimState() == 5) {
      str6 = telephonyManager1.getSimOperator();
    } else {
      str6 = "";
    } 
    TelephonyManager telephonyManager2 = this.b;
    if (telephonyManager2.getSimState() == 5) {
      str7 = telephonyManager2.getSimOperatorName();
    } else {
      str7 = "";
    } 
    i = bool1;
    if (!h.a(this.a, "android.permission.ACCESS_FINE_LOCATION"))
      if (h.a(this.a, "android.permission.ACCESS_COARSE_LOCATION")) {
        i = bool1;
      } else {
        i = 0;
      }  
    if (i != 0) {
      str8 = String.valueOf(Integer.valueOf(f.a(this.b)));
    } else {
      str8 = "";
    } 
    if (i != 0) {
      str9 = String.valueOf(Integer.valueOf(f.b(this.b)));
    } else {
      str9 = "";
    } 
    c c1 = c.a();
    h.a(c1, "NetworkStats.get()");
    String str11 = c1.b();
    String str12 = i.a.a(this.a);
    if (b()) {
      str10 = "tablet";
    } else {
      str10 = "phone";
    } 
    String str13 = locale.toString();
    h.a(str13, "locale.toString()");
    h.a(str5, "advertisingId");
    i = Build.VERSION.SDK_INT;
    String str14 = Build.MODEL;
    h.a(str14, "Build.MODEL");
    String str15 = Build.MANUFACTURER;
    h.a(str15, "Build.MANUFACTURER");
    String str16 = Build.VERSION.RELEASE;
    h.a(str16, "Build.VERSION.RELEASE");
    String str17 = this.a.getPackageName();
    h.a(str17, "context.packageName");
    h.a(str6, "ips");
    h.a(str7, "ipsName");
    String str4 = d.b(this.a).a();
    h.a(str11, "signalLevel");
    return new DeviceInfo(str2, str3, str12, str13, str5, "android", String.valueOf(i), str14, str15, str16, str17, str1, str6, str7, str8, str9, str4, str11, str10, "1.0.16", "");
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */