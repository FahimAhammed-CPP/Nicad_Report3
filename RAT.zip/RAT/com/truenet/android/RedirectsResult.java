package com.truenet.android;

import a.a.b.b.h;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class RedirectsResult {
  @NotNull
  private final List<String> cookies;
  
  private final long loadTime;
  
  private final int response;
  
  @NotNull
  private final String url;
  
  public RedirectsResult(@NotNull String paramString, long paramLong, int paramInt, @NotNull List<String> paramList) {
    this.url = paramString;
    this.loadTime = paramLong;
    this.response = paramInt;
    this.cookies = paramList;
  }
  
  @NotNull
  public final String component1() {
    return this.url;
  }
  
  public final long component2() {
    return this.loadTime;
  }
  
  public final int component3() {
    return this.response;
  }
  
  @NotNull
  public final List<String> component4() {
    return this.cookies;
  }
  
  @NotNull
  public final RedirectsResult copy(@NotNull String paramString, long paramLong, int paramInt, @NotNull List<String> paramList) {
    h.b(paramString, "url");
    h.b(paramList, "cookies");
    return new RedirectsResult(paramString, paramLong, paramInt, paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof RedirectsResult) {
        paramObject = paramObject;
        if (h.a(this.url, ((RedirectsResult)paramObject).url)) {
          boolean bool;
          if (this.loadTime == ((RedirectsResult)paramObject).loadTime) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            if (this.response == ((RedirectsResult)paramObject).response) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool && h.a(this.cookies, ((RedirectsResult)paramObject).cookies))
              return true; 
          } 
        } 
      } 
      return false;
    } 
    return true;
  }
  
  @NotNull
  public final List<String> getCookies() {
    return this.cookies;
  }
  
  public final long getLoadTime() {
    return this.loadTime;
  }
  
  public final int getResponse() {
    return this.response;
  }
  
  @NotNull
  public final String getUrl() {
    return this.url;
  }
  
  public int hashCode() {
    byte b;
    String str = this.url;
    int i = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    long l = this.loadTime;
    int j = (int)(l ^ l >>> 32L);
    int k = this.response;
    List<String> list = this.cookies;
    if (list != null)
      i = list.hashCode(); 
    return ((b * 31 + j) * 31 + k) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RedirectsResult(url=");
    stringBuilder.append(this.url);
    stringBuilder.append(", loadTime=");
    stringBuilder.append(this.loadTime);
    stringBuilder.append(", response=");
    stringBuilder.append(this.response);
    stringBuilder.append(", cookies=");
    stringBuilder.append(this.cookies);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/RedirectsResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */