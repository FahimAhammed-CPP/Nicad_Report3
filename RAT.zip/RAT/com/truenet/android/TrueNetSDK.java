package com.truenet.android;

import a.a.a.g;
import a.a.b.b.e;
import a.a.b.b.g;
import a.a.b.b.h;
import a.a.b.b.i;
import a.a.b.b.m;
import a.a.b.b.n;
import a.a.j;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Log;
import com.startapp.common.b.a.a;
import com.truenet.android.a.a;
import com.truenet.android.a.g;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class TrueNetSDK implements a {
  private static final String BASE_INIT_URL;
  
  private static final String BASE_RESULT_URL;
  
  public static final a Companion = new a(null);
  
  private static final String INIT_URL;
  
  private static final int JOB_ID = 97764;
  
  @NotNull
  public static final String JOB_TAG = "TruenetCheckLinksJob";
  
  private static final String PREFS_ENABLED = "PrefsEnabled";
  
  private static final String PREFS_PUBLISHER_ID = "PrefsPublisherId";
  
  @NotNull
  public static final String PREFS_TAG = "TruenetJobKey";
  
  private static final String RESULT_URL;
  
  private static final URL initUrl;
  
  private static int intervalPosition;
  
  private static final List<Long> intervals;
  
  private static long requestDelay;
  
  private static final URL resultUrl;
  
  private static ThreadFactory threadFactory;
  
  private static boolean wasInitCalled;
  
  static {
    BASE_INIT_URL = new String(new char[] { 
          'h', 't', 't', 'p', 's', ':', '/', '/', 'v', 'a', 
          'l', 'i', 'd', 'a', 't', 'i', 'o', 'n', '-', 'e', 
          'n', 'g', 'i', 'n', 'e', '.', 't', 'r', 'u', 'e', 
          'n', 'e', 't', '.', 'a', 'i' });
    BASE_RESULT_URL = new String(new char[] { 
          'h', 't', 't', 'p', 's', ':', '/', '/', 'r', 'e', 
          's', 'u', 'l', 't', '-', 'a', 'p', 'i', '.', 't', 
          'r', 'u', 'e', 'n', 'e', 't', '.', 'a', 'i' });
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(BASE_INIT_URL);
    stringBuilder.append("/api/initial");
    INIT_URL = stringBuilder.toString();
    stringBuilder = new StringBuilder();
    stringBuilder.append(BASE_RESULT_URL);
    stringBuilder.append("/api/result");
    RESULT_URL = stringBuilder.toString();
    initUrl = new URL(INIT_URL);
    resultUrl = new URL(RESULT_URL);
    intervals = g.a((Object[])new Long[] { Long.valueOf(15L), Long.valueOf(30L), Long.valueOf(60L), Long.valueOf(120L), Long.valueOf(240L), Long.valueOf(480L) });
    threadFactory = b.a;
  }
  
  public static final void enable(@NotNull Context paramContext, boolean paramBoolean) {
    Companion.a(paramContext, paramBoolean);
  }
  
  public static final void with(@NotNull Context paramContext, @NotNull String paramString) {
    Companion.a(paramContext, paramString);
  }
  
  @Nullable
  public com.startapp.common.b.a.b create(int paramInt) {
    if (paramInt != 97764)
      return null; 
    Log.d("JobManager", "addJobCreator");
    return new c(this);
  }
  
  public static final class a {
    private a() {}
    
    private final void a(int param1Int, long param1Long) {
      TrueNetSDK.requestDelay = param1Long;
      TrueNetSDK.intervalPosition = a.a.c.a.a(param1Int, TrueNetSDK.intervals.size() - 1);
      if (param1Long != 0L) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      if (param1Int == 0)
        param1Long = TimeUnit.MINUTES.toMillis(((Number)TrueNetSDK.intervals.get(TrueNetSDK.intervalPosition)).longValue()); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("scheduled millis: ");
      stringBuilder.append(String.valueOf(param1Long));
      Log.d("JobManager", stringBuilder.toString());
      com.startapp.common.b.a.a(97764, false);
      com.startapp.common.b.a.a((new com.startapp.common.b.b.a(97764)).a(param1Long).a(false).a("TruenetCheckLinksJob", "TruenetJobKey").b(true).a());
    }
    
    private final void a(Context param1Context) {
      com.startapp.common.b.a.a(param1Context);
      com.startapp.common.b.a.a(new TrueNetSDK());
      a(this, param1Context, 0L, 2, null);
    }
    
    private final void a(Context param1Context, long param1Long) {
      Executors.newSingleThreadExecutor(TrueNetSDK.threadFactory).execute(new d(param1Long, param1Context));
    }
    
    private final void a(Context param1Context, LinksData param1LinksData, a.a.b.a.a<j> param1a) {
      List<Link> list = param1LinksData.getValidation();
      ArrayList<String> arrayList = new ArrayList(g.a(list, 10));
      Iterator<Link> iterator = list.iterator();
      while (iterator.hasNext())
        arrayList.add(((Link)iterator.next()).getValidationUrl()); 
      c c = new c(param1Context, arrayList, TrueNetSDK.threadFactory, param1LinksData.getMaxRedirectTime(), param1LinksData.getNumOfRedirect(), param1LinksData.getValidateParallel());
      ConcurrentLinkedQueue concurrentLinkedQueue = new ConcurrentLinkedQueue();
      c.a(new a(param1LinksData, concurrentLinkedQueue, param1Context, param1a));
      c.a(new b(param1LinksData, param1Context, concurrentLinkedQueue));
    }
    
    private final void a(Context param1Context, String param1String, a.a.b.a.a<j> param1a) {
      TrueNetSDK.intervalPosition = 0;
      TrueNetSDK.requestDelay = 0L;
      LinksData linksData = (LinksData)com.startapp.common.c.b.a(param1String, LinksData.class);
      if (linksData.getValidation().size() != 0) {
        a a1 = this;
        h.a(linksData, "response");
        a1.a(param1Context, linksData, param1a);
      } else {
        a(param1Context, linksData.getSleep());
        if (linksData.getSleep() != 0L)
          param1a.a(); 
      } 
    }
    
    private final void a(Thread param1Thread, Throwable param1Throwable) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Something went wrong in thread: ");
      stringBuilder.append(String.valueOf(param1Thread.getId()));
      Log.e("TrueNetSDK", stringBuilder.toString(), param1Throwable);
    }
    
    private final String b(Context param1Context) {
      DeviceInfo deviceInfo = (new a(param1Context, null, 2, null)).a();
      deviceInfo.setPublisherId(c(param1Context));
      String str = com.startapp.common.c.b.a(deviceInfo);
      h.a(str, "JSONParser.toJson(info)");
      return str;
    }
    
    private final String c(Context param1Context) {
      String str = param1Context.getSharedPreferences("TruenetJobKey", 0).getString("PrefsPublisherId", "Undefined");
      h.a(str, "prefs.getString(PREFS_PUBLISHER_ID, \"Undefined\")");
      return str;
    }
    
    public final void a(@NotNull Context param1Context, @NotNull a.a.b.a.a<j> param1a) {
      h.b(param1Context, "context");
      h.b(param1a, "finish");
      try {
        if (!param1Context.getSharedPreferences("TruenetJobKey", 0).getBoolean("PrefsEnabled", true)) {
          com.startapp.common.b.a.a(97764, false);
          param1a.a();
          return;
        } 
        ExecutorService executorService = Executors.newSingleThreadExecutor(TrueNetSDK.threadFactory);
        c c = new c();
        this(param1Context, param1a);
        executorService.execute(c);
      } catch (Throwable throwable) {
        a a1 = this;
        Thread thread = Thread.currentThread();
        h.a(thread, "Thread.currentThread()");
        a1.a(thread, throwable);
      } 
    }
    
    public final void a(@NotNull Context param1Context, @NotNull String param1String) {
      h.b(param1Context, "context");
      h.b(param1String, "publisherID");
      try {
        SharedPreferences sharedPreferences = param1Context.getSharedPreferences("TruenetJobKey", 0);
        sharedPreferences.edit().putString("PrefsPublisherId", param1String).apply();
        if (sharedPreferences.getBoolean("PrefsEnabled", true) && !TrueNetSDK.wasInitCalled) {
          a(param1Context);
          TrueNetSDK.wasInitCalled = true;
        } 
      } catch (Throwable throwable) {
        a a1 = this;
        Thread thread = Thread.currentThread();
        h.a(thread, "Thread.currentThread()");
        a1.a(thread, throwable);
      } 
    }
    
    public final void a(@NotNull Context param1Context, boolean param1Boolean) {
      h.b(param1Context, "context");
      try {
        param1Context.getSharedPreferences("TruenetJobKey", 0).edit().putBoolean("PrefsEnabled", param1Boolean).apply();
        if (param1Boolean && !TrueNetSDK.wasInitCalled) {
          a(param1Context);
          TrueNetSDK.wasInitCalled = true;
        } 
      } catch (Throwable throwable) {
        a a1 = this;
        Thread thread = Thread.currentThread();
        h.a(thread, "Thread.currentThread()");
        a1.a(thread, throwable);
      } 
    }
    
    static final class a extends i implements a.a.b.a.a<j> {
      a(LinksData param2LinksData, ConcurrentLinkedQueue param2ConcurrentLinkedQueue, Context param2Context, a.a.b.a.a param2a) {
        super(0);
      }
      
      public final void b() {
        if (this.$links.getBulkResponse()) {
          String str = com.startapp.common.c.b.a(new ValidationResults(g.a(this.$bulkQueue)));
          URL uRL = TrueNetSDK.resultUrl;
          h.a(str, "json");
          g.b(uRL, str, this.$context);
        } 
        TrueNetSDK.a.a(TrueNetSDK.Companion, this.$context, this.$links.getSleep());
        if (this.$links.getSleep() != 0L)
          this.$finish.a(); 
      }
    }
    
    static final class b extends i implements a.a.b.a.b<b, Integer, j> {
      b(LinksData param2LinksData, Context param2Context, ConcurrentLinkedQueue param2ConcurrentLinkedQueue) {
        super(2);
      }
      
      public final void a(@NotNull b param2b, int param2Int) {
        String str1;
        h.b(param2b, "info");
        List<b.b> list = param2b.d();
        ArrayList<RedirectsResult> arrayList1 = new ArrayList(g.a(list, 10));
        for (b.b b1 : list) {
          String str = b1.a();
          long l1 = b1.b();
          int j = b1.c();
          List<String> list1 = b1.d();
          if (list1 == null)
            list1 = g.a(); 
          arrayList1.add(new RedirectsResult(str, l1, j, list1));
        } 
        ArrayList<RedirectsResult> arrayList2 = arrayList1;
        Link link = this.$links.getValidation().get(param2Int);
        String str4 = link.getInstanceId();
        param2Int = param2b.b();
        long l = param2b.c();
        String str3 = param2b.e();
        String str2 = param2b.f();
        if (str2 != null && g.a(new URL(link.getHtmlStorage()), str2, this.$context) == true) {
          str2 = link.getHtmlStorage();
        } else {
          str2 = "";
        } 
        Bitmap bitmap = param2b.a();
        if (bitmap != null && a.a(bitmap, link.getImageStorage()) == true) {
          str1 = link.getImageStorage();
        } else {
          str1 = "";
        } 
        ValidationResult validationResult = new ValidationResult(str4, param2Int, l, arrayList2, str3, str2, str1, TrueNetSDK.a.b(TrueNetSDK.Companion, this.$context), link.getMetaData());
        if (this.$links.getBulkResponse()) {
          this.$bulkQueue.add(validationResult);
        } else {
          String str = com.startapp.common.c.b.a(new ValidationResults(g.a(validationResult)));
          URL uRL = TrueNetSDK.resultUrl;
          h.a(str, "json");
          g.b(uRL, str, this.$context);
        } 
      }
    }
    
    static final class c implements Runnable {
      c(Context param2Context, a.a.b.a.a param2a) {}
      
      public final void run() {
        int i;
        if (TrueNetSDK.requestDelay != 0L) {
          i = 1;
        } else {
          i = 0;
        } 
        Log.d("JobManager", "sending initial request");
        String str = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, this.a), this.a);
        if (str != null) {
          TrueNetSDK.a.a(TrueNetSDK.Companion, this.a, str, this.b);
        } else {
          TrueNetSDK.a a1 = TrueNetSDK.Companion;
          if (i) {
            i = TrueNetSDK.intervalPosition;
          } else {
            i = TrueNetSDK.intervalPosition + 1;
          } 
          TrueNetSDK.a.a(a1, i, 0L);
          this.b.a();
        } 
      }
    }
    
    static final class d implements Runnable {
      d(long param2Long, Context param2Context) {}
      
      public final void run() {
        m.a a = new m.a();
        a.element = null;
        if (this.a == 0L && (new a.a.b.a.a<String>(a) {
            @Nullable
            public final String b() {
              this.$res.element = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, TrueNetSDK.a.d.this.b), TrueNetSDK.a.d.this.b);
              return (String)this.$res.element;
            }
          }).a() != null) {
          TrueNetSDK.a a1 = TrueNetSDK.Companion;
          Context context = this.b;
          String str = (String)a.element;
          if (str == null)
            h.a(); 
          TrueNetSDK.a.a(a1, context, str, null.a);
        } else {
          TrueNetSDK.a.a(TrueNetSDK.Companion, 0, this.a);
        } 
      }
    }
    
    static final class null extends i implements a.a.b.a.a<String> {
      null(m.a param2a) {
        super(0);
      }
      
      @Nullable
      public final String b() {
        this.$res.element = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, TrueNetSDK.a.d.this.b), TrueNetSDK.a.d.this.b);
        return (String)this.$res.element;
      }
    }
    
    static final class null extends i implements a.a.b.a.a<j> {
      public static final null a = (null)new a.a.b.a.a<j>();
      
      null() {
        super(0);
      }
      
      public final void b() {}
    }
  }
  
  static final class a extends i implements a.a.b.a.a<j> {
    a(LinksData param1LinksData, ConcurrentLinkedQueue param1ConcurrentLinkedQueue, Context param1Context, a.a.b.a.a param1a) {
      super(0);
    }
    
    public final void b() {
      if (this.$links.getBulkResponse()) {
        String str = com.startapp.common.c.b.a(new ValidationResults(g.a(this.$bulkQueue)));
        URL uRL = TrueNetSDK.resultUrl;
        h.a(str, "json");
        g.b(uRL, str, this.$context);
      } 
      TrueNetSDK.a.a(TrueNetSDK.Companion, this.$context, this.$links.getSleep());
      if (this.$links.getSleep() != 0L)
        this.$finish.a(); 
    }
  }
  
  static final class b extends i implements a.a.b.a.b<b, Integer, j> {
    b(LinksData param1LinksData, Context param1Context, ConcurrentLinkedQueue param1ConcurrentLinkedQueue) {
      super(2);
    }
    
    public final void a(@NotNull b param1b, int param1Int) {
      String str1;
      h.b(param1b, "info");
      List<b.b> list = param1b.d();
      ArrayList<RedirectsResult> arrayList1 = new ArrayList(g.a(list, 10));
      for (b.b b1 : list) {
        String str = b1.a();
        long l1 = b1.b();
        int j = b1.c();
        List<String> list1 = b1.d();
        if (list1 == null)
          list1 = g.a(); 
        arrayList1.add(new RedirectsResult(str, l1, j, list1));
      } 
      ArrayList<RedirectsResult> arrayList2 = arrayList1;
      Link link = this.$links.getValidation().get(param1Int);
      String str4 = link.getInstanceId();
      param1Int = param1b.b();
      long l = param1b.c();
      String str3 = param1b.e();
      String str2 = param1b.f();
      if (str2 != null && g.a(new URL(link.getHtmlStorage()), str2, this.$context) == true) {
        str2 = link.getHtmlStorage();
      } else {
        str2 = "";
      } 
      Bitmap bitmap = param1b.a();
      if (bitmap != null && a.a(bitmap, link.getImageStorage()) == true) {
        str1 = link.getImageStorage();
      } else {
        str1 = "";
      } 
      ValidationResult validationResult = new ValidationResult(str4, param1Int, l, arrayList2, str3, str2, str1, TrueNetSDK.a.b(TrueNetSDK.Companion, this.$context), link.getMetaData());
      if (this.$links.getBulkResponse()) {
        this.$bulkQueue.add(validationResult);
      } else {
        String str = com.startapp.common.c.b.a(new ValidationResults(g.a(validationResult)));
        URL uRL = TrueNetSDK.resultUrl;
        h.a(str, "json");
        g.b(uRL, str, this.$context);
      } 
    }
  }
  
  static final class c implements Runnable {
    c(Context param1Context, a.a.b.a.a param1a) {}
    
    public final void run() {
      int i;
      if (TrueNetSDK.requestDelay != 0L) {
        i = 1;
      } else {
        i = 0;
      } 
      Log.d("JobManager", "sending initial request");
      String str = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, this.a), this.a);
      if (str != null) {
        TrueNetSDK.a.a(TrueNetSDK.Companion, this.a, str, this.b);
      } else {
        TrueNetSDK.a a1 = TrueNetSDK.Companion;
        if (i) {
          i = TrueNetSDK.intervalPosition;
        } else {
          i = TrueNetSDK.intervalPosition + 1;
        } 
        TrueNetSDK.a.a(a1, i, 0L);
        this.b.a();
      } 
    }
  }
  
  static final class d implements Runnable {
    d(long param1Long, Context param1Context) {}
    
    public final void run() {
      m.a a = new m.a();
      a.element = null;
      if (this.a == 0L && (new a.a.b.a.a<String>(a) {
          @Nullable
          public final String b() {
            this.$res.element = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, TrueNetSDK.a.d.this.b), TrueNetSDK.a.d.this.b);
            return (String)this.$res.element;
          }
        }).a() != null) {
        TrueNetSDK.a a1 = TrueNetSDK.Companion;
        Context context = this.b;
        String str = (String)a.element;
        if (str == null)
          h.a(); 
        TrueNetSDK.a.a(a1, context, str, null.a);
      } else {
        TrueNetSDK.a.a(TrueNetSDK.Companion, 0, this.a);
      } 
    }
  }
  
  static final class null extends i implements a.a.b.a.a<String> {
    null(m.a param1a) {
      super(0);
    }
    
    @Nullable
    public final String b() {
      this.$res.element = g.b(TrueNetSDK.initUrl, TrueNetSDK.a.a(TrueNetSDK.Companion, TrueNetSDK.a.d.this.b), TrueNetSDK.a.d.this.b);
      return (String)this.$res.element;
    }
  }
  
  static final class null extends i implements a.a.b.a.a<j> {
    public static final null a = (null)new a.a.b.a.a<j>();
    
    null() {
      super(0);
    }
    
    public final void b() {}
  }
  
  static final class b implements ThreadFactory {
    public static final b a = new b();
    
    @NotNull
    public final Thread newThread(Runnable param1Runnable) {
      param1Runnable = new Thread(param1Runnable);
      param1Runnable.setUncaughtExceptionHandler(new d(new a.a.b.a.b<Thread, Throwable, j>(TrueNetSDK.Companion) {
              public final a.a.d.c a() {
                return (a.a.d.c)n.a(TrueNetSDK.a.class);
              }
              
              public final void a(@NotNull Thread param2Thread, @NotNull Throwable param2Throwable) {
                h.b(param2Thread, "p1");
                h.b(param2Throwable, "p2");
                TrueNetSDK.a.a((TrueNetSDK.a)this.receiver, param2Thread, param2Throwable);
              }
              
              public final String b() {
                return "uncaughtExceptionHandler";
              }
              
              public final String c() {
                return "uncaughtExceptionHandler(Ljava/lang/Thread;Ljava/lang/Throwable;)V";
              }
            }));
      return (Thread)param1Runnable;
    }
  }
  
  static final class null extends g implements a.a.b.a.b<Thread, Throwable, j> {
    null(TrueNetSDK.a param1a) {
      super(2, param1a);
    }
    
    public final a.a.d.c a() {
      return (a.a.d.c)n.a(TrueNetSDK.a.class);
    }
    
    public final void a(@NotNull Thread param1Thread, @NotNull Throwable param1Throwable) {
      h.b(param1Thread, "p1");
      h.b(param1Throwable, "p2");
      TrueNetSDK.a.a((TrueNetSDK.a)this.receiver, param1Thread, param1Throwable);
    }
    
    public final String b() {
      return "uncaughtExceptionHandler";
    }
    
    public final String c() {
      return "uncaughtExceptionHandler(Ljava/lang/Thread;Ljava/lang/Throwable;)V";
    }
  }
  
  static final class c implements com.startapp.common.b.a.b {
    c(TrueNetSDK param1TrueNetSDK) {}
    
    public final void a(Context param1Context, int param1Int, Map<String, String> param1Map, com.startapp.common.b.a.b.b param1b) {
      synchronized (this.a) {
        if (h.a(param1Map.get("TruenetCheckLinksJob"), "TruenetJobKey")) {
          TrueNetSDK.a a = TrueNetSDK.Companion;
          h.a(param1Context, "context");
          a a1 = new a();
          this(param1Map, param1Context, param1Int, param1b);
          a.a(param1Context, a1);
        } 
        j j = j.a;
        return;
      } 
    }
    
    static final class a extends i implements a.a.b.a.a<j> {
      a(Map param2Map, Context param2Context, int param2Int, com.startapp.common.b.a.b.b param2b) {
        super(0);
      }
      
      public final void b() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("finished ");
        stringBuilder.append(String.valueOf(this.$jobId$inlined));
        Log.d("JobManager", stringBuilder.toString());
        this.$runnerListener$inlined.a(com.startapp.common.b.a.b.a.a);
      }
    }
  }
  
  static final class a extends i implements a.a.b.a.a<j> {
    a(Map param1Map, Context param1Context, int param1Int, com.startapp.common.b.a.b.b param1b) {
      super(0);
    }
    
    public final void b() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("finished ");
      stringBuilder.append(String.valueOf(this.$jobId$inlined));
      Log.d("JobManager", stringBuilder.toString());
      this.$runnerListener$inlined.a(com.startapp.common.b.a.b.a.a);
    }
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/TrueNetSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */