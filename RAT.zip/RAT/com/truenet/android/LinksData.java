package com.truenet.android;

import a.a.a.g;
import a.a.b.b.h;
import com.startapp.common.c.f;
import java.util.ArrayList;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public final class LinksData {
  private final boolean bulkResponse;
  
  private final long maxRedirectTime;
  
  private final int numOfRedirect;
  
  private final long sleep;
  
  private final int validateParallel;
  
  @f(b = ArrayList.class, c = Link.class)
  @NotNull
  private final List<Link> validation;
  
  public LinksData() {
    this(0L, 0, false, 0, 0L, g.a());
  }
  
  public LinksData(long paramLong1, int paramInt1, boolean paramBoolean, int paramInt2, long paramLong2, @NotNull List<Link> paramList) {
    this.sleep = paramLong1;
    this.validateParallel = paramInt1;
    this.bulkResponse = paramBoolean;
    this.numOfRedirect = paramInt2;
    this.maxRedirectTime = paramLong2;
    this.validation = paramList;
  }
  
  public final long component1() {
    return this.sleep;
  }
  
  public final int component2() {
    return this.validateParallel;
  }
  
  public final boolean component3() {
    return this.bulkResponse;
  }
  
  public final int component4() {
    return this.numOfRedirect;
  }
  
  public final long component5() {
    return this.maxRedirectTime;
  }
  
  @NotNull
  public final List<Link> component6() {
    return this.validation;
  }
  
  @NotNull
  public final LinksData copy(long paramLong1, int paramInt1, boolean paramBoolean, int paramInt2, long paramLong2, @NotNull List<Link> paramList) {
    h.b(paramList, "validation");
    return new LinksData(paramLong1, paramInt1, paramBoolean, paramInt2, paramLong2, paramList);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof LinksData) {
        boolean bool;
        paramObject = paramObject;
        if (this.sleep == ((LinksData)paramObject).sleep) {
          bool = true;
        } else {
          bool = false;
        } 
        if (bool) {
          if (this.validateParallel == ((LinksData)paramObject).validateParallel) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            if (this.bulkResponse == ((LinksData)paramObject).bulkResponse) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool) {
              if (this.numOfRedirect == ((LinksData)paramObject).numOfRedirect) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool) {
                if (this.maxRedirectTime == ((LinksData)paramObject).maxRedirectTime) {
                  bool = true;
                } else {
                  bool = false;
                } 
                if (bool && h.a(this.validation, ((LinksData)paramObject).validation))
                  return true; 
              } 
            } 
          } 
        } 
      } 
      return false;
    } 
    return true;
  }
  
  public final boolean getBulkResponse() {
    return this.bulkResponse;
  }
  
  public final long getMaxRedirectTime() {
    return this.maxRedirectTime;
  }
  
  public final int getNumOfRedirect() {
    return this.numOfRedirect;
  }
  
  public final long getSleep() {
    return this.sleep;
  }
  
  public final int getValidateParallel() {
    return this.validateParallel;
  }
  
  @NotNull
  public final List<Link> getValidation() {
    return this.validation;
  }
  
  public int hashCode() {
    long l = this.sleep;
    int i = (int)(l ^ l >>> 32L);
    int j = this.validateParallel;
    boolean bool1 = this.bulkResponse;
    boolean bool2 = bool1;
    if (bool1)
      bool2 = true; 
    int k = this.numOfRedirect;
    l = this.maxRedirectTime;
    int m = (int)(l >>> 32L ^ l);
    List<Link> list = this.validation;
    if (list != null) {
      int n = list.hashCode();
    } else {
      bool1 = false;
    } 
    return ((((i * 31 + j) * 31 + bool2) * 31 + k) * 31 + m) * 31 + bool1;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LinksData(sleep=");
    stringBuilder.append(this.sleep);
    stringBuilder.append(", validateParallel=");
    stringBuilder.append(this.validateParallel);
    stringBuilder.append(", bulkResponse=");
    stringBuilder.append(this.bulkResponse);
    stringBuilder.append(", numOfRedirect=");
    stringBuilder.append(this.numOfRedirect);
    stringBuilder.append(", maxRedirectTime=");
    stringBuilder.append(this.maxRedirectTime);
    stringBuilder.append(", validation=");
    stringBuilder.append(this.validation);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/LinksData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */