package com.truenet.android;

import a.a.b.b.h;
import org.jetbrains.annotations.NotNull;

public final class DeviceInfo {
  @NotNull
  private final String advertisingId;
  
  @NotNull
  private final String cellId;
  
  @NotNull
  private final String deviceManufacturer;
  
  @NotNull
  private final String deviceModel;
  
  @NotNull
  private final String deviceType;
  
  @NotNull
  private final String deviceVersion;
  
  @NotNull
  private final String isp;
  
  @NotNull
  private final String ispName;
  
  @NotNull
  private final String latitude;
  
  @NotNull
  private final String locale;
  
  @NotNull
  private final String locationAreaCode;
  
  @NotNull
  private final String longitude;
  
  @NotNull
  private final String networkOperName;
  
  @NotNull
  private final String networkType;
  
  @NotNull
  private final String osId;
  
  @NotNull
  private final String osVer;
  
  @NotNull
  private final String packageName;
  
  @NotNull
  private String publisherId;
  
  @NotNull
  private final String sdkVersion;
  
  @NotNull
  private final String signalLevel;
  
  @NotNull
  private final String userAgent;
  
  public DeviceInfo(@NotNull String paramString1, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5, @NotNull String paramString6, @NotNull String paramString7, @NotNull String paramString8, @NotNull String paramString9, @NotNull String paramString10, @NotNull String paramString11, @NotNull String paramString12, @NotNull String paramString13, @NotNull String paramString14, @NotNull String paramString15, @NotNull String paramString16, @NotNull String paramString17, @NotNull String paramString18, @NotNull String paramString19, @NotNull String paramString20, @NotNull String paramString21) {
    this.latitude = paramString1;
    this.longitude = paramString2;
    this.userAgent = paramString3;
    this.locale = paramString4;
    this.advertisingId = paramString5;
    this.osId = paramString6;
    this.osVer = paramString7;
    this.deviceModel = paramString8;
    this.deviceManufacturer = paramString9;
    this.deviceVersion = paramString10;
    this.packageName = paramString11;
    this.networkOperName = paramString12;
    this.isp = paramString13;
    this.ispName = paramString14;
    this.cellId = paramString15;
    this.locationAreaCode = paramString16;
    this.networkType = paramString17;
    this.signalLevel = paramString18;
    this.deviceType = paramString19;
    this.sdkVersion = paramString20;
    this.publisherId = paramString21;
  }
  
  @NotNull
  public final String component1() {
    return this.latitude;
  }
  
  @NotNull
  public final String component10() {
    return this.deviceVersion;
  }
  
  @NotNull
  public final String component11() {
    return this.packageName;
  }
  
  @NotNull
  public final String component12() {
    return this.networkOperName;
  }
  
  @NotNull
  public final String component13() {
    return this.isp;
  }
  
  @NotNull
  public final String component14() {
    return this.ispName;
  }
  
  @NotNull
  public final String component15() {
    return this.cellId;
  }
  
  @NotNull
  public final String component16() {
    return this.locationAreaCode;
  }
  
  @NotNull
  public final String component17() {
    return this.networkType;
  }
  
  @NotNull
  public final String component18() {
    return this.signalLevel;
  }
  
  @NotNull
  public final String component19() {
    return this.deviceType;
  }
  
  @NotNull
  public final String component2() {
    return this.longitude;
  }
  
  @NotNull
  public final String component20() {
    return this.sdkVersion;
  }
  
  @NotNull
  public final String component21() {
    return this.publisherId;
  }
  
  @NotNull
  public final String component3() {
    return this.userAgent;
  }
  
  @NotNull
  public final String component4() {
    return this.locale;
  }
  
  @NotNull
  public final String component5() {
    return this.advertisingId;
  }
  
  @NotNull
  public final String component6() {
    return this.osId;
  }
  
  @NotNull
  public final String component7() {
    return this.osVer;
  }
  
  @NotNull
  public final String component8() {
    return this.deviceModel;
  }
  
  @NotNull
  public final String component9() {
    return this.deviceManufacturer;
  }
  
  @NotNull
  public final DeviceInfo copy(@NotNull String paramString1, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5, @NotNull String paramString6, @NotNull String paramString7, @NotNull String paramString8, @NotNull String paramString9, @NotNull String paramString10, @NotNull String paramString11, @NotNull String paramString12, @NotNull String paramString13, @NotNull String paramString14, @NotNull String paramString15, @NotNull String paramString16, @NotNull String paramString17, @NotNull String paramString18, @NotNull String paramString19, @NotNull String paramString20, @NotNull String paramString21) {
    h.b(paramString1, "latitude");
    h.b(paramString2, "longitude");
    h.b(paramString3, "userAgent");
    h.b(paramString4, "locale");
    h.b(paramString5, "advertisingId");
    h.b(paramString6, "osId");
    h.b(paramString7, "osVer");
    h.b(paramString8, "deviceModel");
    h.b(paramString9, "deviceManufacturer");
    h.b(paramString10, "deviceVersion");
    h.b(paramString11, "packageName");
    h.b(paramString12, "networkOperName");
    h.b(paramString13, "isp");
    h.b(paramString14, "ispName");
    h.b(paramString15, "cellId");
    h.b(paramString16, "locationAreaCode");
    h.b(paramString17, "networkType");
    h.b(paramString18, "signalLevel");
    h.b(paramString19, "deviceType");
    h.b(paramString20, "sdkVersion");
    h.b(paramString21, "publisherId");
    return new DeviceInfo(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8, paramString9, paramString10, paramString11, paramString12, paramString13, paramString14, paramString15, paramString16, paramString17, paramString18, paramString19, paramString20, paramString21);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof DeviceInfo) {
        paramObject = paramObject;
        if (h.a(this.latitude, ((DeviceInfo)paramObject).latitude) && h.a(this.longitude, ((DeviceInfo)paramObject).longitude) && h.a(this.userAgent, ((DeviceInfo)paramObject).userAgent) && h.a(this.locale, ((DeviceInfo)paramObject).locale) && h.a(this.advertisingId, ((DeviceInfo)paramObject).advertisingId) && h.a(this.osId, ((DeviceInfo)paramObject).osId) && h.a(this.osVer, ((DeviceInfo)paramObject).osVer) && h.a(this.deviceModel, ((DeviceInfo)paramObject).deviceModel) && h.a(this.deviceManufacturer, ((DeviceInfo)paramObject).deviceManufacturer) && h.a(this.deviceVersion, ((DeviceInfo)paramObject).deviceVersion) && h.a(this.packageName, ((DeviceInfo)paramObject).packageName) && h.a(this.networkOperName, ((DeviceInfo)paramObject).networkOperName) && h.a(this.isp, ((DeviceInfo)paramObject).isp) && h.a(this.ispName, ((DeviceInfo)paramObject).ispName) && h.a(this.cellId, ((DeviceInfo)paramObject).cellId) && h.a(this.locationAreaCode, ((DeviceInfo)paramObject).locationAreaCode) && h.a(this.networkType, ((DeviceInfo)paramObject).networkType) && h.a(this.signalLevel, ((DeviceInfo)paramObject).signalLevel) && h.a(this.deviceType, ((DeviceInfo)paramObject).deviceType) && h.a(this.sdkVersion, ((DeviceInfo)paramObject).sdkVersion) && h.a(this.publisherId, ((DeviceInfo)paramObject).publisherId))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  @NotNull
  public final String getAdvertisingId() {
    return this.advertisingId;
  }
  
  @NotNull
  public final String getCellId() {
    return this.cellId;
  }
  
  @NotNull
  public final String getDeviceManufacturer() {
    return this.deviceManufacturer;
  }
  
  @NotNull
  public final String getDeviceModel() {
    return this.deviceModel;
  }
  
  @NotNull
  public final String getDeviceType() {
    return this.deviceType;
  }
  
  @NotNull
  public final String getDeviceVersion() {
    return this.deviceVersion;
  }
  
  @NotNull
  public final String getIsp() {
    return this.isp;
  }
  
  @NotNull
  public final String getIspName() {
    return this.ispName;
  }
  
  @NotNull
  public final String getLatitude() {
    return this.latitude;
  }
  
  @NotNull
  public final String getLocale() {
    return this.locale;
  }
  
  @NotNull
  public final String getLocationAreaCode() {
    return this.locationAreaCode;
  }
  
  @NotNull
  public final String getLongitude() {
    return this.longitude;
  }
  
  @NotNull
  public final String getNetworkOperName() {
    return this.networkOperName;
  }
  
  @NotNull
  public final String getNetworkType() {
    return this.networkType;
  }
  
  @NotNull
  public final String getOsId() {
    return this.osId;
  }
  
  @NotNull
  public final String getOsVer() {
    return this.osVer;
  }
  
  @NotNull
  public final String getPackageName() {
    return this.packageName;
  }
  
  @NotNull
  public final String getPublisherId() {
    return this.publisherId;
  }
  
  @NotNull
  public final String getSdkVersion() {
    return this.sdkVersion;
  }
  
  @NotNull
  public final String getSignalLevel() {
    return this.signalLevel;
  }
  
  @NotNull
  public final String getUserAgent() {
    return this.userAgent;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    byte b5;
    byte b6;
    byte b7;
    byte b8;
    byte b9;
    byte b10;
    byte b11;
    byte b12;
    byte b13;
    byte b14;
    byte b15;
    byte b16;
    byte b17;
    byte b18;
    byte b19;
    byte b20;
    String str = this.latitude;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.longitude;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    str = this.userAgent;
    if (str != null) {
      b3 = str.hashCode();
    } else {
      b3 = 0;
    } 
    str = this.locale;
    if (str != null) {
      b4 = str.hashCode();
    } else {
      b4 = 0;
    } 
    str = this.advertisingId;
    if (str != null) {
      b5 = str.hashCode();
    } else {
      b5 = 0;
    } 
    str = this.osId;
    if (str != null) {
      b6 = str.hashCode();
    } else {
      b6 = 0;
    } 
    str = this.osVer;
    if (str != null) {
      b7 = str.hashCode();
    } else {
      b7 = 0;
    } 
    str = this.deviceModel;
    if (str != null) {
      b8 = str.hashCode();
    } else {
      b8 = 0;
    } 
    str = this.deviceManufacturer;
    if (str != null) {
      b9 = str.hashCode();
    } else {
      b9 = 0;
    } 
    str = this.deviceVersion;
    if (str != null) {
      b10 = str.hashCode();
    } else {
      b10 = 0;
    } 
    str = this.packageName;
    if (str != null) {
      b11 = str.hashCode();
    } else {
      b11 = 0;
    } 
    str = this.networkOperName;
    if (str != null) {
      b12 = str.hashCode();
    } else {
      b12 = 0;
    } 
    str = this.isp;
    if (str != null) {
      b13 = str.hashCode();
    } else {
      b13 = 0;
    } 
    str = this.ispName;
    if (str != null) {
      b14 = str.hashCode();
    } else {
      b14 = 0;
    } 
    str = this.cellId;
    if (str != null) {
      b15 = str.hashCode();
    } else {
      b15 = 0;
    } 
    str = this.locationAreaCode;
    if (str != null) {
      b16 = str.hashCode();
    } else {
      b16 = 0;
    } 
    str = this.networkType;
    if (str != null) {
      b17 = str.hashCode();
    } else {
      b17 = 0;
    } 
    str = this.signalLevel;
    if (str != null) {
      b18 = str.hashCode();
    } else {
      b18 = 0;
    } 
    str = this.deviceType;
    if (str != null) {
      b19 = str.hashCode();
    } else {
      b19 = 0;
    } 
    str = this.sdkVersion;
    if (str != null) {
      b20 = str.hashCode();
    } else {
      b20 = 0;
    } 
    str = this.publisherId;
    if (str != null)
      i = str.hashCode(); 
    return (((((((((((((((((((b1 * 31 + b2) * 31 + b3) * 31 + b4) * 31 + b5) * 31 + b6) * 31 + b7) * 31 + b8) * 31 + b9) * 31 + b10) * 31 + b11) * 31 + b12) * 31 + b13) * 31 + b14) * 31 + b15) * 31 + b16) * 31 + b17) * 31 + b18) * 31 + b19) * 31 + b20) * 31 + i;
  }
  
  public final void setPublisherId(@NotNull String paramString) {
    h.b(paramString, "<set-?>");
    this.publisherId = paramString;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DeviceInfo(latitude=");
    stringBuilder.append(this.latitude);
    stringBuilder.append(", longitude=");
    stringBuilder.append(this.longitude);
    stringBuilder.append(", userAgent=");
    stringBuilder.append(this.userAgent);
    stringBuilder.append(", locale=");
    stringBuilder.append(this.locale);
    stringBuilder.append(", advertisingId=");
    stringBuilder.append(this.advertisingId);
    stringBuilder.append(", osId=");
    stringBuilder.append(this.osId);
    stringBuilder.append(", osVer=");
    stringBuilder.append(this.osVer);
    stringBuilder.append(", deviceModel=");
    stringBuilder.append(this.deviceModel);
    stringBuilder.append(", deviceManufacturer=");
    stringBuilder.append(this.deviceManufacturer);
    stringBuilder.append(", deviceVersion=");
    stringBuilder.append(this.deviceVersion);
    stringBuilder.append(", packageName=");
    stringBuilder.append(this.packageName);
    stringBuilder.append(", networkOperName=");
    stringBuilder.append(this.networkOperName);
    stringBuilder.append(", isp=");
    stringBuilder.append(this.isp);
    stringBuilder.append(", ispName=");
    stringBuilder.append(this.ispName);
    stringBuilder.append(", cellId=");
    stringBuilder.append(this.cellId);
    stringBuilder.append(", locationAreaCode=");
    stringBuilder.append(this.locationAreaCode);
    stringBuilder.append(", networkType=");
    stringBuilder.append(this.networkType);
    stringBuilder.append(", signalLevel=");
    stringBuilder.append(this.signalLevel);
    stringBuilder.append(", deviceType=");
    stringBuilder.append(this.deviceType);
    stringBuilder.append(", sdkVersion=");
    stringBuilder.append(this.sdkVersion);
    stringBuilder.append(", publisherId=");
    stringBuilder.append(this.publisherId);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/DeviceInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */