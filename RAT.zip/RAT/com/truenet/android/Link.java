package com.truenet.android;

import a.a.b.b.h;
import org.jetbrains.annotations.NotNull;

public final class Link {
  @NotNull
  private final String htmlStorage;
  
  @NotNull
  private final String imageStorage;
  
  @NotNull
  private final String instanceId;
  
  @NotNull
  private final String metaData;
  
  @NotNull
  private final String validationUrl;
  
  public Link() {
    this("", "", "", "", "");
  }
  
  public Link(@NotNull String paramString1, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5) {
    this.instanceId = paramString1;
    this.validationUrl = paramString2;
    this.imageStorage = paramString3;
    this.htmlStorage = paramString4;
    this.metaData = paramString5;
  }
  
  @NotNull
  public final String component1() {
    return this.instanceId;
  }
  
  @NotNull
  public final String component2() {
    return this.validationUrl;
  }
  
  @NotNull
  public final String component3() {
    return this.imageStorage;
  }
  
  @NotNull
  public final String component4() {
    return this.htmlStorage;
  }
  
  @NotNull
  public final String component5() {
    return this.metaData;
  }
  
  @NotNull
  public final Link copy(@NotNull String paramString1, @NotNull String paramString2, @NotNull String paramString3, @NotNull String paramString4, @NotNull String paramString5) {
    h.b(paramString1, "instanceId");
    h.b(paramString2, "validationUrl");
    h.b(paramString3, "imageStorage");
    h.b(paramString4, "htmlStorage");
    h.b(paramString5, "metaData");
    return new Link(paramString1, paramString2, paramString3, paramString4, paramString5);
  }
  
  public boolean equals(Object paramObject) {
    if (this != paramObject) {
      if (paramObject instanceof Link) {
        paramObject = paramObject;
        if (h.a(this.instanceId, ((Link)paramObject).instanceId) && h.a(this.validationUrl, ((Link)paramObject).validationUrl) && h.a(this.imageStorage, ((Link)paramObject).imageStorage) && h.a(this.htmlStorage, ((Link)paramObject).htmlStorage) && h.a(this.metaData, ((Link)paramObject).metaData))
          return true; 
      } 
      return false;
    } 
    return true;
  }
  
  @NotNull
  public final String getHtmlStorage() {
    return this.htmlStorage;
  }
  
  @NotNull
  public final String getImageStorage() {
    return this.imageStorage;
  }
  
  @NotNull
  public final String getInstanceId() {
    return this.instanceId;
  }
  
  @NotNull
  public final String getMetaData() {
    return this.metaData;
  }
  
  @NotNull
  public final String getValidationUrl() {
    return this.validationUrl;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    String str = this.instanceId;
    int i = 0;
    if (str != null) {
      b1 = str.hashCode();
    } else {
      b1 = 0;
    } 
    str = this.validationUrl;
    if (str != null) {
      b2 = str.hashCode();
    } else {
      b2 = 0;
    } 
    str = this.imageStorage;
    if (str != null) {
      b3 = str.hashCode();
    } else {
      b3 = 0;
    } 
    str = this.htmlStorage;
    if (str != null) {
      b4 = str.hashCode();
    } else {
      b4 = 0;
    } 
    str = this.metaData;
    if (str != null)
      i = str.hashCode(); 
    return (((b1 * 31 + b2) * 31 + b3) * 31 + b4) * 31 + i;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Link(instanceId=");
    stringBuilder.append(this.instanceId);
    stringBuilder.append(", validationUrl=");
    stringBuilder.append(this.validationUrl);
    stringBuilder.append(", imageStorage=");
    stringBuilder.append(this.imageStorage);
    stringBuilder.append(", htmlStorage=");
    stringBuilder.append(this.htmlStorage);
    stringBuilder.append(", metaData=");
    stringBuilder.append(this.metaData);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/tv_remote1-dex2jar.jar!/com/truenet/android/Link.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */