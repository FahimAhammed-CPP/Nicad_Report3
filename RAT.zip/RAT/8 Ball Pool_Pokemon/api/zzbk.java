package com.android.billingclient.api;

import java.util.List;

public final class zzbk {
  private final List zza;
  
  private final BillingResult zzb;
  
  public zzbk(BillingResult paramBillingResult, List paramList) {
    this.zza = paramList;
    this.zzb = paramBillingResult;
  }
  
  public final BillingResult zza() {
    return this.zzb;
  }
  
  public final List zzb() {
    return this.zza;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzbk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */