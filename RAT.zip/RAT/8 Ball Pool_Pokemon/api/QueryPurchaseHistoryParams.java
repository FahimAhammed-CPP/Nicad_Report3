package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class QueryPurchaseHistoryParams {
  private final String zza;
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final String zza() {
    return this.zza;
  }
  
  public static class Builder {
    private String zza;
    
    private Builder() {}
    
    public QueryPurchaseHistoryParams build() {
      if (this.zza != null)
        return new QueryPurchaseHistoryParams(this, null); 
      throw new IllegalArgumentException(v416f9e89.xbd520268("16157"));
    }
    
    public Builder setProductType(String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\QueryPurchaseHistoryParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */