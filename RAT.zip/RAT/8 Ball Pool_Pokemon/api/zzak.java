package com.android.billingclient.api;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;
import h8800e55c.pc41fcc5f.v416f9e89;

final class zzak extends ResultReceiver {
  zzak(BillingClientImpl paramBillingClientImpl, Handler paramHandler, InAppMessageResponseListener paramInAppMessageResponseListener) {
    super(paramHandler);
  }
  
  public final void onReceiveResult(int paramInt, Bundle paramBundle) {
    this.zza.onInAppMessageResponse(zzb.zze(paramBundle, v416f9e89.xbd520268("15289")));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */