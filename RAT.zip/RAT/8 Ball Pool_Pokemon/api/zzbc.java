package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;

final class zzbc {
  static final BillingResult zzA;
  
  static final BillingResult zza;
  
  static final BillingResult zzb;
  
  static final BillingResult zzc;
  
  static final BillingResult zzd;
  
  static final BillingResult zze;
  
  static final BillingResult zzf;
  
  static final BillingResult zzg;
  
  static final BillingResult zzh;
  
  static final BillingResult zzi;
  
  static final BillingResult zzj;
  
  static final BillingResult zzk;
  
  static final BillingResult zzl;
  
  static final BillingResult zzm;
  
  static final BillingResult zzn;
  
  static final BillingResult zzo;
  
  static final BillingResult zzp;
  
  static final BillingResult zzq;
  
  static final BillingResult zzr;
  
  static final BillingResult zzs;
  
  static final BillingResult zzt;
  
  static final BillingResult zzu;
  
  static final BillingResult zzv;
  
  static final BillingResult zzw;
  
  static final BillingResult zzx;
  
  static final BillingResult zzy;
  
  static final BillingResult zzz;
  
  static {
    BillingResult.Builder builder = BillingResult.newBuilder();
    builder.setResponseCode(3);
    builder.setDebugMessage(v416f9e89.xbd520268("15599"));
    zza = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(3);
    builder.setDebugMessage(v416f9e89.xbd520268("15600"));
    zzb = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(3);
    builder.setDebugMessage(v416f9e89.xbd520268("15601"));
    zzc = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15602"));
    zzd = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15603"));
    zze = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15604"));
    zzf = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15605"));
    zzg = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15606"));
    zzh = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15607"));
    zzi = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(6);
    builder.setDebugMessage(v416f9e89.xbd520268("15608"));
    zzj = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15609"));
    zzk = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(0);
    zzl = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-1);
    builder.setDebugMessage(v416f9e89.xbd520268("15610"));
    zzm = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-3);
    builder.setDebugMessage(v416f9e89.xbd520268("15611"));
    zzn = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15612"));
    zzo = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15613"));
    zzp = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15614"));
    zzq = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15615"));
    zzr = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15616"));
    zzs = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15617"));
    zzt = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15618"));
    zzu = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15619"));
    zzv = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15620"));
    zzw = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15621"));
    zzx = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(5);
    builder.setDebugMessage(v416f9e89.xbd520268("15622"));
    zzy = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15623"));
    zzz = builder.build();
    builder = BillingResult.newBuilder();
    builder.setResponseCode(-2);
    builder.setDebugMessage(v416f9e89.xbd520268("15624"));
    zzA = builder.build();
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzbc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */