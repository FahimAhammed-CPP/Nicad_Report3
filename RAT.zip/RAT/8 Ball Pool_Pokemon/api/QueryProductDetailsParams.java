package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zzu;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.HashSet;
import java.util.List;

public final class QueryProductDetailsParams {
  private final zzu zza;
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final zzu zza() {
    return this.zza;
  }
  
  public final String zzb() {
    return ((Product)this.zza.get(0)).zzb();
  }
  
  public static class Builder {
    private zzu zza;
    
    private Builder() {}
    
    public QueryProductDetailsParams build() {
      return new QueryProductDetailsParams(this, null);
    }
    
    public Builder setProductList(List<QueryProductDetailsParams.Product> param1List) {
      if (param1List != null && !param1List.isEmpty()) {
        HashSet<String> hashSet = new HashSet();
        for (QueryProductDetailsParams.Product product : param1List) {
          String str = product.zzb();
          if (!v416f9e89.xbd520268("16150").equals(str))
            hashSet.add(product.zzb()); 
        } 
        if (hashSet.size() <= 1) {
          this.zza = zzu.zzj(param1List);
          return this;
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("16151"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("16152"));
    }
  }
  
  public static class Product {
    private final String zza;
    
    private final String zzb;
    
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    public final String zza() {
      return this.zza;
    }
    
    public final String zzb() {
      return this.zzb;
    }
    
    public static class Builder {
      private String zza;
      
      private String zzb;
      
      private Builder() {}
      
      public QueryProductDetailsParams.Product build() {
        String str = this.zzb;
        if (!v416f9e89.xbd520268("16153").equals(str)) {
          if (this.zza != null) {
            if (this.zzb != null)
              return new QueryProductDetailsParams.Product(this, null); 
            throw new IllegalArgumentException(v416f9e89.xbd520268("16154"));
          } 
          throw new IllegalArgumentException(v416f9e89.xbd520268("16155"));
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("16156"));
      }
      
      public Builder setProductId(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      public Builder setProductType(String param2String) {
        this.zzb = param2String;
        return this;
      }
    }
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private Builder() {}
    
    public QueryProductDetailsParams.Product build() {
      String str = this.zzb;
      if (!v416f9e89.xbd520268("16153").equals(str)) {
        if (this.zza != null) {
          if (this.zzb != null)
            return new QueryProductDetailsParams.Product(this, null); 
          throw new IllegalArgumentException(v416f9e89.xbd520268("16154"));
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("16155"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("16156"));
    }
    
    public Builder setProductId(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    public Builder setProductType(String param1String) {
      this.zzb = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\QueryProductDetailsParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */