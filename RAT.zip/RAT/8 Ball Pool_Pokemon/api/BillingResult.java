package com.android.billingclient.api;

import com.google.android.gms.internal.play_billing.zzb;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class BillingResult {
  private int zza;
  
  private String zzb;
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public String getDebugMessage() {
    return this.zzb;
  }
  
  public int getResponseCode() {
    return this.zza;
  }
  
  public String toString() {
    String str1 = zzb.zzg(this.zza);
    String str2 = this.zzb;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("15791"));
    stringBuilder.append(str1);
    stringBuilder.append(v416f9e89.xbd520268("15792"));
    stringBuilder.append(str2);
    return stringBuilder.toString();
  }
  
  public static class Builder {
    private int zza;
    
    private String zzb = v416f9e89.xbd520268("15789");
    
    private Builder() {}
    
    public BillingResult build() {
      BillingResult billingResult = new BillingResult();
      BillingResult.zzb(billingResult, this.zza);
      BillingResult.zza(billingResult, this.zzb);
      return billingResult;
    }
    
    public Builder setDebugMessage(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setResponseCode(int param1Int) {
      this.zza = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\BillingResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */