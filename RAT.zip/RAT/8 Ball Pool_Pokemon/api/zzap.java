package com.android.billingclient.api;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzd;
import com.google.android.gms.internal.play_billing.zzfv;
import h8800e55c.pc41fcc5f.v416f9e89;

final class zzap implements ServiceConnection {
  private final Object zzb = new Object();
  
  private boolean zzc = false;
  
  private BillingClientStateListener zzd;
  
  private final void zzd(BillingResult paramBillingResult) {
    synchronized (this.zzb) {
      BillingClientStateListener billingClientStateListener = this.zzd;
      if (billingClientStateListener != null)
        billingClientStateListener.onBillingSetupFinished(paramBillingResult); 
      return;
    } 
  }
  
  public final void onServiceConnected(ComponentName paramComponentName, IBinder paramIBinder) {
    zzb.zzi(v416f9e89.xbd520268("15348"), v416f9e89.xbd520268("15349"));
    BillingClientImpl.zzD(this.zza, zzd.zzo(paramIBinder));
    BillingClientImpl billingClientImpl = this.zza;
    if (BillingClientImpl.zzp(billingClientImpl, new zzam(this), 30000L, new zzan(this), BillingClientImpl.zzf(billingClientImpl)) == null)
      zzd(BillingClientImpl.zzh(this.zza)); 
  }
  
  public final void onServiceDisconnected(ComponentName paramComponentName) {
    zzb.zzj(v416f9e89.xbd520268("15350"), v416f9e89.xbd520268("15351"));
    int i = zzfv.zzb;
    BillingClientImpl.zzD(this.zza, null);
    BillingClientImpl.zzq(this.zza, 0);
    synchronized (this.zzb) {
      BillingClientStateListener billingClientStateListener = this.zzd;
      if (billingClientStateListener != null)
        billingClientStateListener.onBillingServiceDisconnected(); 
      return;
    } 
  }
  
  final void zzc() {
    synchronized (this.zzb) {
      this.zzd = null;
      this.zzc = true;
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */