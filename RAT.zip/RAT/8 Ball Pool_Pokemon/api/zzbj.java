package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;
import org.json.JSONException;
import org.json.JSONObject;

public final class zzbj {
  zzbj(JSONObject paramJSONObject) throws JSONException {
    paramJSONObject.getInt(v416f9e89.xbd520268("15654"));
    paramJSONObject.getInt(v416f9e89.xbd520268("15655"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzbj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */