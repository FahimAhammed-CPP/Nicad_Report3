package com.android.billingclient.api;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.text.TextUtils;
import android.view.View;
import androidx.core.app.BundleCompat;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zze;
import com.google.android.gms.internal.play_billing.zzfl;
import com.google.android.gms.internal.play_billing.zzfm;
import com.google.android.gms.internal.play_billing.zzg;
import com.google.android.gms.internal.play_billing.zzu;
import com.google.android.gms.internal.play_billing.zzz;
import h8800e55c.pc41fcc5f.v416f9e89;
import h8800e55c.x78d2f21c.y0bc38925;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.json.JSONException;

class BillingClientImpl extends BillingClient {
  private volatile int zza = 0;
  
  private final String zzb;
  
  private final Handler zzc = new Handler(Looper.getMainLooper());
  
  private volatile zzo zzd;
  
  private Context zze;
  
  private volatile zze zzf;
  
  private volatile zzap zzg;
  
  private boolean zzh;
  
  private boolean zzi;
  
  private int zzj = 0;
  
  private boolean zzk;
  
  private boolean zzl;
  
  private boolean zzm;
  
  private boolean zzn;
  
  private boolean zzo;
  
  private boolean zzp;
  
  private boolean zzq;
  
  private boolean zzr;
  
  private boolean zzs;
  
  private boolean zzt;
  
  private boolean zzu;
  
  private boolean zzv;
  
  private boolean zzw;
  
  private boolean zzx;
  
  private ExecutorService zzy;
  
  private zzbh zzz;
  
  private BillingClientImpl(Activity paramActivity, boolean paramBoolean1, boolean paramBoolean2, String paramString) {
    this(paramActivity.getApplicationContext(), paramBoolean1, paramBoolean2, new zzat(), paramString, null, null);
  }
  
  private BillingClientImpl(Context paramContext, boolean paramBoolean1, boolean paramBoolean2, PurchasesUpdatedListener paramPurchasesUpdatedListener, String paramString1, String paramString2, AlternativeBillingListener paramAlternativeBillingListener) {
    this.zzb = paramString1;
    initialize(paramContext, paramPurchasesUpdatedListener, paramBoolean1, paramBoolean2, paramAlternativeBillingListener, paramString1);
  }
  
  private BillingClientImpl(String paramString) {
    this.zzb = paramString;
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean, Context paramContext, zzbf paramzzbf) {
    this.zzb = zzK();
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzu();
    zzfl.zzj(zzK());
    zzfl.zzi(this.zze.getPackageName());
    zzfm zzfm = (zzfm)zzfl.zzc();
    this.zzz = new zzbh();
    zzb.zzj(v416f9e89.xbd520268("15400"), v416f9e89.xbd520268("15401"));
    this.zzd = new zzo(this.zze, null, this.zzz);
    this.zzv = paramBoolean;
  }
  
  BillingClientImpl(String paramString, boolean paramBoolean1, boolean paramBoolean2, Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, AlternativeBillingListener paramAlternativeBillingListener) {
    this(paramContext, paramBoolean1, false, paramPurchasesUpdatedListener, zzK(), null, paramAlternativeBillingListener);
  }
  
  private void initialize(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, boolean paramBoolean1, boolean paramBoolean2, AlternativeBillingListener paramAlternativeBillingListener, String paramString) {
    this.zze = paramContext.getApplicationContext();
    zzfl zzfl = zzfm.zzu();
    zzfl.zzj(paramString);
    zzfl.zzi(this.zze.getPackageName());
    zzfm zzfm = (zzfm)zzfl.zzc();
    this.zzz = new zzbh();
    if (paramPurchasesUpdatedListener == null)
      zzb.zzj(v416f9e89.xbd520268("15402"), v416f9e89.xbd520268("15403")); 
    this.zzd = new zzo(this.zze, paramPurchasesUpdatedListener, paramAlternativeBillingListener, this.zzz);
    this.zzv = paramBoolean1;
    this.zzw = paramBoolean2;
    if (paramAlternativeBillingListener != null) {
      paramBoolean1 = true;
    } else {
      paramBoolean1 = false;
    } 
    this.zzx = paramBoolean1;
  }
  
  private int launchBillingFlowCpp(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    return launchBillingFlow(paramActivity, paramBillingFlowParams).getResponseCode();
  }
  
  private void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, long paramLong) {
    launchPriceChangeConfirmationFlow(paramActivity, paramPriceChangeFlowParams, new zzat(paramLong));
  }
  
  private void startConnection(long paramLong) {
    zzat zzat = new zzat(paramLong);
    if (isReady()) {
      zzb.zzi("BillingClient", v416f9e89.xbd520268("15404"));
      zzat.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzj("BillingClient", v416f9e89.xbd520268("15405"));
      zzat.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzj("BillingClient", v416f9e89.xbd520268("15406"));
      zzat.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzi("BillingClient", v416f9e89.xbd520268("15407"));
    this.zzg = new zzap(this, zzat, null);
    Intent intent = new Intent(v416f9e89.xbd520268("15408"));
    String str = v416f9e89.xbd520268("15409");
    intent.setPackage(str);
    List<ResolveInfo> list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str1 = resolveInfo.serviceInfo.packageName;
        String str2 = resolveInfo.serviceInfo.name;
        if (str.equals(str1) && str2 != null) {
          ComponentName componentName = new ComponentName(str1, str2);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          String str3 = this.zzb;
          intent.putExtra(v416f9e89.xbd520268("15410"), str3);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzi("BillingClient", v416f9e89.xbd520268("15411"));
            return;
          } 
          zzb.zzj("BillingClient", v416f9e89.xbd520268("15412"));
        } else {
          zzb.zzj("BillingClient", v416f9e89.xbd520268("15413"));
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzi("BillingClient", v416f9e89.xbd520268("15414"));
    zzat.onBillingSetupFinished(zzbc.zzc);
  }
  
  private final Handler zzH() {
    return (Looper.myLooper() == null) ? this.zzc : new Handler(Looper.myLooper());
  }
  
  private final BillingResult zzI(BillingResult paramBillingResult) {
    if (Thread.interrupted())
      return paramBillingResult; 
    this.zzc.post(new zzag(this, paramBillingResult));
    return paramBillingResult;
  }
  
  private final BillingResult zzJ() {
    return (this.zza == 0 || this.zza == 3) ? zzbc.zzm : zzbc.zzj;
  }
  
  private static String zzK() {
    try {
      return (String)y0bc38925.classForName(v416f9e89.xbd520268("15415")).getField(v416f9e89.xbd520268("15416")).get(null);
    } catch (Exception exception) {
      return v416f9e89.xbd520268("15417");
    } 
  }
  
  private final Future zzL(Callable<?> paramCallable, long paramLong, Runnable paramRunnable, Handler paramHandler) {
    if (this.zzy == null)
      this.zzy = Executors.newFixedThreadPool(zzb.zza, new zzal(this)); 
    try {
      Future<?> future = this.zzy.submit(paramCallable);
      double d = paramLong;
      paramHandler.postDelayed(new zzaf(future, paramRunnable), (long)(d * 0.95D));
      return future;
    } catch (Exception exception) {
      zzb.zzk(v416f9e89.xbd520268("15418"), v416f9e89.xbd520268("15419"), exception);
      return null;
    } 
  }
  
  private final void zzM(BillingResult paramBillingResult, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    if (Thread.interrupted())
      return; 
    this.zzc.post(new zzx(paramPriceChangeConfirmationListener, paramBillingResult));
  }
  
  private final void zzN(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    if (!isReady()) {
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzbc.zzm, null);
      return;
    } 
    if (zzL(new zzaj(this, paramString, paramPurchaseHistoryResponseListener), 30000L, new zzw(paramPurchaseHistoryResponseListener), zzH()) == null)
      paramPurchaseHistoryResponseListener.onPurchaseHistoryResponse(zzJ(), null); 
  }
  
  private final void zzO(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    if (!isReady()) {
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzm, (List<Purchase>)zzu.zzk());
      return;
    } 
    if (TextUtils.isEmpty(paramString)) {
      zzb.zzj(v416f9e89.xbd520268("15420"), v416f9e89.xbd520268("15421"));
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzbc.zzg, (List<Purchase>)zzu.zzk());
      return;
    } 
    if (zzL(new zzai(this, paramString, paramPurchasesResponseListener), 30000L, new zzad(paramPurchasesResponseListener), zzH()) == null)
      paramPurchasesResponseListener.onQueryPurchasesResponse(zzJ(), (List<Purchase>)zzu.zzk()); 
  }
  
  private final boolean zzP() {
    return (this.zzu && this.zzw);
  }
  
  public final void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener) {
    if (!isReady()) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzm);
      return;
    } 
    if (TextUtils.isEmpty(paramAcknowledgePurchaseParams.getPurchaseToken())) {
      zzb.zzj(v416f9e89.xbd520268("15447"), v416f9e89.xbd520268("15448"));
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzi);
      return;
    } 
    if (!this.zzm) {
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzbc.zzb);
      return;
    } 
    if (zzL(new zzz(this, paramAcknowledgePurchaseParams, paramAcknowledgePurchaseResponseListener), 30000L, new zzaa(paramAcknowledgePurchaseResponseListener), zzH()) == null)
      paramAcknowledgePurchaseResponseListener.onAcknowledgePurchaseResponse(zzJ()); 
  }
  
  public final void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener) {
    if (!isReady()) {
      paramConsumeResponseListener.onConsumeResponse(zzbc.zzm, paramConsumeParams.getPurchaseToken());
      return;
    } 
    if (zzL(new zzu(this, paramConsumeParams, paramConsumeResponseListener), 30000L, new zzv(paramConsumeResponseListener, paramConsumeParams), zzH()) == null)
      paramConsumeResponseListener.onConsumeResponse(zzJ(), paramConsumeParams.getPurchaseToken()); 
  }
  
  public final void endConnection() {
    String str = v416f9e89.xbd520268("15449");
    try {
      this.zzd.zzd();
      if (this.zzg != null)
        this.zzg.zzc(); 
      if (this.zzg != null && this.zzf != null) {
        zzb.zzi(str, v416f9e89.xbd520268("15450"));
        this.zze.unbindService(this.zzg);
        this.zzg = null;
      } 
      this.zzf = null;
      ExecutorService executorService = this.zzy;
      if (executorService != null) {
        executorService.shutdownNow();
        this.zzy = null;
      } 
      this.zza = 3;
      return;
    } catch (Exception exception) {
      zzb.zzk(str, v416f9e89.xbd520268("15451"), exception);
      this.zza = 3;
      return;
    } finally {}
    this.zza = 3;
    throw str;
  }
  
  public final int getConnectionState() {
    return this.zza;
  }
  
  public final BillingResult isFeatureSupported(String paramString) {
    byte b;
    if (!isReady())
      return zzbc.zzm; 
    switch (paramString.hashCode()) {
      default:
        b = -1;
        break;
      case 1987365622:
        if (paramString.equals(v416f9e89.xbd520268("15452"))) {
          b = 0;
          break;
        } 
      case 207616302:
        if (paramString.equals(v416f9e89.xbd520268("15453"))) {
          b = 2;
          break;
        } 
      case 103272:
        if (paramString.equals(v416f9e89.xbd520268("15454"))) {
          b = 10;
          break;
        } 
      case 102279:
        if (paramString.equals(v416f9e89.xbd520268("15455"))) {
          b = 9;
          break;
        } 
      case 101286:
        if (paramString.equals(v416f9e89.xbd520268("15456"))) {
          b = 8;
          break;
        } 
      case 100293:
        if (paramString.equals(v416f9e89.xbd520268("15457"))) {
          b = 7;
          break;
        } 
      case 99300:
        if (paramString.equals(v416f9e89.xbd520268("15458"))) {
          b = 5;
          break;
        } 
      case 98307:
        if (paramString.equals(v416f9e89.xbd520268("15459"))) {
          b = 6;
          break;
        } 
      case 97314:
        if (paramString.equals(v416f9e89.xbd520268("15460"))) {
          b = 3;
          break;
        } 
      case 96321:
        if (paramString.equals(v416f9e89.xbd520268("15461"))) {
          b = 4;
          break;
        } 
      case -422092961:
        if (paramString.equals(v416f9e89.xbd520268("15462"))) {
          b = 1;
          break;
        } 
    } 
    switch (b) {
      default:
        paramString = String.valueOf(paramString);
        paramString = v416f9e89.xbd520268("15463").concat(paramString);
        zzb.zzj(v416f9e89.xbd520268("15464"), paramString);
        return zzbc.zzy;
      case 10:
        return this.zzt ? zzbc.zzl : zzbc.zzA;
      case 9:
        return this.zzt ? zzbc.zzl : zzbc.zzz;
      case 8:
        return this.zzs ? zzbc.zzl : zzbc.zzv;
      case 6:
      case 7:
        return this.zzr ? zzbc.zzl : zzbc.zzt;
      case 5:
        return this.zzp ? zzbc.zzl : zzbc.zzu;
      case 4:
        return this.zzq ? zzbc.zzl : zzbc.zzs;
      case 3:
        return this.zzo ? zzbc.zzl : zzbc.zzw;
      case 2:
        return this.zzl ? zzbc.zzl : zzbc.zzr;
      case 1:
        return this.zzi ? zzbc.zzl : zzbc.zzp;
      case 0:
        break;
    } 
    return this.zzh ? zzbc.zzl : zzbc.zzo;
  }
  
  public final boolean isReady() {
    return (this.zza == 2 && this.zzf != null && this.zzg != null);
  }
  
  public final BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams) {
    String str1;
    String str2;
    BillingFlowParams.ProductDetailsParams productDetailsParams2;
    Bundle bundle;
    BillingClientImpl billingClientImpl = this;
    String str5 = v416f9e89.xbd520268("15465");
    String str4 = v416f9e89.xbd520268("15466");
    if (!isReady()) {
      zzba.zza(2, 2, zzbc.zzm);
      BillingResult billingResult = zzbc.zzm;
      billingClientImpl.zzI(billingResult);
      return billingResult;
    } 
    ArrayList<SkuDetails> arrayList = paramBillingFlowParams.zzf();
    List<BillingFlowParams.ProductDetailsParams> list = paramBillingFlowParams.zzg();
    SkuDetails skuDetails = (SkuDetails)zzz.zza(arrayList, null);
    BillingFlowParams.ProductDetailsParams productDetailsParams1 = (BillingFlowParams.ProductDetailsParams)zzz.zza(list, null);
    if (skuDetails != null) {
      str1 = skuDetails.getSku();
      str2 = skuDetails.getType();
    } else {
      str1 = productDetailsParams1.zza().getProductId();
      str2 = productDetailsParams1.zza().getProductType();
    } 
    boolean bool = str2.equals(v416f9e89.xbd520268("15467"));
    String str3 = v416f9e89.xbd520268("15468");
    if (!bool || billingClientImpl.zzh) {
      if (!paramBillingFlowParams.zzp() || billingClientImpl.zzk) {
        if (arrayList.size() <= 1 || billingClientImpl.zzr) {
          if (list.isEmpty() || billingClientImpl.zzs) {
            if (billingClientImpl.zzk) {
              SkuDetails skuDetails1;
              bool = billingClientImpl.zzm;
              boolean bool1 = billingClientImpl.zzu;
              boolean bool2 = billingClientImpl.zzv;
              boolean bool3 = billingClientImpl.zzw;
              boolean bool4 = billingClientImpl.zzx;
              String str6 = billingClientImpl.zzb;
              bundle = new Bundle();
              bundle.putString(v416f9e89.xbd520268("15473"), str6);
              if (paramBillingFlowParams.zza() != 0) {
                int i = paramBillingFlowParams.zza();
                bundle.putInt(v416f9e89.xbd520268("15474"), i);
              } 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzb())) {
                str6 = paramBillingFlowParams.zzb();
                bundle.putString(v416f9e89.xbd520268("15475"), str6);
              } 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzc())) {
                str6 = paramBillingFlowParams.zzc();
                bundle.putString(v416f9e89.xbd520268("15476"), str6);
              } 
              if (paramBillingFlowParams.zzo())
                bundle.putBoolean(v416f9e89.xbd520268("15477"), true); 
              if (!TextUtils.isEmpty(null)) {
                ArrayList arrayList1 = new ArrayList(Arrays.asList((Object[])new String[] { null }));
                bundle.putStringArrayList(v416f9e89.xbd520268("15478"), arrayList1);
              } 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zzd())) {
                str6 = paramBillingFlowParams.zzd();
                bundle.putString(v416f9e89.xbd520268("15479"), str6);
              } 
              if (!TextUtils.isEmpty(null))
                bundle.putString(v416f9e89.xbd520268("15480"), null); 
              if (!TextUtils.isEmpty(paramBillingFlowParams.zze())) {
                str6 = paramBillingFlowParams.zze();
                bundle.putString(v416f9e89.xbd520268("15481"), str6);
              } 
              if (!TextUtils.isEmpty(null))
                bundle.putString(v416f9e89.xbd520268("15482"), null); 
              if (bool && bool2)
                bundle.putBoolean(v416f9e89.xbd520268("15483"), true); 
              if (bool1 && bool3)
                bundle.putBoolean(v416f9e89.xbd520268("15484"), true); 
              if (bool4)
                bundle.putBoolean(v416f9e89.xbd520268("15485"), true); 
              bool = arrayList.isEmpty();
              String str9 = v416f9e89.xbd520268("15486");
              String str10 = v416f9e89.xbd520268("15487");
              str6 = v416f9e89.xbd520268("15488");
              String str7 = v416f9e89.xbd520268("15489");
              String str8 = v416f9e89.xbd520268("15490");
              if (!bool) {
                ArrayList<String> arrayList1 = new ArrayList();
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList3 = new ArrayList();
                ArrayList<Integer> arrayList4 = new ArrayList();
                ArrayList<String> arrayList5 = new ArrayList();
                Iterator<SkuDetails> iterator = arrayList.iterator();
                int m = 0;
                int k = 0;
                int j = 0;
                int i = 0;
                while (iterator.hasNext()) {
                  SkuDetails skuDetails2 = iterator.next();
                  if (!skuDetails2.zzf().isEmpty())
                    arrayList1.add(skuDetails2.zzf()); 
                  String str11 = skuDetails2.zzc();
                  String str12 = skuDetails2.zzb();
                  int i1 = skuDetails2.zza();
                  String str13 = skuDetails2.zze();
                  arrayList2.add(str11);
                  m |= TextUtils.isEmpty(str11) ^ true;
                  arrayList3.add(str12);
                  int n = k | TextUtils.isEmpty(str12) ^ true;
                  arrayList4.add(Integer.valueOf(i1));
                  if (i1 != 0) {
                    k = 1;
                  } else {
                    k = 0;
                  } 
                  j |= k;
                  i |= TextUtils.isEmpty(str13) ^ true;
                  arrayList5.add(str13);
                  k = n;
                } 
                if (!arrayList1.isEmpty())
                  bundle.putStringArrayList(str7, arrayList1); 
                if (m != 0)
                  bundle.putStringArrayList(str8, arrayList2); 
                if (k != 0)
                  bundle.putStringArrayList(v416f9e89.xbd520268("15491"), arrayList3); 
                if (j != 0)
                  bundle.putIntegerArrayList(v416f9e89.xbd520268("15492"), arrayList4); 
                if (i != 0)
                  bundle.putStringArrayList(str6, arrayList5); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (arrayList.size() > 1) {
                  ArrayList<String> arrayList6 = new ArrayList(arrayList.size() - 1);
                  ArrayList<String> arrayList7 = new ArrayList(arrayList.size() - 1);
                  for (i = 1; i < arrayList.size(); i++) {
                    arrayList6.add(((SkuDetails)arrayList.get(i)).getSku());
                    arrayList7.add(((SkuDetails)arrayList.get(i)).getType());
                  } 
                  bundle.putStringArrayList(str10, arrayList6);
                  bundle.putStringArrayList(str9, arrayList7);
                  productDetailsParams2 = productDetailsParams1;
                  skuDetails1 = skuDetails;
                } 
              } else {
                arrayList = new ArrayList<SkuDetails>(list.size() - 1);
                ArrayList<String> arrayList1 = new ArrayList(list.size() - 1);
                ArrayList<String> arrayList2 = new ArrayList();
                ArrayList<String> arrayList3 = new ArrayList();
                ArrayList<String> arrayList4 = new ArrayList();
                for (int i = 0; i < list.size(); i++) {
                  BillingFlowParams.ProductDetailsParams productDetailsParams = list.get(i);
                  ProductDetails productDetails = productDetailsParams.zza();
                  if (!productDetails.zzb().isEmpty())
                    arrayList2.add(productDetails.zzb()); 
                  arrayList3.add(productDetailsParams.zzb());
                  if (!TextUtils.isEmpty(productDetails.zzc()))
                    arrayList4.add(productDetails.zzc()); 
                  if (i > 0) {
                    arrayList.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductId());
                    arrayList1.add(((BillingFlowParams.ProductDetailsParams)list.get(i)).zza().getProductType());
                  } 
                } 
                bundle.putStringArrayList(str8, arrayList3);
                if (!arrayList2.isEmpty())
                  bundle.putStringArrayList((String)skuDetails1, arrayList2); 
                if (!arrayList4.isEmpty())
                  bundle.putStringArrayList((String)productDetailsParams2, arrayList4); 
                productDetailsParams2 = productDetailsParams1;
                skuDetails1 = skuDetails;
                if (!arrayList.isEmpty()) {
                  bundle.putStringArrayList(str10, arrayList);
                  bundle.putStringArrayList(str9, arrayList1);
                  skuDetails1 = skuDetails;
                  productDetailsParams2 = productDetailsParams1;
                } 
              } 
              bool = bundle.containsKey(str8);
              BillingClientImpl billingClientImpl1 = this;
              if (!bool || billingClientImpl1.zzp) {
                String str = v416f9e89.xbd520268("15493");
                if (skuDetails1 != null && !TextUtils.isEmpty(skuDetails1.zzd())) {
                  bundle.putString(str, skuDetails1.zzd());
                } else if (productDetailsParams2 != null && !TextUtils.isEmpty(productDetailsParams2.zza().zza())) {
                  bundle.putString(str, productDetailsParams2.zza().zza());
                } else {
                  boolean bool6 = false;
                  if (!TextUtils.isEmpty(null))
                    bundle.putString(v416f9e89.xbd520268("15494"), null); 
                } 
                boolean bool5 = true;
              } else {
                zzba.zza(21, 2, zzbc.zzu);
                BillingResult billingResult = zzbc.zzu;
                billingClientImpl1.zzI(billingResult);
                return billingResult;
              } 
            } else {
              String str = str3;
              Future future = zzL(new zzac((BillingClientImpl)productDetailsParams2, str1, str2), 5000L, null, ((BillingClientImpl)productDetailsParams2).zzc);
              BillingClientImpl billingClientImpl1 = this;
            } 
          } else {
            zzb.zzj(str3, v416f9e89.xbd520268("15472"));
            zzba.zza(20, 2, zzbc.zzv);
            BillingResult billingResult = zzbc.zzv;
            productDetailsParams2.zzI(billingResult);
            return billingResult;
          } 
        } else {
          zzb.zzj(str3, v416f9e89.xbd520268("15471"));
          zzba.zza(19, 2, zzbc.zzt);
          BillingResult billingResult = zzbc.zzt;
          productDetailsParams2.zzI(billingResult);
          return billingResult;
        } 
      } else {
        zzb.zzj(str3, v416f9e89.xbd520268("15470"));
        zzba.zza(18, 2, zzbc.zzh);
        BillingResult billingResult = zzbc.zzh;
        productDetailsParams2.zzI(billingResult);
        return billingResult;
      } 
    } else {
      zzb.zzj(str3, v416f9e89.xbd520268("15469"));
      zzba.zza(9, 2, zzbc.zzo);
      BillingResult billingResult = zzbc.zzo;
      productDetailsParams2.zzI(billingResult);
      return billingResult;
    } 
    if (!TextUtils.isEmpty(null))
      bundle.putString(v416f9e89.xbd520268("15494"), null); 
  }
  
  public void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    String str4 = v416f9e89.xbd520268("15502");
    String str2 = v416f9e89.xbd520268("15503");
    if (!isReady()) {
      zzM(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    String str5 = v416f9e89.xbd520268("15504");
    String str3 = v416f9e89.xbd520268("15505");
    if (paramPriceChangeFlowParams == null || paramPriceChangeFlowParams.getSkuDetails() == null) {
      zzb.zzj(str3, str5);
      zzM(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    String str1 = paramPriceChangeFlowParams.getSkuDetails().getSku();
    if (str1 == null) {
      zzb.zzj(str3, str5);
      zzM(zzbc.zzk, paramPriceChangeConfirmationListener);
      return;
    } 
    if (!this.zzl) {
      zzb.zzj(str3, v416f9e89.xbd520268("15506"));
      zzM(zzbc.zzr, paramPriceChangeConfirmationListener);
      return;
    } 
    Bundle bundle = new Bundle();
    String str6 = this.zzb;
    bundle.putString(v416f9e89.xbd520268("15507"), str6);
    bundle.putBoolean(v416f9e89.xbd520268("15508"), true);
    Future<Bundle> future = zzL(new zzr(this, str1, bundle), 5000L, null, this.zzc);
    try {
      StringBuilder stringBuilder1;
      Bundle bundle1 = future.get(5000L, TimeUnit.MILLISECONDS);
      int i = zzb.zzb(bundle1, str3);
      str6 = zzb.zzf(bundle1, str3);
      BillingResult.Builder builder = BillingResult.newBuilder();
      builder.setResponseCode(i);
      builder.setDebugMessage(str6);
      BillingResult billingResult = builder.build();
      if (i != 0) {
        stringBuilder1 = new StringBuilder();
        stringBuilder1.append(v416f9e89.xbd520268("15509"));
        stringBuilder1.append(i);
        zzb.zzj(str3, stringBuilder1.toString());
        zzM(billingResult, paramPriceChangeConfirmationListener);
        return;
      } 
      zzah zzah = new zzah(this, this.zzc, paramPriceChangeConfirmationListener);
      Intent intent = new Intent((Context)stringBuilder1, ProxyBillingActivity.class);
      intent.putExtra(str4, bundle1.getParcelable(str4));
      intent.putExtra(v416f9e89.xbd520268("15510"), (Parcelable)zzah);
      stringBuilder1.startActivity(intent);
      return;
    } catch (TimeoutException null) {
    
    } catch (CancellationException null) {
    
    } catch (Exception exception) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(v416f9e89.xbd520268("15511"));
      stringBuilder1.append(str1);
      stringBuilder1.append(str2);
      zzb.zzk(str3, stringBuilder1.toString(), exception);
      zzM(zzbc.zzm, paramPriceChangeConfirmationListener);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("15512"));
    stringBuilder.append(str1);
    stringBuilder.append(str2);
    zzb.zzk(str3, stringBuilder.toString(), exception);
    zzM(zzbc.zzn, paramPriceChangeConfirmationListener);
  }
  
  public void queryProductDetailsAsync(QueryProductDetailsParams paramQueryProductDetailsParams, ProductDetailsResponseListener paramProductDetailsResponseListener) {
    if (!isReady()) {
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzm, new ArrayList<ProductDetails>());
      return;
    } 
    if (!this.zzs) {
      zzb.zzj(v416f9e89.xbd520268("15513"), v416f9e89.xbd520268("15514"));
      paramProductDetailsResponseListener.onProductDetailsResponse(zzbc.zzv, new ArrayList<ProductDetails>());
      return;
    } 
    if (zzL(new zzs(this, paramQueryProductDetailsParams, paramProductDetailsResponseListener), 30000L, new zzt(paramProductDetailsResponseListener), zzH()) == null)
      paramProductDetailsResponseListener.onProductDetailsResponse(zzJ(), new ArrayList<ProductDetails>()); 
  }
  
  public void queryPurchaseHistoryAsync(QueryPurchaseHistoryParams paramQueryPurchaseHistoryParams, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzN(paramQueryPurchaseHistoryParams.zza(), paramPurchaseHistoryResponseListener);
  }
  
  public final void queryPurchaseHistoryAsync(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener) {
    zzN(paramString, paramPurchaseHistoryResponseListener);
  }
  
  public void queryPurchasesAsync(QueryPurchasesParams paramQueryPurchasesParams, PurchasesResponseListener paramPurchasesResponseListener) {
    zzO(paramQueryPurchasesParams.zza(), paramPurchasesResponseListener);
  }
  
  public void queryPurchasesAsync(String paramString, PurchasesResponseListener paramPurchasesResponseListener) {
    zzO(paramString, paramPurchasesResponseListener);
  }
  
  public final void querySkuDetailsAsync(SkuDetailsParams paramSkuDetailsParams, SkuDetailsResponseListener paramSkuDetailsResponseListener) {
    ArrayList<zzby> arrayList;
    if (!isReady()) {
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzm, null);
      return;
    } 
    String str2 = paramSkuDetailsParams.getSkuType();
    List<String> list = paramSkuDetailsParams.getSkusList();
    boolean bool = TextUtils.isEmpty(str2);
    String str1 = v416f9e89.xbd520268("15515");
    if (bool) {
      zzb.zzj(str1, v416f9e89.xbd520268("15516"));
      paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zzf, null);
      return;
    } 
    if (list != null) {
      arrayList = new ArrayList();
      for (String str : list) {
        zzbw zzbw = new zzbw(null);
        zzbw.zza(str);
        arrayList.add(zzbw.zzb());
      } 
      if (zzL(new zzq(this, str2, arrayList, null, paramSkuDetailsResponseListener), 30000L, new zzy(paramSkuDetailsResponseListener), zzH()) == null)
        paramSkuDetailsResponseListener.onSkuDetailsResponse(zzJ(), null); 
      return;
    } 
    zzb.zzj((String)arrayList, v416f9e89.xbd520268("15517"));
    paramSkuDetailsResponseListener.onSkuDetailsResponse(zzbc.zze, null);
  }
  
  public BillingResult showInAppMessages(Activity paramActivity, InAppMessageParams paramInAppMessageParams, InAppMessageResponseListener paramInAppMessageResponseListener) {
    boolean bool = isReady();
    String str1 = v416f9e89.xbd520268("15518");
    if (!bool) {
      zzb.zzj(str1, v416f9e89.xbd520268("15519"));
      return zzbc.zzm;
    } 
    if (!this.zzo) {
      zzb.zzj(str1, v416f9e89.xbd520268("15520"));
      return zzbc.zzw;
    } 
    View view = paramActivity.findViewById(16908290);
    IBinder iBinder = view.getWindowToken();
    Rect rect = new Rect();
    view.getGlobalVisibleRect(rect);
    Bundle bundle = new Bundle();
    BundleCompat.putBinder(bundle, v416f9e89.xbd520268("15521"), iBinder);
    int i = rect.left;
    bundle.putInt(v416f9e89.xbd520268("15522"), i);
    i = rect.top;
    bundle.putInt(v416f9e89.xbd520268("15523"), i);
    i = rect.right;
    bundle.putInt(v416f9e89.xbd520268("15524"), i);
    i = rect.bottom;
    bundle.putInt(v416f9e89.xbd520268("15525"), i);
    String str2 = this.zzb;
    bundle.putString(v416f9e89.xbd520268("15526"), str2);
    ArrayList<Integer> arrayList = paramInAppMessageParams.getInAppMessageCategoriesToShow();
    bundle.putIntegerArrayList(v416f9e89.xbd520268("15527"), arrayList);
    zzL(new zzae(this, bundle, paramActivity, new zzak(this, this.zzc, paramInAppMessageResponseListener)), 5000L, null, this.zzc);
    return zzbc.zzl;
  }
  
  public final void startConnection(BillingClientStateListener paramBillingClientStateListener) {
    boolean bool = isReady();
    String str1 = v416f9e89.xbd520268("15528");
    if (bool) {
      zzb.zzi(str1, v416f9e89.xbd520268("15529"));
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzl);
      return;
    } 
    if (this.zza == 1) {
      zzb.zzj(str1, v416f9e89.xbd520268("15530"));
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzd);
      return;
    } 
    if (this.zza == 3) {
      zzb.zzj(str1, v416f9e89.xbd520268("15531"));
      paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzm);
      return;
    } 
    this.zza = 1;
    this.zzd.zze();
    zzb.zzi(str1, v416f9e89.xbd520268("15532"));
    this.zzg = new zzap(this, paramBillingClientStateListener, null);
    Intent intent = new Intent(v416f9e89.xbd520268("15533"));
    String str2 = v416f9e89.xbd520268("15534");
    intent.setPackage(str2);
    List<ResolveInfo> list = this.zze.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ResolveInfo resolveInfo = list.get(0);
      if (resolveInfo.serviceInfo != null) {
        String str3 = resolveInfo.serviceInfo.packageName;
        String str4 = resolveInfo.serviceInfo.name;
        if (str2.equals(str3) && str4 != null) {
          ComponentName componentName = new ComponentName(str3, str4);
          intent = new Intent(intent);
          intent.setComponent(componentName);
          String str = this.zzb;
          intent.putExtra(v416f9e89.xbd520268("15535"), str);
          if (this.zze.bindService(intent, this.zzg, 1)) {
            zzb.zzi(str1, v416f9e89.xbd520268("15536"));
            return;
          } 
          zzb.zzj(str1, v416f9e89.xbd520268("15537"));
        } else {
          zzb.zzj(str1, v416f9e89.xbd520268("15538"));
        } 
      } 
    } 
    this.zza = 0;
    zzb.zzi(str1, v416f9e89.xbd520268("15539"));
    paramBillingClientStateListener.onBillingSetupFinished(zzbc.zzc);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\BillingClientImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */