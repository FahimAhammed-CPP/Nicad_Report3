package com.android.billingclient.api;

import android.text.TextUtils;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class PurchaseHistoryRecord {
  private final String zza;
  
  private final String zzb;
  
  private final JSONObject zzc;
  
  public PurchaseHistoryRecord(String paramString1, String paramString2) throws JSONException {
    this.zza = paramString1;
    this.zzb = paramString2;
    this.zzc = new JSONObject(paramString1);
  }
  
  private final ArrayList zza() {
    ArrayList<String> arrayList = new ArrayList();
    JSONObject jSONObject = this.zzc;
    String str = v416f9e89.xbd520268("16139");
    if (jSONObject.has(str)) {
      JSONArray jSONArray = this.zzc.optJSONArray(str);
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.optString(i));  
    } else {
      jSONObject = this.zzc;
      str = v416f9e89.xbd520268("16140");
      if (jSONObject.has(str))
        arrayList.add(this.zzc.optString(str)); 
    } 
    return arrayList;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PurchaseHistoryRecord))
      return false; 
    paramObject = paramObject;
    return (TextUtils.equals(this.zza, paramObject.getOriginalJson()) && TextUtils.equals(this.zzb, paramObject.getSignature()));
  }
  
  public String getDeveloperPayload() {
    return this.zzc.optString(v416f9e89.xbd520268("16141"));
  }
  
  public String getOriginalJson() {
    return this.zza;
  }
  
  public List<String> getProducts() {
    return zza();
  }
  
  public long getPurchaseTime() {
    return this.zzc.optLong(v416f9e89.xbd520268("16142"));
  }
  
  public String getPurchaseToken() {
    JSONObject jSONObject = this.zzc;
    String str = jSONObject.optString(v416f9e89.xbd520268("16143"));
    return jSONObject.optString(v416f9e89.xbd520268("16144"), str);
  }
  
  public int getQuantity() {
    return this.zzc.optInt(v416f9e89.xbd520268("16145"), 1);
  }
  
  public String getSignature() {
    return this.zzb;
  }
  
  @Deprecated
  public ArrayList<String> getSkus() {
    return zza();
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  public String toString() {
    String str = String.valueOf(this.zza);
    return v416f9e89.xbd520268("16146").concat(str);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\PurchaseHistoryRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */