package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AlternativeChoiceDetails {
  private final String zza;
  
  private final JSONObject zzb;
  
  private final List zzc;
  
  AlternativeChoiceDetails(String paramString) throws JSONException {
    this.zza = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.zzb = jSONObject;
    JSONArray jSONArray = jSONObject.optJSONArray(v416f9e89.xbd520268("15286"));
    ArrayList<Product> arrayList = new ArrayList();
    if (jSONArray != null)
      for (int i = 0; i < jSONArray.length(); i++) {
        JSONObject jSONObject1 = jSONArray.optJSONObject(i);
        if (jSONObject1 != null)
          arrayList.add(new Product(jSONObject1, null)); 
      }  
    this.zzc = arrayList;
  }
  
  public String getExternalTransactionToken() {
    return this.zzb.optString(v416f9e89.xbd520268("15287"));
  }
  
  public String getOriginalExternalTransactionId() {
    String str2 = this.zzb.optString(v416f9e89.xbd520268("15288"));
    String str1 = str2;
    if (str2.isEmpty())
      str1 = null; 
    return str1;
  }
  
  public List<Product> getProducts() {
    return this.zzc;
  }
  
  public static class Product {
    private final String zza;
    
    private final String zzb;
    
    private final String zzc;
    
    public final boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Product))
        return false; 
      Product product = (Product)param1Object;
      if (this.zza.equals(product.getId()) && this.zzb.equals(product.getType())) {
        param1Object = this.zzc;
        String str = product.getOfferToken();
        if (param1Object == str || (param1Object != null && param1Object.equals(str)))
          return true; 
      } 
      return false;
    }
    
    public String getId() {
      return this.zza;
    }
    
    public String getOfferToken() {
      return this.zzc;
    }
    
    public String getType() {
      return this.zzb;
    }
    
    public final int hashCode() {
      return Arrays.hashCode(new Object[] { this.zza, this.zzb, this.zzc });
    }
    
    public final String toString() {
      String str1 = this.zza;
      String str2 = this.zzb;
      String str3 = this.zzc;
      return String.format(v416f9e89.xbd520268("15285"), new Object[] { str1, str2, str3 });
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\AlternativeChoiceDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */