package com.android.billingclient.api;

import android.content.Context;
import android.content.IntentFilter;
import h8800e55c.pc41fcc5f.v416f9e89;

final class zzo {
  private final Context zza;
  
  private final zzn zzb;
  
  zzo(Context paramContext, PurchasesUpdatedListener paramPurchasesUpdatedListener, AlternativeBillingListener paramAlternativeBillingListener, zzbh paramzzbh) {
    this.zza = paramContext;
    this.zzb = new zzn(this, paramPurchasesUpdatedListener, paramAlternativeBillingListener, paramzzbh, null);
  }
  
  zzo(Context paramContext, zzbf paramzzbf, zzbh paramzzbh) {
    this.zza = paramContext;
    this.zzb = new zzn(this, null, paramzzbh, null);
  }
  
  final zzbf zzb() {
    zzn.zza(this.zzb);
    return null;
  }
  
  final PurchasesUpdatedListener zzc() {
    return zzn.zzb(this.zzb);
  }
  
  final void zzd() {
    this.zzb.zzd(this.zza);
  }
  
  final void zze() {
    IntentFilter intentFilter = new IntentFilter(v416f9e89.xbd520268("15308"));
    intentFilter.addAction(v416f9e89.xbd520268("15309"));
    this.zzb.zzc(this.zza, intentFilter);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */