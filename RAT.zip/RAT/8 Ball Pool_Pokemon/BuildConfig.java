package com.android.billingclient;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class BuildConfig {
  public static final String APPLICATION_ID = v416f9e89.xbd520268("15246");
  
  public static final String VERSION_NAME = v416f9e89.xbd520268("15247");
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */