package com.baidu.location;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

class a implements b {
  private static String kD;
  
  private static Boolean kE;
  
  private static char kF;
  
  private static String kG;
  
  private static SimpleDateFormat kH;
  
  private static int kI;
  
  private static Boolean kJ = Boolean.valueOf(true);
  
  private static SimpleDateFormat kK;
  
  static {
    kE = Boolean.valueOf(true);
    kF = (char)'v';
    kG = "/sdcard/baidu";
    kI = 0;
    kD = "LocLog.txt";
    kK = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    kH = new SimpleDateFormat("yyyy-MM-dd");
  }
  
  public static void byte(String paramString1, String paramString2) {
    if(paramString1, paramString2, 'w');
  }
  
  public static void cL() {
    String str = kH.format(cM());
    File file = new File(kG, str + kD);
    if (file.exists())
      file.delete(); 
  }
  
  private static Date cM() {
    Date date = new Date();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(5, calendar.get(5) - kI);
    return calendar.getTime();
  }
  
  public static void case(String paramString1, String paramString2) {
    if(paramString1, paramString2, 'i');
  }
  
  public static void char(String paramString1, String paramString2) {
    if(paramString1, paramString2, 'v');
  }
  
  public static void do(String paramString, Object paramObject) {
    if(paramString, paramObject.toString(), 'i');
  }
  
  public static void else(String paramString1, String paramString2) {
    if(paramString1, paramString2, 'e');
  }
  
  public static void for(String paramString, Object paramObject) {
    if(paramString, paramObject.toString(), 'v');
  }
  
  public static void if(String paramString, Object paramObject) {
    if(paramString, paramObject.toString(), 'w');
  }
  
  private static void if(String paramString1, String paramString2, char paramChar) {}
  
  public static void int(String paramString, Object paramObject) {
    if(paramString, paramObject.toString(), 'e');
  }
  
  private static void int(String paramString1, String paramString2, String paramString3) {
    Date date = new Date();
    String str = kH.format(date);
    paramString1 = kK.format(date) + "    " + paramString1 + "    " + paramString2 + "    " + paramString3;
    File file = new File(kG, str + kD);
    try {
      FileWriter fileWriter = new FileWriter();
      this(file, true);
      BufferedWriter bufferedWriter = new BufferedWriter();
      this(fileWriter);
      bufferedWriter.write(paramString1);
      bufferedWriter.newLine();
      bufferedWriter.close();
      fileWriter.close();
    } catch (IOException iOException) {}
  }
  
  public static void new(String paramString, Object paramObject) {
    if(paramString, paramObject.toString(), 'd');
  }
  
  public static void try(String paramString1, String paramString2) {
    if(paramString1, paramString2, 'd');
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */