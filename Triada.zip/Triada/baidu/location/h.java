package com.baidu.location;

import android.location.Location;

class h implements au, b {
  private static h kx = null;
  
  long kA = 0L;
  
  double kB = 0.0D;
  
  double kt = 0.0D;
  
  double ku = 0.0D;
  
  boolean kv = false;
  
  volatile int kw = -1;
  
  double ky = 0.0D;
  
  int kz = -1;
  
  public static h cK() {
    if (kx == null)
      kx = new h(); 
    return kx;
  }
  
  public void byte(BDLocation paramBDLocation) {
    if (this.kv && System.currentTimeMillis() - this.kA <= 4000L && paramBDLocation != null && paramBDLocation.getLocType() == 161 && ("wf".equals(paramBDLocation.getNetworkLocationType()) || paramBDLocation.getRadius() < 300.0F)) {
      this.kt = paramBDLocation.getLongitude();
      this.ku = paramBDLocation.getLatitude();
      float[] arrayOfFloat = new float[1];
      Location.distanceBetween(this.ky, this.kB, this.ku, this.kt, arrayOfFloat);
      this.kw = (int)arrayOfFloat[0];
      this.kv = false;
    } 
  }
  
  public String cJ() {
    boolean bool1 = true;
    if (this.kz < 0 && this.kw < 0)
      return null; 
    null = new StringBuffer(128);
    boolean bool2 = false;
    if (this.kz >= 0) {
      null.append("&osr=");
      null.append(this.kz);
      this.kz = -1;
      bool2 = true;
    } 
    if (this.kw >= 0) {
      null.append("&oac=");
      null.append(this.kw);
      this.kw = -2;
      bool2 = bool1;
    } 
    return bool2 ? null.toString() : null;
  }
  
  public void if(boolean paramBoolean1, boolean paramBoolean2, double paramDouble1, double paramDouble2) {
    if (this.kz < 0)
      this.kz = 0; 
    if (paramBoolean1)
      this.kz |= 0x1; 
    if (paramBoolean2) {
      this.kz |= 0x2;
      this.kB = paramDouble1;
      this.ky = paramDouble2;
      this.kv = true;
      this.kA = System.currentTimeMillis();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */