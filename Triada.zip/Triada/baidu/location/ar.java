package com.baidu.location;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.baidu.location.b.a.a;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

class ar implements au, l {
  private static final String h = "GeofenceMan";
  
  private static final String hJ = "GeofenceMan";
  
  private static final int hK = 3;
  
  public static final int hL = 10;
  
  private static final String hM = "http://loc.map.baidu.com/fence";
  
  private static final String hN = "geofence_id";
  
  private static final String hO = ";";
  
  private static final String hQ = "status_code";
  
  private static ar hR;
  
  private static final int hT = 5;
  
  private static final int hU = 2;
  
  private static final int hV = 1;
  
  private static final String hX = "geofence_ids";
  
  private Context hI;
  
  private Object hP = new Object();
  
  private HandlerThread hS;
  
  private a hW;
  
  private String bN() {
    Context context1 = this.hI;
    String str = LocationClient.PREF_FILE_NAME;
    Context context2 = this.hI;
    return context1.getSharedPreferences(str, 0).getString(LocationClient.PREF_KEY_NAME, null);
  }
  
  private void bP() {
    this.hS = new HandlerThread("GeofenceMan", 10);
    this.hS.start();
    this.hW = new a(this, this.hS.getLooper());
  }
  
  private void bQ() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hI : Landroid/content/Context;
    //   6: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   9: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   12: astore_1
    //   13: aload_1
    //   14: ifnull -> 112
    //   17: aload_1
    //   18: invokevirtual beginTransaction : ()V
    //   21: invokestatic currentTimeMillis : ()J
    //   24: lstore_2
    //   25: aload_1
    //   26: ldc 'DELETE FROM %s WHERE EXISTS (SELECT * FROM %s WHERE (%s + %s) < %d)'
    //   28: iconst_5
    //   29: anewarray java/lang/Object
    //   32: dup
    //   33: iconst_0
    //   34: ldc 'geofence_detail'
    //   36: aastore
    //   37: dup
    //   38: iconst_1
    //   39: ldc 'geofence'
    //   41: aastore
    //   42: dup
    //   43: iconst_2
    //   44: ldc 'valid_date'
    //   46: aastore
    //   47: dup
    //   48: iconst_3
    //   49: ldc 'duration_millis'
    //   51: aastore
    //   52: dup
    //   53: iconst_4
    //   54: lload_2
    //   55: invokestatic valueOf : (J)Ljava/lang/Long;
    //   58: aastore
    //   59: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   62: invokevirtual execSQL : (Ljava/lang/String;)V
    //   65: aload_1
    //   66: ldc 'DELETE FROM %s WHERE (%s + %s) < %d'
    //   68: iconst_4
    //   69: anewarray java/lang/Object
    //   72: dup
    //   73: iconst_0
    //   74: ldc 'geofence'
    //   76: aastore
    //   77: dup
    //   78: iconst_1
    //   79: ldc 'valid_date'
    //   81: aastore
    //   82: dup
    //   83: iconst_2
    //   84: ldc 'duration_millis'
    //   86: aastore
    //   87: dup
    //   88: iconst_3
    //   89: lload_2
    //   90: invokestatic valueOf : (J)Ljava/lang/Long;
    //   93: aastore
    //   94: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   97: invokevirtual execSQL : (Ljava/lang/String;)V
    //   100: aload_1
    //   101: invokevirtual setTransactionSuccessful : ()V
    //   104: aload_1
    //   105: invokevirtual endTransaction : ()V
    //   108: aload_1
    //   109: invokevirtual close : ()V
    //   112: aload_0
    //   113: monitorexit
    //   114: return
    //   115: astore #4
    //   117: aload_1
    //   118: invokevirtual endTransaction : ()V
    //   121: aload_1
    //   122: invokevirtual close : ()V
    //   125: goto -> 112
    //   128: astore_1
    //   129: aload_0
    //   130: monitorexit
    //   131: aload_1
    //   132: athrow
    //   133: astore #4
    //   135: aload_1
    //   136: invokevirtual endTransaction : ()V
    //   139: aload_1
    //   140: invokevirtual close : ()V
    //   143: aload #4
    //   145: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	128	finally
    //   17	21	128	finally
    //   21	104	115	java/lang/Exception
    //   21	104	133	finally
    //   104	112	128	finally
    //   117	125	128	finally
    //   135	146	128	finally
  }
  
  private void bR() {
    this.hW.sendEmptyMessage(3);
  }
  
  private final void bS() {
    if (!q.if(this.hI))
      throw new IllegalStateException("Not net connection"); 
  }
  
  private long bT() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: lconst_0
    //   3: lstore_1
    //   4: lload_1
    //   5: lstore_3
    //   6: aload_0
    //   7: getfield hI : Landroid/content/Context;
    //   10: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   13: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   16: astore #5
    //   18: lload_1
    //   19: lstore_3
    //   20: aload #5
    //   22: ifnull -> 44
    //   25: lload_1
    //   26: lstore_3
    //   27: aload #5
    //   29: ldc 'geofence'
    //   31: invokestatic queryNumEntries : (Landroid/database/sqlite/SQLiteDatabase;Ljava/lang/String;)J
    //   34: lstore_1
    //   35: lload_1
    //   36: lstore_3
    //   37: aload #5
    //   39: invokevirtual close : ()V
    //   42: lload_1
    //   43: lstore_3
    //   44: aload_0
    //   45: monitorexit
    //   46: lload_3
    //   47: lreturn
    //   48: astore #5
    //   50: aload_0
    //   51: monitorexit
    //   52: aload #5
    //   54: athrow
    //   55: astore #5
    //   57: goto -> 44
    // Exception table:
    //   from	to	target	type
    //   6	18	55	java/lang/Exception
    //   6	18	48	finally
    //   27	35	55	java/lang/Exception
    //   27	35	48	finally
    //   37	42	55	java/lang/Exception
    //   37	42	48	finally
  }
  
  public static int do(Context paramContext) {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getSubscriberId();
    if (str != null) {
      if (str.startsWith("46000") || str.startsWith("46002") || str.startsWith("46007"))
        return 1; 
      if (str.startsWith("46001"))
        return 2; 
      if (str.startsWith("46003"))
        return 3; 
    } 
    return 5;
  }
  
  private int do(List paramList) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hI : Landroid/content/Context;
    //   6: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   9: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   12: astore_2
    //   13: aload_2
    //   14: ifnull -> 150
    //   17: aload_2
    //   18: invokevirtual beginTransaction : ()V
    //   21: aload_1
    //   22: invokeinterface iterator : ()Ljava/util/Iterator;
    //   27: astore_3
    //   28: aload_3
    //   29: invokeinterface hasNext : ()Z
    //   34: ifeq -> 124
    //   37: aload_3
    //   38: invokeinterface next : ()Ljava/lang/Object;
    //   43: checkcast java/lang/String
    //   46: astore_1
    //   47: iconst_1
    //   48: anewarray java/lang/String
    //   51: astore #4
    //   53: aload #4
    //   55: iconst_0
    //   56: aload_1
    //   57: aastore
    //   58: aload_2
    //   59: ldc 'geofence'
    //   61: ldc '%s=?'
    //   63: iconst_1
    //   64: anewarray java/lang/Object
    //   67: dup
    //   68: iconst_0
    //   69: ldc 'geofence_id'
    //   71: aastore
    //   72: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   75: aload #4
    //   77: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   80: pop
    //   81: aload_2
    //   82: ldc 'geofence_detail'
    //   84: ldc '%s=?'
    //   86: iconst_1
    //   87: anewarray java/lang/Object
    //   90: dup
    //   91: iconst_0
    //   92: ldc 'geofence_id'
    //   94: aastore
    //   95: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   98: aload #4
    //   100: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   103: pop
    //   104: goto -> 28
    //   107: astore_1
    //   108: aload_2
    //   109: invokevirtual endTransaction : ()V
    //   112: iconst_1
    //   113: istore #5
    //   115: aload_2
    //   116: invokevirtual close : ()V
    //   119: aload_0
    //   120: monitorexit
    //   121: iload #5
    //   123: ireturn
    //   124: aload_2
    //   125: invokevirtual setTransactionSuccessful : ()V
    //   128: aload_2
    //   129: invokevirtual endTransaction : ()V
    //   132: iconst_0
    //   133: istore #5
    //   135: goto -> 115
    //   138: astore_1
    //   139: aload_2
    //   140: invokevirtual endTransaction : ()V
    //   143: aload_1
    //   144: athrow
    //   145: astore_1
    //   146: aload_0
    //   147: monitorexit
    //   148: aload_1
    //   149: athrow
    //   150: iconst_0
    //   151: istore #5
    //   153: goto -> 119
    // Exception table:
    //   from	to	target	type
    //   2	13	145	finally
    //   17	21	145	finally
    //   21	28	107	java/lang/Exception
    //   21	28	138	finally
    //   28	53	107	java/lang/Exception
    //   28	53	138	finally
    //   58	104	107	java/lang/Exception
    //   58	104	138	finally
    //   108	112	145	finally
    //   115	119	145	finally
    //   124	128	107	java/lang/Exception
    //   124	128	138	finally
    //   128	132	145	finally
    //   139	145	145	finally
  }
  
  public static ar for(Context paramContext) {
    if (hR == null) {
      hR = new ar();
      hR.bP();
      hR.hI = paramContext;
    } 
    return hR;
  }
  
  private int if(an paraman, String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: iconst_0
    //   3: istore #4
    //   5: aload_0
    //   6: monitorenter
    //   7: aload_0
    //   8: getfield hI : Landroid/content/Context;
    //   11: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   14: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   17: astore #5
    //   19: aload #5
    //   21: ifnull -> 381
    //   24: aload #5
    //   26: invokevirtual beginTransaction : ()V
    //   29: invokestatic currentTimeMillis : ()J
    //   32: lstore #6
    //   34: new android/content/ContentValues
    //   37: astore #8
    //   39: aload #8
    //   41: invokespecial <init> : ()V
    //   44: aload_1
    //   45: invokevirtual getGeofenceId : ()Ljava/lang/String;
    //   48: astore #9
    //   50: aload #8
    //   52: ldc 'geofence_id'
    //   54: aload #9
    //   56: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   59: aload #8
    //   61: ldc_w 'longitude'
    //   64: aload_1
    //   65: invokevirtual a : ()D
    //   68: invokestatic valueOf : (D)Ljava/lang/Double;
    //   71: invokevirtual put : (Ljava/lang/String;Ljava/lang/Double;)V
    //   74: aload #8
    //   76: ldc_w 'latitude'
    //   79: aload_1
    //   80: invokevirtual byte : ()D
    //   83: invokestatic valueOf : (D)Ljava/lang/Double;
    //   86: invokevirtual put : (Ljava/lang/String;Ljava/lang/Double;)V
    //   89: aload #8
    //   91: ldc_w 'radius'
    //   94: aload_1
    //   95: invokevirtual do : ()F
    //   98: invokestatic valueOf : (F)Ljava/lang/Float;
    //   101: invokevirtual put : (Ljava/lang/String;Ljava/lang/Float;)V
    //   104: aload #8
    //   106: ldc_w 'radius_type'
    //   109: aload_1
    //   110: invokevirtual new : ()I
    //   113: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   116: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   119: aload #8
    //   121: ldc 'valid_date'
    //   123: lload #6
    //   125: invokestatic valueOf : (J)Ljava/lang/Long;
    //   128: invokevirtual put : (Ljava/lang/String;Ljava/lang/Long;)V
    //   131: aload #8
    //   133: ldc 'duration_millis'
    //   135: aload_1
    //   136: invokevirtual else : ()J
    //   139: invokestatic valueOf : (J)Ljava/lang/Long;
    //   142: invokevirtual put : (Ljava/lang/String;Ljava/lang/Long;)V
    //   145: aload #8
    //   147: ldc_w 'coord_type'
    //   150: aload_1
    //   151: invokevirtual int : ()Ljava/lang/String;
    //   154: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   157: aload_1
    //   158: invokevirtual try : ()Z
    //   161: ifeq -> 348
    //   164: iconst_1
    //   165: istore_3
    //   166: aload #8
    //   168: ldc_w 'is_lac'
    //   171: iload_3
    //   172: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   175: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   178: aload_1
    //   179: invokevirtual if : ()Z
    //   182: ifeq -> 353
    //   185: iconst_1
    //   186: istore_3
    //   187: aload #8
    //   189: ldc_w 'is_cell'
    //   192: iload_3
    //   193: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   196: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   199: aload_1
    //   200: invokevirtual for : ()Z
    //   203: ifeq -> 358
    //   206: iconst_1
    //   207: istore_3
    //   208: aload #8
    //   210: ldc_w 'is_wifi'
    //   213: iload_3
    //   214: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   217: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   220: aload #8
    //   222: ldc_w 'next_active_time'
    //   225: iconst_0
    //   226: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   229: invokevirtual put : (Ljava/lang/String;Ljava/lang/Integer;)V
    //   232: aload #5
    //   234: ldc 'geofence'
    //   236: aconst_null
    //   237: aload #8
    //   239: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   242: pop2
    //   243: aload_2
    //   244: ldc ';'
    //   246: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   249: astore #8
    //   251: aload #8
    //   253: arraylength
    //   254: istore #10
    //   256: iconst_0
    //   257: istore_3
    //   258: iload_3
    //   259: iload #10
    //   261: if_icmpge -> 363
    //   264: aload #8
    //   266: iload_3
    //   267: aaload
    //   268: astore_2
    //   269: new android/content/ContentValues
    //   272: astore #11
    //   274: aload #11
    //   276: invokespecial <init> : ()V
    //   279: aload #11
    //   281: ldc 'geofence_id'
    //   283: aload #9
    //   285: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   288: aload #11
    //   290: ldc_w 'ap_backup'
    //   293: aload_2
    //   294: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   297: aload_2
    //   298: ldc_w '|'
    //   301: invokevirtual lastIndexOf : (Ljava/lang/String;)I
    //   304: istore #12
    //   306: aload_2
    //   307: astore_1
    //   308: iload #12
    //   310: iconst_m1
    //   311: if_icmpeq -> 322
    //   314: aload_2
    //   315: iconst_0
    //   316: iload #12
    //   318: invokevirtual substring : (II)Ljava/lang/String;
    //   321: astore_1
    //   322: aload #11
    //   324: ldc_w 'ap'
    //   327: aload_1
    //   328: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   331: aload #5
    //   333: ldc 'geofence_detail'
    //   335: aconst_null
    //   336: aload #11
    //   338: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   341: pop2
    //   342: iinc #3, 1
    //   345: goto -> 258
    //   348: iconst_0
    //   349: istore_3
    //   350: goto -> 166
    //   353: iconst_0
    //   354: istore_3
    //   355: goto -> 187
    //   358: iconst_0
    //   359: istore_3
    //   360: goto -> 208
    //   363: aload #5
    //   365: invokevirtual setTransactionSuccessful : ()V
    //   368: aload #5
    //   370: invokevirtual endTransaction : ()V
    //   373: iload #4
    //   375: istore_3
    //   376: aload #5
    //   378: invokevirtual close : ()V
    //   381: aload_0
    //   382: monitorexit
    //   383: iload_3
    //   384: ireturn
    //   385: astore_1
    //   386: aload #5
    //   388: invokevirtual endTransaction : ()V
    //   391: iconst_1
    //   392: istore_3
    //   393: goto -> 376
    //   396: astore_1
    //   397: aload #5
    //   399: invokevirtual endTransaction : ()V
    //   402: aload_1
    //   403: athrow
    //   404: astore_1
    //   405: aload_0
    //   406: monitorexit
    //   407: aload_1
    //   408: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	404	finally
    //   24	34	404	finally
    //   34	164	385	java/lang/Exception
    //   34	164	396	finally
    //   166	185	385	java/lang/Exception
    //   166	185	396	finally
    //   187	206	385	java/lang/Exception
    //   187	206	396	finally
    //   208	256	385	java/lang/Exception
    //   208	256	396	finally
    //   269	306	385	java/lang/Exception
    //   269	306	396	finally
    //   314	322	385	java/lang/Exception
    //   314	322	396	finally
    //   322	342	385	java/lang/Exception
    //   322	342	396	finally
    //   363	368	385	java/lang/Exception
    //   363	368	396	finally
    //   368	373	404	finally
    //   376	381	404	finally
    //   386	391	404	finally
    //   397	404	404	finally
  }
  
  private void if(int paramInt, String paramString, GeofenceClient.OnAddBDGeofencesResultListener paramOnAddBDGeofencesResultListener) {
    if (paramInt == 1);
    paramOnAddBDGeofencesResultListener.onAddBDGeofencesResult(paramInt, paramString);
  }
  
  private void if(int paramInt, String[] paramArrayOfString, GeofenceClient.OnRemoveBDGeofencesResultListener paramOnRemoveBDGeofencesResultListener) {
    paramOnRemoveBDGeofencesResultListener.onRemoveBDGeofencesByRequestIdsResult(paramInt, paramArrayOfString);
  }
  
  private void if(GeofenceClient.OnAddBDGeofencesResultListener paramOnAddBDGeofencesResultListener, int paramInt, String paramString) {
    Message message = Message.obtain(this.hW);
    message.what = 0;
    message.obj = paramOnAddBDGeofencesResultListener;
    Bundle bundle = new Bundle();
    bundle.putInt("status_code", paramInt);
    bundle.putString("geofence_id", paramString);
    message.setData(bundle);
    this.hW.sendMessage(message);
  }
  
  public static void int(Context paramContext) {
    ax.cf().byte(f.getServiceContext());
  }
  
  public void bO() {
    synchronized (this.hP) {
      a a1 = this.hW;
      ar$2 ar$2 = new ar$2();
      this(this);
      a1.post(ar$2);
      return;
    } 
  }
  
  public void if(an paraman) {
    this.hW.post(new ar$1(this, paraman));
  }
  
  public void if(an paraman, GeofenceClient.OnAddBDGeofencesResultListener paramOnAddBDGeofencesResultListener) {
    bS();
    ak.a(paramOnAddBDGeofencesResultListener, "OnAddBDGeofenceRecesResultListener not provided.");
    if (bT() >= 10L) {
      paramOnAddBDGeofencesResultListener.onAddBDGeofencesResult(1001, paraman.getGeofenceId());
      return;
    } 
    (new b(this, paraman, paramOnAddBDGeofencesResultListener)).V();
    bR();
  }
  
  public void if(List paramList, GeofenceClient.OnRemoveBDGeofencesResultListener paramOnRemoveBDGeofencesResultListener) {
    boolean bool;
    if (paramList != null && paramList.size() > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    ak.if(bool, "geofenceRequestIds can't be null nor empty.");
    ak.a(paramOnRemoveBDGeofencesResultListener, "onRemoveBDGeofencesResultListener not provided.");
    this.hW.post(new d(this, paramList, paramOnRemoveBDGeofencesResultListener));
  }
  
  public void p(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield hI : Landroid/content/Context;
    //   18: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   21: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   24: astore_3
    //   25: aload_3
    //   26: ifnull -> 11
    //   29: new android/content/ContentValues
    //   32: astore #4
    //   34: aload #4
    //   36: invokespecial <init> : ()V
    //   39: aload #4
    //   41: ldc_w 'next_active_time'
    //   44: invokestatic currentTimeMillis : ()J
    //   47: ldc2_w 21600000
    //   50: ladd
    //   51: invokestatic valueOf : (J)Ljava/lang/Long;
    //   54: invokevirtual put : (Ljava/lang/String;Ljava/lang/Long;)V
    //   57: aload_3
    //   58: ldc 'geofence'
    //   60: aload #4
    //   62: ldc_w 'geofence_id= ?'
    //   65: iconst_1
    //   66: anewarray java/lang/String
    //   69: dup
    //   70: iconst_0
    //   71: aload_1
    //   72: aastore
    //   73: invokevirtual update : (Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    //   76: pop
    //   77: aload_3
    //   78: invokevirtual close : ()V
    //   81: goto -> 11
    //   84: astore_1
    //   85: aload_0
    //   86: monitorexit
    //   87: aload_1
    //   88: athrow
    //   89: astore_1
    //   90: aload_3
    //   91: invokevirtual close : ()V
    //   94: goto -> 11
    //   97: astore_1
    //   98: aload_3
    //   99: invokevirtual close : ()V
    //   102: aload_1
    //   103: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	84	finally
    //   14	25	84	finally
    //   29	77	89	java/lang/Exception
    //   29	77	97	finally
    //   77	81	84	finally
    //   90	94	84	finally
    //   98	104	84	finally
  }
  
  private class a extends Handler {
    public static final int do = 2;
    
    public static final int for = 3;
    
    public static final int if = 0;
    
    public a(ar this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      GeofenceClient.OnAddBDGeofencesResultListener onAddBDGeofencesResultListener2;
      GeofenceClient.OnRemoveBDGeofencesResultListener onRemoveBDGeofencesResultListener;
      super.handleMessage(param1Message);
      int i = param1Message.what;
      Bundle bundle = param1Message.getData();
      switch (i) {
        default:
          return;
        case 0:
          if (bundle != null) {
            i = bundle.getInt("status_code", 1);
            str = bundle.getString("geofence_id");
          } else {
            break;
          } 
          onAddBDGeofencesResultListener2 = (GeofenceClient.OnAddBDGeofencesResultListener)param1Message.obj;
          ar.if(this.a, i, str, onAddBDGeofencesResultListener2);
        case 2:
          if (str != null) {
            i = str.getInt("status_code", 1);
            String[] arrayOfString = str.getStringArray("geofence_ids");
          } else {
            i = 1;
            str = null;
          } 
          onRemoveBDGeofencesResultListener = (GeofenceClient.OnRemoveBDGeofencesResultListener)((Message)onAddBDGeofencesResultListener2).obj;
          ar.if(this.a, i, (String[])str, onRemoveBDGeofencesResultListener);
        case 3:
          this.a.bO();
      } 
      i = 1;
      String str = null;
      GeofenceClient.OnAddBDGeofencesResultListener onAddBDGeofencesResultListener1 = (GeofenceClient.OnAddBDGeofencesResultListener)((Message)onRemoveBDGeofencesResultListener).obj;
      ar.if(this.a, i, str, onAddBDGeofencesResultListener1);
    }
  }
  
  class b extends q {
    private static final String dA = "lac";
    
    private static final String dC = "wf";
    
    private static final String dE = "radius";
    
    private static final String dv = "error";
    
    private static final int dw = -3;
    
    private static final String dx = "ext";
    
    private static final String dy = "cl";
    
    private static final String dz = "fence";
    
    private int dD;
    
    private final an dF;
    
    private GeofenceClient.OnAddBDGeofencesResultListener du;
    
    public b(ar this$0, an param1an, GeofenceClient.OnAddBDGeofencesResultListener param1OnAddBDGeofencesResultListener) {
      this.dF = param1an;
      this.du = param1OnAddBDGeofencesResultListener;
      this.cP = new ArrayList();
    }
    
    public void O() {
      this.cN = "http://loc.map.baidu.com/fence";
      DecimalFormat decimalFormat = new DecimalFormat("0.00000");
      String str = Jni.h(String.format("&x=%s&y=%s&r=%s&coord=%s&type=%s&cu=%s", new Object[] { decimalFormat.format(this.dF.a()), decimalFormat.format(this.dF.byte()), String.valueOf(this.dF.new()), String.valueOf(this.dF.int()), Integer.valueOf(ar.do(ar.if(this.dB))), a.if(ar.if(this.dB)) }));
      this.cP.add(new BasicNameValuePair("fence", str));
      this.cP.add(new BasicNameValuePair("ext", Jni.h(String.format("&ki=%s&sn=%s", new Object[] { ar.do(this.dB), t.if(ar.if(this.dB)) }))));
    }
    
    public void V() {
      J();
    }
    
    public void do(boolean param1Boolean) {
      if (param1Boolean && this.cO != null) {
        StringBuilder stringBuilder = null;
        try {
          String str1;
          String str2 = EntityUtils.toString(this.cO, "UTF-8");
          JSONObject jSONObject = new JSONObject();
          this(str2);
          if (jSONObject != null) {
            stringBuilder = new StringBuilder();
            this();
            if (jSONObject.has("lac")) {
              str2 = jSONObject.getString("lac");
              if (!TextUtils.isEmpty(str2)) {
                stringBuilder.append(str2);
                this.dF.do(true);
              } 
            } 
            if (jSONObject.has("cl")) {
              str2 = jSONObject.getString("cl");
              if (!TextUtils.isEmpty(str2)) {
                stringBuilder.append(str2);
                this.dF.a(true);
              } 
            } 
            if (jSONObject.has("wf")) {
              str2 = jSONObject.getString("wf");
              if (!TextUtils.isEmpty(str2)) {
                stringBuilder.append(str2);
                this.dF.if(true);
              } 
            } 
            str2 = stringBuilder.toString();
            if (jSONObject.has("radius")) {
              float f = Float.valueOf(jSONObject.getString("radius")).floatValue();
              this.dF.a(f);
            } 
            str1 = str2;
            if (jSONObject.has("error")) {
              this.dD = Integer.valueOf(jSONObject.getString("error")).intValue();
              str1 = str2;
            } 
          } 
          if (TextUtils.isEmpty(str1)) {
            if (this.dD == -3) {
              ar.if(this.dB, this.du, 1002, this.dF.getGeofenceId());
              return;
            } 
            ar.if(this.dB, this.du, 1, this.dF.getGeofenceId());
            return;
          } 
        } catch (Exception exception) {
          ar.if(this.dB, this.du, 1, this.dF.getGeofenceId());
          return;
        } 
        ar.for(this.dB).post(new ar.c(this.dB, this.dF, (String)exception, this.du));
        return;
      } 
      ar.if(this.dB, this.du, 1, this.dF.getGeofenceId());
    }
  }
  
  private class c implements Runnable {
    private final an do;
    
    private final GeofenceClient.OnAddBDGeofencesResultListener for;
    
    private final String if;
    
    public c(ar this$0, an param1an, String param1String, GeofenceClient.OnAddBDGeofencesResultListener param1OnAddBDGeofencesResultListener) {
      this.do = param1an;
      this.if = param1String;
      this.for = param1OnAddBDGeofencesResultListener;
    }
    
    public void run() {
      int i = ar.if(this.a, this.do, this.if);
      ar.if(this.a, this.for, i, this.do.getGeofenceId());
    }
  }
  
  private class d implements Runnable {
    private final GeofenceClient.OnRemoveBDGeofencesResultListener do;
    
    private final List if;
    
    public d(ar this$0, List param1List, GeofenceClient.OnRemoveBDGeofencesResultListener param1OnRemoveBDGeofencesResultListener) {
      this.if = param1List;
      this.do = param1OnRemoveBDGeofencesResultListener;
    }
    
    public void run() {
      int i = ar.if(this.a, this.if);
      Message message = Message.obtain(ar.for(this.a));
      message.what = 2;
      message.obj = this.do;
      Bundle bundle = new Bundle();
      bundle.putInt("status_code", i);
      bundle.putStringArray("geofence_ids", (String[])this.if.toArray((Object[])new String[this.if.size()]));
      message.setData(bundle);
      ar.for(this.a).sendMessage(message);
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */