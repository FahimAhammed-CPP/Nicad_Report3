package com.baidu.location;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

class ac implements au, l, SensorEventListener {
  private static float gM;
  
  private static ac gQ;
  
  private boolean gK;
  
  float[] gL;
  
  SensorManager gN;
  
  float[] gO = new float[9];
  
  float[] gP;
  
  public static ac bc() {
    if (gQ == null)
      gQ = new ac(); 
    return gQ;
  }
  
  public float ba() {
    return gM;
  }
  
  public void bb() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield gN : Landroid/hardware/SensorManager;
    //   6: ifnull -> 22
    //   9: aload_0
    //   10: getfield gN : Landroid/hardware/SensorManager;
    //   13: aload_0
    //   14: invokevirtual unregisterListener : (Landroid/hardware/SensorEventListener;)V
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield gN : Landroid/hardware/SensorManager;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  public void bd() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield gN : Landroid/hardware/SensorManager;
    //   6: ifnonnull -> 24
    //   9: aload_0
    //   10: invokestatic getServiceContext : ()Landroid/content/Context;
    //   13: ldc 'sensor'
    //   15: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   18: checkcast android/hardware/SensorManager
    //   21: putfield gN : Landroid/hardware/SensorManager;
    //   24: aload_0
    //   25: getfield gN : Landroid/hardware/SensorManager;
    //   28: aload_0
    //   29: aload_0
    //   30: getfield gN : Landroid/hardware/SensorManager;
    //   33: iconst_1
    //   34: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   37: iconst_3
    //   38: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   41: pop
    //   42: aload_0
    //   43: getfield gN : Landroid/hardware/SensorManager;
    //   46: aload_0
    //   47: aload_0
    //   48: getfield gN : Landroid/hardware/SensorManager;
    //   51: iconst_2
    //   52: invokevirtual getDefaultSensor : (I)Landroid/hardware/Sensor;
    //   55: iconst_3
    //   56: invokevirtual registerListener : (Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z
    //   59: pop
    //   60: aload_0
    //   61: monitorexit
    //   62: return
    //   63: astore_1
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_1
    //   67: athrow
    // Exception table:
    //   from	to	target	type
    //   2	24	63	finally
    //   24	60	63	finally
  }
  
  public boolean be() {
    return this.gK;
  }
  
  public void onAccuracyChanged(Sensor paramSensor, int paramInt) {}
  
  public void onSensorChanged(SensorEvent paramSensorEvent) {
    float[] arrayOfFloat;
    switch (paramSensorEvent.sensor.getType()) {
      default:
        if (this.gL != null && this.gP != null) {
          float[] arrayOfFloat1 = new float[9];
          if (SensorManager.getRotationMatrix(arrayOfFloat1, null, this.gL, this.gP)) {
            arrayOfFloat = new float[3];
            SensorManager.getOrientation(arrayOfFloat1, arrayOfFloat);
            gM = (float)Math.toDegrees(arrayOfFloat[0]);
            if (gM >= 0.0F) {
              d = gM;
            } else {
              break;
            } 
          } else {
            return;
          } 
        } else {
          return;
        } 
        gM = (float)Math.floor(d);
        return;
      case 1:
        this.gL = ((SensorEvent)arrayOfFloat).values;
      case 2:
        this.gP = ((SensorEvent)arrayOfFloat).values;
    } 
    double d = (gM + 360.0F);
    gM = (float)Math.floor(d);
  }
  
  public void try(boolean paramBoolean) {
    this.gK = paramBoolean;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */