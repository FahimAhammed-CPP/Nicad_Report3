package com.baidu.location;

public interface BDLocationListener {
  void onReceiveLocation(BDLocation paramBDLocation);
  
  void onReceivePoi(BDLocation paramBDLocation);
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/BDLocationListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */