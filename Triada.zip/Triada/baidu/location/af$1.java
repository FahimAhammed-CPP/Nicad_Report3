package com.baidu.location;

class af$1 implements Runnable {
  af$1(af paramaf) {}
  
  public void run() {
    af.for(this.a);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/af$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */