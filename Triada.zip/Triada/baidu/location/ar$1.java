package com.baidu.location;

class ar$1 implements Runnable {
  ar$1(ar paramar, an paraman) {}
  
  public void run() {
    this.a.p(this.if.getGeofenceId());
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ar$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */