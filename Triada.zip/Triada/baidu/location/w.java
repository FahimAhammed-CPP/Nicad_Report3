package com.baidu.location;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Locale;
import org.apache.http.HttpEntity;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

class w implements au, l {
  private static w f0 = null;
  
  public static boolean f2 = false;
  
  public static int f3 = 0;
  
  public static int f4 = 0;
  
  public static boolean fR = false;
  
  public static boolean fS = false;
  
  private static final String fT;
  
  public static int fV = 0;
  
  public static boolean fW = false;
  
  public static boolean fX = true;
  
  private static final int fY = 128;
  
  public static boolean fZ = true;
  
  private long f1 = 0L;
  
  private a fU = null;
  
  static {
    f2 = false;
    fR = true;
    fS = true;
    fW = true;
    fT = f.H + "/conlts.dat";
    f3 = -1;
    fV = -1;
    f4 = 0;
  }
  
  private w() {
    this.fU = new a(this);
  }
  
  public static void aS() {
    boolean bool1;
    boolean bool2;
    String str = f.H + "/config.dat";
    if (c.ay) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (c.aX) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    byte[] arrayOfByte = String.format(Locale.CHINA, "{\"ver\":\"%d\",\"gps\":\"%.1f|%.1f|%.1f|%.1f|%d|%d|%d|%d|%d|%d|%d\",\"up\":\"%.1f|%.1f|%.1f|%.1f\",\"wf\":\"%d|%.1f|%d|%.1f\",\"ab\":\"%.2f|%.2f|%d|%d\",\"gpc\":\"%d|%d|%d|%d|%d|%d\",\"zxd\":\"%.1f|%.1f|%d|%d|%d\",\"shak\":\"%d|%d|%.1f\",\"dmx\":%d}", new Object[] { 
          Integer.valueOf(c.ah), Float.valueOf(c.ad), Float.valueOf(c.aP), Float.valueOf(c.af), Float.valueOf(c.aR), Integer.valueOf(c.aG), Integer.valueOf(c.V), Integer.valueOf(c.aH), Integer.valueOf(c.W), Integer.valueOf(c.Z), 
          Integer.valueOf(c.aw), Integer.valueOf(c.a2), Float.valueOf(c.bc), Float.valueOf(c.a9), Float.valueOf(c.ao), Float.valueOf(c.aY), Integer.valueOf(c.aV), Float.valueOf(c.aa), Integer.valueOf(c.as), Float.valueOf(c.aS), 
          Float.valueOf(c.bb), Float.valueOf(c.a8), Integer.valueOf(c.a6), Integer.valueOf(c.a4), Integer.valueOf(bool1), Integer.valueOf(bool2), Integer.valueOf(c.au), Integer.valueOf(c.ax), Long.valueOf(c.aQ), Integer.valueOf(c.aT), 
          Float.valueOf(c.ae), Float.valueOf(c.Y), Integer.valueOf(c.ap), Integer.valueOf(c.aD), Integer.valueOf(c.at), Integer.valueOf(c.aU), Integer.valueOf(c.aM), Float.valueOf(c.a0), Integer.valueOf(c.a3) }).getBytes();
    try {
      File file = new File();
      this(str);
      if (!file.exists()) {
        File file1 = new File();
        this(f.H);
        if (!file1.exists())
          file1.mkdirs(); 
        if (file.createNewFile()) {
          RandomAccessFile randomAccessFile1 = new RandomAccessFile();
          this(file, "rw");
          randomAccessFile1.seek(0L);
          randomAccessFile1.writeBoolean(false);
          randomAccessFile1.writeBoolean(false);
          randomAccessFile1.close();
        } else {
          return;
        } 
      } 
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(file, "rw");
      randomAccessFile.seek(0L);
      randomAccessFile.writeBoolean(true);
      randomAccessFile.seek(2L);
      randomAccessFile.writeInt(arrayOfByte.length);
      randomAccessFile.write(arrayOfByte);
      randomAccessFile.close();
    } catch (Exception exception) {}
  }
  
  public static void aT() {
    try {
      File file = new File();
      this(fT);
      if (!file.exists()) {
        File file1 = new File();
        this(f.H);
        if (!file1.exists())
          file1.mkdirs(); 
        file1 = file;
        if (!file.createNewFile())
          file1 = null; 
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(file1, "rw");
        randomAccessFile.seek(0L);
        randomAccessFile.writeInt(0);
        randomAccessFile.writeInt(128);
        randomAccessFile.writeInt(0);
        randomAccessFile.close();
      } 
    } catch (Exception exception) {}
  }
  
  public static w aU() {
    if (f0 == null)
      f0 = new w(); 
    return f0;
  }
  
  private void aX() {
    String str = "&ver=" + c.ah + "&usr=" + aw.b6().b3() + "&app=" + aw.iq + "&prod=" + aw.iw;
    this.fU.if(str, false);
  }
  
  public static void aY() {
    String str = f.H + "/config.dat";
    try {
      File file = new File();
      this(str);
      if (!file.exists()) {
        File file1 = new File();
        this(f.H);
        if (!file1.exists())
          file1.mkdirs(); 
        if (file.createNewFile()) {
          RandomAccessFile randomAccessFile1 = new RandomAccessFile();
          this(file, "rw");
          randomAccessFile1.seek(0L);
          randomAccessFile1.writeBoolean(false);
          randomAccessFile1.writeBoolean(false);
          randomAccessFile1.close();
        } else {
          return;
        } 
      } 
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(file, "rw");
      randomAccessFile.seek(1L);
      randomAccessFile.writeBoolean(true);
      randomAccessFile.seek(1024L);
      randomAccessFile.writeDouble(c.aF);
      randomAccessFile.writeDouble(c.ab);
      randomAccessFile.writeBoolean(c.aq);
      if (c.aq && c.aA != null)
        randomAccessFile.write(c.aA); 
      randomAccessFile.close();
    } catch (Exception exception) {}
  }
  
  public static void aZ() {
    byte b = 0;
    try {
      RandomAccessFile randomAccessFile;
      int i;
      File file = new File();
      this(fT);
      if (file.exists()) {
        randomAccessFile = new RandomAccessFile();
        this(file, "rw");
        randomAccessFile.seek(4L);
        i = randomAccessFile.readInt();
        if (i > 3000) {
          randomAccessFile.close();
          f4 = 0;
          aT();
          return;
        } 
      } else {
        return;
      } 
      int j = randomAccessFile.readInt();
      randomAccessFile.seek(128L);
      byte[] arrayOfByte = new byte[i];
      while (true) {
        if (b < j) {
          randomAccessFile.seek((i * b + 128));
          int k = randomAccessFile.readInt();
          if (k > 0 && k < i) {
            randomAccessFile.read(arrayOfByte, 0, k);
            if (arrayOfByte[k - 1] == 0) {
              String str = new String();
              this(arrayOfByte, 0, k - 1);
              aw.b6();
              if (str.equals(aw.iq)) {
                f3 = randomAccessFile.readInt();
                f4 = b;
              } else {
                continue;
              } 
            } else {
              continue;
            } 
          } else {
            continue;
          } 
        } 
        if (b == j)
          f4 = j; 
        randomAccessFile.close();
        return;
        b++;
      } 
    } catch (Exception exception) {}
  }
  
  private void do(HttpEntity paramHttpEntity) {
    String str = null;
    fV = -1;
    if (paramHttpEntity != null) {
      String str1;
      try {
        String str2 = EntityUtils.toString(paramHttpEntity, "utf-8");
        str1 = str2;
        str = str2;
        if (m(str2)) {
          str = str2;
          aS();
          str1 = str2;
        } 
      } catch (Exception exception) {
        str1 = str;
      } 
      try {
        JSONObject jSONObject = new JSONObject();
        this(str1);
        if (jSONObject.has("ctr"))
          fV = Integer.parseInt(jSONObject.getString("ctr")); 
      } catch (Exception exception) {}
    } 
    try {
      byte b;
      aZ();
      if (fV != -1) {
        b = fV;
        new(fV);
      } else if (f3 != -1) {
        b = f3;
      } else {
        b = -1;
      } 
      if (b != -1)
        try(b); 
      p.D().E().obtainMessage(92).sendToTarget();
    } catch (Exception exception) {}
  }
  
  private void if(HttpEntity paramHttpEntity) {
    byte b1 = 0;
    byte b2 = 0;
    try {
      byte[] arrayOfByte = EntityUtils.toByteArray(paramHttpEntity);
      if (arrayOfByte != null)
        if (arrayOfByte.length < 640) {
          c.aq = false;
          c.ab = c.am + 0.025D;
          c.aF = c.a7 - 0.025D;
          b2 = 1;
        } else {
          c.aq = true;
          c.aF = Double.longBitsToDouble(Long.valueOf((arrayOfByte[7] & 0xFFL) << 56L | (arrayOfByte[6] & 0xFFL) << 48L | (arrayOfByte[5] & 0xFFL) << 40L | (arrayOfByte[4] & 0xFFL) << 32L | (arrayOfByte[3] & 0xFFL) << 24L | (arrayOfByte[2] & 0xFFL) << 16L | (arrayOfByte[1] & 0xFFL) << 8L | arrayOfByte[0] & 0xFFL).longValue());
          c.ab = Double.longBitsToDouble(Long.valueOf((arrayOfByte[15] & 0xFFL) << 56L | (arrayOfByte[14] & 0xFFL) << 48L | (arrayOfByte[13] & 0xFFL) << 40L | (arrayOfByte[12] & 0xFFL) << 32L | (arrayOfByte[11] & 0xFFL) << 24L | (arrayOfByte[10] & 0xFFL) << 16L | (arrayOfByte[9] & 0xFFL) << 8L | arrayOfByte[8] & 0xFFL).longValue());
          c.aA = new byte[625];
          for (b2 = b1; b2 < 'ɱ'; b2++)
            c.aA[b2] = (byte)arrayOfByte[b2 + 16]; 
          b2 = 1;
        }  
      if (b2 != 0)
        aY(); 
    } catch (Exception exception) {}
  }
  
  public static void new(int paramInt) {
    File file = new File(fT);
    if (!file.exists())
      aT(); 
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(file, "rw");
      randomAccessFile.seek(4L);
      int i = randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      randomAccessFile.seek((i * f4 + 128));
      StringBuilder stringBuilder = new StringBuilder();
      this();
      byte[] arrayOfByte = stringBuilder.append(aw.iq).append(false).toString().getBytes();
      randomAccessFile.writeInt(arrayOfByte.length);
      randomAccessFile.write(arrayOfByte, 0, arrayOfByte.length);
      randomAccessFile.writeInt(paramInt);
      if (j == f4) {
        randomAccessFile.seek(8L);
        randomAccessFile.writeInt(j + 1);
      } 
      randomAccessFile.close();
    } catch (Exception exception) {}
  }
  
  public static void try(int paramInt) {
    boolean bool2;
    boolean bool1 = true;
    if ((paramInt & 0x1) == 1) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    fX = bool2;
    if ((paramInt & 0x2) == 2) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    fZ = bool2;
    if ((paramInt & 0x4) == 4) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    f2 = bool2;
    if ((paramInt & 0x8) == 8) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    fR = bool2;
    if ((paramInt & 0x10000) == 65536) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    fS = bool2;
    if ((paramInt & 0x20000) == 131072) {
      bool2 = bool1;
    } else {
      bool2 = false;
    } 
    fW = bool2;
  }
  
  public void aV() {
    String str = f.H + "/config.dat";
    try {
      File file = new File();
      this(str);
      if (file.exists()) {
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(file, "rw");
        if (randomAccessFile.readBoolean()) {
          randomAccessFile.seek(2L);
          int i = randomAccessFile.readInt();
          byte[] arrayOfByte = new byte[i];
          randomAccessFile.read(arrayOfByte, 0, i);
          String str1 = new String();
          this(arrayOfByte);
          m(str1);
        } 
        randomAccessFile.seek(1L);
        if (randomAccessFile.readBoolean()) {
          randomAccessFile.seek(1024L);
          c.aF = randomAccessFile.readDouble();
          c.ab = randomAccessFile.readDouble();
          c.aq = randomAccessFile.readBoolean();
          if (c.aq) {
            c.aA = new byte[625];
            randomAccessFile.read(c.aA, 0, 625);
          } 
        } 
        randomAccessFile.close();
      } 
    } catch (Exception exception) {}
    do(null);
  }
  
  public void aW() {
    if (System.currentTimeMillis() - this.f1 > 72000000L) {
      this.f1 = System.currentTimeMillis();
      aX();
    } 
  }
  
  public void l(String paramString) {
    this.fU.if(paramString, true);
  }
  
  public boolean m(String paramString) {
    boolean bool1 = true;
    boolean bool2 = false;
    if (paramString != null)
      try {
        JSONObject jSONObject = new JSONObject();
        this(paramString);
        int i = Integer.parseInt(jSONObject.getString("ver"));
        if (i > c.ah) {
          c.ah = i;
          if (jSONObject.has("gps")) {
            String[] arrayOfString = jSONObject.getString("gps").split("\\|");
            if (arrayOfString.length > 10) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.ad = Float.parseFloat(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.aP = Float.parseFloat(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.af = Float.parseFloat(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.aR = Float.parseFloat(arrayOfString[3]); 
              if (arrayOfString[4] != null && !arrayOfString[4].equals(""))
                c.aG = Integer.parseInt(arrayOfString[4]); 
              if (arrayOfString[5] != null && !arrayOfString[5].equals(""))
                c.V = Integer.parseInt(arrayOfString[5]); 
              if (arrayOfString[6] != null && !arrayOfString[6].equals(""))
                c.aH = Integer.parseInt(arrayOfString[6]); 
              if (arrayOfString[7] != null && !arrayOfString[7].equals(""))
                c.W = Integer.parseInt(arrayOfString[7]); 
              if (arrayOfString[8] != null && !arrayOfString[8].equals(""))
                c.Z = Integer.parseInt(arrayOfString[8]); 
              if (arrayOfString[9] != null && !arrayOfString[9].equals(""))
                c.aw = Integer.parseInt(arrayOfString[9]); 
              if (arrayOfString[10] != null && !arrayOfString[10].equals(""))
                c.a2 = Integer.parseInt(arrayOfString[10]); 
            } 
          } 
          if (jSONObject.has("up")) {
            String[] arrayOfString = jSONObject.getString("up").split("\\|");
            if (arrayOfString.length > 3) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.bc = Float.parseFloat(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.a9 = Float.parseFloat(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.ao = Float.parseFloat(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.aY = Float.parseFloat(arrayOfString[3]); 
            } 
          } 
          if (jSONObject.has("wf")) {
            String[] arrayOfString = jSONObject.getString("wf").split("\\|");
            if (arrayOfString.length > 3) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.aV = Integer.parseInt(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.aa = Float.parseFloat(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.as = Integer.parseInt(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.aS = Float.parseFloat(arrayOfString[3]); 
            } 
          } 
          if (jSONObject.has("ab")) {
            String[] arrayOfString = jSONObject.getString("ab").split("\\|");
            if (arrayOfString.length > 3) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.bb = Float.parseFloat(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.a8 = Float.parseFloat(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.a6 = Integer.parseInt(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.a4 = Integer.parseInt(arrayOfString[3]); 
            } 
          } 
          if (jSONObject.has("zxd")) {
            String[] arrayOfString = jSONObject.getString("zxd").split("\\|");
            if (arrayOfString.length > 4) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.ae = Float.parseFloat(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.Y = Float.parseFloat(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.ap = Integer.parseInt(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.aD = Integer.parseInt(arrayOfString[3]); 
              if (arrayOfString[4] != null && !arrayOfString[4].equals(""))
                c.at = Integer.parseInt(arrayOfString[4]); 
            } 
          } 
          if (jSONObject.has("gpc")) {
            String[] arrayOfString = jSONObject.getString("gpc").split("\\|");
            if (arrayOfString.length > 5) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                if (Integer.parseInt(arrayOfString[0]) > 0) {
                  c.ay = true;
                } else {
                  c.ay = false;
                }  
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                if (Integer.parseInt(arrayOfString[1]) > 0) {
                  c.aX = true;
                } else {
                  c.aX = false;
                }  
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.au = Integer.parseInt(arrayOfString[2]); 
              if (arrayOfString[3] != null && !arrayOfString[3].equals(""))
                c.ax = Integer.parseInt(arrayOfString[3]); 
              if (arrayOfString[4] != null && !arrayOfString[4].equals("")) {
                i = Integer.parseInt(arrayOfString[4]);
                if (i > 0) {
                  c.aQ = i;
                  c.aO = c.aQ * 1000L * 60L;
                  c.aC = c.aO >> 2L;
                } else {
                  c.a5 = false;
                } 
              } 
              if (arrayOfString[5] != null && !arrayOfString[5].equals(""))
                c.aT = Integer.parseInt(arrayOfString[5]); 
            } 
          } 
          if (jSONObject.has("shak")) {
            String[] arrayOfString = jSONObject.getString("shak").split("\\|");
            if (arrayOfString.length > 2) {
              if (arrayOfString[0] != null && !arrayOfString[0].equals(""))
                c.aU = Integer.parseInt(arrayOfString[0]); 
              if (arrayOfString[1] != null && !arrayOfString[1].equals(""))
                c.aM = Integer.parseInt(arrayOfString[1]); 
              if (arrayOfString[2] != null && !arrayOfString[2].equals(""))
                c.a0 = Float.parseFloat(arrayOfString[2]); 
            } 
          } 
          boolean bool = bool1;
          if (jSONObject.has("dmx")) {
            c.a3 = jSONObject.getInt("dmx");
            bool = bool1;
          } 
          return bool;
        } 
      } catch (Exception exception) {
        return bool2;
      }  
    return false;
  }
  
  class a extends q {
    boolean dj = false;
    
    String dk = null;
    
    boolean dl = false;
    
    public a(w this$0) {}
    
    void O() {
      this.cN = c.for();
      this.cW = 2;
      String str = Jni.h(this.dk);
      this.dk = null;
      if (this.dj) {
        this.cP.add(new BasicNameValuePair("qt", "grid"));
      } else {
        this.cP.add(new BasicNameValuePair("qt", "conf"));
      } 
      this.cP.add(new BasicNameValuePair("req", str));
    }
    
    void do(boolean param1Boolean) {
      if (param1Boolean && this.cO != null) {
        if (this.dj) {
          w.if(this.di, this.cO);
        } else {
          w.do(this.di, this.cO);
        } 
      } else {
        w.do(this.di, null);
      } 
      if (this.cP != null)
        this.cP.clear(); 
      this.dl = false;
    }
    
    public void if(String param1String, boolean param1Boolean) {
      if (!this.dl) {
        this.dl = true;
        this.dk = param1String;
        this.dj = param1Boolean;
        J();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */