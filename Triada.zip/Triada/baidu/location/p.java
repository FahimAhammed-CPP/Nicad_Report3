package com.baidu.location;

import android.os.Handler;
import android.os.Message;

class p implements au, l {
  private static p cL = null;
  
  private j cK = null;
  
  private Handler cM = null;
  
  private p() {
    this.cM = new a(this);
  }
  
  public static p D() {
    if (cL == null)
      cL = new p(); 
    return cL;
  }
  
  private void F() {
    try {
      if (w.f2) {
        boolean bool = c.a5;
        if (bool);
      } 
    } catch (Exception exception) {}
  }
  
  public void C() {
    if (this.cK != null)
      this.cK.r(); 
    this.cK = null;
  }
  
  public Handler E() {
    return this.cM;
  }
  
  public void G() {}
  
  public class a extends Handler {
    public a(p this$0) {}
    
    public void handleMessage(Message param1Message) {
      if (f.isServing) {
        switch (param1Message.what) {
          default:
            super.handleMessage(param1Message);
            return;
          case 92:
            break;
        } 
        p.if(this.a);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */