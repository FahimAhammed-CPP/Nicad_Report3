package com.baidu.location;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class k extends SQLiteOpenHelper {
  private static k a;
  
  private static final String do = "bd_geofence.db";
  
  private static final int if = 1;
  
  public k(Context paramContext) {
    super(paramContext, "bd_geofence.db", null, 1);
  }
  
  public static k a(Context paramContext) {
    // Byte code:
    //   0: ldc com/baidu/location/k
    //   2: monitorenter
    //   3: getstatic com/baidu/location/k.a : Lcom/baidu/location/k;
    //   6: ifnonnull -> 22
    //   9: new com/baidu/location/k
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/content/Context;)V
    //   18: aload_1
    //   19: putstatic com/baidu/location/k.a : Lcom/baidu/location/k;
    //   22: getstatic com/baidu/location/k.a : Lcom/baidu/location/k;
    //   25: astore_0
    //   26: ldc com/baidu/location/k
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/baidu/location/k
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  private void a(SQLiteDatabase paramSQLiteDatabase) {
    paramSQLiteDatabase.execSQL("CREATE TABLE  IF NOT EXISTS geofence (_id INTEGER PRIMARY KEY AUTOINCREMENT,geofence_id NTEXT,longitude NTEXT,latitude NTEXT,radius_type INTEGER,radius NTEXT,valid_date INTEGER,duration_millis INTEGER,coord_type NTEXT,next_active_time INTEGER,is_lac INTEGER,is_cell INTEGER,is_wifi INTEGER);");
    paramSQLiteDatabase.execSQL("CREATE TABLE  IF NOT EXISTS geofence_detail (_id INTEGER PRIMARY KEY AUTOINCREMENT,geofence_id NTEXT,ap NTEXT,ap_backup NTEXT);");
    paramSQLiteDatabase.execSQL("CREATE INDEX  IF NOT EXISTS ap_index ON geofence_detail (ap);");
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    a(paramSQLiteDatabase);
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */