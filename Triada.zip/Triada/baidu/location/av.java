package com.baidu.location;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.net.wifi.ScanResult;
import android.os.AsyncTask;
import android.os.Message;
import java.io.File;
import java.util.Iterator;
import java.util.Locale;
import org.json.JSONObject;

class av implements au, l {
  private static av h4 = null;
  
  private boolean h5 = false;
  
  private String h6 = null;
  
  private long h7 = 0L;
  
  private final int h8 = 6;
  
  private double h9 = 0.0D;
  
  private double ia = 0.0D;
  
  private final String ib = "bdcltb09";
  
  private double ic = 0.0D;
  
  private double id = 0.0D;
  
  private boolean ie = false;
  
  private boolean ig = true;
  
  private boolean ih = false;
  
  private double ii = 0.0D;
  
  private volatile boolean ij = false;
  
  private final String ik = H + "/ls.db";
  
  private int il = 0;
  
  private final String im = "wof";
  
  private boolean in = false;
  
  private final int io = 10000;
  
  private String ip = null;
  
  private av() {
    try {
      bZ();
    } catch (Exception exception) {}
  }
  
  public static av bW() {
    if (h4 == null)
      h4 = new av(); 
    return h4;
  }
  
  private void bX() {
    try {
      SQLiteDatabase sQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(this.ik, null);
    } catch (Exception exception) {
      exception = null;
    } 
    if (exception != null) {
      boolean bool1;
      boolean bool2;
      long l1 = DatabaseUtils.queryNumEntries((SQLiteDatabase)exception, "wof");
      long l2 = DatabaseUtils.queryNumEntries((SQLiteDatabase)exception, "bdcltb09");
      if (l1 > 10000L) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (l2 > 10000L) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      if (bool1 || bool2)
        (new a(null)).execute((Object[])new Boolean[] { Boolean.valueOf(bool1), Boolean.valueOf(bool2) }); 
      exception.close();
    } 
  }
  
  private void bY() {
    r.a a = r.aa().X();
    if (a != null)
      q(a.a()); 
    for(ao.bC().by());
  }
  
  private void bZ() {
    try {
      File file1 = new File();
      this(H);
      File file2 = new File();
      this(this.ik);
      if (!file1.exists())
        file1.mkdirs(); 
      if (!file2.exists())
        file2.createNewFile(); 
      if (file2.exists()) {
        SQLiteDatabase sQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(file2, null);
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS bdcltb09(id CHAR(40) PRIMARY KEY,time DOUBLE,tag DOUBLE, type DOUBLE , ac INT);");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS wof(id CHAR(15) PRIMARY KEY,mktime DOUBLE,time DOUBLE, ac INT, bc INT, cc INT);");
        sQLiteDatabase.setVersion(1);
        sQLiteDatabase.close();
      } 
    } catch (Exception exception) {}
  }
  
  private String byte(boolean paramBoolean) {
    double d2;
    double d3;
    boolean bool1;
    boolean bool2;
    double d1 = 0.0D;
    if (this.in) {
      d2 = this.ia;
      d1 = this.h9;
      d3 = 246.4D;
      bool1 = true;
      bool2 = true;
    } else if (this.ih) {
      d2 = this.id;
      d1 = this.ic;
      d3 = this.ii;
      bool1 = ad.al().an();
      bool2 = true;
    } else {
      d3 = 0.0D;
      d2 = 0.0D;
      bool1 = false;
      bool2 = false;
    } 
    h.cK().if(this.ih, this.in, d2, d1);
    if (bool2) {
      if (paramBoolean) {
        null = "{\"result\":{\"time\":\"" + c.int() + "\",\"error\":\"66\"},\"content\":{\"point\":{\"x\":" + "\"%f\",\"y\":\"%f\"},\"radius\":\"%f\",\"isCellChanged\":\"%b\"}}";
        return String.format(Locale.CHINA, null, new Object[] { Double.valueOf(d2), Double.valueOf(d1), Double.valueOf(d3), Boolean.valueOf(true) });
      } 
      null = "{\"result\":{\"time\":\"" + c.int() + "\",\"error\":\"68\"},\"content\":{\"point\":{\"x\":" + "\"%f\",\"y\":\"%f\"},\"radius\":\"%f\",\"isCellChanged\":\"%b\"}}";
      return String.format(Locale.CHINA, null, new Object[] { Double.valueOf(d2), Double.valueOf(d1), Double.valueOf(d3), Boolean.valueOf(bool1) });
    } 
    return paramBoolean ? ("{\"result\":{\"time\":\"" + c.int() + "\",\"error\":\"67\"}}") : ("{\"result\":{\"time\":\"" + c.int() + "\",\"error\":\"63\"}}");
  }
  
  private void for(ao.b paramb) {
    System.currentTimeMillis();
    this.in = false;
    if (paramb.for != null) {
      try {
        SQLiteDatabase sQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(this.ik, null);
      } catch (Exception exception) {
        exception = null;
      } 
      if (exception != null && paramb != null) {
        Object object1;
        Object object2;
        Object object3;
        Iterator<ScanResult> iterator = paramb.for.iterator();
        byte b1 = 0;
        paramb = null;
        boolean bool = false;
        byte b2 = 0;
        double d1 = 0.0D;
        double d2 = 0.0D;
        byte b3 = 0;
        while (true) {
          double d3;
          double d4;
          int i = b2;
          Object object4 = object2;
          Object object5 = object3;
          if (iterator.hasNext()) {
            ScanResult scanResult = iterator.next();
            if (++b3 > 10) {
              object5 = object3;
              object4 = object2;
              i = b2;
            } else {
              double[] arrayOfDouble;
              int j;
              String str = Jni.i(scanResult.BSSID.replace(":", ""));
              Object object = object1;
              ao.b b4 = paramb;
              boolean bool1 = bool;
              i = b2;
              object5 = object2;
              object4 = object3;
              try {
                double[] arrayOfDouble1;
                int k;
                double d5;
                double d6;
                float[] arrayOfFloat;
                StringBuilder stringBuilder = new StringBuilder();
                object = object1;
                b4 = paramb;
                bool1 = bool;
                i = b2;
                object5 = object2;
                object4 = object3;
                this();
                object = object1;
                b4 = paramb;
                bool1 = bool;
                i = b2;
                object5 = object2;
                object4 = object3;
                Cursor cursor = exception.rawQuery(stringBuilder.append("select * from wof where id = \"").append(str).append("\";").toString(), null);
                object = object1;
                b4 = paramb;
                bool1 = bool;
                i = b2;
                object5 = object2;
                object4 = object3;
                if (cursor.moveToFirst()) {
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  double d7 = cursor.getDouble(1) - 113.2349D;
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  double d8 = cursor.getDouble(2) - 432.1238D;
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  cursor.getInt(3);
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  int m = cursor.getInt(4);
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  int n = cursor.getInt(5);
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  cursor.close();
                  if (n > 8 && n > m)
                    continue; 
                  object = object1;
                  b4 = paramb;
                  bool1 = bool;
                  i = b2;
                  object5 = object2;
                  object4 = object3;
                  if (this.ih) {
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    object5 = object2;
                    object4 = object3;
                    arrayOfFloat = new float[1];
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    object5 = object2;
                    object4 = object3;
                    Location.distanceBetween(d8, d7, this.ic, this.id, arrayOfFloat);
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    object5 = object2;
                    object4 = object3;
                    if (arrayOfFloat[0] > this.ii + 2000.0D)
                      continue; 
                    bool = true;
                    b2++;
                    double d = object2 + d8;
                    d5 = object3 + d7;
                    d6 = d;
                  } else if (bool) {
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    double d10 = d5;
                    double d9 = d6;
                    arrayOfFloat = new float[1];
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    d10 = d5;
                    d9 = d6;
                    Location.distanceBetween(d8, d7, d5 / b2, d6 / b2, arrayOfFloat);
                    if (arrayOfFloat[0] > 1000.0F)
                      continue; 
                    d9 = d5;
                    d5 = d6;
                    d6 = d9;
                  } else if (paramb == null) {
                    object = object1;
                    b4 = paramb;
                    bool1 = bool;
                    i = b2;
                    double d10 = d5;
                    double d9 = d6;
                    arrayOfDouble1 = new double[8];
                    i = object1 + 1;
                    arrayOfDouble1[object1] = d7;
                    k = i + 1;
                    arrayOfDouble1[i] = d8;
                    d9 = d5;
                    d5 = d6;
                    d6 = d9;
                  } else {
                    for (m = 0; m < k; m += 2) {
                      j = k;
                      arrayOfDouble = arrayOfDouble1;
                      bool1 = bool;
                      i = b2;
                      double d10 = d5;
                      double d9 = d6;
                      arrayOfFloat = new float[1];
                      j = k;
                      arrayOfDouble = arrayOfDouble1;
                      bool1 = bool;
                      i = b2;
                      d10 = d5;
                      d9 = d6;
                      Location.distanceBetween(d8, d7, arrayOfDouble1[m + 1], arrayOfDouble1[m], arrayOfFloat);
                      float f = arrayOfFloat[0];
                      if (f < 1000.0F) {
                        bool = true;
                        d9 = arrayOfDouble1[m];
                        d10 = arrayOfDouble1[m + 1];
                        d5 += d10;
                        b2++;
                        d6 += d9;
                      } 
                    } 
                    if (bool) {
                      b2++;
                      d5 += d8;
                      double d = d6 + d7;
                      d6 = d5;
                      d5 = d;
                    } else if (k < 8) {
                      i = k + 1;
                      arrayOfDouble1[k] = d7;
                      k = i + 1;
                      arrayOfDouble1[i] = d8;
                      double d = d6;
                      d6 = d5;
                      d5 = d;
                    } else {
                      j = k;
                      arrayOfDouble = arrayOfDouble1;
                      bool1 = bool;
                      i = b2;
                      double d10 = d5;
                      double d9 = d6;
                      exception.close();
                      return;
                    } 
                  } 
                  i = k;
                  k = b2;
                  d4 = d6;
                  d3 = d5;
                  if (b2 > 4) {
                    i = b2;
                    d3 = d6;
                    d4 = d5;
                  } else {
                    continue;
                  } 
                } else {
                  j = k;
                  arrayOfDouble = arrayOfDouble1;
                  bool1 = bool;
                  i = b2;
                  d4 = d5;
                  d3 = d6;
                  arrayOfFloat.close();
                  continue;
                } 
                if (i > 0) {
                  this.in = true;
                  this.ia = d4 / i;
                  this.h9 = d3 / i;
                } 
                exception.close();
                return;
              } catch (Exception exception1) {
                double[] arrayOfDouble1 = arrayOfDouble;
                bool = bool1;
                int k = i;
                i = j;
                continue;
              } 
            } 
          } 
          if (i > 0) {
            this.in = true;
            this.ia = d4 / i;
            this.h9 = d3 / i;
          } 
          exception.close();
          return;
          b2 = b1;
          object2 = SYNTHETIC_LOCAL_VARIABLE_15;
          object3 = SYNTHETIC_LOCAL_VARIABLE_13;
          object1 = SYNTHETIC_LOCAL_VARIABLE_12;
        } 
      } 
    } 
  }
  
  private void if(ao.b paramb, BDLocation paramBDLocation, SQLiteDatabase paramSQLiteDatabase) {
    if (paramBDLocation != null && paramBDLocation.getLocType() == 161 && ("wf".equals(paramBDLocation.getNetworkLocationType()) || paramBDLocation.getRadius() < 300.0F) && paramb.for != null) {
      int i = (int)(System.currentTimeMillis() >> 28L);
      System.currentTimeMillis();
      Iterator<ScanResult> iterator = paramb.for.iterator();
      byte b1 = 0;
      while (true) {
        if (iterator.hasNext()) {
          ScanResult scanResult = iterator.next();
          if (scanResult.level != 0) {
            if (++b1 <= 6) {
              ContentValues contentValues = new ContentValues();
              String str = Jni.i(scanResult.BSSID.replace(":", ""));
              try {
                double d1;
                double d2;
                int j;
                byte b2;
                int k;
                StringBuilder stringBuilder = new StringBuilder();
                this();
                Cursor cursor = paramSQLiteDatabase.rawQuery(stringBuilder.append("select * from wof where id = \"").append(str).append("\";").toString(), null);
                if (cursor != null && cursor.moveToFirst()) {
                  d1 = cursor.getDouble(1);
                  d2 = cursor.getDouble(2);
                  cursor.getInt(3);
                  j = cursor.getInt(4);
                  b2 = cursor.getInt(5);
                  d2 -= 432.1238D;
                  k = 1;
                  d1 -= 113.2349D;
                } else {
                  b2 = 0;
                  j = 0;
                  d1 = 0.0D;
                  k = 0;
                  d2 = 0.0D;
                } 
                cursor.close();
                if (!k) {
                  contentValues.put("mktime", Double.valueOf(paramBDLocation.getLongitude() + 113.2349D));
                  contentValues.put("time", Double.valueOf(paramBDLocation.getLatitude() + 432.1238D));
                  contentValues.put("bc", Integer.valueOf(1));
                  contentValues.put("cc", Integer.valueOf(1));
                  contentValues.put("ac", Integer.valueOf(i));
                  contentValues.put("id", str);
                  paramSQLiteDatabase.insert("wof", null, contentValues);
                  continue;
                } 
                if (!b2)
                  continue; 
                float[] arrayOfFloat = new float[1];
                Location.distanceBetween(d2, d1, paramBDLocation.getLatitude(), paramBDLocation.getLongitude(), arrayOfFloat);
                if (arrayOfFloat[0] > 1500.0F) {
                  k = b2 + 1;
                  if (k > 10 && k > j * 3) {
                    contentValues.put("mktime", Double.valueOf(paramBDLocation.getLongitude() + 113.2349D));
                    contentValues.put("time", Double.valueOf(paramBDLocation.getLatitude() + 432.1238D));
                    contentValues.put("bc", Integer.valueOf(1));
                    contentValues.put("cc", Integer.valueOf(1));
                    contentValues.put("ac", Integer.valueOf(i));
                  } else {
                    contentValues.put("cc", Integer.valueOf(k));
                  } 
                } else {
                  d1 = (d1 * j + paramBDLocation.getLongitude()) / (j + 1);
                  d2 = (d2 * j + paramBDLocation.getLatitude()) / (j + 1);
                  contentValues.put("mktime", Double.valueOf(d1 + 113.2349D));
                  contentValues.put("time", Double.valueOf(d2 + 432.1238D));
                  contentValues.put("bc", Integer.valueOf(j + 1));
                  contentValues.put("ac", Integer.valueOf(i));
                } 
                try {
                  StringBuilder stringBuilder1 = new StringBuilder();
                  this();
                  j = paramSQLiteDatabase.update("wof", contentValues, stringBuilder1.append("id = \"").append(str).append("\"").toString(), null);
                  if (j <= 0);
                } catch (Exception exception) {}
              } catch (Exception exception) {
                continue;
              } 
            } 
            return;
          } 
          continue;
        } 
        return;
      } 
    } 
  }
  
  private void if(String paramString, r.a parama, SQLiteDatabase paramSQLiteDatabase) {
    if (parama.for() && ad.al().an()) {
      System.currentTimeMillis();
      double d1 = 0.0D;
      double d2 = 0.0D;
      float f = 0.0F;
      int i = (int)(System.currentTimeMillis() >> 28L);
      String str = parama.a();
      boolean bool = true;
      try {
        JSONObject jSONObject = new JSONObject();
        this(paramString);
        int j = Integer.parseInt(jSONObject.getJSONObject("result").getString("error"));
        if (j == 161) {
          JSONObject jSONObject1 = jSONObject.getJSONObject("content");
          if (jSONObject1.has("clf")) {
            JSONObject jSONObject2;
            bool = false;
            String str1 = jSONObject1.getString("clf");
            if (str1.equals("0")) {
              jSONObject2 = jSONObject1.getJSONObject("point");
              d1 = Double.parseDouble(jSONObject2.getString("x"));
              d2 = Double.parseDouble(jSONObject2.getString("y"));
              f = Float.parseFloat(jSONObject1.getString("radius"));
            } else {
              String[] arrayOfString = jSONObject2.split("\\|");
              d1 = Double.parseDouble(arrayOfString[0]);
              d2 = Double.parseDouble(arrayOfString[1]);
              f = Float.parseFloat(arrayOfString[2]);
            } 
          } 
        } else if (j == 167) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          paramSQLiteDatabase.delete("bdcltb09", stringBuilder.append("id = \"").append(str).append("\"").toString(), null);
          return;
        } 
        if (!bool) {
          ContentValues contentValues = new ContentValues();
          contentValues.put("time", Double.valueOf(d1 + 1235.4323D));
          contentValues.put("tag", Float.valueOf(4326.0F + f));
          contentValues.put("type", Double.valueOf(d2 + 2367.3217D));
          contentValues.put("ac", Integer.valueOf(i));
          try {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            if (paramSQLiteDatabase.update("bdcltb09", contentValues, stringBuilder.append("id = \"").append(str).append("\"").toString(), null) <= 0) {
              contentValues.put("id", str);
              paramSQLiteDatabase.insert("bdcltb09", null, contentValues);
            } 
          } catch (Exception exception) {}
        } 
      } catch (Exception exception) {}
    } 
  }
  
  private void k(Message paramMessage) {
    i.m().if(case(true), paramMessage);
  }
  
  private void q(String paramString) {
    SQLiteDatabase sQLiteDatabase = null;
    if (paramString != null && !paramString.equals(this.ip)) {
      try {
        SQLiteDatabase sQLiteDatabase1 = SQLiteDatabase.openOrCreateDatabase(this.ik, null);
        sQLiteDatabase = sQLiteDatabase1;
      } catch (Exception exception) {}
      if (sQLiteDatabase == null || paramString == null) {
        this.ih = false;
        return;
      } 
      this.ih = false;
      try {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        Cursor cursor = sQLiteDatabase.rawQuery(stringBuilder.append("select * from bdcltb09 where id = \"").append(paramString).append("\";").toString(), null);
        this.ip = paramString;
        this.h7 = System.currentTimeMillis();
        if (cursor != null) {
          if (cursor.moveToFirst()) {
            this.id = cursor.getDouble(1) - 1235.4323D;
            this.ii = cursor.getDouble(2) - 4326.0D;
            this.ic = cursor.getDouble(3) - 2367.3217D;
            this.ih = true;
          } 
          cursor.close();
        } 
      } catch (Exception exception) {}
      sQLiteDatabase.close();
    } 
  }
  
  public void b0() {}
  
  public void b1() {
    this.ig = true;
    f.getHandler().postDelayed(new av$1(this), 3000L);
  }
  
  public BDLocation case(boolean paramBoolean) {
    bY();
    return new BDLocation(byte(paramBoolean));
  }
  
  public void if(String paramString, r.a parama, ao.b paramb, BDLocation paramBDLocation) {
    boolean bool1;
    boolean bool2;
    if (!parama.for() || !ad.al().an()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (paramBDLocation == null || paramBDLocation.getLocType() != 161 || (!"wf".equals(paramBDLocation.getNetworkLocationType()) && paramBDLocation.getRadius() >= 300.0F)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (paramb.for == null)
      bool2 = true; 
    if ((!bool1 || !bool2) && !this.ij) {
      this.ij = true;
      (new b(null)).execute(new Object[] { paramString, parama, paramb, paramBDLocation });
    } 
  }
  
  public void j(Message paramMessage) {
    k(paramMessage);
  }
  
  private class a extends AsyncTask {
    private a(av this$0) {}
    
    protected Boolean a(Boolean... param1VarArgs) {
      SQLiteDatabase sQLiteDatabase = null;
      if (param1VarArgs.length != 4)
        return Boolean.valueOf(false); 
      try {
        SQLiteDatabase sQLiteDatabase1 = SQLiteDatabase.openOrCreateDatabase(av.if(this.a), null);
        sQLiteDatabase = sQLiteDatabase1;
      } catch (Exception exception) {}
      if (sQLiteDatabase == null)
        return Boolean.valueOf(false); 
      int i = (int)(System.currentTimeMillis() >> 28L);
      try {
        sQLiteDatabase.beginTransaction();
        if (param1VarArgs[0].booleanValue()) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          String str = stringBuilder.append("delete from wof where ac < ").append(i - 35).toString();
          try {
            sQLiteDatabase.execSQL(str);
          } catch (Exception exception) {}
        } 
        if (param1VarArgs[1].booleanValue()) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          String str = stringBuilder.append("delete from bdcltb09 where ac is NULL or ac < ").append(i - 130).toString();
          try {
            sQLiteDatabase.execSQL(str);
            sQLiteDatabase.setTransactionSuccessful();
            sQLiteDatabase.endTransaction();
            sQLiteDatabase.close();
          } catch (Exception exception) {}
          return (Boolean)exception;
        } 
        sQLiteDatabase.setTransactionSuccessful();
        sQLiteDatabase.endTransaction();
        sQLiteDatabase.close();
      } catch (Exception exception) {}
      Boolean bool = Boolean.valueOf(true);
    }
  }
  
  private class b extends AsyncTask {
    private b(av this$0) {}
    
    protected Boolean a(Object... param1VarArgs) {
      if (param1VarArgs.length != 4) {
        av.if(this.a, false);
        return Boolean.valueOf(false);
      } 
      try {
        SQLiteDatabase sQLiteDatabase = SQLiteDatabase.openOrCreateDatabase(av.if(this.a), null);
        if (sQLiteDatabase == null) {
          av.if(this.a, false);
          return Boolean.valueOf(false);
        } 
      } catch (Exception exception2) {
        exception2 = null;
        if (exception2 == null) {
          av.if(this.a, false);
          return Boolean.valueOf(false);
        } 
      } 
      try {
        exception2.beginTransaction();
        av.if(this.a, (String)param1VarArgs[0], (r.a)param1VarArgs[1], (SQLiteDatabase)exception2);
        av.if(this.a, (ao.b)param1VarArgs[2], (BDLocation)param1VarArgs[3], (SQLiteDatabase)exception2);
        exception2.setTransactionSuccessful();
        exception2.endTransaction();
        exception2.close();
        av.if(this.a, false);
        Boolean bool = Boolean.valueOf(true);
      } catch (Exception exception1) {}
      return (Boolean)exception1;
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/av.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */