package com.baidu.location;

import android.location.Location;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import java.util.Locale;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

abstract class ae implements au, l {
  public static String d5 = null;
  
  private boolean d4 = false;
  
  private boolean d6 = true;
  
  final Handler d7 = new b(this);
  
  public r.a d8 = null;
  
  private boolean d9 = false;
  
  private boolean ea = false;
  
  public ao.b eb = null;
  
  abstract void ag();
  
  abstract void byte(Message paramMessage);
  
  public String d(String paramString) {
    String str3;
    if (this.d8 == null || !this.d8.do())
      this.d8 = r.aa().X(); 
    if (this.d8 != null) {
      c.if("baidu_location_service", this.d8.if());
    } else {
      c.if("baidu_location_service", "cellInfo null...");
    } 
    if (this.eb == null || !this.eb.for())
      this.eb = ao.bC().bH(); 
    if (this.eb != null) {
      c.if("baidu_location_service", this.eb.else());
    } else {
      c.if("baidu_location_service", "wifi list null");
    } 
    Location location = null;
    if (v.aR().aE())
      location = v.aR().aF(); 
    String str1 = i.m().l();
    if (ao.bA()) {
      str2 = "&cn=32";
    } else {
      str2 = String.format(Locale.CHINA, "&cn=%d", new Object[] { Integer.valueOf(r.aa().ac()) });
    } 
    if (this.d6) {
      this.d6 = false;
      str3 = str2;
    } else {
      str3 = str2;
      if (!this.d4) {
        str3 = o.v();
        String str = str2;
        if (str3 != null)
          str = str2 + str3; 
        str2 = ao.bC().bG();
        str3 = str;
        if (!TextUtils.isEmpty(str2)) {
          str2 = str2.replace(":", "");
          str3 = String.format(Locale.CHINA, "%s&mac=%s", new Object[] { str, str2 });
          this.d4 = true;
        } 
      } 
    } 
    String str4 = str3 + str1;
    String str2 = str4;
    if (paramString != null)
      str2 = paramString + str4; 
    return c.if(this.d8, this.eb, location, str2, 0);
  }
  
  class a extends q {
    String dn = null;
    
    String dp = null;
    
    public a(ae this$0) {}
    
    void O() {
      this.cN = c.for();
      String str2 = Jni.h(this.dn);
      ah.a().a(str2);
      this.dn = null;
      if (this.dp == null)
        this.dp = o.x(); 
      this.cP.add(new BasicNameValuePair("bloc", str2));
      if (this.dp != null)
        this.cP.add(new BasicNameValuePair("up", this.dp)); 
      StringBuffer stringBuffer = new StringBuffer(512);
      Locale locale = Locale.CHINA;
      aw.b6();
      String str4 = aw.iu;
      aw.b6();
      stringBuffer.append(String.format(locale, "&ki=%s&sn=%s", new Object[] { str4, aw.iA }));
      String str3 = h.cK().cJ();
      if (str3 != null)
        stringBuffer.append(str3); 
      if (stringBuffer.length() > 0)
        this.cP.add(new BasicNameValuePair("ext", Jni.h(stringBuffer.toString()))); 
      String str1 = String.format(Locale.CHINA, "%d", new Object[] { Long.valueOf(System.currentTimeMillis()) });
      this.cP.add(new BasicNameValuePair("trtm", str1));
      d.long().void();
    }
    
    void do(boolean param1Boolean) {
      if (param1Boolean && this.cO != null) {
        try {
          String str = EntityUtils.toString(this.cO, "utf-8");
          ae.d5 = str;
          ah.a().if(str);
          try {
            BDLocation bDLocation2 = new BDLocation();
            this(str);
            BDLocation bDLocation1 = bDLocation2;
            if (bDLocation2.getLocType() == 161) {
              d.long().new(bDLocation2.getTime());
              bDLocation2.byte(r.aa().ad());
              bDLocation1 = bDLocation2;
              if (ac.bc().be()) {
                bDLocation2.setDirection(ac.bc().ba());
                bDLocation1 = bDLocation2;
              } 
            } 
          } catch (Exception exception) {}
          Message message = this.dm.d7.obtainMessage(21);
          message.obj = exception;
          message.sendToTarget();
          this.dp = null;
        } catch (Exception exception) {
          Message message = this.dm.d7.obtainMessage(63);
          message.obj = "HttpStatus error";
          message.sendToTarget();
        } 
      } else {
        ah.a().if("network exception");
        Message message = this.dm.d7.obtainMessage(63);
        message.obj = "HttpStatus error";
        message.sendToTarget();
      } 
      if (this.cP != null)
        this.cP.clear(); 
    }
    
    public void void(String param1String) {
      this.dn = param1String;
      J();
    }
  }
  
  public class b extends Handler {
    public b(ae this$0) {}
    
    public void handleMessage(Message param1Message) {
      if (!f.isServing);
      switch (param1Message.what) {
        default:
          return;
        case 21:
          this.a.byte(param1Message);
        case 62:
        case 63:
          break;
      } 
      this.a.ag();
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */