package com.baidu.location;

class aa$2 implements Runnable {
  aa$2(aa paramaa) {}
  
  public void run() {
    aa.if(this.a).removeCallbacks(aa.for(this.a));
    aa.if(this.a).removeCallbacks(aa.do(this.a));
    this.a.cz();
    this.a.cA();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aa$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */