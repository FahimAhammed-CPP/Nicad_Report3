package com.baidu.location;

import android.os.Handler;

class ab implements l, au {
  private static ab gJ;
  
  public Handler gI = null;
  
  private ab() {
    this.gI = new Handler();
  }
  
  public static ab a5() {
    if (gJ == null)
      gJ = new ab(); 
    return gJ;
  }
  
  public boolean a6() {
    return false;
  }
  
  public void a7() {
    /* monitor enter ThisExpression{ObjectType{com/baidu/location/ab}} */
    /* monitor exit ThisExpression{ObjectType{com/baidu/location/ab}} */
  }
  
  public boolean a8() {
    return false;
  }
  
  public void a9() {
    /* monitor enter ThisExpression{ObjectType{com/baidu/location/ab}} */
    /* monitor exit ThisExpression{ObjectType{com/baidu/location/ab}} */
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */