package com.baidu.location;

class av$1 implements Runnable {
  av$1(av paramav) {}
  
  public void run() {
    if (f.isServing)
      av.do(this.a); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/av$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */