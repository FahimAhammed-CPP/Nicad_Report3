package com.baidu.location;

interface z {
  public static final boolean Q = false;
  
  public static final boolean R = false;
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */