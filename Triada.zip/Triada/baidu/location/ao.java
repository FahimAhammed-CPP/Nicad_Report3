package com.baidu.location;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Pattern;

class ao implements au, l {
  private static ao hD = null;
  
  private static final int hu = 15;
  
  private long hA = 0L;
  
  private final long hB = 5000L;
  
  private WifiManager hC = null;
  
  private Method hE = null;
  
  private boolean hF = false;
  
  private long hG = 0L;
  
  private a hH = null;
  
  private final long ht = 3000L;
  
  private boolean hv = true;
  
  private long hw = 0L;
  
  private b hx = null;
  
  private Object hy = null;
  
  private final long hz = 3000L;
  
  public static boolean bA() {
    boolean bool;
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)f.getServiceContext().getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null) {
        int i = networkInfo.getType();
        if (i == 1)
          return true; 
      } 
      bool = false;
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  private void bB() {
    if (this.hC != null)
      try {
        List list = this.hC.getScanResults();
        b b1 = new b(this, list, this.hA);
        this.hA = 0L;
        if (this.hx == null || !b1.if(this.hx))
          this.hx = b1; 
      } catch (Exception exception) {} 
  }
  
  public static ao bC() {
    if (hD == null)
      hD = new ao(); 
    return hD;
  }
  
  public static double if(b paramb1, b paramb2) {
    // Byte code:
    //   0: dconst_1
    //   1: dstore_2
    //   2: aload_0
    //   3: ifnull -> 10
    //   6: aload_1
    //   7: ifnonnull -> 16
    //   10: dconst_0
    //   11: dstore #4
    //   13: dload #4
    //   15: dreturn
    //   16: aload_0
    //   17: getfield for : Ljava/util/List;
    //   20: astore_0
    //   21: aload_1
    //   22: getfield for : Ljava/util/List;
    //   25: astore_1
    //   26: dload_2
    //   27: dstore #4
    //   29: aload_0
    //   30: aload_1
    //   31: if_acmpeq -> 13
    //   34: aload_0
    //   35: ifnull -> 42
    //   38: aload_1
    //   39: ifnonnull -> 48
    //   42: dconst_0
    //   43: dstore #4
    //   45: goto -> 13
    //   48: aload_0
    //   49: invokeinterface size : ()I
    //   54: istore #6
    //   56: aload_1
    //   57: invokeinterface size : ()I
    //   62: istore #7
    //   64: iload #6
    //   66: iload #7
    //   68: iadd
    //   69: i2f
    //   70: fstore #8
    //   72: iload #6
    //   74: ifne -> 85
    //   77: dload_2
    //   78: dstore #4
    //   80: iload #7
    //   82: ifeq -> 13
    //   85: iload #6
    //   87: ifeq -> 95
    //   90: iload #7
    //   92: ifne -> 101
    //   95: dconst_0
    //   96: dstore #4
    //   98: goto -> 13
    //   101: iconst_0
    //   102: istore #9
    //   104: iconst_0
    //   105: istore #10
    //   107: iload #9
    //   109: iload #6
    //   111: if_icmpge -> 185
    //   114: aload_0
    //   115: iload #9
    //   117: invokeinterface get : (I)Ljava/lang/Object;
    //   122: checkcast android/net/wifi/ScanResult
    //   125: getfield BSSID : Ljava/lang/String;
    //   128: astore #11
    //   130: aload #11
    //   132: ifnonnull -> 141
    //   135: iinc #9, 1
    //   138: goto -> 107
    //   141: iconst_0
    //   142: istore #12
    //   144: iload #12
    //   146: iload #7
    //   148: if_icmpge -> 210
    //   151: aload #11
    //   153: aload_1
    //   154: iload #12
    //   156: invokeinterface get : (I)Ljava/lang/Object;
    //   161: checkcast android/net/wifi/ScanResult
    //   164: getfield BSSID : Ljava/lang/String;
    //   167: invokevirtual equals : (Ljava/lang/Object;)Z
    //   170: ifeq -> 179
    //   173: iinc #10, 1
    //   176: goto -> 135
    //   179: iinc #12, 1
    //   182: goto -> 144
    //   185: fload #8
    //   187: fconst_0
    //   188: fcmpg
    //   189: ifgt -> 198
    //   192: dconst_0
    //   193: dstore #4
    //   195: goto -> 13
    //   198: iload #10
    //   200: i2d
    //   201: fload #8
    //   203: f2d
    //   204: ddiv
    //   205: dstore #4
    //   207: goto -> 13
    //   210: goto -> 135
  }
  
  public static boolean if(b paramb1, b paramb2, float paramFloat) {
    if (paramb1 == null || paramb2 == null)
      return false; 
    List list1 = paramb1.for;
    List list2 = paramb2.for;
    if (list1 == list2)
      return true; 
    if (list1 == null || list2 == null)
      return false; 
    int i = list1.size();
    int j = list2.size();
    float f = (i + j);
    if (i == 0 && j == 0)
      return true; 
    if (i == 0 || j == 0)
      return false; 
    byte b1 = 0;
    byte b2 = 0;
    label43: while (b1 < i) {
      String str = ((ScanResult)list1.get(b1)).BSSID;
      if (str == null)
        continue; 
      byte b3 = 0;
      while (true) {
        if (b3 < j)
          if (str.equals(((ScanResult)list2.get(b3)).BSSID)) {
            b2++;
          } else {
            b3++;
            continue;
          }  
        b1++;
        continue label43;
      } 
    } 
    return ((b2 * 2) >= f * paramFloat);
  }
  
  private boolean o(String paramString) {
    return TextUtils.isEmpty(paramString) ? false : Pattern.compile("wpa|wep", 2).matcher(paramString).find();
  }
  
  public boolean bD() {
    boolean bool = false;
    if (this.hC != null && System.currentTimeMillis() - this.hA > 3000L)
      bool = bL(); 
    return bool;
  }
  
  public b bE() {
    if (this.hC != null)
      try {
        b b1 = new b();
        this(this, this.hC.getScanResults(), 0L);
        return b1;
      } catch (Exception exception) {} 
    return new b(this, null, 0L);
  }
  
  public boolean bF() {
    return (this.hC.isWifiEnabled() && 3 == this.hC.getWifiState());
  }
  
  public String bG() {
    String str2;
    String str1 = null;
    try {
      WifiInfo wifiInfo = this.hC.getConnectionInfo();
      str2 = str1;
      if (wifiInfo != null)
        str2 = wifiInfo.getMacAddress(); 
    } catch (Exception exception) {
      str2 = str1;
    } 
    return str2;
  }
  
  public b bH() {
    return (this.hx == null || !this.hx.new()) ? bE() : this.hx;
  }
  
  public void bI() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hF : Z
    //   6: istore_1
    //   7: iload_1
    //   8: iconst_1
    //   9: if_icmpne -> 15
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: getstatic com/baidu/location/f.isServing : Z
    //   18: ifeq -> 12
    //   21: aload_0
    //   22: invokestatic getServiceContext : ()Landroid/content/Context;
    //   25: ldc 'wifi'
    //   27: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   30: checkcast android/net/wifi/WifiManager
    //   33: putfield hC : Landroid/net/wifi/WifiManager;
    //   36: new com/baidu/location/ao$a
    //   39: astore_2
    //   40: aload_2
    //   41: aload_0
    //   42: aconst_null
    //   43: invokespecial <init> : (Lcom/baidu/location/ao;Lcom/baidu/location/ao$1;)V
    //   46: aload_0
    //   47: aload_2
    //   48: putfield hH : Lcom/baidu/location/ao$a;
    //   51: invokestatic getServiceContext : ()Landroid/content/Context;
    //   54: astore_2
    //   55: aload_0
    //   56: getfield hH : Lcom/baidu/location/ao$a;
    //   59: astore_3
    //   60: new android/content/IntentFilter
    //   63: astore #4
    //   65: aload #4
    //   67: ldc 'android.net.wifi.SCAN_RESULTS'
    //   69: invokespecial <init> : (Ljava/lang/String;)V
    //   72: aload_2
    //   73: aload_3
    //   74: aload #4
    //   76: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   79: pop
    //   80: aload_0
    //   81: iconst_1
    //   82: putfield hF : Z
    //   85: ldc 'android.net.wifi.WifiManager'
    //   87: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   90: ldc 'mService'
    //   92: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   95: astore_2
    //   96: aload_2
    //   97: ifnull -> 12
    //   100: aload_2
    //   101: iconst_1
    //   102: invokevirtual setAccessible : (Z)V
    //   105: aload_0
    //   106: aload_2
    //   107: aload_0
    //   108: getfield hC : Landroid/net/wifi/WifiManager;
    //   111: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   114: putfield hy : Ljava/lang/Object;
    //   117: aload_0
    //   118: aload_0
    //   119: getfield hy : Ljava/lang/Object;
    //   122: invokevirtual getClass : ()Ljava/lang/Class;
    //   125: ldc_w 'startScan'
    //   128: iconst_1
    //   129: anewarray java/lang/Class
    //   132: dup
    //   133: iconst_0
    //   134: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   137: aastore
    //   138: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   141: putfield hE : Ljava/lang/reflect/Method;
    //   144: aload_0
    //   145: getfield hE : Ljava/lang/reflect/Method;
    //   148: ifnull -> 12
    //   151: aload_0
    //   152: getfield hE : Ljava/lang/reflect/Method;
    //   155: iconst_1
    //   156: invokevirtual setAccessible : (Z)V
    //   159: goto -> 12
    //   162: astore_2
    //   163: goto -> 12
    //   166: astore_2
    //   167: aload_0
    //   168: monitorexit
    //   169: aload_2
    //   170: athrow
    //   171: astore_2
    //   172: goto -> 80
    // Exception table:
    //   from	to	target	type
    //   2	7	166	finally
    //   15	51	166	finally
    //   51	80	171	java/lang/Exception
    //   51	80	166	finally
    //   80	85	166	finally
    //   85	96	162	java/lang/Exception
    //   85	96	166	finally
    //   100	159	162	java/lang/Exception
    //   100	159	166	finally
  }
  
  public boolean bJ() {
    long l1 = System.currentTimeMillis();
    if (l1 - this.hG <= 10000L)
      return false; 
    this.hG = l1;
    return bD();
  }
  
  public String bK() {
    WifiInfo wifiInfo = null;
    null = this.hC.getConnectionInfo();
    if (null == null)
      return (String)wifiInfo; 
    try {
      String str = null.getBSSID();
      if (str != null) {
        String str1;
        String str2 = str.replace(":", "");
        WifiInfo wifiInfo1 = wifiInfo;
        if (!"000000000000".equals(str2)) {
          boolean bool = "".equals(str2);
          wifiInfo1 = wifiInfo;
          if (!bool)
            str1 = str2; 
        } 
        return str1;
      } 
    } catch (Exception exception) {
      return (String)wifiInfo;
    } 
    return null;
  }
  
  public boolean bL() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: getfield hC : Landroid/net/wifi/WifiManager;
    //   6: invokevirtual isWifiEnabled : ()Z
    //   9: ifeq -> 92
    //   12: aload_0
    //   13: getfield hE : Ljava/lang/reflect/Method;
    //   16: ifnull -> 81
    //   19: aload_0
    //   20: getfield hy : Ljava/lang/Object;
    //   23: astore_2
    //   24: aload_2
    //   25: ifnull -> 81
    //   28: aload_0
    //   29: getfield hE : Ljava/lang/reflect/Method;
    //   32: aload_0
    //   33: getfield hy : Ljava/lang/Object;
    //   36: iconst_1
    //   37: anewarray java/lang/Object
    //   40: dup
    //   41: iconst_0
    //   42: aload_0
    //   43: getfield hv : Z
    //   46: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   49: aastore
    //   50: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   53: pop
    //   54: aload_0
    //   55: invokestatic currentTimeMillis : ()J
    //   58: putfield hA : J
    //   61: iload_1
    //   62: ireturn
    //   63: astore_2
    //   64: aload_0
    //   65: getfield hC : Landroid/net/wifi/WifiManager;
    //   68: invokevirtual startScan : ()Z
    //   71: pop
    //   72: goto -> 54
    //   75: astore_2
    //   76: iconst_0
    //   77: istore_1
    //   78: goto -> 61
    //   81: aload_0
    //   82: getfield hC : Landroid/net/wifi/WifiManager;
    //   85: invokevirtual startScan : ()Z
    //   88: pop
    //   89: goto -> 54
    //   92: aload_0
    //   93: lconst_0
    //   94: putfield hA : J
    //   97: iconst_0
    //   98: istore_1
    //   99: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   2	24	75	java/lang/Exception
    //   28	54	63	java/lang/Exception
    //   54	61	75	java/lang/Exception
    //   64	72	75	java/lang/Exception
    //   81	89	75	java/lang/Exception
    //   92	97	75	java/lang/Exception
  }
  
  public b by() {
    return (this.hx == null || !this.hx.for()) ? bE() : this.hx;
  }
  
  public void bz() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hF : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifne -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: invokestatic getServiceContext : ()Landroid/content/Context;
    //   17: aload_0
    //   18: getfield hH : Lcom/baidu/location/ao$a;
    //   21: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   24: aload_0
    //   25: lconst_0
    //   26: putfield hw : J
    //   29: aload_0
    //   30: aconst_null
    //   31: putfield hH : Lcom/baidu/location/ao$a;
    //   34: aload_0
    //   35: aconst_null
    //   36: putfield hC : Landroid/net/wifi/WifiManager;
    //   39: aload_0
    //   40: iconst_0
    //   41: putfield hF : Z
    //   44: goto -> 11
    //   47: astore_2
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_2
    //   51: athrow
    //   52: astore_2
    //   53: goto -> 29
    // Exception table:
    //   from	to	target	type
    //   2	7	47	finally
    //   14	29	52	java/lang/Exception
    //   14	29	47	finally
    //   29	44	47	finally
  }
  
  private class a extends BroadcastReceiver {
    private a(ao this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      if (param1Context != null && param1Intent.getAction().equals("android.net.wifi.SCAN_RESULTS")) {
        ao.if(this.a, System.currentTimeMillis() / 1000L);
        ao.if(this.a);
        f.getHandler().obtainMessage(41).sendToTarget();
        if (ab.a5().a8())
          (ab.a5()).gI.obtainMessage(41).sendToTarget(); 
      } 
    }
  }
  
  protected class b {
    private boolean do = false;
    
    public List for = null;
    
    private long if = 0L;
    
    private long int = 0L;
    
    private boolean new;
    
    public b(ao this$0, b param1b) {
      if (param1b != null) {
        this.for = param1b.for;
        this.if = param1b.if;
        this.int = param1b.int;
        this.do = param1b.do;
      } 
    }
    
    public b(ao this$0, List param1List, long param1Long) {
      this.if = param1Long;
      this.for = param1List;
      this.int = System.currentTimeMillis();
      a();
      c.if("baidu_location_service", int());
    }
    
    private void a() {
      if (try() >= 1) {
        int i = this.for.size() - 1;
        boolean bool = true;
        while (true) {
          if (i >= 1 && bool) {
            byte b1 = 0;
            bool = false;
            while (b1 < i) {
              if (((ScanResult)this.for.get(b1)).level < ((ScanResult)this.for.get(b1 + 1)).level) {
                ScanResult scanResult = this.for.get(b1 + 1);
                this.for.set(b1 + 1, this.for.get(b1));
                this.for.set(b1, scanResult);
                bool = true;
              } 
              b1++;
            } 
            i--;
            continue;
          } 
          return;
        } 
      } 
    }
    
    public String a(int param1Int) {
      if (try() < 1)
        return null; 
      int i = 0;
      null = new Random();
      StringBuffer stringBuffer = new StringBuffer(512);
      String str = this.a.bK();
      int j = 0;
      int k = 0;
      int m = this.for.size();
      int n = 1;
      if (m > param1Int)
        m = param1Int; 
      byte b1 = 0;
      param1Int = i;
      while (b1 < m) {
        if (((ScanResult)this.for.get(b1)).level == 0) {
          i = n;
          n = param1Int;
          param1Int = k;
          k = i;
        } else {
          if (n != 0) {
            n = 0;
            stringBuffer.append("&wf=");
          } else {
            stringBuffer.append("|");
          } 
          String str1 = ((ScanResult)this.for.get(b1)).BSSID.replace(":", "");
          stringBuffer.append(str1);
          int i1 = ((ScanResult)this.for.get(b1)).level;
          i = i1;
          if (i1 < 0)
            i = -i1; 
          stringBuffer.append(String.format(Locale.CHINA, ";%d;", new Object[] { Integer.valueOf(i) }));
          i = j + 1;
          j = k;
          if (str != null) {
            j = k;
            if (str.equals(str1)) {
              this.new = ao.if(this.a, ((ScanResult)this.for.get(b1)).capabilities);
              j = i;
            } 
          } 
          if (param1Int == 0) {
            try {
              if (null.nextInt(10) == 2 && ((ScanResult)this.for.get(b1)).SSID != null && ((ScanResult)this.for.get(b1)).SSID.length() < 30) {
                stringBuffer.append(((ScanResult)this.for.get(b1)).SSID);
                param1Int = 1;
              } 
              i1 = param1Int;
              k = n;
              param1Int = j;
              j = i;
              n = i1;
            } catch (Exception exception) {
              k = n;
              n = param1Int;
              param1Int = j;
              j = i;
            } 
          } else {
            if (param1Int == 1 && null.nextInt(20) == 1 && ((ScanResult)this.for.get(b1)).SSID != null && ((ScanResult)this.for.get(b1)).SSID.length() < 30) {
              stringBuffer.append(((ScanResult)this.for.get(b1)).SSID);
              param1Int = 2;
            } 
            i1 = param1Int;
            k = n;
            param1Int = j;
            j = i;
            n = i1;
          } 
        } 
        b1++;
        i = param1Int;
        param1Int = n;
        n = k;
        k = i;
      } 
      if (n == 0) {
        stringBuffer.append("&wf_n=" + k);
        stringBuffer.append("&wf_st=");
        stringBuffer.append(this.if);
        stringBuffer.append("&wf_et=");
        stringBuffer.append(this.int);
        stringBuffer.append("&wf_vt=");
        stringBuffer.append(ao.do(this.a));
        if (k > 0) {
          this.do = true;
          stringBuffer.append("&wf_en=");
          if (this.new) {
            param1Int = 1;
          } else {
            param1Int = 0;
          } 
          stringBuffer.append(param1Int);
        } 
        return stringBuffer.toString();
      } 
      return null;
    }
    
    public boolean a(b param1b) {
      return ao.if(param1b, this, c.aS);
    }
    
    public String byte() {
      try {
        String str = a(15);
      } catch (Exception exception) {
        exception = null;
      } 
      return (String)exception;
    }
    
    public boolean case() {
      return this.do;
    }
    
    public String char() {
      try {
        String str = a(c.aV);
      } catch (Exception exception) {
        exception = null;
      } 
      return (String)exception;
    }
    
    public int do() {
      byte b1 = 0;
      byte b2 = 0;
      while (true) {
        int i = b1;
        if (b2 < try()) {
          i = -((ScanResult)this.for.get(b2)).level;
          if (i <= 0) {
            b2++;
            continue;
          } 
        } 
        return i;
      } 
    }
    
    public boolean do(b param1b) {
      // Byte code:
      //   0: aload_0
      //   1: getfield for : Ljava/util/List;
      //   4: ifnull -> 176
      //   7: aload_1
      //   8: ifnull -> 176
      //   11: aload_1
      //   12: getfield for : Ljava/util/List;
      //   15: ifnull -> 176
      //   18: aload_0
      //   19: getfield for : Ljava/util/List;
      //   22: invokeinterface size : ()I
      //   27: aload_1
      //   28: getfield for : Ljava/util/List;
      //   31: invokeinterface size : ()I
      //   36: if_icmpge -> 151
      //   39: aload_0
      //   40: getfield for : Ljava/util/List;
      //   43: invokeinterface size : ()I
      //   48: istore_2
      //   49: iconst_0
      //   50: istore_3
      //   51: iload_3
      //   52: iload_2
      //   53: if_icmpge -> 170
      //   56: aload_0
      //   57: getfield for : Ljava/util/List;
      //   60: iload_3
      //   61: invokeinterface get : (I)Ljava/lang/Object;
      //   66: checkcast android/net/wifi/ScanResult
      //   69: getfield BSSID : Ljava/lang/String;
      //   72: astore #4
      //   74: aload_0
      //   75: getfield for : Ljava/util/List;
      //   78: iload_3
      //   79: invokeinterface get : (I)Ljava/lang/Object;
      //   84: checkcast android/net/wifi/ScanResult
      //   87: getfield level : I
      //   90: istore #5
      //   92: aload_1
      //   93: getfield for : Ljava/util/List;
      //   96: iload_3
      //   97: invokeinterface get : (I)Ljava/lang/Object;
      //   102: checkcast android/net/wifi/ScanResult
      //   105: getfield BSSID : Ljava/lang/String;
      //   108: astore #6
      //   110: aload_1
      //   111: getfield for : Ljava/util/List;
      //   114: iload_3
      //   115: invokeinterface get : (I)Ljava/lang/Object;
      //   120: checkcast android/net/wifi/ScanResult
      //   123: getfield level : I
      //   126: istore #7
      //   128: aload #4
      //   130: aload #6
      //   132: invokevirtual equals : (Ljava/lang/Object;)Z
      //   135: ifeq -> 145
      //   138: iload #5
      //   140: iload #7
      //   142: if_icmpeq -> 164
      //   145: iconst_0
      //   146: istore #8
      //   148: iload #8
      //   150: ireturn
      //   151: aload_1
      //   152: getfield for : Ljava/util/List;
      //   155: invokeinterface size : ()I
      //   160: istore_2
      //   161: goto -> 49
      //   164: iinc #3, 1
      //   167: goto -> 51
      //   170: iconst_1
      //   171: istore #8
      //   173: goto -> 148
      //   176: iconst_0
      //   177: istore #8
      //   179: goto -> 148
    }
    
    public String else() {
      StringBuffer stringBuffer = new StringBuffer(512);
      stringBuffer.append("wifi info:");
      if (try() < 1)
        return stringBuffer.toString(); 
      int i = this.for.size();
      int j = i;
      if (i > 10)
        j = 10; 
      byte b1 = 0;
      i = 1;
      while (b1 < j) {
        if (((ScanResult)this.for.get(b1)).level != 0)
          if (i != 0) {
            stringBuffer.append("wifi=");
            stringBuffer.append(((ScanResult)this.for.get(b1)).BSSID.replace(":", ""));
            i = ((ScanResult)this.for.get(b1)).level;
            stringBuffer.append(String.format(Locale.CHINA, ";%d;", new Object[] { Integer.valueOf(i) }));
            i = 0;
          } else {
            stringBuffer.append(";");
            stringBuffer.append(((ScanResult)this.for.get(b1)).BSSID.replace(":", ""));
            int k = ((ScanResult)this.for.get(b1)).level;
            stringBuffer.append(String.format(Locale.CHINA, ",%d;", new Object[] { Integer.valueOf(k) }));
          }  
        b1++;
      } 
      return stringBuffer.toString();
    }
    
    public boolean for() {
      return (System.currentTimeMillis() - this.int < 3000L);
    }
    
    public String if(int param1Int) {
      if (param1Int == 0 || try() < 1)
        return null; 
      StringBuffer stringBuffer = new StringBuffer(256);
      int i = 0;
      int j = 1;
      byte b1 = 0;
      while (b1 < c.aV) {
        int k = i;
        if ((j & param1Int) != 0) {
          if (!i) {
            stringBuffer.append("&ssid=");
          } else {
            stringBuffer.append("|");
          } 
          stringBuffer.append(((ScanResult)this.for.get(b1)).BSSID);
          stringBuffer.append(";");
          stringBuffer.append(((ScanResult)this.for.get(b1)).SSID);
          k = i + 1;
        } 
        j <<= 1;
        b1++;
        i = k;
      } 
      return stringBuffer.toString();
    }
    
    public boolean if() {
      return (System.currentTimeMillis() - this.if < 3000L);
    }
    
    public boolean if(b param1b) {
      // Byte code:
      //   0: aload_0
      //   1: getfield for : Ljava/util/List;
      //   4: ifnull -> 125
      //   7: aload_1
      //   8: ifnull -> 125
      //   11: aload_1
      //   12: getfield for : Ljava/util/List;
      //   15: ifnull -> 125
      //   18: aload_0
      //   19: getfield for : Ljava/util/List;
      //   22: invokeinterface size : ()I
      //   27: aload_1
      //   28: getfield for : Ljava/util/List;
      //   31: invokeinterface size : ()I
      //   36: if_icmpge -> 100
      //   39: aload_0
      //   40: getfield for : Ljava/util/List;
      //   43: invokeinterface size : ()I
      //   48: istore_2
      //   49: iconst_0
      //   50: istore_3
      //   51: iload_3
      //   52: iload_2
      //   53: if_icmpge -> 119
      //   56: aload_0
      //   57: getfield for : Ljava/util/List;
      //   60: iload_3
      //   61: invokeinterface get : (I)Ljava/lang/Object;
      //   66: checkcast android/net/wifi/ScanResult
      //   69: getfield BSSID : Ljava/lang/String;
      //   72: aload_1
      //   73: getfield for : Ljava/util/List;
      //   76: iload_3
      //   77: invokeinterface get : (I)Ljava/lang/Object;
      //   82: checkcast android/net/wifi/ScanResult
      //   85: getfield BSSID : Ljava/lang/String;
      //   88: invokevirtual equals : (Ljava/lang/Object;)Z
      //   91: ifne -> 113
      //   94: iconst_0
      //   95: istore #4
      //   97: iload #4
      //   99: ireturn
      //   100: aload_1
      //   101: getfield for : Ljava/util/List;
      //   104: invokeinterface size : ()I
      //   109: istore_2
      //   110: goto -> 49
      //   113: iinc #3, 1
      //   116: goto -> 51
      //   119: iconst_1
      //   120: istore #4
      //   122: goto -> 97
      //   125: iconst_0
      //   126: istore #4
      //   128: goto -> 97
    }
    
    public String int() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("wifi=");
      if (this.for == null)
        return stringBuilder.toString(); 
      for (byte b1 = 0; b1 < this.for.size(); b1++) {
        int i = ((ScanResult)this.for.get(b1)).level;
        stringBuilder.append(((ScanResult)this.for.get(b1)).BSSID.replace(":", ""));
        stringBuilder.append(String.format(Locale.CHINA, ",%d;", new Object[] { Integer.valueOf(i) }));
      } 
      return stringBuilder.toString();
    }
    
    public boolean new() {
      return (System.currentTimeMillis() - this.int < 5000L);
    }
    
    public int try() {
      return (this.for == null) ? 0 : this.for.size();
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */