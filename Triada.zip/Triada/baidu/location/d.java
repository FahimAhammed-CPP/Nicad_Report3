package com.baidu.location;

import java.text.SimpleDateFormat;

class d implements au, l {
  private static d bo = null;
  
  private long bl = 0L;
  
  public long bm = 0L;
  
  private long bn = 0L;
  
  public boolean bp = false;
  
  public static d long() {
    if (bo == null)
      bo = new d(); 
    return bo;
  }
  
  public long int(String paramString) {
    long l1;
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss");
      l1 = simpleDateFormat.parse(paramString).getTime();
    } catch (Exception exception) {
      l1 = -1L;
    } 
    return l1;
  }
  
  public void new(String paramString) {
    if (!this.bp) {
      this.bn = System.currentTimeMillis();
      long l1 = (this.bn - this.bl) / 2L;
      if (l1 <= 3000L && l1 >= 0L) {
        long l2 = int(paramString);
        if (l2 > 0L) {
          this.bm = l1 + l2 - System.currentTimeMillis();
          this.bp = false;
        } 
      } 
    } 
  }
  
  public void void() {
    if (!this.bp)
      this.bl = System.currentTimeMillis(); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */