package com.baidu.location;

import android.os.Handler;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.http.message.BasicNameValuePair;

class m extends q {
  public static final int c2 = 1;
  
  static m c4 = null;
  
  private int c1 = 0;
  
  private a c3 = null;
  
  boolean c5 = false;
  
  int c6 = 0;
  
  long c7 = 0L;
  
  long c8 = 0L;
  
  ArrayList c9 = null;
  
  private Handler da = null;
  
  public m() {
    this.c3 = new a(this);
    this.cW = 2;
    this.da = new m$1(this);
  }
  
  public static m R() {
    if (c4 == null)
      c4 = new m(); 
    return c4;
  }
  
  private void S() {
    if (cU < 6 && this.c1 < 10 && at.do().int()) {
      this.c1++;
      if (!Q())
        this.c1 = 0; 
      return;
    } 
    this.c1 = 0;
  }
  
  void O() {
    this.cP.add(new BasicNameValuePair("qt", "cltr"));
    try {
      List<BasicNameValuePair> list = this.cP;
      BasicNameValuePair basicNameValuePair = new BasicNameValuePair();
      this("info", Jni.h(aw.b6().b7()));
      list.add(basicNameValuePair);
    } catch (Exception exception) {}
    for (byte b = 0; b < this.c9.size(); b++)
      this.cP.add(new BasicNameValuePair("cltr[" + b + "]", this.c9.get(b))); 
    String str = String.format(Locale.CHINA, "%d", new Object[] { Long.valueOf(System.currentTimeMillis()) });
    this.cP.add(new BasicNameValuePair("trtm", str));
  }
  
  public boolean Q() {
    boolean bool = true;
    if (!ao.bA())
      return false; 
    if (this.c3.cY > 2) {
      a a1 = this.c3;
      a1.cY--;
      return for(true);
    } 
    if (!this.c3.P())
      bool = for(true); 
    return bool;
  }
  
  public void do(int paramInt) {
    this.da.sendEmptyMessageDelayed(paramInt, 500L);
  }
  
  void do(boolean paramBoolean) {
    if (paramBoolean && this.cO != null) {
      if (this.c9 != null)
        this.c9.clear(); 
    } else {
      this.c7 = 0L;
    } 
    if (this.cP != null)
      this.cP.clear(); 
    this.c5 = false;
    this.da.sendEmptyMessageDelayed(1, 1500L);
  }
  
  public boolean for(boolean paramBoolean) {
    boolean bool = true;
    if (this.c5)
      return bool; 
    if (System.currentTimeMillis() - this.c7 < 7200000L)
      return false; 
    if (System.currentTimeMillis() - this.c8 > 3600000L)
      this.c6 = 0; 
    if (this.c6 > 5 && paramBoolean)
      return false; 
    if (!ao.bA())
      return false; 
    if (!at.do().int() && paramBoolean)
      return false; 
    if (this.c9 == null || this.c9.size() < 1) {
      String str = c.try();
      if (str != null) {
        byte b = 0;
        while (b < 2) {
          String str1 = Jni.j(str);
          if (str1 != null) {
            if (this.c9 == null)
              this.c9 = new ArrayList(); 
            this.c9.add(str1);
            b++;
            continue;
          } 
          this.c7 = System.currentTimeMillis();
        } 
      } else {
        return false;
      } 
    } 
    if (this.c9 != null && this.c9.size() > 0) {
      this.c6++;
      this.c8 = System.currentTimeMillis();
      this.c5 = true;
      J();
      return bool;
    } 
    return false;
  }
  
  class a extends q {
    String c0 = null;
    
    int cY = 0;
    
    boolean cZ = false;
    
    a(m this$0) {}
    
    void O() {
      this.cS = this.c0;
      this.cN = c.do() + "?&qt=state&trtm=" + System.currentTimeMillis();
      this.cW = 2;
    }
    
    public boolean P() {
      boolean bool = true;
      if (!this.cZ) {
        this.c0 = aa.cx().cr();
        if (this.c0 == null)
          return false; 
        this.cZ = true;
        M();
      } 
      return bool;
    }
    
    void do(boolean param1Boolean) {
      if (param1Boolean) {
        try {
          File file = new File();
          this(this.c0);
          file.delete();
          this.cY = 0;
        } catch (Exception exception) {}
      } else {
        this.cY += 2;
      } 
      this.c0 = null;
      this.cZ = false;
      m.do(this.cX).sendEmptyMessageDelayed(1, 1500L);
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */