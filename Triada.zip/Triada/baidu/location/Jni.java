package com.baidu.location;

class Jni implements au, l {
  private static int e0;
  
  private static int e1;
  
  private static int e2;
  
  private static boolean e3;
  
  private static int e4;
  
  private static int e5;
  
  private static int e6 = 0;
  
  private static int eY;
  
  private static int eZ;
  
  static {
    e4 = 1;
    e5 = 2;
    e1 = 11;
    e2 = 12;
    eZ = 13;
    eY = 14;
    e0 = 1024;
    e3 = false;
    try {
      System.loadLibrary("locSDK4b");
      return;
    } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
      unsatisfiedLinkError.printStackTrace();
      e3 = true;
      throw new IllegalStateException("no found the liblocSDK4b.so file, please correct settings");
    } 
  }
  
  private static native String a(byte[] paramArrayOfbyte, int paramInt);
  
  private static native String b(double paramDouble1, double paramDouble2, int paramInt1, int paramInt2);
  
  private static native String c(byte[] paramArrayOfbyte, int paramInt);
  
  private static native void f(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2);
  
  public static void for(String paramString1, String paramString2) {
    try {
      f(paramString1.getBytes(), paramString2.getBytes());
    } catch (Exception exception) {}
  }
  
  private static native String g(byte[] paramArrayOfbyte);
  
  public static String h(String paramString) {
    int i = 740;
    byte b = 0;
    if (e3)
      return "err!"; 
    byte[] arrayOfByte1 = paramString.getBytes();
    byte[] arrayOfByte2 = new byte[e0];
    int j = arrayOfByte1.length;
    if (j <= 740)
      i = j; 
    for (j = 0; b < i; j = k) {
      int k = j;
      if (arrayOfByte1[b] != 0) {
        arrayOfByte2[j] = (byte)arrayOfByte1[b];
        k = j + 1;
      } 
      b++;
    } 
    return a(arrayOfByte2, 132456) + "|tp=3";
  }
  
  public static String i(String paramString) {
    return e3 ? "err!" : c(paramString.getBytes(), 132456);
  }
  
  public static double[] if(double paramDouble1, double paramDouble2, String paramString) {
    double[] arrayOfDouble = new double[2];
    arrayOfDouble[0] = 0.0D;
    arrayOfDouble[1] = 0.0D;
    if (!e3) {
      int i = -1;
      if (paramString.equals("bd09")) {
        i = e6;
      } else if (paramString.equals("bd09ll")) {
        i = e4;
      } else if (paramString.equals("gcj02")) {
        i = e5;
      } else if (paramString.equals("gps2gcj")) {
        i = e1;
      } else if (paramString.equals("bd092gcj")) {
        i = e2;
      } else if (paramString.equals("bd09ll2gcj")) {
        i = eZ;
      } 
      try {
        String[] arrayOfString = b(paramDouble1, paramDouble2, i, 132456).split(":");
        arrayOfDouble[0] = Double.parseDouble(arrayOfString[0]);
        arrayOfDouble[1] = Double.parseDouble(arrayOfString[1]);
      } catch (Exception exception) {}
    } 
    return arrayOfDouble;
  }
  
  public static String j(String paramString) {
    String str1;
    String str2 = null;
    try {
      String str = g(paramString.getBytes());
      if (str == null)
        return str2; 
      paramString = str2;
      if (str.length() >= 2) {
        paramString = str2;
        if (!"no".equals(str))
          paramString = str; 
      } 
    } catch (Exception exception) {
      str1 = str2;
    } 
    return str1;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/Jni.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */