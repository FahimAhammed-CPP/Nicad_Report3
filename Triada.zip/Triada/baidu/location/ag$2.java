package com.baidu.location;

import java.util.TimerTask;

class ag$2 extends TimerTask {
  ag$2(ag paramag) {}
  
  public void run() {
    ag.if(this.a);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ag$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */