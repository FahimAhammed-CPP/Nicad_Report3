package com.baidu.location;

interface n {
  void bM();
  
  boolean do(ao.b paramb);
  
  int try(BDLocation paramBDLocation);
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */