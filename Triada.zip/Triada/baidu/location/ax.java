package com.baidu.location;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.Messenger;
import android.os.PowerManager;
import com.baidu.location.b.a.a;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

class ax implements l {
  public static final String i0 = "http://loc.map.baidu.com/fence";
  
  private static final String i3 = "&gf=1";
  
  private static final String iC = "GeofenceStrategyService";
  
  private static final int iD = 30000;
  
  private static final int iE = 360000;
  
  private static final int iG = 6;
  
  private static final String iJ = "GeofenceStrategyService";
  
  public static final long iM = 21600000L;
  
  private static final String iN = "1";
  
  private static final String iS = "com.baidu.locsdk.geofence.geofencestrategyservice";
  
  private static final int iT = 180000;
  
  private static final int iV = 60000;
  
  public static ax iX;
  
  private static final String iZ = "0";
  
  private String i1;
  
  private ao.b i2;
  
  private List i4;
  
  private ao.b i5;
  
  private String iF;
  
  private boolean iH;
  
  private boolean iI;
  
  private String iK;
  
  private d iL;
  
  private Handler iO = new Handler();
  
  private String iP;
  
  private c iQ;
  
  private PowerManager.WakeLock iR;
  
  private int iU;
  
  private HandlerThread iW;
  
  private Messenger iY;
  
  private void b9() {
    if (this.iR != null && this.iR.isHeld()) {
      this.iR.release();
      this.iR = null;
    } 
  }
  
  private boolean ca() {
    boolean bool = true;
    if (this.i2 != null) {
      if (this.i5 == this.i2)
        return false; 
      if (this.i2.a(this.i5))
        bool = false; 
    } 
    return bool;
  }
  
  private void cb() {
    if (this.iH) {
      if(f.getServiceContext(), 30000);
      return;
    } 
    if (this.iU > 0) {
      int i;
      Context context = f.getServiceContext();
      if (this.iU >= 6) {
        i = 180000;
      } else {
        i = this.iU * 30000;
      } 
      if(context, i);
      return;
    } 
    if (this.i4 != null && this.i4.size() > 0) {
      Iterator<an> iterator = this.i4.iterator();
      boolean bool;
      for (bool = false; iterator.hasNext(); bool = bool1) {
        an an = iterator.next();
        boolean bool1 = bool;
        if (!an.if()) {
          bool1 = bool;
          if (!an.for()) {
            bool1 = true;
            do(an);
          } 
        } 
      } 
      if (bool) {
        if(f.getServiceContext(), 30000);
        return;
      } 
      if(f.getServiceContext(), 180000);
      return;
    } 
    if(f.getServiceContext(), 360000);
  }
  
  private void cc() {
    List list = for(ce());
    if (list != null) {
      if (!this.iK.equals(this.iP) || ca())
        for (an an : list) {
          int i;
          if (an != null) {
            this.iH = true;
            do(an);
            this.iP = this.iK;
            this.i2 = this.i5;
            this.iU = 0;
            continue;
          } 
          this.iH = false;
          this.iU++;
          if (this.iU == Integer.MAX_VALUE) {
            i = 1;
          } else {
            i = this.iU;
          } 
          this.iU = i;
        }  
    } else {
      this.iH = false;
    } 
  }
  
  private void cd() {
    this.iW = new HandlerThread("GeofenceStrategyService", 10);
    this.iW.start();
    this.iO = new Handler(this.iW.getLooper());
    this.iL = new d();
  }
  
  private List ce() {
    r.a a = r.aa().X();
    this.i5 = ao.bC().by();
    ArrayList<String> arrayList = new ArrayList();
    this.iK = String.format("%s|%s|%s|%s", new Object[] { Integer.valueOf(a.do), Integer.valueOf(a.if), Integer.valueOf(a.for), Integer.valueOf(a.try) });
    arrayList.add(this.iK);
    if (this.i5 != null) {
      List list = this.i5.for;
      if (list != null)
        for (ScanResult scanResult : list) {
          if (scanResult != null)
            arrayList.add(scanResult.BSSID.replace(":", "")); 
        }  
    } 
    return arrayList;
  }
  
  public static ax cf() {
    if (iX == null) {
      iX = new ax();
      iX.cd();
    } 
    return iX;
  }
  
  private void do(an paraman) {
    (new a(this, paraman, Jni.h((new b()).d("&gf=1").replace("gcj02", paraman.int())))).W();
  }
  
  private void new(Context paramContext) {
    if (this.iR == null) {
      this.iR = ((PowerManager)paramContext.getSystemService("power")).newWakeLock(1, "GeofenceStrategyService");
      this.iR.setReferenceCounted(false);
      this.iR.acquire(60000L);
    } 
  }
  
  public void byte(Context paramContext) {
    this.iI = false;
    g.a(paramContext, PendingIntent.getBroadcast(paramContext, 0, new Intent("com.baidu.locsdk.geofence.geofencestrategyservice"), 134217728));
    b9();
    if (this.iQ != null)
      try {
        paramContext.unregisterReceiver(this.iQ);
      } catch (Exception exception) {} 
  }
  
  public List for(List paramList) {
    // Byte code:
    //   0: invokestatic getServiceContext : ()Landroid/content/Context;
    //   3: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   6: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   9: astore_2
    //   10: aconst_null
    //   11: astore_3
    //   12: aconst_null
    //   13: astore #4
    //   15: aconst_null
    //   16: astore #5
    //   18: aload_2
    //   19: ifnull -> 518
    //   22: aconst_null
    //   23: astore_3
    //   24: invokestatic currentTimeMillis : ()J
    //   27: lstore #6
    //   29: aload_1
    //   30: invokeinterface iterator : ()Ljava/util/Iterator;
    //   35: astore #8
    //   37: aconst_null
    //   38: astore_1
    //   39: aload #8
    //   41: invokeinterface hasNext : ()Z
    //   46: ifeq -> 498
    //   49: aload #8
    //   51: invokeinterface next : ()Ljava/lang/Object;
    //   56: checkcast java/lang/String
    //   59: astore #4
    //   61: aload_2
    //   62: ldc_w 'SELECT b.geofence_id, b.longitude, b.latitude, b.radius, b.coord_type, b.duration_millis, b.is_lac, b.is_cell, b.is_wifi, b.radius_type FROM %s AS a LEFT JOIN %s AS b WHERE (a.geofence_id = b.geofence_id) AND (a.ap = '%s' AND  (b.valid_date + b.duration_millis) >= %d) AND (b.next_active_time < %d)'
    //   65: iconst_5
    //   66: anewarray java/lang/Object
    //   69: dup
    //   70: iconst_0
    //   71: ldc_w 'geofence_detail'
    //   74: aastore
    //   75: dup
    //   76: iconst_1
    //   77: ldc_w 'geofence'
    //   80: aastore
    //   81: dup
    //   82: iconst_2
    //   83: aload #4
    //   85: invokestatic i : (Ljava/lang/String;)Ljava/lang/String;
    //   88: aastore
    //   89: dup
    //   90: iconst_3
    //   91: lload #6
    //   93: invokestatic valueOf : (J)Ljava/lang/Long;
    //   96: aastore
    //   97: dup
    //   98: iconst_4
    //   99: lload #6
    //   101: invokestatic valueOf : (J)Ljava/lang/Long;
    //   104: aastore
    //   105: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   108: aconst_null
    //   109: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   112: astore_3
    //   113: aload_3
    //   114: astore_1
    //   115: aload_1
    //   116: ifnull -> 589
    //   119: aload_1
    //   120: invokeinterface getCount : ()I
    //   125: ifle -> 589
    //   128: new java/util/ArrayList
    //   131: astore_3
    //   132: aload_3
    //   133: invokespecial <init> : ()V
    //   136: aload_3
    //   137: invokeinterface clear : ()V
    //   142: aload_1
    //   143: invokeinterface moveToFirst : ()Z
    //   148: pop
    //   149: aload_1
    //   150: ldc_w 'geofence_id'
    //   153: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   158: istore #9
    //   160: aload_1
    //   161: ldc_w 'longitude'
    //   164: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   169: istore #10
    //   171: aload_1
    //   172: ldc_w 'latitude'
    //   175: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   180: istore #11
    //   182: aload_1
    //   183: ldc_w 'radius'
    //   186: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   191: istore #12
    //   193: aload_1
    //   194: ldc_w 'coord_type'
    //   197: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   202: istore #13
    //   204: aload_1
    //   205: ldc_w 'duration_millis'
    //   208: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   213: istore #14
    //   215: aload_1
    //   216: ldc_w 'is_lac'
    //   219: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   224: istore #15
    //   226: aload_1
    //   227: ldc_w 'is_cell'
    //   230: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   235: istore #16
    //   237: aload_1
    //   238: ldc_w 'is_wifi'
    //   241: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   246: istore #17
    //   248: aload_1
    //   249: ldc_w 'radius_type'
    //   252: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   257: istore #18
    //   259: aload_0
    //   260: aload #4
    //   262: putfield i1 : Ljava/lang/String;
    //   265: aload_1
    //   266: iload #9
    //   268: invokeinterface getString : (I)Ljava/lang/String;
    //   273: astore #5
    //   275: aload_1
    //   276: iload #10
    //   278: invokeinterface getString : (I)Ljava/lang/String;
    //   283: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   286: invokevirtual floatValue : ()F
    //   289: fstore #19
    //   291: aload_1
    //   292: iload #11
    //   294: invokeinterface getString : (I)Ljava/lang/String;
    //   299: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   302: invokevirtual floatValue : ()F
    //   305: fstore #20
    //   307: aload_1
    //   308: iload #12
    //   310: invokeinterface getString : (I)Ljava/lang/String;
    //   315: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   318: invokevirtual floatValue : ()F
    //   321: fstore #21
    //   323: aload_1
    //   324: iload #13
    //   326: invokeinterface getString : (I)Ljava/lang/String;
    //   331: astore #22
    //   333: aload_1
    //   334: iload #14
    //   336: invokeinterface getLong : (I)J
    //   341: lstore #23
    //   343: aload_1
    //   344: iload #15
    //   346: invokeinterface getInt : (I)I
    //   351: ifeq -> 480
    //   354: iconst_1
    //   355: istore #25
    //   357: aload_1
    //   358: iload #16
    //   360: invokeinterface getInt : (I)I
    //   365: ifeq -> 486
    //   368: iconst_1
    //   369: istore #26
    //   371: aload_1
    //   372: iload #17
    //   374: invokeinterface getInt : (I)I
    //   379: ifeq -> 492
    //   382: iconst_1
    //   383: istore #27
    //   385: aload_1
    //   386: iload #18
    //   388: invokeinterface getInt : (I)I
    //   393: istore #28
    //   395: new com/baidu/location/an
    //   398: astore #29
    //   400: aload #29
    //   402: aload #5
    //   404: fload #19
    //   406: f2d
    //   407: fload #20
    //   409: f2d
    //   410: iload #28
    //   412: lload #23
    //   414: aload #22
    //   416: invokespecial <init> : (Ljava/lang/String;DDIJLjava/lang/String;)V
    //   419: aload #29
    //   421: ifnull -> 452
    //   424: aload #29
    //   426: fload #21
    //   428: invokevirtual a : (F)V
    //   431: aload #29
    //   433: iload #25
    //   435: invokevirtual do : (Z)V
    //   438: aload #29
    //   440: iload #26
    //   442: invokevirtual a : (Z)V
    //   445: aload #29
    //   447: iload #27
    //   449: invokevirtual if : (Z)V
    //   452: aload_3
    //   453: aload #29
    //   455: invokeinterface add : (Ljava/lang/Object;)Z
    //   460: pop
    //   461: aload_1
    //   462: invokeinterface moveToNext : ()Z
    //   467: istore #25
    //   469: iload #25
    //   471: ifne -> 259
    //   474: aload_3
    //   475: astore #5
    //   477: goto -> 39
    //   480: iconst_0
    //   481: istore #25
    //   483: goto -> 357
    //   486: iconst_0
    //   487: istore #26
    //   489: goto -> 371
    //   492: iconst_0
    //   493: istore #27
    //   495: goto -> 385
    //   498: aload #5
    //   500: astore_3
    //   501: aload_1
    //   502: ifnull -> 514
    //   505: aload_1
    //   506: invokeinterface close : ()V
    //   511: aload #5
    //   513: astore_3
    //   514: aload_2
    //   515: invokevirtual close : ()V
    //   518: aload_3
    //   519: areturn
    //   520: astore_1
    //   521: aload #4
    //   523: astore #5
    //   525: aload_3
    //   526: astore_1
    //   527: aload #5
    //   529: astore_3
    //   530: aload_1
    //   531: ifnull -> 514
    //   534: aload_1
    //   535: invokeinterface close : ()V
    //   540: aload #5
    //   542: astore_3
    //   543: goto -> 514
    //   546: astore #5
    //   548: aconst_null
    //   549: astore_1
    //   550: aload_1
    //   551: ifnull -> 560
    //   554: aload_1
    //   555: invokeinterface close : ()V
    //   560: aload #5
    //   562: athrow
    //   563: astore #5
    //   565: goto -> 550
    //   568: astore #5
    //   570: goto -> 550
    //   573: astore #5
    //   575: aload_3
    //   576: astore #5
    //   578: goto -> 527
    //   581: astore_3
    //   582: goto -> 527
    //   585: astore_3
    //   586: goto -> 527
    //   589: goto -> 477
    // Exception table:
    //   from	to	target	type
    //   24	37	520	java/lang/Exception
    //   24	37	546	finally
    //   39	113	581	java/lang/Exception
    //   39	113	568	finally
    //   119	136	585	java/lang/Exception
    //   119	136	563	finally
    //   136	259	573	java/lang/Exception
    //   136	259	563	finally
    //   259	354	573	java/lang/Exception
    //   259	354	563	finally
    //   357	368	573	java/lang/Exception
    //   357	368	563	finally
    //   371	382	573	java/lang/Exception
    //   371	382	563	finally
    //   385	419	573	java/lang/Exception
    //   385	419	563	finally
    //   424	452	573	java/lang/Exception
    //   424	452	563	finally
    //   452	469	573	java/lang/Exception
    //   452	469	563	finally
  }
  
  public void if(Context paramContext, int paramInt) {
    Intent intent = new Intent("com.baidu.locsdk.geofence.geofencestrategyservice");
    PendingIntent pendingIntent = PendingIntent.getBroadcast(paramContext, 0, intent, 134217728);
    if (paramInt <= 0) {
      g.a(paramContext, pendingIntent);
      paramContext.sendBroadcast(intent);
      return;
    } 
    g.a(paramContext, pendingIntent, paramInt);
  }
  
  public void if(Context paramContext, Message paramMessage) {
    if (!this.iI) {
      this.iY = paramMessage.replyTo;
      this.iI = true;
      this.iQ = new c(this);
      paramContext.registerReceiver(this.iQ, new IntentFilter("com.baidu.locsdk.geofence.geofencestrategyservice"));
      if(paramContext, 0);
    } 
  }
  
  public List s(String paramString) {
    // Byte code:
    //   0: invokestatic getServiceContext : ()Landroid/content/Context;
    //   3: invokestatic a : (Landroid/content/Context;)Lcom/baidu/location/k;
    //   6: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   9: astore_2
    //   10: aconst_null
    //   11: astore_3
    //   12: aconst_null
    //   13: astore #4
    //   15: aconst_null
    //   16: astore #5
    //   18: aload_2
    //   19: ifnull -> 448
    //   22: aconst_null
    //   23: astore #6
    //   25: invokestatic currentTimeMillis : ()J
    //   28: lstore #7
    //   30: aload_2
    //   31: ldc_w 'SELECT b.geofence_id, b.longitude, b.latitude, b.radius, b.coord_type, b.duration_millis, b.is_lac, b.is_cell, b.is_wifi, b.radius_type FROM %s AS a LEFT JOIN %s AS b WHERE (a.geofence_id = b.geofence_id) AND (a.ap = '%s' AND  (b.valid_date + b.duration_millis >= %d) AND b.next_active_time < %d)'
    //   34: iconst_5
    //   35: anewarray java/lang/Object
    //   38: dup
    //   39: iconst_0
    //   40: ldc_w 'geofence_detail'
    //   43: aastore
    //   44: dup
    //   45: iconst_1
    //   46: ldc_w 'geofence'
    //   49: aastore
    //   50: dup
    //   51: iconst_2
    //   52: aload_1
    //   53: aastore
    //   54: dup
    //   55: iconst_3
    //   56: lload #7
    //   58: invokestatic valueOf : (J)Ljava/lang/Long;
    //   61: aastore
    //   62: dup
    //   63: iconst_4
    //   64: lload #7
    //   66: invokestatic valueOf : (J)Ljava/lang/Long;
    //   69: aastore
    //   70: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   73: aconst_null
    //   74: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   77: astore_1
    //   78: aload #5
    //   80: astore #6
    //   82: aload_1
    //   83: ifnull -> 428
    //   86: aload #5
    //   88: astore #6
    //   90: aload_1
    //   91: invokeinterface getCount : ()I
    //   96: ifle -> 428
    //   99: new java/util/ArrayList
    //   102: astore #6
    //   104: aload #6
    //   106: invokespecial <init> : ()V
    //   109: aload_1
    //   110: invokeinterface moveToFirst : ()Z
    //   115: pop
    //   116: aload_1
    //   117: ldc_w 'geofence_id'
    //   120: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   125: istore #9
    //   127: aload_1
    //   128: ldc_w 'longitude'
    //   131: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   136: istore #10
    //   138: aload_1
    //   139: ldc_w 'latitude'
    //   142: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   147: istore #11
    //   149: aload_1
    //   150: ldc_w 'radius'
    //   153: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   158: istore #12
    //   160: aload_1
    //   161: ldc_w 'coord_type'
    //   164: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   169: istore #13
    //   171: aload_1
    //   172: ldc_w 'duration_millis'
    //   175: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   180: istore #14
    //   182: aload_1
    //   183: ldc_w 'is_lac'
    //   186: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   191: istore #15
    //   193: aload_1
    //   194: ldc_w 'is_cell'
    //   197: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   202: istore #16
    //   204: aload_1
    //   205: ldc_w 'is_wifi'
    //   208: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   213: istore #17
    //   215: aload_1
    //   216: ldc_w 'radius_type'
    //   219: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   224: istore #18
    //   226: aload_1
    //   227: iload #9
    //   229: invokeinterface getString : (I)Ljava/lang/String;
    //   234: astore #5
    //   236: aload_1
    //   237: iload #10
    //   239: invokeinterface getString : (I)Ljava/lang/String;
    //   244: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   247: invokevirtual floatValue : ()F
    //   250: fstore #19
    //   252: aload_1
    //   253: iload #11
    //   255: invokeinterface getString : (I)Ljava/lang/String;
    //   260: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   263: invokevirtual floatValue : ()F
    //   266: fstore #20
    //   268: aload_1
    //   269: iload #12
    //   271: invokeinterface getString : (I)Ljava/lang/String;
    //   276: invokestatic valueOf : (Ljava/lang/String;)Ljava/lang/Float;
    //   279: invokevirtual floatValue : ()F
    //   282: fstore #21
    //   284: aload_1
    //   285: iload #13
    //   287: invokeinterface getString : (I)Ljava/lang/String;
    //   292: astore #4
    //   294: aload_1
    //   295: iload #14
    //   297: invokeinterface getLong : (I)J
    //   302: lstore #7
    //   304: aload_1
    //   305: iload #15
    //   307: invokeinterface getInt : (I)I
    //   312: ifeq -> 450
    //   315: iconst_1
    //   316: istore #22
    //   318: aload_1
    //   319: iload #16
    //   321: invokeinterface getInt : (I)I
    //   326: ifeq -> 456
    //   329: iconst_1
    //   330: istore #23
    //   332: aload_1
    //   333: iload #17
    //   335: invokeinterface getInt : (I)I
    //   340: ifeq -> 462
    //   343: iconst_1
    //   344: istore #24
    //   346: aload_1
    //   347: iload #18
    //   349: invokeinterface getInt : (I)I
    //   354: istore #25
    //   356: new com/baidu/location/an
    //   359: astore_3
    //   360: aload_3
    //   361: aload #5
    //   363: fload #19
    //   365: f2d
    //   366: fload #20
    //   368: f2d
    //   369: iload #25
    //   371: lload #7
    //   373: aload #4
    //   375: invokespecial <init> : (Ljava/lang/String;DDIJLjava/lang/String;)V
    //   378: aload_3
    //   379: ifnull -> 406
    //   382: aload_3
    //   383: fload #21
    //   385: invokevirtual a : (F)V
    //   388: aload_3
    //   389: iload #22
    //   391: invokevirtual do : (Z)V
    //   394: aload_3
    //   395: iload #23
    //   397: invokevirtual a : (Z)V
    //   400: aload_3
    //   401: iload #24
    //   403: invokevirtual if : (Z)V
    //   406: aload #6
    //   408: aload_3
    //   409: invokeinterface add : (Ljava/lang/Object;)Z
    //   414: pop
    //   415: aload_1
    //   416: invokeinterface moveToNext : ()Z
    //   421: istore #22
    //   423: iload #22
    //   425: ifne -> 226
    //   428: aload #6
    //   430: astore_3
    //   431: aload_1
    //   432: ifnull -> 444
    //   435: aload_1
    //   436: invokeinterface close : ()V
    //   441: aload #6
    //   443: astore_3
    //   444: aload_2
    //   445: invokevirtual close : ()V
    //   448: aload_3
    //   449: areturn
    //   450: iconst_0
    //   451: istore #22
    //   453: goto -> 318
    //   456: iconst_0
    //   457: istore #23
    //   459: goto -> 332
    //   462: iconst_0
    //   463: istore #24
    //   465: goto -> 346
    //   468: astore_1
    //   469: aload #4
    //   471: astore_1
    //   472: aload_1
    //   473: astore_3
    //   474: aload #6
    //   476: ifnull -> 444
    //   479: aload #6
    //   481: invokeinterface close : ()V
    //   486: aload_1
    //   487: astore_3
    //   488: goto -> 444
    //   491: astore #6
    //   493: aconst_null
    //   494: astore_1
    //   495: aload_1
    //   496: ifnull -> 505
    //   499: aload_1
    //   500: invokeinterface close : ()V
    //   505: aload #6
    //   507: athrow
    //   508: astore #6
    //   510: goto -> 495
    //   513: astore #6
    //   515: aload_1
    //   516: astore #6
    //   518: aload #4
    //   520: astore_1
    //   521: goto -> 472
    //   524: astore_3
    //   525: aload_1
    //   526: astore_3
    //   527: aload #6
    //   529: astore_1
    //   530: aload_3
    //   531: astore #6
    //   533: goto -> 472
    // Exception table:
    //   from	to	target	type
    //   30	78	468	java/lang/Exception
    //   30	78	491	finally
    //   90	109	513	java/lang/Exception
    //   90	109	508	finally
    //   109	226	524	java/lang/Exception
    //   109	226	508	finally
    //   226	315	524	java/lang/Exception
    //   226	315	508	finally
    //   318	329	524	java/lang/Exception
    //   318	329	508	finally
    //   332	343	524	java/lang/Exception
    //   332	343	508	finally
    //   346	378	524	java/lang/Exception
    //   346	378	508	finally
    //   382	406	524	java/lang/Exception
    //   382	406	508	finally
    //   406	423	524	java/lang/Exception
    //   406	423	508	finally
  }
  
  public void try(Context paramContext) {
    if(paramContext, (Message)null);
  }
  
  private class a extends q {
    private static final String dH = "fence";
    
    private static final String dJ = "bloc";
    
    private static final String dK = "ext";
    
    private static final String dL = "error";
    
    private static final String dN = "in";
    
    private an dI;
    
    private final String dM;
    
    public a(ax this$0, an param1an, String param1String) {
      this.dI = param1an;
      this.dM = param1String;
      this.cP = new ArrayList();
    }
    
    void O() {
      this.cN = "http://loc.map.baidu.com/fence";
      DecimalFormat decimalFormat = new DecimalFormat("0.00000");
      String str2 = decimalFormat.format(this.dI.a());
      String str3 = decimalFormat.format(this.dI.byte());
      float f = this.dI.do();
      String str4 = String.valueOf(this.dI.int());
      int i = ar.do(f.getServiceContext());
      String str5 = a.if(f.getServiceContext());
      int j = this.dI.case();
      if (ao.bC().bF()) {
        str1 = "1";
      } else {
        str1 = "0";
      } 
      String str1 = Jni.h(String.format("&x=%s&y=%s&r=%s&coord=%s&type=%s&cu=%s&fence_type=%s&wf_on=%s", new Object[] { str2, str3, String.valueOf(f), str4, Integer.valueOf(i), str5, Integer.valueOf(j), str1 }));
      this.cP.add(new BasicNameValuePair("fence", str1));
      this.cP.add(new BasicNameValuePair("bloc", this.dM));
      List<BasicNameValuePair> list = this.cP;
      aw.b6();
      str1 = aw.iu;
      aw.b6();
      list.add(new BasicNameValuePair("ext", Jni.h(String.format("&ki=%s&sn=%s", new Object[] { str1, aw.iA }))));
    }
    
    public void W() {
      J();
    }
    
    void do(boolean param1Boolean) {
      int i = 0;
      ax.if(this.dG, false);
      if (param1Boolean && this.cO != null)
        try {
          String str = EntityUtils.toString(this.cO, "UTF-8");
          JSONObject jSONObject = new JSONObject();
          this(str);
          if (jSONObject != null) {
            int j = Integer.valueOf(jSONObject.getString("error")).intValue();
            if (jSONObject.has("in"))
              i = Integer.valueOf(jSONObject.getString("in")).intValue(); 
            if (j == 0 && i == 1) {
              ax.do(this.dG, null);
              ax.if(this.dG, (ao.b)null);
              ar.for(f.getServiceContext()).if(this.dI);
              ar.for(f.getServiceContext()).bO();
              if (ax.new(this.dG) != null) {
                Message message = Message.obtain(null, 208);
                Bundle bundle = new Bundle();
                this();
                bundle.putString("geofence_id", this.dI.getGeofenceId());
                message.setData(bundle);
                ax.new(this.dG).send(message);
              } 
            } 
          } 
        } catch (Exception exception) {} 
    }
  }
  
  private class b extends ae {
    private b(ax this$0) {}
    
    void ag() {}
    
    void byte(Message param1Message) {}
  }
  
  public class c extends BroadcastReceiver {
    public c(ax this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      ax.if(this.a, param1Context);
      ax.do(this.a).post(ax.for(this.a));
    }
  }
  
  private class d implements Runnable, b {
    private d(ax this$0) {}
    
    public void run() {
      try {
        r.a a = r.aa().X();
        String str = Jni.i(String.format("%s|%s|%s|0", new Object[] { Integer.valueOf(a.do), Integer.valueOf(a.if), Integer.valueOf(a.for) }));
        ax.if(this.kC, String.format("%s|%s|%s|0", new Object[] { Integer.valueOf(a.do), Integer.valueOf(a.if), Integer.valueOf(a.for) }));
        ax.if(this.kC, this.kC.s(str));
        ax.int(this.kC);
        ax.if(this.kC);
      } catch (Exception exception) {
        this.kC.if(f.getServiceContext(), 360000);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/ax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */