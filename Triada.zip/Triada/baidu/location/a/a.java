package com.baidu.location.a;

public class a {
  public static final String a = "valid_date";
  
  public static final String byte = "is_lac";
  
  public static final String case = "longitude";
  
  public static final String char = "radius";
  
  public static final String do = "geofence_id";
  
  public static final String else = "geofence";
  
  public static final String for = "latitude";
  
  public static final String goto = "is_wifi";
  
  public static final String if = "_id";
  
  public static final String int = "coord_type";
  
  public static final String long = "is_cell";
  
  public static final String new = "next_active_time";
  
  public static final String try = "radius_type";
  
  public static final String void = "duration_millis";
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */