package com.baidu.location.b.a;

import android.content.Context;
import android.text.TextUtils;

public class a {
  private static final boolean a = false;
  
  private static final String if = a.class.getSimpleName();
  
  private static String a(Context paramContext) {
    return b.a(paramContext);
  }
  
  public static String if(Context paramContext) {
    String str2 = a(paramContext);
    String str3 = b.do(paramContext);
    String str1 = str3;
    if (TextUtils.isEmpty(str3))
      str1 = "0"; 
    str1 = (new StringBuffer(str1)).reverse().toString();
    return str2 + "|" + str1;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */