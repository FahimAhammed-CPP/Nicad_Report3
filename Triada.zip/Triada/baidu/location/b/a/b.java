package com.baidu.location.b.a;

import android.content.Context;
import android.os.Environment;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;

public final class b {
  private static final boolean a = false;
  
  private static final String do = "DeviceId";
  
  private static final String for = "30212102dicudiab";
  
  private static final String if = "baidu/.cuid";
  
  private static final String int = "com.baidu.deviceid";
  
  public static String a(Context paramContext) {
    boolean bool;
    a(paramContext, "android.permission.WRITE_SETTINGS");
    a(paramContext, "android.permission.READ_PHONE_STATE");
    a(paramContext, "android.permission.WRITE_EXTERNAL_STORAGE");
    a a = a.a(paramContext);
    String str2 = a.if;
    if (!a.a) {
      bool = true;
    } else {
      bool = false;
    } 
    String str3 = if(paramContext);
    if (bool)
      return c.a(("com.baidu" + str3).getBytes(), true); 
    String str4 = null;
    String str5 = Settings.System.getString(paramContext.getContentResolver(), "com.baidu.deviceid");
    String str1 = str5;
    if (TextUtils.isEmpty(str5)) {
      String str = c.a(("com.baidu" + str2 + str3).getBytes(), true);
      str5 = Settings.System.getString(paramContext.getContentResolver(), str);
      str4 = str;
      str1 = str5;
      if (!TextUtils.isEmpty(str5)) {
        Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str5);
        a(str2, str5);
        str1 = str5;
        str4 = str;
      } 
    } 
    str5 = str1;
    if (TextUtils.isEmpty(str1)) {
      str1 = a(str2);
      str5 = str1;
      if (!TextUtils.isEmpty(str1)) {
        Settings.System.putString(paramContext.getContentResolver(), str4, str1);
        Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str1);
        str5 = str1;
      } 
    } 
    str1 = str5;
    if (TextUtils.isEmpty(str5)) {
      str1 = UUID.randomUUID().toString();
      str1 = c.a((str2 + str3 + str1).getBytes(), true);
      Settings.System.putString(paramContext.getContentResolver(), str4, str1);
      Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str1);
      a(str2, str1);
    } 
    return str1;
  }
  
  private static String a(String paramString) {
    String str1;
    if (TextUtils.isEmpty(paramString))
      return ""; 
    String str2 = "";
    File file = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
    try {
      FileReader fileReader = new FileReader();
      this(file);
      BufferedReader bufferedReader = new BufferedReader();
      this(fileReader);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      while (true) {
        String str = bufferedReader.readLine();
        if (str != null) {
          stringBuilder.append(str);
          stringBuilder.append("\r\n");
          continue;
        } 
        bufferedReader.close();
        str1 = new String();
        this(com.baidu.location.b.b.a.a("30212102dicudiab", "30212102dicudiab", com.baidu.location.b.b.b.a(stringBuilder.toString().getBytes())));
        String[] arrayOfString = str1.split("=");
        str1 = str2;
        if (arrayOfString != null) {
          str1 = str2;
          if (arrayOfString.length == 2) {
            str1 = str2;
            if (paramString.equals(arrayOfString[0]))
              str1 = arrayOfString[1]; 
          } 
        } 
        return str1;
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      str1 = str2;
    } catch (IOException iOException) {
      str1 = str2;
    } catch (Exception exception) {
      str1 = str2;
    } 
    return str1;
  }
  
  private static void a(Context paramContext, String paramString) {
    boolean bool;
    if (paramContext.checkCallingOrSelfPermission(paramString) == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      throw new SecurityException("Permission Denial: requires permission " + paramString); 
  }
  
  private static void a(String paramString1, String paramString2) {
    if (!TextUtils.isEmpty(paramString1)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString1);
      stringBuilder.append("=");
      stringBuilder.append(paramString2);
      File file = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
      try {
        File file1 = new File();
        this(file.getParent());
        file1.mkdirs();
        FileWriter fileWriter = new FileWriter();
        this(file, false);
        fileWriter.write(com.baidu.location.b.b.b.a(com.baidu.location.b.b.a.if("30212102dicudiab", "30212102dicudiab", stringBuilder.toString().getBytes()), "utf-8"));
        fileWriter.flush();
        fileWriter.close();
      } catch (IOException iOException) {
      
      } catch (Exception exception) {}
    } 
  }
  
  public static String do(Context paramContext) {
    return (a.a(paramContext)).if;
  }
  
  public static String if(Context paramContext) {
    String str2 = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
    String str1 = str2;
    if (TextUtils.isEmpty(str2))
      str1 = ""; 
    return str1;
  }
  
  static final class a {
    private static final String do = "bd_setting_i";
    
    public final boolean a;
    
    public final String if;
    
    private a(String param1String, boolean param1Boolean) {
      this.if = param1String;
      this.a = param1Boolean;
    }
    
    static a a(Context param1Context) {
      boolean bool2;
      boolean bool1 = true;
      String str = "";
      try {
        String str1 = Settings.System.getString(param1Context.getContentResolver(), "bd_setting_i");
        str = str1;
        if (TextUtils.isEmpty(str1)) {
          str = str1;
          str1 = a(param1Context, "");
          str = str1;
        } else {
          str = str1;
        } 
        try {
          Settings.System.putString(param1Context.getContentResolver(), "bd_setting_i", str);
          bool2 = false;
          if (bool2)
            bool1 = false; 
          return new a(str, bool1);
        } catch (Exception null) {}
      } catch (Exception exception) {}
      Log.e("DeviceId", "Settings.System.getString or putString failed", exception);
      if (TextUtils.isEmpty(str)) {
        str = a(param1Context, "");
        bool2 = true;
      } else {
        bool2 = true;
      } 
      if (bool2)
        bool1 = false; 
      return new a(str, bool1);
    }
    
    private static String a(Context param1Context, String param1String) {
      // Byte code:
      //   0: aload_0
      //   1: ldc 'phone'
      //   3: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
      //   6: checkcast android/telephony/TelephonyManager
      //   9: astore_0
      //   10: aload_0
      //   11: ifnull -> 40
      //   14: aload_0
      //   15: invokevirtual getDeviceId : ()Ljava/lang/String;
      //   18: astore_0
      //   19: aload_0
      //   20: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
      //   23: ifeq -> 45
      //   26: aload_1
      //   27: astore_0
      //   28: aload_0
      //   29: areturn
      //   30: astore_0
      //   31: ldc 'DeviceId'
      //   33: ldc 'Read IMEI failed'
      //   35: aload_0
      //   36: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   39: pop
      //   40: aconst_null
      //   41: astore_0
      //   42: goto -> 19
      //   45: goto -> 28
      // Exception table:
      //   from	to	target	type
      //   0	10	30	java/lang/Exception
      //   14	19	30	java/lang/Exception
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/b/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */