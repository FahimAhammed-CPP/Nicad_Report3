package com.baidu.location;

import android.location.Location;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import java.io.File;
import java.util.Calendar;
import java.util.Locale;

class c implements au, l {
  public static int V = 0;
  
  public static int W = 0;
  
  public static String X;
  
  public static float Y = 0.0F;
  
  public static int Z = 0;
  
  public static float a0 = 0.0F;
  
  public static boolean a1 = false;
  
  public static int a2 = 0;
  
  public static int a3 = 0;
  
  public static int a4 = 0;
  
  public static boolean a5 = false;
  
  public static int a6 = 0;
  
  public static double a7 = 0.0D;
  
  public static float a8 = 0.0F;
  
  public static float a9 = 0.0F;
  
  public static byte[] aA;
  
  private static boolean aB = false;
  
  public static long aC = 0L;
  
  public static int aD = 0;
  
  public static final boolean aE = true;
  
  public static double aF;
  
  public static int aG;
  
  public static int aH;
  
  public static long aI;
  
  private static String aJ;
  
  public static int aK;
  
  private static String aL;
  
  public static int aM;
  
  private static Process aN;
  
  public static long aO;
  
  public static float aP;
  
  public static long aQ;
  
  public static float aR;
  
  public static float aS;
  
  public static int aT;
  
  public static int aU;
  
  public static int aV;
  
  private static String aW;
  
  public static boolean aX;
  
  public static float aY;
  
  private static String aZ;
  
  public static float aa;
  
  public static double ab;
  
  public static long ac;
  
  public static float ad;
  
  public static float ae;
  
  public static float af;
  
  public static boolean ag;
  
  public static int ah;
  
  public static int ai;
  
  public static int aj;
  
  public static int ak;
  
  public static boolean al = false;
  
  public static double am;
  
  public static long an;
  
  public static float ao;
  
  public static int ap;
  
  public static boolean aq;
  
  public static int ar;
  
  public static int as;
  
  public static int at;
  
  public static int au;
  
  public static String av;
  
  public static int aw;
  
  public static int ax;
  
  public static boolean ay;
  
  private static boolean az;
  
  public static String ba;
  
  public static float bb;
  
  public static float bc;
  
  static {
    ag = false;
    ak = 0;
    aL = "http://loc.map.baidu.com/sdk.php";
    X = "http://loc.map.baidu.com/sdk_ep.php";
    aZ = "http://loc.map.baidu.com/user_err.php";
    aW = "http://loc.map.baidu.com/oqur.php";
    az = false;
    aB = false;
    aJ = "[baidu_location_service]";
    aN = null;
    av = "no";
    ba = "gcj02";
    a5 = true;
    aK = 3;
    a7 = 0.0D;
    am = 0.0D;
    aF = 0.0D;
    ab = 0.0D;
    aj = 0;
    aA = null;
    aq = false;
    ah = 0;
    ad = 1.1F;
    aP = 2.2F;
    af = 2.3F;
    aR = 3.8F;
    aG = 3;
    V = 10;
    aH = 2;
    W = 7;
    Z = 20;
    aw = 70;
    a2 = 120;
    bc = 2.0F;
    a9 = 10.0F;
    ao = 50.0F;
    aY = 200.0F;
    aV = 16;
    aa = 0.9F;
    as = 10000;
    aS = 0.5F;
    bb = 0.0F;
    a8 = 0.1F;
    a6 = 30;
    a4 = 100;
    ai = 420000;
    ay = true;
    aX = true;
    au = 20;
    ar = 300;
    ax = 1000;
    aO = 900000L;
    aI = 420000L;
    ac = 180000L;
    an = 180000L;
    aQ = 15L;
    aC = 300000L;
    a3 = 100;
    aT = 0;
    aU = 30000;
    aM = 30000;
    a0 = 10.0F;
    ae = 6.0F;
    Y = 10.0F;
    ap = 60;
    aD = 70;
    at = 6;
  }
  
  public static void byte() {}
  
  public static void case() {
    try {
      if (aN != null) {
        aN.destroy();
        aN = null;
      } 
    } catch (Exception exception) {}
  }
  
  public static String char() {
    null = try();
    return (null == null) ? null : (null + "/baidu/tempdata");
  }
  
  static int do(String paramString1, String paramString2, String paramString3) {
    int i = Integer.MIN_VALUE;
    int j = i;
    if (paramString1 != null) {
      if (paramString1.equals(""))
        return i; 
    } else {
      return j;
    } 
    int k = paramString1.indexOf(paramString2);
    j = i;
    if (k != -1) {
      int m = k + paramString2.length();
      k = paramString1.indexOf(paramString3, m);
      j = i;
      if (k != -1) {
        paramString1 = paramString1.substring(m, k);
        j = i;
        if (paramString1 != null) {
          j = i;
          if (!paramString1.equals(""))
            try {
              j = Integer.parseInt(paramString1);
            } catch (NumberFormatException numberFormatException) {
              j = i;
            }  
        } 
      } 
    } 
    return j;
  }
  
  public static String do() {
    return aW;
  }
  
  public static void do(String paramString) {
    if (paramString != null)
      aL = paramString; 
  }
  
  public static void do(String paramString1, String paramString2) {}
  
  static double for(String paramString1, String paramString2, String paramString3) {
    double d1 = Double.MIN_VALUE;
    double d2 = d1;
    if (paramString1 != null) {
      if (paramString1.equals(""))
        return d1; 
    } else {
      return d2;
    } 
    int i = paramString1.indexOf(paramString2);
    d2 = d1;
    if (i != -1) {
      int j = i + paramString2.length();
      i = paramString1.indexOf(paramString3, j);
      d2 = d1;
      if (i != -1) {
        paramString1 = paramString1.substring(j, i);
        d2 = d1;
        if (paramString1 != null) {
          d2 = d1;
          if (!paramString1.equals(""))
            try {
              d2 = Double.parseDouble(paramString1);
            } catch (NumberFormatException numberFormatException) {
              d2 = d1;
            }  
        } 
      } 
    } 
    return d2;
  }
  
  public static String for() {
    return aL;
  }
  
  static float if(String paramString1, String paramString2, String paramString3) {
    float f1 = Float.MIN_VALUE;
    float f2 = f1;
    if (paramString1 != null) {
      if (paramString1.equals(""))
        return f1; 
    } else {
      return f2;
    } 
    int i = paramString1.indexOf(paramString2);
    f2 = f1;
    if (i != -1) {
      int j = i + paramString2.length();
      i = paramString1.indexOf(paramString3, j);
      f2 = f1;
      if (i != -1) {
        paramString1 = paramString1.substring(j, i);
        f2 = f1;
        if (paramString1 != null) {
          f2 = f1;
          if (!paramString1.equals(""))
            try {
              f2 = Float.parseFloat(paramString1);
            } catch (NumberFormatException numberFormatException) {
              f2 = f1;
            }  
        } 
      } 
    } 
    return f2;
  }
  
  static String if() {
    Calendar calendar = Calendar.getInstance();
    int i = calendar.get(5);
    int j = calendar.get(1);
    int k = calendar.get(2);
    int m = calendar.get(11);
    int n = calendar.get(12);
    int i1 = calendar.get(13);
    return String.format(Locale.CHINA, "%d_%d_%d_%d_%d_%d", new Object[] { Integer.valueOf(j), Integer.valueOf(k + 1), Integer.valueOf(i), Integer.valueOf(m), Integer.valueOf(n), Integer.valueOf(i1) });
  }
  
  public static String if(r.a parama, ao.b paramb, Location paramLocation, String paramString) {
    StringBuffer stringBuffer = new StringBuffer();
    if (parama != null) {
      String str1 = parama.toString();
      if (str1 != null)
        stringBuffer.append(str1); 
    } 
    if (paramb != null) {
      try {
        String str1 = paramb.a(5);
      } catch (Exception exception) {
        exception = null;
      } 
      if (exception != null)
        stringBuffer.append((String)exception); 
    } 
    if (paramLocation != null) {
      String str1;
      if (ak != 0) {
        str1 = v.new(paramLocation);
      } else {
        str1 = v.byte(paramLocation);
      } 
      if (str1 != null)
        stringBuffer.append(str1); 
    } 
    String str = aw.b6().char(false);
    if (str != null)
      stringBuffer.append(str); 
    if (paramString != null)
      stringBuffer.append(paramString); 
    if (parama != null) {
      String str1 = parama.int();
      if (str1 != null && str1.length() + stringBuffer.length() < 750)
        stringBuffer.append(str1); 
    } 
    return stringBuffer.toString();
  }
  
  public static String if(r.a parama, ao.b paramb, Location paramLocation, String paramString, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    if (parama != null) {
      String str = parama.toString();
      if (str != null)
        stringBuffer.append(str); 
    } 
    if (paramb != null) {
      String str;
      if (paramInt == 0) {
        str = paramb.char();
      } else {
        str = paramb.byte();
      } 
      if (str != null)
        stringBuffer.append(str); 
    } 
    if (paramLocation != null) {
      String str;
      if (ak != 0 && paramInt != 0) {
        str = v.new(paramLocation);
      } else {
        str = v.byte(paramLocation);
      } 
      if (str != null)
        stringBuffer.append(str); 
    } 
    boolean bool = false;
    if (paramInt == 0)
      bool = true; 
    String str2 = aw.b6().char(bool);
    if (str2 != null)
      stringBuffer.append(str2); 
    if (paramString != null)
      stringBuffer.append(paramString); 
    paramString = at.do().a();
    if (!TextUtils.isEmpty(paramString))
      stringBuffer.append("&bc=").append(paramString); 
    if (parama != null) {
      String str = parama.int();
      if (str != null && str.length() + stringBuffer.length() < 750)
        stringBuffer.append(str); 
    } 
    String str1 = stringBuffer.toString();
    if (paramLocation != null && paramb != null) {
      try {
        float f = paramLocation.getSpeed();
        int i = ak;
        paramInt = paramb.do();
        int j = paramb.try();
        bool = paramb.case();
        if (f < ae && (i == 1 || i == 0) && (paramInt < ap || bool == true)) {
          aK = 1;
          return str1;
        } 
        if (f < Y && (i == 1 || i == 0 || i == 3) && (paramInt < aD || j > at)) {
          aK = 2;
          return str1;
        } 
      } catch (Exception exception) {
        aK = 3;
        return str1;
      } 
      aK = 3;
      return str1;
    } 
    aK = 3;
    return str1;
  }
  
  static String if(String paramString1, String paramString2, String paramString3, double paramDouble) {
    String str1 = null;
    String str2 = str1;
    if (paramString1 != null) {
      if (paramString1.equals(""))
        return str1; 
    } else {
      return str2;
    } 
    int i = paramString1.indexOf(paramString2);
    str2 = str1;
    if (i != -1) {
      int j = i + paramString2.length();
      i = paramString1.indexOf(paramString3, j);
      str2 = str1;
      if (i != -1) {
        paramString2 = paramString1.substring(0, j);
        paramString1 = paramString1.substring(i);
        paramString3 = String.format(Locale.CHINA, "%.7f", new Object[] { Double.valueOf(paramDouble) });
        str2 = paramString2 + paramString3 + paramString1;
      } 
    } 
    return str2;
  }
  
  public static void if(String paramString) {
    if (aB)
      Log.d(aJ, paramString); 
  }
  
  public static void if(String paramString1, String paramString2) {
    if (az)
      Log.d(paramString1, paramString2); 
  }
  
  public static boolean if(BDLocation paramBDLocation) {
    int i = paramBDLocation.getLocType();
    return (i > 100 && i < 200);
  }
  
  static String int() {
    Calendar calendar = Calendar.getInstance();
    int i = calendar.get(5);
    int j = calendar.get(1);
    int k = calendar.get(2);
    int m = calendar.get(11);
    int n = calendar.get(12);
    int i1 = calendar.get(13);
    return String.format(Locale.CHINA, "%d-%d-%d %d:%d:%d", new Object[] { Integer.valueOf(j), Integer.valueOf(k + 1), Integer.valueOf(i), Integer.valueOf(m), Integer.valueOf(n), Integer.valueOf(i1) });
  }
  
  public static String new() {
    return aZ;
  }
  
  public static String try() {
    if (Environment.getExternalStorageState().equals("mounted")) {
      try {
        String str1 = Environment.getExternalStorageDirectory().getPath();
        StringBuilder stringBuilder = new StringBuilder();
        this();
        String str2 = stringBuilder.append(str1).append("/baidu/tempdata").toString();
        File file = new File();
        this(str2);
        str2 = str1;
        if (!file.exists()) {
          file.mkdirs();
          str2 = str1;
        } 
      } catch (Exception exception) {
        exception = null;
      } 
      return (String)exception;
    } 
    return null;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */