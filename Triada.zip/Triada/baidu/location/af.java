package com.baidu.location;

import android.os.Handler;

class af implements au, l {
  private static af gS = null;
  
  private boolean gR = false;
  
  private Handler gT = null;
  
  private boolean gU = false;
  
  private af() {
    this.gT = new Handler();
  }
  
  public static af bg() {
    if (gS == null)
      gS = new af(); 
    return gS;
  }
  
  private void bi() {}
  
  public void bf() {
    this.gT.post(new af$1(this));
  }
  
  public void bh() {
    this.gR = false;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */