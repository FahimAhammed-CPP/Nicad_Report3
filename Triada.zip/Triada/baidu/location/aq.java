package com.baidu.location;

import java.util.List;

class aq implements au {
  public static String kf = null;
  
  public int ka = 0;
  
  private int kb = 1;
  
  private List kc = null;
  
  private final boolean kd = false;
  
  private double ke = 0.0D;
  
  private String kg = "";
  
  private boolean kh = false;
  
  private double ki = 0.0D;
  
  private char kj = (char)'N';
  
  private String kk = "";
  
  private boolean kl = false;
  
  private int km = 0;
  
  private boolean kn = false;
  
  private int ko = 0;
  
  private int kp = 0;
  
  private String kq = "";
  
  private String kr = "";
  
  private boolean ks = false;
  
  public aq(List paramList, String paramString1, String paramString2, String paramString3) {
    this.kc = paramList;
    this.kk = paramString1;
    this.kq = paramString2;
    this.kr = paramString3;
    cD();
  }
  
  private void cD() {
    byte b = 0;
    if (t(this.kr)) {
      String str = this.kr.substring(0, this.kr.length() - 3);
      int i;
      for (i = 0; b < str.length(); i = j) {
        int j = i;
        if (str.charAt(b) == ',')
          j = i + 1; 
        b++;
      } 
      String[] arrayOfString = str.split(",", i + 1);
      if (arrayOfString.length < 6)
        return; 
      if (!arrayOfString[2].equals("") && !arrayOfString[arrayOfString.length - 3].equals("") && !arrayOfString[arrayOfString.length - 2].equals("") && !arrayOfString[arrayOfString.length - 1].equals("")) {
        this.kb = Integer.valueOf(arrayOfString[2]).intValue();
        this.ki = Double.valueOf(arrayOfString[arrayOfString.length - 3]).doubleValue();
        this.ke = Double.valueOf(arrayOfString[arrayOfString.length - 2]).doubleValue();
        this.kn = true;
      } 
    } 
    this.kl = this.kn;
  }
  
  private boolean t(String paramString) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramString != null) {
      bool2 = bool1;
      if (paramString.length() > 8) {
        byte b = 1;
        int i = 0;
        while (b < paramString.length() - 3) {
          i ^= paramString.charAt(b);
          b++;
        } 
        bool2 = bool1;
        if (Integer.toHexString(i).equalsIgnoreCase(paramString.substring(paramString.length() - 2, paramString.length())))
          bool2 = true; 
      } 
    } 
    return bool2;
  }
  
  public double cE() {
    return this.ke;
  }
  
  public String cF() {
    return this.kg;
  }
  
  public boolean cG() {
    return this.kl;
  }
  
  public double cH() {
    return this.ki;
  }
  
  public int cI() {
    return this.km;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */