package com.baidu.location;

import android.location.Location;
import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.apache.http.message.BasicNameValuePair;

class o implements au, l {
  private static Location b6;
  
  private static final int b7 = 2048;
  
  private static final int b8 = 2048;
  
  private static double b9 = 0.0D;
  
  private static Location cA;
  
  private static ArrayList cB;
  
  private static final int cC = 2048;
  
  private static final String cD;
  
  private static final String cE;
  
  private static int cF = 0;
  
  private static int cG = 0;
  
  private static ArrayList cH;
  
  private static o cI;
  
  private static String cJ;
  
  private static double ca = 0.0D;
  
  private static int cb = 0;
  
  private static int cc = 0;
  
  private static int cd = 0;
  
  private static int ce = 0;
  
  private static File cf;
  
  private static final int cg = 128;
  
  private static ArrayList ch;
  
  private static double ci = 0.0D;
  
  private static int cj = 0;
  
  private static int cl = 0;
  
  private static final int cm = 1040;
  
  private static Location cn;
  
  private static final int co = 32;
  
  private static ao.b cp;
  
  private static ArrayList cq = new ArrayList();
  
  private static int cr;
  
  private static ArrayList cs;
  
  private static final String ct;
  
  private static int cu;
  
  private static ArrayList cw;
  
  private static double cx;
  
  private static int cy;
  
  private static final String cz;
  
  private int ck = 0;
  
  private b cv = null;
  
  static {
    ch = new ArrayList();
    cw = new ArrayList();
    cH = new ArrayList();
    cs = new ArrayList();
    cB = new ArrayList();
    cJ = f.H + "/yo.dat";
    cE = f.H + "/yoh.dat";
    cD = f.H + "/yom.dat";
    ct = f.H + "/yol.dat";
    cz = f.H + "/yor.dat";
    cf = null;
    cd = 1024;
    cG = 512;
    cc = 8;
    cr = 5;
    cj = 8;
    cb = 16;
    cy = 1024;
    cu = 256;
    ca = 0.0D;
    cx = 0.1D;
    ci = 30.0D;
    b9 = 100.0D;
    cl = 0;
    ce = 64;
    cF = 128;
    cn = null;
    cA = null;
    b6 = null;
    cp = null;
    cI = null;
  }
  
  private o() {
    this.cv = new b(this);
    this.ck = 0;
  }
  
  public static void B() {}
  
  public static void byte(String paramString) {
    try {
      File file = new File();
      this(paramString);
      if (!file.exists()) {
        File file1 = new File();
        this(f.H);
        if (!file1.exists())
          file1.mkdirs(); 
        file1 = file;
        if (!file.createNewFile())
          file1 = null; 
        RandomAccessFile randomAccessFile = new RandomAccessFile();
        this(file1, "rw");
        randomAccessFile.seek(0L);
        randomAccessFile.writeInt(32);
        randomAccessFile.writeInt(2048);
        randomAccessFile.writeInt(1040);
        randomAccessFile.writeInt(0);
        randomAccessFile.writeInt(0);
        randomAccessFile.writeInt(0);
        randomAccessFile.close();
      } 
    } catch (Exception exception) {}
  }
  
  public static void case(String paramString) {
    ArrayList<String> arrayList;
    int i = c.aK;
    if (i == 1) {
      arrayList = cH;
    } else if (i == 2) {
      arrayList = cs;
    } else if (i == 3) {
      arrayList = cB;
    } else {
      return;
    } 
    if (arrayList != null) {
      if (arrayList.size() <= cb)
        arrayList.add(paramString); 
      if (arrayList.size() >= cb)
        if(i, false); 
      while (true) {
        if (arrayList.size() > cb) {
          arrayList.remove(0);
          continue;
        } 
        return;
      } 
    } 
  }
  
  private static void char(String paramString) {
    case(paramString);
  }
  
  public static void do(r.a parama, ao.b paramb, Location paramLocation, String paramString) {
    ao.b b1 = null;
    r.a a1 = null;
    if (w.fX && (c.aj != 3 || if(paramLocation, paramb) || if(paramLocation, false))) {
      if (parama != null && parama.do()) {
        b1 = paramb;
        if (!if(paramLocation, paramb))
          b1 = null; 
        String str = c.if(parama, b1, paramLocation, paramString, 1);
        if (str != null) {
          else(Jni.h(str));
          cA = paramLocation;
          cn = paramLocation;
          if (b1 != null)
            cp = b1; 
        } 
        return;
      } 
      if (paramb != null && paramb.if() && if(paramLocation, paramb)) {
        if (!if(paramLocation))
          parama = a1; 
        String str = c.if(parama, paramb, paramLocation, paramString, 2);
        if (str != null) {
          char(Jni.h(str));
          b6 = paramLocation;
          cn = paramLocation;
          if (paramb != null)
            cp = paramb; 
        } 
        return;
      } 
      if (!if(paramLocation))
        parama = null; 
      if (!if(paramLocation, paramb))
        paramb = b1; 
      if (parama != null || paramb != null) {
        String str = c.if(parama, paramb, paramLocation, paramString, 3);
        if (str != null) {
          long(Jni.h(str));
          cn = paramLocation;
          if (paramb != null)
            cp = paramb; 
        } 
      } 
    } 
  }
  
  private static void else(String paramString) {
    case(paramString);
  }
  
  private static int if(List<String> paramList, int paramInt) {
    if (paramList == null || paramInt > 256 || paramInt < 0)
      return -1; 
    try {
      if (cf == null) {
        File file = new File();
        this(cJ);
        cf = file;
        if (!cf.exists()) {
          cf = null;
          return -2;
        } 
      } 
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(cf, "rw");
      if (randomAccessFile.length() < 1L) {
        randomAccessFile.close();
        return -3;
      } 
      randomAccessFile.seek(paramInt);
      int i = randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      int k = randomAccessFile.readInt();
      int m = randomAccessFile.readInt();
      long l1 = randomAccessFile.readLong();
      if (!if(i, j, k, m, l1) || j < 1) {
        randomAccessFile.close();
        return -4;
      } 
      byte[] arrayOfByte = new byte[cy];
      int n = cc;
      while (n > 0 && j > 0) {
        randomAccessFile.seek(((i + j - 1) % k * m) + l1);
        int i1 = randomAccessFile.readInt();
        if (i1 > 0 && i1 < m) {
          randomAccessFile.read(arrayOfByte, 0, i1);
          if (arrayOfByte[i1 - 1] == 0) {
            String str = new String();
            this(arrayOfByte, 0, i1 - 1);
            paramList.add(str);
          } 
        } 
        n--;
        j--;
      } 
      randomAccessFile.seek(paramInt);
      randomAccessFile.writeInt(i);
      randomAccessFile.writeInt(j);
      randomAccessFile.writeInt(k);
      randomAccessFile.writeInt(m);
      randomAccessFile.writeLong(l1);
      randomAccessFile.close();
      paramInt = cc;
      paramInt -= n;
    } catch (Exception exception) {
      exception.printStackTrace();
      paramInt = -5;
    } 
    return paramInt;
  }
  
  public static String if(int paramInt) {
    ArrayList<String> arrayList;
    String str1 = null;
    if (paramInt == 1) {
      String str = cE;
      arrayList = cH;
    } else if (paramInt == 2) {
      String str = cD;
      arrayList = cs;
    } else if (paramInt == 3) {
      String str = ct;
      arrayList = cB;
    } else {
      String str = str1;
      if (paramInt == 4) {
        str = cz;
        arrayList = cB;
      } else {
        return str;
      } 
    } 
    if (arrayList == null)
      return str1; 
    if (arrayList.size() < 1)
      if((String)SYNTHETIC_LOCAL_VARIABLE_2, arrayList); 
    paramInt = arrayList.size();
    String str2 = str1;
    if (paramInt > 0) {
      str2 = arrayList.get(paramInt - 1);
      arrayList.remove(paramInt - 1);
    } 
    return str2;
  }
  
  public static String if(r.a parama, ao.b paramb, Location paramLocation, String paramString1, String paramString2) {
    return !w.fX ? null : (c.if(parama, paramb, paramLocation, paramString1) + paramString2);
  }
  
  public static void if(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
    if (paramDouble1 <= 0.0D)
      paramDouble1 = ca; 
    ca = paramDouble1;
    cx = paramDouble2;
    if (paramDouble3 <= 20.0D)
      paramDouble3 = ci; 
    ci = paramDouble3;
    b9 = paramDouble4;
  }
  
  public static void if(int paramInt1, int paramInt2) {}
  
  public static void if(int paramInt1, int paramInt2, boolean paramBoolean) {}
  
  public static void if(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: iload_0
    //   1: iconst_1
    //   2: if_icmpne -> 234
    //   5: getstatic com/baidu/location/o.cE : Ljava/lang/String;
    //   8: astore_2
    //   9: iload_1
    //   10: ifeq -> 14
    //   13: return
    //   14: getstatic com/baidu/location/o.cH : Ljava/util/ArrayList;
    //   17: astore_3
    //   18: new java/io/File
    //   21: dup
    //   22: aload_2
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: astore #4
    //   28: aload #4
    //   30: invokevirtual exists : ()Z
    //   33: ifne -> 40
    //   36: aload_2
    //   37: invokestatic byte : (Ljava/lang/String;)V
    //   40: new java/io/RandomAccessFile
    //   43: astore_2
    //   44: aload_2
    //   45: aload #4
    //   47: ldc 'rw'
    //   49: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   52: aload_2
    //   53: ldc2_w 4
    //   56: invokevirtual seek : (J)V
    //   59: aload_2
    //   60: invokevirtual readInt : ()I
    //   63: istore #5
    //   65: aload_2
    //   66: invokevirtual readInt : ()I
    //   69: istore #6
    //   71: aload_2
    //   72: invokevirtual readInt : ()I
    //   75: istore #7
    //   77: aload_2
    //   78: invokevirtual readInt : ()I
    //   81: istore #8
    //   83: aload_2
    //   84: invokevirtual readInt : ()I
    //   87: istore #9
    //   89: aload_3
    //   90: invokeinterface size : ()I
    //   95: istore #10
    //   97: iload #10
    //   99: getstatic com/baidu/location/o.cj : I
    //   102: if_icmple -> 506
    //   105: iload_1
    //   106: ifeq -> 503
    //   109: iinc #9, 1
    //   112: iload #7
    //   114: iload #5
    //   116: if_icmpge -> 320
    //   119: aload_2
    //   120: iload #6
    //   122: iload #7
    //   124: imul
    //   125: sipush #128
    //   128: iadd
    //   129: i2l
    //   130: invokevirtual seek : (J)V
    //   133: new java/lang/StringBuilder
    //   136: astore #4
    //   138: aload #4
    //   140: invokespecial <init> : ()V
    //   143: aload #4
    //   145: aload_3
    //   146: iconst_0
    //   147: invokeinterface get : (I)Ljava/lang/Object;
    //   152: checkcast java/lang/String
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: iconst_0
    //   159: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   162: invokevirtual toString : ()Ljava/lang/String;
    //   165: invokevirtual getBytes : ()[B
    //   168: astore #4
    //   170: aload_2
    //   171: aload #4
    //   173: arraylength
    //   174: invokevirtual writeInt : (I)V
    //   177: aload_2
    //   178: aload #4
    //   180: iconst_0
    //   181: aload #4
    //   183: arraylength
    //   184: invokevirtual write : ([BII)V
    //   187: aload_3
    //   188: iconst_0
    //   189: invokeinterface remove : (I)Ljava/lang/Object;
    //   194: pop
    //   195: iload #7
    //   197: iconst_1
    //   198: iadd
    //   199: istore #11
    //   201: iload #8
    //   203: istore #7
    //   205: iload #11
    //   207: istore #8
    //   209: iload #10
    //   211: iconst_1
    //   212: isub
    //   213: istore #11
    //   215: iload #8
    //   217: istore #10
    //   219: iload #7
    //   221: istore #8
    //   223: iload #10
    //   225: istore #7
    //   227: iload #11
    //   229: istore #10
    //   231: goto -> 97
    //   234: iload_0
    //   235: iconst_2
    //   236: if_icmpne -> 261
    //   239: getstatic com/baidu/location/o.cD : Ljava/lang/String;
    //   242: astore_2
    //   243: iload_1
    //   244: ifeq -> 254
    //   247: getstatic com/baidu/location/o.cH : Ljava/util/ArrayList;
    //   250: astore_3
    //   251: goto -> 18
    //   254: getstatic com/baidu/location/o.cs : Ljava/util/ArrayList;
    //   257: astore_3
    //   258: goto -> 18
    //   261: iload_0
    //   262: iconst_3
    //   263: if_icmpne -> 300
    //   266: getstatic com/baidu/location/o.ct : Ljava/lang/String;
    //   269: astore_3
    //   270: iload_1
    //   271: ifeq -> 287
    //   274: getstatic com/baidu/location/o.cs : Ljava/util/ArrayList;
    //   277: astore #4
    //   279: aload_3
    //   280: astore_2
    //   281: aload #4
    //   283: astore_3
    //   284: goto -> 18
    //   287: getstatic com/baidu/location/o.cB : Ljava/util/ArrayList;
    //   290: astore #4
    //   292: aload_3
    //   293: astore_2
    //   294: aload #4
    //   296: astore_3
    //   297: goto -> 18
    //   300: iload_0
    //   301: iconst_4
    //   302: if_icmpne -> 13
    //   305: getstatic com/baidu/location/o.cz : Ljava/lang/String;
    //   308: astore_2
    //   309: iload_1
    //   310: ifeq -> 13
    //   313: getstatic com/baidu/location/o.cB : Ljava/util/ArrayList;
    //   316: astore_3
    //   317: goto -> 18
    //   320: iload_1
    //   321: ifeq -> 439
    //   324: iload #8
    //   326: iload #6
    //   328: imul
    //   329: sipush #128
    //   332: iadd
    //   333: i2l
    //   334: lstore #12
    //   336: aload_2
    //   337: lload #12
    //   339: invokevirtual seek : (J)V
    //   342: new java/lang/StringBuilder
    //   345: astore #4
    //   347: aload #4
    //   349: invokespecial <init> : ()V
    //   352: aload #4
    //   354: aload_3
    //   355: iconst_0
    //   356: invokeinterface get : (I)Ljava/lang/Object;
    //   361: checkcast java/lang/String
    //   364: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: iconst_0
    //   368: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   371: invokevirtual toString : ()Ljava/lang/String;
    //   374: invokevirtual getBytes : ()[B
    //   377: astore #4
    //   379: aload_2
    //   380: aload #4
    //   382: arraylength
    //   383: invokevirtual writeInt : (I)V
    //   386: aload_2
    //   387: aload #4
    //   389: iconst_0
    //   390: aload #4
    //   392: arraylength
    //   393: invokevirtual write : ([BII)V
    //   396: aload_3
    //   397: iconst_0
    //   398: invokeinterface remove : (I)Ljava/lang/Object;
    //   403: pop
    //   404: iload #8
    //   406: iconst_1
    //   407: iadd
    //   408: istore #11
    //   410: iload #11
    //   412: istore #8
    //   414: iload #11
    //   416: iload #7
    //   418: if_icmple -> 424
    //   421: iconst_0
    //   422: istore #8
    //   424: iload #7
    //   426: istore #11
    //   428: iload #8
    //   430: istore #7
    //   432: iload #11
    //   434: istore #8
    //   436: goto -> 209
    //   439: iconst_1
    //   440: istore #11
    //   442: iload #9
    //   444: istore #10
    //   446: iload #11
    //   448: istore #9
    //   450: aload_2
    //   451: ldc2_w 12
    //   454: invokevirtual seek : (J)V
    //   457: aload_2
    //   458: iload #7
    //   460: invokevirtual writeInt : (I)V
    //   463: aload_2
    //   464: iload #8
    //   466: invokevirtual writeInt : (I)V
    //   469: aload_2
    //   470: iload #10
    //   472: invokevirtual writeInt : (I)V
    //   475: aload_2
    //   476: invokevirtual close : ()V
    //   479: iload #9
    //   481: ifeq -> 13
    //   484: iload_0
    //   485: iconst_4
    //   486: if_icmpge -> 13
    //   489: iload_0
    //   490: iconst_1
    //   491: iadd
    //   492: iconst_1
    //   493: invokestatic if : (IZ)V
    //   496: goto -> 13
    //   499: astore_3
    //   500: goto -> 13
    //   503: goto -> 112
    //   506: iconst_0
    //   507: istore #11
    //   509: iload #9
    //   511: istore #10
    //   513: iload #11
    //   515: istore #9
    //   517: goto -> 450
    // Exception table:
    //   from	to	target	type
    //   40	97	499	java/lang/Exception
    //   97	105	499	java/lang/Exception
    //   119	195	499	java/lang/Exception
    //   336	404	499	java/lang/Exception
    //   450	479	499	java/lang/Exception
    //   489	496	499	java/lang/Exception
  }
  
  public static void if(String paramString, int paramInt) {}
  
  public static void if(String paramString, int paramInt, boolean paramBoolean) {}
  
  private static boolean if(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramInt1 >= 0) {
      if (paramInt1 >= paramInt3)
        return bool1; 
    } else {
      return bool2;
    } 
    bool2 = bool1;
    if (paramInt2 >= 0) {
      bool2 = bool1;
      if (paramInt2 <= paramInt3) {
        bool2 = bool1;
        if (paramInt3 >= 0) {
          bool2 = bool1;
          if (paramInt3 <= 1024) {
            bool2 = bool1;
            if (paramInt4 >= 128) {
              bool2 = bool1;
              if (paramInt4 <= 1024)
                bool2 = true; 
            } 
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  private static boolean if(Location paramLocation) {
    boolean bool = true;
    if (paramLocation == null)
      return false; 
    if (cA == null || cn == null) {
      cA = paramLocation;
      return bool;
    } 
    double d1 = paramLocation.distanceTo(cA);
    double d2 = c.bb;
    double d3 = c.a8;
    double d4 = c.a6;
    if (paramLocation.distanceTo(cn) <= d1 * d3 + d2 * d1 * d1 + d4)
      bool = false; 
    return bool;
  }
  
  private static boolean if(Location paramLocation, ao.b paramb) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramLocation != null) {
      bool2 = bool1;
      if (paramb != null) {
        bool2 = bool1;
        if (paramb.for != null) {
          if (paramb.for.isEmpty())
            return bool1; 
        } else {
          return bool2;
        } 
      } else {
        return bool2;
      } 
    } else {
      return bool2;
    } 
    bool2 = bool1;
    if (!paramb.do(cp)) {
      if (b6 == null) {
        b6 = paramLocation;
        return true;
      } 
      bool2 = true;
    } 
    return bool2;
  }
  
  public static boolean if(Location paramLocation, boolean paramBoolean) {
    return v.if(cn, paramLocation, paramBoolean);
  }
  
  public static boolean if(String paramString, List<String> paramList) {
    boolean bool;
    File file = new File(paramString);
    if (!file.exists())
      return false; 
    try {
      RandomAccessFile randomAccessFile = new RandomAccessFile();
      this(file, "rw");
      randomAccessFile.seek(8L);
      int i = randomAccessFile.readInt();
      int j = randomAccessFile.readInt();
      int k = randomAccessFile.readInt();
      byte[] arrayOfByte = new byte[cy];
      int m = cj;
      m++;
      bool = false;
      while (true) {
        if (m > 0 && j > 0) {
          int n = k;
          if (j < k)
            n = 0; 
          long l1 = ((j - 1) * i + 128);
          try {
            randomAccessFile.seek(l1);
            k = randomAccessFile.readInt();
            boolean bool1 = bool;
            if (k > 0) {
              bool1 = bool;
              if (k < i) {
                randomAccessFile.read(arrayOfByte, 0, k);
                bool1 = bool;
                if (arrayOfByte[k - 1] == 0) {
                  String str = new String();
                  this(arrayOfByte, 0, k - 1);
                  paramList.add(0, str);
                  bool1 = true;
                } 
              } 
            } 
            m--;
            j--;
            bool = bool1;
            k = n;
            continue;
          } catch (Exception exception) {}
          return bool;
        } 
        exception.seek(12L);
        exception.writeInt(j);
        exception.writeInt(k);
        exception.close();
        return bool;
      } 
    } catch (Exception exception) {
      bool = false;
    } 
    return bool;
  }
  
  private static void long(String paramString) {
    case(paramString);
  }
  
  public static void t() {
    cj = 0;
    if(1, false);
    if(2, false);
    if(3, false);
    cj = 8;
  }
  
  public static o u() {
    if (cI == null)
      cI = new o(); 
    return cI;
  }
  
  public static String v() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_0
    //   2: aconst_null
    //   3: astore_1
    //   4: new java/io/File
    //   7: dup
    //   8: getstatic com/baidu/location/o.cD : Ljava/lang/String;
    //   11: invokespecial <init> : (Ljava/lang/String;)V
    //   14: astore_2
    //   15: aload_1
    //   16: astore_3
    //   17: aload_2
    //   18: invokevirtual exists : ()Z
    //   21: ifeq -> 136
    //   24: aload_0
    //   25: astore_3
    //   26: new java/io/RandomAccessFile
    //   29: astore #4
    //   31: aload_0
    //   32: astore_3
    //   33: aload #4
    //   35: aload_2
    //   36: ldc 'rw'
    //   38: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   41: aload_0
    //   42: astore_3
    //   43: aload #4
    //   45: ldc2_w 20
    //   48: invokevirtual seek : (J)V
    //   51: aload_0
    //   52: astore_3
    //   53: aload #4
    //   55: invokevirtual readInt : ()I
    //   58: istore #5
    //   60: iload #5
    //   62: sipush #128
    //   65: if_icmple -> 127
    //   68: aload_0
    //   69: astore_3
    //   70: new java/lang/StringBuilder
    //   73: astore_1
    //   74: aload_0
    //   75: astore_3
    //   76: aload_1
    //   77: invokespecial <init> : ()V
    //   80: aload_0
    //   81: astore_3
    //   82: aload_1
    //   83: ldc_w '&p1='
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: iload #5
    //   91: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   94: invokevirtual toString : ()Ljava/lang/String;
    //   97: astore_0
    //   98: aload_0
    //   99: astore_3
    //   100: aload #4
    //   102: ldc2_w 20
    //   105: invokevirtual seek : (J)V
    //   108: aload_0
    //   109: astore_3
    //   110: aload #4
    //   112: iconst_0
    //   113: invokevirtual writeInt : (I)V
    //   116: aload_0
    //   117: astore_3
    //   118: aload #4
    //   120: invokevirtual close : ()V
    //   123: aload_0
    //   124: astore_3
    //   125: aload_3
    //   126: areturn
    //   127: aload_0
    //   128: astore_3
    //   129: aload #4
    //   131: invokevirtual close : ()V
    //   134: aload_1
    //   135: astore_3
    //   136: new java/io/File
    //   139: dup
    //   140: getstatic com/baidu/location/o.ct : Ljava/lang/String;
    //   143: invokespecial <init> : (Ljava/lang/String;)V
    //   146: astore #4
    //   148: aload_3
    //   149: astore_0
    //   150: aload #4
    //   152: invokevirtual exists : ()Z
    //   155: ifeq -> 258
    //   158: aload_3
    //   159: astore_0
    //   160: new java/io/RandomAccessFile
    //   163: astore_1
    //   164: aload_3
    //   165: astore_0
    //   166: aload_1
    //   167: aload #4
    //   169: ldc 'rw'
    //   171: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   174: aload_3
    //   175: astore_0
    //   176: aload_1
    //   177: ldc2_w 20
    //   180: invokevirtual seek : (J)V
    //   183: aload_3
    //   184: astore_0
    //   185: aload_1
    //   186: invokevirtual readInt : ()I
    //   189: istore #5
    //   191: iload #5
    //   193: sipush #256
    //   196: if_icmple -> 385
    //   199: aload_3
    //   200: astore_0
    //   201: new java/lang/StringBuilder
    //   204: astore #4
    //   206: aload_3
    //   207: astore_0
    //   208: aload #4
    //   210: invokespecial <init> : ()V
    //   213: aload_3
    //   214: astore_0
    //   215: aload #4
    //   217: ldc_w '&p2='
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: iload #5
    //   225: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   228: invokevirtual toString : ()Ljava/lang/String;
    //   231: astore_3
    //   232: aload_3
    //   233: astore_0
    //   234: aload_1
    //   235: ldc2_w 20
    //   238: invokevirtual seek : (J)V
    //   241: aload_3
    //   242: astore_0
    //   243: aload_1
    //   244: iconst_0
    //   245: invokevirtual writeInt : (I)V
    //   248: aload_3
    //   249: astore_0
    //   250: aload_1
    //   251: invokevirtual close : ()V
    //   254: goto -> 125
    //   257: astore_3
    //   258: new java/io/File
    //   261: dup
    //   262: getstatic com/baidu/location/o.cz : Ljava/lang/String;
    //   265: invokespecial <init> : (Ljava/lang/String;)V
    //   268: astore #4
    //   270: aload_0
    //   271: astore_3
    //   272: aload #4
    //   274: invokevirtual exists : ()Z
    //   277: ifeq -> 125
    //   280: aload_0
    //   281: astore_3
    //   282: new java/io/RandomAccessFile
    //   285: astore_1
    //   286: aload_0
    //   287: astore_3
    //   288: aload_1
    //   289: aload #4
    //   291: ldc 'rw'
    //   293: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   296: aload_0
    //   297: astore_3
    //   298: aload_1
    //   299: ldc2_w 20
    //   302: invokevirtual seek : (J)V
    //   305: aload_0
    //   306: astore_3
    //   307: aload_1
    //   308: invokevirtual readInt : ()I
    //   311: istore #5
    //   313: iload #5
    //   315: sipush #512
    //   318: if_icmple -> 396
    //   321: aload_0
    //   322: astore_3
    //   323: new java/lang/StringBuilder
    //   326: astore #4
    //   328: aload_0
    //   329: astore_3
    //   330: aload #4
    //   332: invokespecial <init> : ()V
    //   335: aload_0
    //   336: astore_3
    //   337: aload #4
    //   339: ldc_w '&p3='
    //   342: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   345: iload #5
    //   347: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   350: invokevirtual toString : ()Ljava/lang/String;
    //   353: astore_0
    //   354: aload_0
    //   355: astore_3
    //   356: aload_1
    //   357: ldc2_w 20
    //   360: invokevirtual seek : (J)V
    //   363: aload_0
    //   364: astore_3
    //   365: aload_1
    //   366: iconst_0
    //   367: invokevirtual writeInt : (I)V
    //   370: aload_0
    //   371: astore_3
    //   372: aload_1
    //   373: invokevirtual close : ()V
    //   376: aload_0
    //   377: astore_3
    //   378: goto -> 125
    //   381: astore_0
    //   382: goto -> 125
    //   385: aload_3
    //   386: astore_0
    //   387: aload_1
    //   388: invokevirtual close : ()V
    //   391: aload_3
    //   392: astore_0
    //   393: goto -> 258
    //   396: aload_0
    //   397: astore_3
    //   398: aload_1
    //   399: invokevirtual close : ()V
    //   402: aload_0
    //   403: astore_3
    //   404: goto -> 125
    //   407: astore_0
    //   408: goto -> 136
    // Exception table:
    //   from	to	target	type
    //   26	31	407	java/lang/Exception
    //   33	41	407	java/lang/Exception
    //   43	51	407	java/lang/Exception
    //   53	60	407	java/lang/Exception
    //   70	74	407	java/lang/Exception
    //   76	80	407	java/lang/Exception
    //   82	98	407	java/lang/Exception
    //   100	108	407	java/lang/Exception
    //   110	116	407	java/lang/Exception
    //   118	123	407	java/lang/Exception
    //   129	134	407	java/lang/Exception
    //   160	164	257	java/lang/Exception
    //   166	174	257	java/lang/Exception
    //   176	183	257	java/lang/Exception
    //   185	191	257	java/lang/Exception
    //   201	206	257	java/lang/Exception
    //   208	213	257	java/lang/Exception
    //   215	232	257	java/lang/Exception
    //   234	241	257	java/lang/Exception
    //   243	248	257	java/lang/Exception
    //   250	254	257	java/lang/Exception
    //   282	286	381	java/lang/Exception
    //   288	296	381	java/lang/Exception
    //   298	305	381	java/lang/Exception
    //   307	313	381	java/lang/Exception
    //   323	328	381	java/lang/Exception
    //   330	335	381	java/lang/Exception
    //   337	354	381	java/lang/Exception
    //   356	363	381	java/lang/Exception
    //   365	370	381	java/lang/Exception
    //   372	376	381	java/lang/Exception
    //   387	391	257	java/lang/Exception
    //   398	402	381	java/lang/Exception
  }
  
  public static String x() {
    return z();
  }
  
  public static void y() {}
  
  public static String z() {
    String str1 = null;
    byte b1 = 1;
    while (b1 < 5) {
      String str = if(b1);
      if (str == null) {
        b1++;
        str1 = str;
        continue;
      } 
      return str;
    } 
    if(cB, ce);
    if (cB.size() > 0) {
      str1 = cB.get(0);
      cB.remove(0);
    } 
    String str2 = str1;
    if (str1 == null) {
      if(cB, cl);
      if (cB.size() > 0) {
        str1 = cB.get(0);
        cB.remove(0);
      } 
      str2 = str1;
      if (str1 == null) {
        if(cB, cF);
        str2 = str1;
        if (cB.size() > 0) {
          str2 = cB.get(0);
          cB.remove(0);
        } 
      } 
    } 
    return str2;
  }
  
  public void A() {
    if (ao.bA())
      this.cv.U(); 
  }
  
  public void goto(String paramString) {
    (new a(this, paramString)).T();
  }
  
  public void w() {
    if (!m.R().Q()) {
      this.ck++;
      if (this.ck > 1) {
        this.ck = 0;
        A();
      } 
    } 
  }
  
  private class a extends q {
    private String dc;
    
    public a(o this$0, String param1String) {
      this.dc = param1String;
      this.cP = new ArrayList();
    }
    
    void O() {
      this.cN = c.for();
      this.cP.add(new BasicNameValuePair("cldc[0]", this.dc));
    }
    
    public void T() {
      J();
    }
    
    void do(boolean param1Boolean) {
      if (!param1Boolean || this.cO != null);
    }
  }
  
  private class b extends q {
    boolean de = false;
    
    private ArrayList df = null;
    
    int dg = 0;
    
    int dh = 0;
    
    public b(o this$0) {}
    
    void O() {
      this.cN = c.for();
      this.cW = 2;
      if (this.df != null) {
        for (byte b1 = 0; b1 < this.df.size(); b1++) {
          if (this.dh == 1) {
            this.cP.add(new BasicNameValuePair("cldc[" + b1 + "]", this.df.get(b1)));
          } else {
            this.cP.add(new BasicNameValuePair("cltr[" + b1 + "]", this.df.get(b1)));
          } 
        } 
        String str = String.format(Locale.CHINA, "%d", new Object[] { Long.valueOf(System.currentTimeMillis()) });
        this.cP.add(new BasicNameValuePair("trtm", str));
      } 
    }
    
    public void U() {
      // Byte code:
      //   0: aload_0
      //   1: getfield de : Z
      //   4: ifeq -> 8
      //   7: return
      //   8: getstatic com/baidu/location/o$b.cU : I
      //   11: iconst_4
      //   12: if_icmple -> 38
      //   15: aload_0
      //   16: getfield dg : I
      //   19: getstatic com/baidu/location/o$b.cU : I
      //   22: if_icmpge -> 38
      //   25: aload_0
      //   26: aload_0
      //   27: getfield dg : I
      //   30: iconst_1
      //   31: iadd
      //   32: putfield dg : I
      //   35: goto -> 7
      //   38: aload_0
      //   39: iconst_0
      //   40: putfield dg : I
      //   43: aload_0
      //   44: iconst_1
      //   45: putfield de : Z
      //   48: aload_0
      //   49: iconst_0
      //   50: putfield dh : I
      //   53: aload_0
      //   54: getfield df : Ljava/util/ArrayList;
      //   57: ifnull -> 71
      //   60: aload_0
      //   61: getfield df : Ljava/util/ArrayList;
      //   64: invokevirtual size : ()I
      //   67: iconst_1
      //   68: if_icmpge -> 149
      //   71: aload_0
      //   72: getfield df : Ljava/util/ArrayList;
      //   75: ifnonnull -> 89
      //   78: aload_0
      //   79: new java/util/ArrayList
      //   82: dup
      //   83: invokespecial <init> : ()V
      //   86: putfield df : Ljava/util/ArrayList;
      //   89: aload_0
      //   90: iconst_0
      //   91: putfield dh : I
      //   94: iconst_0
      //   95: istore_1
      //   96: aload_0
      //   97: getfield dh : I
      //   100: iconst_2
      //   101: if_icmpge -> 256
      //   104: invokestatic x : ()Ljava/lang/String;
      //   107: astore_2
      //   108: aload_2
      //   109: ifnonnull -> 210
      //   112: aload_0
      //   113: getfield dh : I
      //   116: iconst_1
      //   117: if_icmpeq -> 210
      //   120: aload_0
      //   121: iconst_2
      //   122: putfield dh : I
      //   125: getstatic com/baidu/location/c.aT : I
      //   128: ifne -> 180
      //   131: invokestatic p : ()Ljava/lang/String;
      //   134: astore_3
      //   135: aload_3
      //   136: astore_2
      //   137: aload_3
      //   138: ifnonnull -> 145
      //   141: invokestatic az : ()Ljava/lang/String;
      //   144: astore_2
      //   145: aload_2
      //   146: ifnonnull -> 218
      //   149: aload_0
      //   150: getfield df : Ljava/util/ArrayList;
      //   153: ifnull -> 167
      //   156: aload_0
      //   157: getfield df : Ljava/util/ArrayList;
      //   160: invokevirtual size : ()I
      //   163: iconst_1
      //   164: if_icmpge -> 249
      //   167: aload_0
      //   168: aconst_null
      //   169: putfield df : Ljava/util/ArrayList;
      //   172: aload_0
      //   173: iconst_0
      //   174: putfield de : Z
      //   177: goto -> 7
      //   180: getstatic com/baidu/location/c.aT : I
      //   183: iconst_1
      //   184: if_icmpne -> 145
      //   187: invokestatic az : ()Ljava/lang/String;
      //   190: astore_3
      //   191: aload_3
      //   192: astore_2
      //   193: aload_3
      //   194: ifnonnull -> 145
      //   197: invokestatic p : ()Ljava/lang/String;
      //   200: astore_2
      //   201: goto -> 145
      //   204: astore_2
      //   205: aconst_null
      //   206: astore_2
      //   207: goto -> 145
      //   210: aload_0
      //   211: iconst_1
      //   212: putfield dh : I
      //   215: goto -> 145
      //   218: aload_0
      //   219: getfield df : Ljava/util/ArrayList;
      //   222: aload_2
      //   223: invokevirtual add : (Ljava/lang/Object;)Z
      //   226: pop
      //   227: iload_1
      //   228: aload_2
      //   229: invokevirtual length : ()I
      //   232: iadd
      //   233: istore #4
      //   235: iload #4
      //   237: istore_1
      //   238: iload #4
      //   240: sipush #5120
      //   243: if_icmplt -> 96
      //   246: goto -> 149
      //   249: aload_0
      //   250: invokevirtual J : ()V
      //   253: goto -> 7
      //   256: aconst_null
      //   257: astore_2
      //   258: goto -> 108
      // Exception table:
      //   from	to	target	type
      //   125	135	204	java/lang/Exception
      //   141	145	204	java/lang/Exception
      //   180	191	204	java/lang/Exception
      //   197	201	204	java/lang/Exception
    }
    
    void do(boolean param1Boolean) {
      if (param1Boolean && this.cO != null && this.df != null)
        this.df.clear(); 
      if (this.cP != null)
        this.cP.clear(); 
      this.de = false;
    }
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */