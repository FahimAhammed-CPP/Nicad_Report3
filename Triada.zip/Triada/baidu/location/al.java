package com.baidu.location;

import android.os.HandlerThread;

class al {
  private static HandlerThread a = null;
  
  static HandlerThread a() {
    if (a == null) {
      a = new HandlerThread("ServiceStartArguments", 10);
      a.start();
    } 
    return a;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */