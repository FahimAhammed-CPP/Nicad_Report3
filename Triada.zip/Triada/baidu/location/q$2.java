package com.baidu.location;

class q$2 extends Thread {
  q$2(q paramq) {}
  
  public void run() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Lcom/baidu/location/q;
    //   4: invokestatic for : ()Ljava/lang/String;
    //   7: putfield cN : Ljava/lang/String;
    //   10: aload_0
    //   11: getfield a : Lcom/baidu/location/q;
    //   14: invokevirtual O : ()V
    //   17: aload_0
    //   18: getfield a : Lcom/baidu/location/q;
    //   21: getfield cW : I
    //   24: istore_1
    //   25: aload_0
    //   26: getfield a : Lcom/baidu/location/q;
    //   29: invokestatic if : (Lcom/baidu/location/q;)V
    //   32: aconst_null
    //   33: astore_2
    //   34: iload_1
    //   35: ifle -> 273
    //   38: new org/apache/http/client/methods/HttpPost
    //   41: astore_3
    //   42: aload_3
    //   43: aload_0
    //   44: getfield a : Lcom/baidu/location/q;
    //   47: getfield cN : Ljava/lang/String;
    //   50: invokespecial <init> : (Ljava/lang/String;)V
    //   53: new org/apache/http/entity/FileEntity
    //   56: astore_2
    //   57: new java/io/File
    //   60: astore #4
    //   62: aload #4
    //   64: aload_0
    //   65: getfield a : Lcom/baidu/location/q;
    //   68: getfield cS : Ljava/lang/String;
    //   71: invokespecial <init> : (Ljava/lang/String;)V
    //   74: aload_2
    //   75: aload #4
    //   77: ldc 'binary/octet-stream'
    //   79: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   82: aload_3
    //   83: ldc 'Content-Type'
    //   85: ldc 'application/octet-stream'
    //   87: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   90: aload_3
    //   91: ldc 'Accept-Charset'
    //   93: ldc 'UTF-8;'
    //   95: invokevirtual setHeader : (Ljava/lang/String;Ljava/lang/String;)V
    //   98: aload_3
    //   99: aload_2
    //   100: invokevirtual setEntity : (Lorg/apache/http/HttpEntity;)V
    //   103: new org/apache/http/impl/client/DefaultHttpClient
    //   106: astore #4
    //   108: aload #4
    //   110: invokespecial <init> : ()V
    //   113: aload #4
    //   115: invokeinterface getParams : ()Lorg/apache/http/params/HttpParams;
    //   120: ldc 'http.connection.timeout'
    //   122: sipush #12000
    //   125: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   128: invokeinterface setParameter : (Ljava/lang/String;Ljava/lang/Object;)Lorg/apache/http/params/HttpParams;
    //   133: pop
    //   134: aload #4
    //   136: invokeinterface getParams : ()Lorg/apache/http/params/HttpParams;
    //   141: ldc 'http.socket.timeout'
    //   143: sipush #12000
    //   146: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   149: invokeinterface setParameter : (Ljava/lang/String;Ljava/lang/Object;)Lorg/apache/http/params/HttpParams;
    //   154: pop
    //   155: aload #4
    //   157: invokeinterface getParams : ()Lorg/apache/http/params/HttpParams;
    //   162: iconst_0
    //   163: invokestatic setUseExpectContinue : (Lorg/apache/http/params/HttpParams;Z)V
    //   166: invokestatic I : ()I
    //   169: iconst_1
    //   170: if_icmpeq -> 180
    //   173: invokestatic I : ()I
    //   176: iconst_4
    //   177: if_icmpne -> 226
    //   180: aload_0
    //   181: getfield a : Lcom/baidu/location/q;
    //   184: getfield cW : I
    //   187: iload_1
    //   188: isub
    //   189: iconst_2
    //   190: irem
    //   191: ifne -> 226
    //   194: new org/apache/http/HttpHost
    //   197: astore_2
    //   198: aload_2
    //   199: invokestatic K : ()Ljava/lang/String;
    //   202: invokestatic N : ()I
    //   205: ldc 'http'
    //   207: invokespecial <init> : (Ljava/lang/String;ILjava/lang/String;)V
    //   210: aload #4
    //   212: invokeinterface getParams : ()Lorg/apache/http/params/HttpParams;
    //   217: ldc 'http.route.default-proxy'
    //   219: aload_2
    //   220: invokeinterface setParameter : (Ljava/lang/String;Ljava/lang/Object;)Lorg/apache/http/params/HttpParams;
    //   225: pop
    //   226: aload #4
    //   228: aload_3
    //   229: invokeinterface execute : (Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    //   234: astore_2
    //   235: aload_2
    //   236: invokeinterface getStatusLine : ()Lorg/apache/http/StatusLine;
    //   241: invokeinterface getStatusCode : ()I
    //   246: sipush #200
    //   249: if_icmpne -> 311
    //   252: aload_0
    //   253: getfield a : Lcom/baidu/location/q;
    //   256: aload_2
    //   257: invokeinterface getEntity : ()Lorg/apache/http/HttpEntity;
    //   262: putfield cO : Lorg/apache/http/HttpEntity;
    //   265: aload_0
    //   266: getfield a : Lcom/baidu/location/q;
    //   269: iconst_1
    //   270: invokevirtual do : (Z)V
    //   273: iload_1
    //   274: ifgt -> 341
    //   277: getstatic com/baidu/location/q.cU : I
    //   280: iconst_1
    //   281: iadd
    //   282: putstatic com/baidu/location/q.cU : I
    //   285: aload_0
    //   286: getfield a : Lcom/baidu/location/q;
    //   289: aconst_null
    //   290: putfield cO : Lorg/apache/http/HttpEntity;
    //   293: aload_0
    //   294: getfield a : Lcom/baidu/location/q;
    //   297: iconst_0
    //   298: invokevirtual do : (Z)V
    //   301: aload_0
    //   302: getfield a : Lcom/baidu/location/q;
    //   305: iconst_0
    //   306: invokestatic if : (Lcom/baidu/location/q;Z)Z
    //   309: pop
    //   310: return
    //   311: aload_3
    //   312: invokevirtual abort : ()V
    //   315: aload_3
    //   316: astore_2
    //   317: iinc #1, -1
    //   320: goto -> 34
    //   323: astore_2
    //   324: aload_3
    //   325: astore_2
    //   326: aload_2
    //   327: invokevirtual abort : ()V
    //   330: ldc 'baidu_location_service'
    //   332: ldc 'NetworkCommunicationException!'
    //   334: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   337: pop
    //   338: goto -> 317
    //   341: iconst_0
    //   342: putstatic com/baidu/location/q.cU : I
    //   345: goto -> 301
    //   348: astore_3
    //   349: goto -> 326
    // Exception table:
    //   from	to	target	type
    //   38	53	348	java/lang/Exception
    //   53	180	323	java/lang/Exception
    //   180	226	323	java/lang/Exception
    //   226	273	323	java/lang/Exception
    //   311	315	323	java/lang/Exception
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/baidu/location/q$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */