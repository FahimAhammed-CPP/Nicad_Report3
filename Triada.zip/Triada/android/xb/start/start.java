package com.android.xb.start;

import android.content.Context;
import e.b;

public class start {
  public static Context a;
  
  public static Thread b;
  
  private static boolean c = false;
  
  public static void init(Context paramContext) {
    if (b == null) {
      b = new start$2(paramContext);
      b.start();
    } 
  }
  
  public static void setInterface(SuccessInterface paramSuccessInterface) {
    b.a(paramSuccessInterface);
  }
  
  public void init(Context paramContext, String paramString) {
    if (b == null) {
      b = new start$1(this, paramContext, paramString);
      b.start();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/xb/start/start.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */