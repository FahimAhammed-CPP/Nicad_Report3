package com.android.xb.start;

public interface SuccessInterface {
  void OnFailed();
  
  void OnSuccess();
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/xb/start/SuccessInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */