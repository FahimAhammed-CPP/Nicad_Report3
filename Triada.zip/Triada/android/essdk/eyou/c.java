package com.android.essdk.eyou;

import android.content.Context;
import com.android.essdk.eyou.ui.a;

class c implements a {
  c(EPayActivity paramEPayActivity) {}
  
  public void a() {
    EPayActivity.g(this.a);
  }
  
  public void b() {
    d.a().a((Context)this.a);
    EPayActivity.e(this.a);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */