package com.android.essdk.eyou;

class g implements Runnable {
  g(d paramd, int paramInt) {}
  
  public void run() {
    if (this.a.a == null)
      throw new RuntimeException("EpayCallback is null ? == 回调函数不能为空。"); 
    this.a.a.onEpayBuyProductFaild(d.b(this.a), (new StringBuilder(String.valueOf(this.b))).toString());
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */