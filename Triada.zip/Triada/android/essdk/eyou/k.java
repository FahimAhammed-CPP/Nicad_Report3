package com.android.essdk.eyou;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

class k extends Handler {
  k(PlateService paramPlateService) {}
  
  public void handleMessage(Message paramMessage) {
    super.handleMessage(paramMessage);
    Log.e("handleMessage", "Message msg.what=" + paramMessage.what + " msg.arg1=" + paramMessage.arg1 + " msg.arg2=" + paramMessage.arg2 + " msg.obj=" + paramMessage.obj + " msg.toString()=" + paramMessage.toString());
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */