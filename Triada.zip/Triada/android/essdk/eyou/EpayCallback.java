package com.android.essdk.eyou;

public interface EpayCallback {
  void onEpayBuyProductFaild(String paramString1, String paramString2);
  
  void onEpayBuyProductOK(String paramString1, String paramString2);
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/EpayCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */