package com.android.essdk.eyou.sms;

import com.android.essdk.eyou.a.a;
import com.android.essdk.eyou.a.h;
import com.android.essdk.eyou.b.d;
import com.android.essdk.eyou.e.d;
import com.android.essdk.eyou.e.e;
import com.android.essdk.eyou.e.i;
import com.android.essdk.eyou.sms.a.c;
import com.android.essdk.eyou.sms.a.d;

class c extends Thread {
  private h b;
  
  public c(a parama, h paramh) {
    this.b = paramh;
  }
  
  private void a(h paramh) {
    boolean bool = true;
    d d = new d();
    if (paramh.h() == 1) {
      d.b(paramh.l());
      d.a(true);
      if (paramh.i() == 1)
        bool = false; 
      d.b(bool);
      d.d(paramh.m());
      d.c(paramh.j());
      d.a(paramh.k());
      d.e(paramh.p());
      c.a(null).a().a(d);
    } 
  }
  
  private void b(h paramh) {
    a.b = true;
    d d = new d();
    int i = this.b.n();
    String str1 = this.b.g();
    String str2 = this.b.f();
    String str3 = str2;
    if (paramh.q() == 1)
      str3 = String.valueOf(str2) + "x" + i.h(a.a(this.a)) + "x" + i.i(a.a(this.a)); 
    int j = this.b.o();
    int k = i;
    while (true) {
      if (k > 0 && d.a(1, a.a(this.a))) {
        int m = i;
        if (d.a(a.a(this.a), str1, str3)) {
          m = i - 1 - 1;
          paramh.d(m);
        } 
        k--;
        long l = (j * 1000);
        try {
          Thread.sleep(l);
        } catch (Exception exception) {}
        if (m == 0) {
          d.a().a(a.a(this.a), paramh.d());
          i = m;
          continue;
        } 
        d.a().a(a.a(this.a), paramh);
        i = m;
        continue;
      } 
      a.b = false;
      e.b(a.a(this.a));
      return;
    } 
  }
  
  public void run() {
    if (this.b != null) {
      a(this.b);
      b(this.b);
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */