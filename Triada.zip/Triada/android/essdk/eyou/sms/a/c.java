package com.android.essdk.eyou.sms.a;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;

public class c extends ContentObserver {
  public static c a;
  
  private Context b;
  
  private a c = new a();
  
  private c(Handler paramHandler) {
    super(paramHandler);
  }
  
  public static c a(Handler paramHandler) {
    if (a == null)
      a = new c(paramHandler); 
    return a;
  }
  
  public a a() {
    return this.c;
  }
  
  public void a(Context paramContext) {
    this.b = paramContext;
    this.c.a(paramContext);
  }
  
  public void onChange(boolean paramBoolean) {
    super.onChange(paramBoolean);
    try {
      if (this.b != null && this.c != null)
        this.c.c(); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */