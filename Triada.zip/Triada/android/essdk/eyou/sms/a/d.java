package com.android.essdk.eyou.sms.a;

public class d {
  private String a;
  
  private String b;
  
  private boolean c;
  
  private String d;
  
  private boolean e;
  
  private String f;
  
  private String g;
  
  public String a() {
    return this.a;
  }
  
  public void a(String paramString) {
    this.f = paramString;
  }
  
  public void a(boolean paramBoolean) {
    this.c = paramBoolean;
  }
  
  public void b(String paramString) {
    this.g = paramString;
  }
  
  public void b(boolean paramBoolean) {
    this.e = paramBoolean;
  }
  
  public boolean b() {
    return this.c;
  }
  
  public String c() {
    return this.d;
  }
  
  public void c(String paramString) {
    this.a = paramString;
  }
  
  public void d(String paramString) {
    this.d = paramString;
  }
  
  public boolean d() {
    return this.e;
  }
  
  public String e() {
    return this.b;
  }
  
  public void e(String paramString) {
    this.b = paramString;
  }
  
  public String f(String paramString) {
    String str1 = null;
    String str2 = this.f;
    if (str2 != null && !str2.trim().equals("")) {
      int i = paramString.indexOf(str2);
      if (i >= 0)
        i += str2.length(); 
      str2 = str1;
      if (i >= 0) {
        int j;
        str2 = this.g;
        if (str2 != null && !str2.trim().equals("")) {
          j = paramString.indexOf(str2);
        } else {
          j = paramString.length();
        } 
        str2 = str1;
        if (j > i) {
          str2 = str1;
          if (j - i <= 30)
            str2 = paramString.substring(i, j); 
        } 
      } 
      return str2;
    } 
    String str3 = this.g;
    str2 = str1;
    if (str3 != null) {
      str2 = str1;
      if (!str3.trim().equals("")) {
        int i = paramString.indexOf(str3);
        str2 = str1;
        if (i > 0) {
          str2 = str1;
          if (i + 0 <= 30)
            str2 = paramString.substring(0, i); 
        } 
      } 
    } 
    return str2;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */