package com.android.essdk.eyou.sms.a;

import com.android.essdk.eyou.sms.d;

class b extends Thread {
  b(a parama, d paramd, String paramString1, String paramString2) {}
  
  public void run() {
    String str2;
    String str1 = this.b.a();
    if (this.b.d()) {
      str2 = this.b.f(this.c);
    } else {
      str2 = this.b.c();
    } 
    if (str1 != null && !str1.trim().equals("") && str2 != null && !str2.trim().equals(""))
      (new d()).a(a.a(this.a), this.d, str2); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */