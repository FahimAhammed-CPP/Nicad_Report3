package com.android.essdk.eyou.sms;

public interface b {
  void a();
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */