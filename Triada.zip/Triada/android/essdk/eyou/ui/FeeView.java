package com.android.essdk.eyou.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.c;
import com.android.essdk.eyou.e.f;
import java.math.BigDecimal;

public class FeeView extends RelativeLayout implements View.OnClickListener {
  public static String c;
  
  public static String d;
  
  public Button a;
  
  public Button b;
  
  private RelativeLayout e;
  
  private ImageView f;
  
  private TextView g;
  
  private WebView h;
  
  private a i;
  
  public FeeView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    b();
  }
  
  public static String a(String paramString) {
    return BigDecimal.valueOf(Long.valueOf(paramString).longValue()).divide(new BigDecimal(100)).toString();
  }
  
  private void b() {
    this.e = new RelativeLayout(getContext(), null);
    setBackgroundColor(Color.argb(102, 0, 0, 0));
    Drawable drawable = f.a(getContext(), "epay_pic/pay_bg.9.png");
    this.e.setBackgroundDrawable(drawable);
    int i = (int)(250.0F * c.a(getContext()));
    int j = (int)(250.0F * c.a(getContext()));
    c.a(getContext());
    RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(i, j);
    layoutParams.addRule(13, -1);
    this.e.setId(1996);
    addView((View)this.e, (ViewGroup.LayoutParams)layoutParams);
    int k = (int)(50.0F * c.a(getContext()));
    j = (int)(c.a(getContext()) * 200.0F);
    i = (int)(10.0F * c.a(getContext()));
    layoutParams = new RelativeLayout.LayoutParams(j, k);
    layoutParams.addRule(13, -1);
    layoutParams.addRule(10, -1);
    layoutParams.topMargin = i;
    this.f = new ImageView(getContext());
    this.f.setImageBitmap(c.a("epay_pic/top_title.png", getContext(), j, k));
    this.f.setId(1997);
    this.e.addView((View)this.f, (ViewGroup.LayoutParams)layoutParams);
    j = (int)(c.a(getContext()) * 200.0F);
    k = (int)(100.0F * c.a(getContext()));
    i = (int)(c.a(getContext()) * 20.0F);
    layoutParams = new RelativeLayout.LayoutParams(j, k);
    layoutParams.addRule(3, this.f.getId());
    layoutParams.topMargin = i;
    layoutParams.addRule(14, -1);
    this.g = new TextView(getContext());
    this.g.setTextSize(17.0F);
    String str = e.a().j(getContext());
    this.g.setText("商品价格:" + a(str) + "￥");
    this.g.setTextColor(-16777216);
    this.g.setText("购买商品详情:" + e.a().i(getContext()) + ",价格为:" + a(str) + ".00元");
    this.g.setTextColor(-1728053248);
    this.g.setId(1998);
    this.e.addView((View)this.g, (ViewGroup.LayoutParams)layoutParams);
    j = (int)(c.a(getContext()) * 200.0F);
    k = (int)(150.0F * c.a(getContext()));
    i = (int)(90.0F * c.a(getContext()));
    layoutParams = new RelativeLayout.LayoutParams(j, k);
    layoutParams.addRule(3, this.f.getId());
    layoutParams.topMargin = i;
    layoutParams.addRule(14, -1);
    this.g = new TextView(getContext());
    this.g.setTextSize(14.0F);
    this.g.setTextColor(Color.rgb(82, 161, 232));
    this.g.setId(2000);
    this.e.addView((View)this.g, (ViewGroup.LayoutParams)layoutParams);
    j = (int)(c.a(getContext()) * 20.0F);
    i = (int)(150.0F * c.a(getContext()));
    layoutParams = new RelativeLayout.LayoutParams((int)(c.a(getContext()) * 200.0F), i);
    layoutParams.addRule(12, -1);
    layoutParams.addRule(13, -1);
    layoutParams.leftMargin = j;
    layoutParams.rightMargin = j;
    layoutParams.bottomMargin = j;
    this.h = new WebView(getContext());
    this.h.setId(2001);
    this.h.setScrollBarStyle(0);
    j = (int)(40.0F * c.a(getContext()));
    layoutParams = new RelativeLayout.LayoutParams((int)(180.0F * c.a(getContext())), j);
    layoutParams.addRule(13, -1);
    layoutParams.bottomMargin = (int)(5.0F * c.a(getContext()));
    layoutParams.addRule(12, this.h.getId());
    this.a = new Button(getContext());
    this.a.setOnClickListener(this);
    this.a.setBackgroundDrawable((Drawable)c.a(getContext(), "epay_pic/button_normal.9.png", "epay_pic/button_on.9.png", "epay_pic/button_on.9.png", "epay_pic/button_on.9.png"));
    this.a.setId(2002);
    this.a.setText("确认");
    this.a.setTextColor(-1);
    this.a.setTextSize(22.0F);
    this.e.addView((View)this.a, (ViewGroup.LayoutParams)layoutParams);
    j = (int)(1.0F * c.a(getContext()));
    i = (int)(40.0F * c.a(getContext()));
    layoutParams = new RelativeLayout.LayoutParams(i, i);
    layoutParams.addRule(10, -1);
    layoutParams.addRule(11, -1);
    layoutParams.rightMargin = j;
    layoutParams.topMargin = j;
    this.b = new Button(getContext());
    this.b.setOnClickListener(this);
    this.b.setBackgroundDrawable((Drawable)c.a(getContext(), "epay_pic/close_normal.9.png", "epay_pic/close_pressed.9.png", "epay_pic/close_pressed.9.png", "epay_pic/close_pressed.9.png"));
    this.b.setId(2003);
    this.e.addView((View)this.b, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public void a() {
    if (d != null)
      this.g.setText(d); 
    if (c != null) {
      this.h.getSettings().setDefaultTextEncodingName("utf-8");
      this.h.loadDataWithBaseURL(null, c, "text/html", "utf-8", null);
    } 
  }
  
  public void a(a parama) {
    this.i = parama;
  }
  
  public void onClick(View paramView) {
    if (paramView == this.b) {
      if (this.i != null)
        this.i.b(); 
      return;
    } 
    if (paramView == this.a && this.i != null)
      this.i.a(); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/ui/FeeView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */