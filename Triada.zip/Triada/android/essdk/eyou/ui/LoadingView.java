package com.android.essdk.eyou.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.essdk.eyou.e.f;
import com.android.essdk.eyou.e.l;

public class LoadingView extends RelativeLayout {
  private TextView a;
  
  public LoadingView(Context paramContext) {
    super(paramContext);
    a(paramContext);
  }
  
  public LoadingView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    a(paramContext);
  }
  
  private void a(Context paramContext) {
    LinearLayout linearLayout = new LinearLayout(getContext(), null);
    linearLayout.setOrientation(1);
    linearLayout.setBackgroundDrawable(f.a(paramContext, "epay_pic/loading_background.9.png"));
    setBackgroundColor(1711276032);
    RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(l.a(getContext(), 128.0F), l.a(getContext(), 64.0F));
    layoutParams1.addRule(13, -1);
    addView((View)linearLayout, (ViewGroup.LayoutParams)layoutParams1);
    ProgressBar progressBar = new ProgressBar(getContext());
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
    layoutParams.gravity = 17;
    this.a = new TextView(paramContext);
    this.a.setTypeface(Typeface.defaultFromStyle(1));
    this.a.setTextColor(-1711276033);
    this.a.setText("");
    linearLayout.addView((View)this.a, (ViewGroup.LayoutParams)layoutParams);
    linearLayout.addView((View)progressBar, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public void a(CharSequence paramCharSequence) {
    this.a.setText(paramCharSequence);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/ui/LoadingView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */