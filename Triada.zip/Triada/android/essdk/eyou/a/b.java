package com.android.essdk.eyou.a;

import java.io.Serializable;

public class b implements Serializable {
  private int a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  public String a() {
    return this.b;
  }
  
  public void a(int paramInt) {
    this.a = paramInt;
  }
  
  public void a(String paramString) {
    this.b = paramString;
  }
  
  public String b() {
    return this.c;
  }
  
  public void b(String paramString) {
    this.c = paramString;
  }
  
  public String c() {
    return this.d;
  }
  
  public void c(String paramString) {
    this.d = paramString;
  }
  
  public int d() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */