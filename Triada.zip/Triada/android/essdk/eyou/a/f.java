package com.android.essdk.eyou.a;

public class f {
  private String a;
  
  private int b;
  
  private int c;
  
  private String d;
  
  public String a() {
    return this.a;
  }
  
  public void a(int paramInt) {
    this.b = paramInt;
  }
  
  public void a(String paramString) {
    this.a = paramString;
  }
  
  public int b() {
    return this.b;
  }
  
  public void b(int paramInt) {
    this.c = paramInt;
  }
  
  public void b(String paramString) {
    this.d = paramString;
  }
  
  public String c() {
    return this.d;
  }
  
  public int d() {
    return this.c;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */