package com.android.essdk.eyou.a;

public class a {
  public static boolean a = false;
  
  public static boolean b = false;
  
  public static boolean c = false;
  
  public static boolean d = false;
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */