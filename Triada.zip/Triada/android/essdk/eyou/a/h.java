package com.android.essdk.eyou.a;

public class h extends b {
  private String a;
  
  private String b;
  
  private int c;
  
  private int d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private int j;
  
  private int k;
  
  private boolean l;
  
  private int m;
  
  public void a(boolean paramBoolean) {
    this.l = paramBoolean;
  }
  
  public void b(int paramInt) {
    this.c = paramInt;
  }
  
  public void c(int paramInt) {
    this.d = paramInt;
  }
  
  public void d(int paramInt) {
    this.j = paramInt;
  }
  
  public void d(String paramString) {
    this.a = paramString;
  }
  
  public void e(int paramInt) {
    this.k = paramInt;
  }
  
  public void e(String paramString) {
    this.b = paramString;
  }
  
  public boolean e() {
    return this.l;
  }
  
  public String f() {
    return this.a;
  }
  
  public void f(int paramInt) {
    this.m = paramInt;
  }
  
  public void f(String paramString) {
    this.e = paramString;
  }
  
  public String g() {
    return this.b;
  }
  
  public void g(String paramString) {
    this.g = paramString;
  }
  
  public int h() {
    return this.c;
  }
  
  public void h(String paramString) {
    this.h = paramString;
  }
  
  public int i() {
    return this.d;
  }
  
  public void i(String paramString) {
    this.i = paramString;
  }
  
  public String j() {
    return this.e;
  }
  
  public void j(String paramString) {
    this.f = paramString;
  }
  
  public String k() {
    return this.g;
  }
  
  public String l() {
    return this.h;
  }
  
  public String m() {
    return this.i;
  }
  
  public int n() {
    return this.j;
  }
  
  public int o() {
    return this.k;
  }
  
  public String p() {
    return this.f;
  }
  
  public int q() {
    return this.m;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */