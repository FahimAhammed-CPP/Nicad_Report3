package com.android.essdk.eyou.a;

import java.util.ArrayList;
import java.util.List;

public class g extends b {
  private List a = new ArrayList();
  
  public void a(List paramList) {
    this.a = paramList;
  }
  
  public List e() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */