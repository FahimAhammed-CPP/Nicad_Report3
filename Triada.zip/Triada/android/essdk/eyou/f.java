package com.android.essdk.eyou;

class f implements Runnable {
  f(d paramd) {}
  
  public void run() {
    this.a.a.onEpayBuyProductOK(d.b(this.a), "101");
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */