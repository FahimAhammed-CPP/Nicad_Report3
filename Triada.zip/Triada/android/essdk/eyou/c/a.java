package com.android.essdk.eyou.c;

import android.content.Context;
import com.android.essdk.eyou.e.e;
import com.android.essdk.eyou.e.h;
import com.android.essdk.eyou.e.i;
import java.util.List;

public class a {
  private final Context a;
  
  public a(Context paramContext) {
    this.a = paramContext;
  }
  
  private void b(List paramList) {
    (new b(this, paramList)).start();
  }
  
  public boolean a(List paramList) {
    com.android.essdk.eyou.a.a.d = true;
    if (h.a(this.a).a()) {
      String str = i.f(this.a);
      if (str.equals("wifi") || str.equals("unknow"))
        e.a(this.a); 
      b(paramList);
      return false;
    } 
    com.android.essdk.eyou.a.a.d = false;
    e.b(this.a);
    return false;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/c/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */