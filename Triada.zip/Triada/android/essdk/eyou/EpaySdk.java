package com.android.essdk.eyou;

import android.content.Context;
import android.content.Intent;
import java.util.HashMap;
import java.util.Map;

public class EpaySdk {
  private static EpaySdk b = null;
  
  public EpayCallback a;
  
  private void a(Context paramContext, Map paramMap) {
    Intent intent = new Intent();
    intent.setClass(paramContext, EPayActivity.class);
    intent.addFlags(536870912);
    intent.putExtra("map", (HashMap)paramMap);
    paramContext.startActivity(intent);
  }
  
  public static EpaySdk getInstance() {
    // Byte code:
    //   0: ldc com/android/essdk/eyou/EpaySdk
    //   2: monitorenter
    //   3: getstatic com/android/essdk/eyou/EpaySdk.b : Lcom/android/essdk/eyou/EpaySdk;
    //   6: ifnonnull -> 21
    //   9: new com/android/essdk/eyou/EpaySdk
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/android/essdk/eyou/EpaySdk.b : Lcom/android/essdk/eyou/EpaySdk;
    //   21: getstatic com/android/essdk/eyou/EpaySdk.b : Lcom/android/essdk/eyou/EpaySdk;
    //   24: astore_0
    //   25: ldc com/android/essdk/eyou/EpaySdk
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc com/android/essdk/eyou/EpaySdk
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  private void pay(Context paramContext, Map paramMap, EpayCallback paramEpayCallback) {
    this.a = paramEpayCallback;
    d.a().a(paramContext, (HashMap)paramMap, paramEpayCallback);
  }
  
  public int init(Context paramContext, String paramString) {
    return 100;
  }
  
  public void initLocation(Context paramContext) {
    d.a().b(paramContext);
  }
  
  public void pay(Context paramContext, Map paramMap, EpayCallback paramEpayCallback, boolean paramBoolean) {
    this.a = paramEpayCallback;
    if (paramBoolean) {
      a(paramContext, paramMap);
      return;
    } 
    pay(paramContext, paramMap, paramEpayCallback);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/EpaySdk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */