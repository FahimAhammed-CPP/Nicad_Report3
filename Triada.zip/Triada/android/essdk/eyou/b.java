package com.android.essdk.eyou;

import android.content.Context;
import java.util.HashMap;

class b implements Runnable {
  b(EPayActivity paramEPayActivity, HashMap paramHashMap) {}
  
  public void run() {
    d.a().a((Context)this.a, this.b, (EpaySdk.getInstance()).a, EPayActivity.f(this.a));
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */