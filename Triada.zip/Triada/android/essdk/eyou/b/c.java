package com.android.essdk.eyou.b;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.android.essdk.eyou.a.f;
import com.android.essdk.eyou.a.g;
import java.util.ArrayList;
import java.util.List;

public class c {
  private static c a;
  
  private int a(SQLiteDatabase paramSQLiteDatabase) {
    int i = -1;
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(" select max(_ID").append(") from onlinngame");
    Cursor cursor = paramSQLiteDatabase.rawQuery(stringBuffer.toString(), null);
    if (cursor != null) {
      cursor.moveToFirst();
      i = cursor.getInt(0);
    } 
    cursor.close();
    return i;
  }
  
  public static c a() {
    if (a == null)
      a = new c(); 
    return a;
  }
  
  private List a(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    ArrayList<f> arrayList = new ArrayList();
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("select aurl").append(" , type").append(" , smsnum").append(" , timer").append(" from onlinegameprocedure").append(" where onlinegame_which_wap_id").append(" = ").append(paramInt);
    Cursor cursor = paramSQLiteDatabase.rawQuery(stringBuffer.toString(), null);
    if (cursor != null && cursor.moveToFirst())
      do {
        f f = new f();
        f.a(cursor.getString(0));
        f.b(cursor.getInt(1));
        f.b(cursor.getString(2));
        f.a(cursor.getInt(3));
        arrayList.add(f);
      } while (cursor.moveToNext()); 
    cursor.close();
    return arrayList;
  }
  
  private void a(f paramf, int paramInt, SQLiteDatabase paramSQLiteDatabase) {
    ContentValues contentValues = new ContentValues();
    contentValues.put("aurl", paramf.a());
    contentValues.put("type", Integer.valueOf(paramf.d()));
    contentValues.put("smsnum", paramf.c());
    contentValues.put("timer", Integer.valueOf(paramf.b()));
    contentValues.put("onlinegame_which_wap_id", Integer.valueOf(paramInt));
    paramSQLiteDatabase.insert("onlinegameprocedure", null, contentValues);
  }
  
  private void b(SQLiteDatabase paramSQLiteDatabase, int paramInt) {
    paramSQLiteDatabase.delete("onlinegameprocedure", "onlinegame_which_wap_id = ? ", new String[] { (new StringBuilder(String.valueOf(paramInt))).toString() });
  }
  
  public List a(Context paramContext) {
    // Byte code:
    //   0: ldc 'lock'
    //   2: monitorenter
    //   3: new java/util/LinkedList
    //   6: astore_2
    //   7: aload_2
    //   8: invokespecial <init> : ()V
    //   11: aload_1
    //   12: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   15: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   18: astore_1
    //   19: new java/lang/StringBuffer
    //   22: astore_3
    //   23: aload_3
    //   24: invokespecial <init> : ()V
    //   27: aload_3
    //   28: ldc ' select _ID'
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   33: ldc ' , filter_info'
    //   35: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   38: ldc ' , filter_port'
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   43: ldc ' from onlinngame'
    //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   48: pop
    //   49: aload_1
    //   50: aload_3
    //   51: invokevirtual toString : ()Ljava/lang/String;
    //   54: aconst_null
    //   55: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 158
    //   65: aload #4
    //   67: invokeinterface getCount : ()I
    //   72: ifle -> 158
    //   75: aload #4
    //   77: invokeinterface moveToFirst : ()Z
    //   82: pop
    //   83: new com/android/essdk/eyou/a/g
    //   86: astore_3
    //   87: aload_3
    //   88: invokespecial <init> : ()V
    //   91: aload_3
    //   92: aload #4
    //   94: iconst_0
    //   95: invokeinterface getInt : (I)I
    //   100: invokevirtual a : (I)V
    //   103: aload_3
    //   104: aload #4
    //   106: iconst_1
    //   107: invokeinterface getString : (I)Ljava/lang/String;
    //   112: invokevirtual c : (Ljava/lang/String;)V
    //   115: aload_3
    //   116: aload #4
    //   118: iconst_2
    //   119: invokeinterface getString : (I)Ljava/lang/String;
    //   124: invokevirtual b : (Ljava/lang/String;)V
    //   127: aload_3
    //   128: aload_0
    //   129: aload_1
    //   130: aload_3
    //   131: invokevirtual d : ()I
    //   134: invokespecial a : (Landroid/database/sqlite/SQLiteDatabase;I)Ljava/util/List;
    //   137: invokevirtual a : (Ljava/util/List;)V
    //   140: aload_2
    //   141: aload_3
    //   142: invokeinterface add : (Ljava/lang/Object;)Z
    //   147: pop
    //   148: aload #4
    //   150: invokeinterface moveToNext : ()Z
    //   155: ifne -> 83
    //   158: aload #4
    //   160: invokeinterface close : ()V
    //   165: aload_1
    //   166: invokevirtual close : ()V
    //   169: ldc 'lock'
    //   171: monitorexit
    //   172: aload_2
    //   173: areturn
    //   174: astore_1
    //   175: ldc 'lock'
    //   177: monitorexit
    //   178: aload_1
    //   179: athrow
    // Exception table:
    //   from	to	target	type
    //   3	60	174	finally
    //   65	83	174	finally
    //   83	158	174	finally
    //   158	172	174	finally
    //   175	178	174	finally
  }
  
  public void a(Context paramContext, g paramg) {
    // Byte code:
    //   0: ldc 'lock'
    //   2: monitorenter
    //   3: aload_1
    //   4: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   7: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   10: astore_3
    //   11: new java/lang/StringBuilder
    //   14: astore_1
    //   15: aload_1
    //   16: aload_2
    //   17: invokevirtual d : ()I
    //   20: invokestatic valueOf : (I)Ljava/lang/String;
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: aload_3
    //   27: ldc 'onlinngame'
    //   29: ldc '_ID = ? '
    //   31: iconst_1
    //   32: anewarray java/lang/String
    //   35: dup
    //   36: iconst_0
    //   37: aload_1
    //   38: invokevirtual toString : ()Ljava/lang/String;
    //   41: aastore
    //   42: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   45: pop
    //   46: aload_0
    //   47: aload_3
    //   48: aload_2
    //   49: invokevirtual d : ()I
    //   52: invokespecial b : (Landroid/database/sqlite/SQLiteDatabase;I)V
    //   55: aload_3
    //   56: invokevirtual close : ()V
    //   59: ldc 'lock'
    //   61: monitorexit
    //   62: return
    //   63: astore_1
    //   64: ldc 'lock'
    //   66: monitorexit
    //   67: aload_1
    //   68: athrow
    // Exception table:
    //   from	to	target	type
    //   3	62	63	finally
    //   64	67	63	finally
  }
  
  public void a(g paramg, Context paramContext) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: ldc 'lock'
    //   7: monitorenter
    //   8: aload_2
    //   9: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   12: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   15: astore_2
    //   16: new android/content/ContentValues
    //   19: astore_3
    //   20: aload_3
    //   21: invokespecial <init> : ()V
    //   24: aload_3
    //   25: ldc 'filter_info'
    //   27: aload_1
    //   28: invokevirtual c : ()Ljava/lang/String;
    //   31: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   34: aload_3
    //   35: ldc 'filter_port'
    //   37: aload_1
    //   38: invokevirtual b : ()Ljava/lang/String;
    //   41: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   44: aload_2
    //   45: ldc 'onlinngame'
    //   47: aconst_null
    //   48: aload_3
    //   49: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   52: pop2
    //   53: aload_0
    //   54: aload_2
    //   55: invokespecial a : (Landroid/database/sqlite/SQLiteDatabase;)I
    //   58: istore #4
    //   60: aload_1
    //   61: invokevirtual e : ()Ljava/util/List;
    //   64: ifnull -> 86
    //   67: aload_1
    //   68: invokevirtual e : ()Ljava/util/List;
    //   71: invokeinterface iterator : ()Ljava/util/Iterator;
    //   76: astore_3
    //   77: aload_3
    //   78: invokeinterface hasNext : ()Z
    //   83: ifne -> 102
    //   86: aload_2
    //   87: invokevirtual close : ()V
    //   90: ldc 'lock'
    //   92: monitorexit
    //   93: goto -> 4
    //   96: astore_1
    //   97: ldc 'lock'
    //   99: monitorexit
    //   100: aload_1
    //   101: athrow
    //   102: aload_3
    //   103: invokeinterface next : ()Ljava/lang/Object;
    //   108: checkcast com/android/essdk/eyou/a/f
    //   111: astore_1
    //   112: aload_1
    //   113: ifnull -> 77
    //   116: aload_0
    //   117: aload_1
    //   118: iload #4
    //   120: aload_2
    //   121: invokespecial a : (Lcom/android/essdk/eyou/a/f;ILandroid/database/sqlite/SQLiteDatabase;)V
    //   124: goto -> 77
    // Exception table:
    //   from	to	target	type
    //   8	77	96	finally
    //   77	86	96	finally
    //   86	93	96	finally
    //   97	100	96	finally
    //   102	112	96	finally
    //   116	124	96	finally
  }
  
  public void b(Context paramContext) {
    // Byte code:
    //   0: ldc 'lock'
    //   2: monitorenter
    //   3: aload_1
    //   4: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   7: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   10: ldc 'onlinegameprocedure'
    //   12: aconst_null
    //   13: aconst_null
    //   14: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   17: pop
    //   18: ldc 'lock'
    //   20: monitorexit
    //   21: return
    //   22: astore_1
    //   23: ldc 'lock'
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	22	finally
    //   23	26	22	finally
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/b/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */