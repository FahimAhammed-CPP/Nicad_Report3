package com.android.essdk.eyou.b;

import android.content.Context;
import java.util.List;

public class b {
  private static b a;
  
  public static b a() {
    if (a == null)
      a = new b(); 
    return a;
  }
  
  public List a(Context paramContext) {
    // Byte code:
    //   0: ldc 'lock'
    //   2: monitorenter
    //   3: new java/util/LinkedList
    //   6: astore_2
    //   7: aload_2
    //   8: invokespecial <init> : ()V
    //   11: aload_1
    //   12: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   15: invokevirtual getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   18: astore_1
    //   19: new java/lang/StringBuffer
    //   22: astore_3
    //   23: aload_3
    //   24: invokespecial <init> : ()V
    //   27: aload_3
    //   28: ldc ' select filter_info'
    //   30: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   33: ldc ' , filter_port'
    //   35: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   38: ldc ' , insert_time'
    //   40: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   43: ldc ' , _ID'
    //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   48: ldc ' from filter'
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   53: pop
    //   54: aload_1
    //   55: aload_3
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: aconst_null
    //   60: invokevirtual rawQuery : (Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;
    //   63: astore #4
    //   65: aload #4
    //   67: invokeinterface moveToFirst : ()Z
    //   72: pop
    //   73: aload #4
    //   75: invokeinterface getCount : ()I
    //   80: ifle -> 240
    //   83: new com/android/essdk/eyou/a/c
    //   86: astore #5
    //   88: aload #5
    //   90: invokespecial <init> : ()V
    //   93: aload #4
    //   95: iconst_0
    //   96: invokeinterface getString : (I)Ljava/lang/String;
    //   101: astore_3
    //   102: aload #4
    //   104: iconst_1
    //   105: invokeinterface getString : (I)Ljava/lang/String;
    //   110: astore #6
    //   112: aload #4
    //   114: iconst_2
    //   115: invokeinterface getString : (I)Ljava/lang/String;
    //   120: astore #7
    //   122: aload #4
    //   124: iconst_3
    //   125: invokeinterface getInt : (I)I
    //   130: istore #8
    //   132: new java/lang/StringBuilder
    //   135: astore #9
    //   137: aload #9
    //   139: ldc '存储在数据库中需要过滤的内容为[content: '
    //   141: invokespecial <init> : (Ljava/lang/String;)V
    //   144: ldc 'FilterDBManager'
    //   146: aload #9
    //   148: aload_3
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: ldc 'num: '
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: aload #6
    //   159: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: ldc 'time: '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: aload #7
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: ldc 'id: '
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: iload #8
    //   179: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   182: ldc ']'
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokestatic a : (Ljava/lang/String;Ljava/lang/String;)I
    //   193: pop
    //   194: aload #5
    //   196: aload_3
    //   197: invokevirtual b : (Ljava/lang/String;)V
    //   200: aload #5
    //   202: aload #6
    //   204: invokevirtual a : (Ljava/lang/String;)V
    //   207: aload #5
    //   209: aload #7
    //   211: invokevirtual c : (Ljava/lang/String;)V
    //   214: aload #5
    //   216: iload #8
    //   218: invokevirtual a : (I)V
    //   221: aload_2
    //   222: aload #5
    //   224: invokeinterface add : (Ljava/lang/Object;)Z
    //   229: pop
    //   230: aload #4
    //   232: invokeinterface moveToNext : ()Z
    //   237: ifne -> 83
    //   240: aload #4
    //   242: invokeinterface close : ()V
    //   247: aload_1
    //   248: invokevirtual close : ()V
    //   251: ldc 'lock'
    //   253: monitorexit
    //   254: aload_2
    //   255: areturn
    //   256: astore_1
    //   257: ldc 'lock'
    //   259: monitorexit
    //   260: aload_1
    //   261: athrow
    // Exception table:
    //   from	to	target	type
    //   3	83	256	finally
    //   83	240	256	finally
    //   240	254	256	finally
    //   257	260	256	finally
  }
  
  public void a(List paramList, Context paramContext) {
    // Byte code:
    //   0: ldc 'lock'
    //   2: monitorenter
    //   3: aload_2
    //   4: invokestatic a : (Landroid/content/Context;)Lcom/android/essdk/eyou/b/a;
    //   7: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   10: astore_2
    //   11: aload_1
    //   12: invokeinterface iterator : ()Ljava/util/Iterator;
    //   17: astore_1
    //   18: aload_1
    //   19: invokeinterface hasNext : ()Z
    //   24: ifne -> 35
    //   27: aload_2
    //   28: invokevirtual close : ()V
    //   31: ldc 'lock'
    //   33: monitorexit
    //   34: return
    //   35: aload_1
    //   36: invokeinterface next : ()Ljava/lang/Object;
    //   41: checkcast com/android/essdk/eyou/a/b
    //   44: astore_3
    //   45: aload_3
    //   46: instanceof com/android/essdk/eyou/a/h
    //   49: ifeq -> 151
    //   52: aload_3
    //   53: checkcast com/android/essdk/eyou/a/h
    //   56: astore #4
    //   58: aload #4
    //   60: invokevirtual e : ()Z
    //   63: ifne -> 151
    //   66: aload #4
    //   68: invokevirtual a : ()Ljava/lang/String;
    //   71: invokevirtual trim : ()Ljava/lang/String;
    //   74: ldc '1'
    //   76: invokevirtual equals : (Ljava/lang/Object;)Z
    //   79: ifeq -> 151
    //   82: new android/content/ContentValues
    //   85: astore #5
    //   87: aload #5
    //   89: invokespecial <init> : ()V
    //   92: aload #5
    //   94: ldc 'filter_info'
    //   96: aload #4
    //   98: invokevirtual f : ()Ljava/lang/String;
    //   101: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   104: aload #5
    //   106: ldc 'filter_port'
    //   108: ldc ''
    //   110: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   113: new java/lang/StringBuilder
    //   116: astore #4
    //   118: aload #4
    //   120: invokespecial <init> : ()V
    //   123: aload #5
    //   125: ldc 'insert_time'
    //   127: aload #4
    //   129: invokestatic currentTimeMillis : ()J
    //   132: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   135: invokevirtual toString : ()Ljava/lang/String;
    //   138: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   141: aload_2
    //   142: ldc 'filter'
    //   144: aconst_null
    //   145: aload #5
    //   147: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   150: pop2
    //   151: aload_3
    //   152: invokevirtual a : ()Ljava/lang/String;
    //   155: invokevirtual trim : ()Ljava/lang/String;
    //   158: ldc '1'
    //   160: invokevirtual equals : (Ljava/lang/Object;)Z
    //   163: ifeq -> 18
    //   166: new android/content/ContentValues
    //   169: astore #5
    //   171: aload #5
    //   173: invokespecial <init> : ()V
    //   176: aload #5
    //   178: ldc 'filter_info'
    //   180: aload_3
    //   181: invokevirtual c : ()Ljava/lang/String;
    //   184: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   187: aload #5
    //   189: ldc 'filter_port'
    //   191: aload_3
    //   192: invokevirtual b : ()Ljava/lang/String;
    //   195: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   198: new java/lang/StringBuilder
    //   201: astore_3
    //   202: aload_3
    //   203: invokespecial <init> : ()V
    //   206: aload #5
    //   208: ldc 'insert_time'
    //   210: aload_3
    //   211: invokestatic currentTimeMillis : ()J
    //   214: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: invokevirtual put : (Ljava/lang/String;Ljava/lang/String;)V
    //   223: aload_2
    //   224: ldc 'filter'
    //   226: aconst_null
    //   227: aload #5
    //   229: invokevirtual insert : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   232: pop2
    //   233: goto -> 18
    //   236: astore_1
    //   237: ldc 'lock'
    //   239: monitorexit
    //   240: aload_1
    //   241: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	236	finally
    //   18	34	236	finally
    //   35	151	236	finally
    //   151	233	236	finally
    //   237	240	236	finally
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */