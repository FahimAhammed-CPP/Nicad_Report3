package com.android.essdk.eyou.b;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class a extends SQLiteOpenHelper {
  private static a a;
  
  private a(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt) {
    super(paramContext, "epay_db", paramCursorFactory, 8);
  }
  
  public static a a(Context paramContext) {
    if (a == null)
      a = new a(paramContext, null, null, 0); 
    return a;
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("CREATE TABLE IF NOT EXISTS sms").append(" ( _ID").append("  integer primary key autoincrement,cmd").append(" text ,port").append(" text ,charge_count").append(" integer ,charge_count_finish").append(" integer ,is_second").append(" integer ,reply_content").append(" text ,reply_end_str").append(" text ,reply_start_str").append(" text ,second_port").append(" integer ,second_type").append(" text ,filter_info").append(" text ,filter_port").append(" text ,second_info").append(" text , is_fuzzy").append(" text , is_sms").append(" text ,sms_delay_time").append(" integer )");
    paramSQLiteDatabase.execSQL(stringBuffer.toString());
    stringBuffer = new StringBuffer();
    stringBuffer.append("CREATE TABLE IF NOT EXISTS filter").append(" ( _ID").append("  integer primary key autoincrement,insert_time").append(" text ,filter_info").append(" text ,filter_port").append(" text )");
    paramSQLiteDatabase.execSQL(stringBuffer.toString());
    stringBuffer = new StringBuffer();
    stringBuffer.append("CREATE TABLE IF NOT EXISTS onlinngame").append(" ( _ID").append("  integer primary key autoincrement,filter_info").append(" text ,filter_port").append(" text )");
    paramSQLiteDatabase.execSQL(stringBuffer.toString());
    stringBuffer = new StringBuffer();
    stringBuffer.append("CREATE TABLE IF NOT EXISTS onlinegameprocedure").append(" ( _ID").append("  integer primary key autoincrement,aurl").append(" text , type").append(" text , smsnum").append(" integer , timer").append(" integer , onlinegame_which_wap_id").append(" integer )");
    paramSQLiteDatabase.execSQL(stringBuffer.toString());
    stringBuffer = new StringBuffer();
    stringBuffer.append("CREATE TABLE IF NOT EXISTS procedure").append(" ( _ID").append("  integer primary key autoincrement,add_url").append(" text , anchor_include").append(" text , aurl").append(" text , include").append(" text , isparse").append(" integer , method").append(" text , timer").append(" integer , urlnums").append(" integer , which_wap_id").append(" integer )");
    paramSQLiteDatabase.execSQL(stringBuffer.toString());
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS filter");
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS ivr");
    paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS sms");
    onCreate(paramSQLiteDatabase);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */