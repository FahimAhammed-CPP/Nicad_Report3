package com.android.essdk.eyou.b;

import android.content.Context;
import android.content.SharedPreferences;
import com.android.essdk.eyou.e.i;

public class e {
  public static e a;
  
  public static int a(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getInt("is_pop", 10);
  }
  
  public static e a() {
    if (a == null)
      a = new e(); 
    return a;
  }
  
  public static void a(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putInt("call_interval", paramInt);
    editor.commit();
  }
  
  public static void a(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("fee", paramString);
    editor.commit();
  }
  
  public static void a(Context paramContext, String paramString1, String paramString2) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
  
  public static String b(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("sms_count", "");
  }
  
  public static String b(Context paramContext, String paramString1, String paramString2) {
    return paramContext.getSharedPreferences("epay_share", 0).getString(paramString1, paramString2);
  }
  
  public static void b(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putInt("call_max", paramInt);
    editor.commit();
  }
  
  public static void b(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("prod_name", paramString);
    editor.commit();
  }
  
  public static String c(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("ivr_count", "");
  }
  
  public static void c(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putInt("fee_type", paramInt);
    editor.commit();
  }
  
  public static void c(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("supp_name", paramString);
    editor.commit();
  }
  
  public static String d(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("wap_count", "");
  }
  
  public static void d(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putInt("is_pop", paramInt);
    editor.commit();
  }
  
  public static void d(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("sms_count", paramString);
    editor.commit();
  }
  
  public static String e(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("mobile-" + i.b(paramContext), null);
  }
  
  public static void e(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("ivr_count", paramString);
    editor.commit();
  }
  
  public static String f(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("mobileimsi", "");
  }
  
  public static void f(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("wap_count", paramString);
    editor.commit();
  }
  
  public static String g(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 1).getString("isOrderId", "");
  }
  
  public static void g(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("mobileimsi", paramString);
    editor.commit();
  }
  
  public static void h(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 2).edit();
    editor.putString("isOrderId", paramString);
    editor.commit();
  }
  
  public void e(Context paramContext, int paramInt) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_sms_status", 0).edit();
    editor.putInt("SmsResult", paramInt);
    editor.commit();
  }
  
  public int h(Context paramContext) {
    return paramContext.getSharedPreferences("epay_sms_status", 0).getInt("SmsResult", 0);
  }
  
  public String i(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 0).getString("tradeName", "");
  }
  
  public void i(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 0).edit();
    editor.putString("tradeName", paramString);
    editor.commit();
  }
  
  public String j(Context paramContext) {
    return paramContext.getSharedPreferences("epay_share", 0).getString("money", "0.00");
  }
  
  public void j(Context paramContext, String paramString) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences("epay_share", 0).edit();
    editor.putString("money", paramString);
    editor.commit();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/b/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */