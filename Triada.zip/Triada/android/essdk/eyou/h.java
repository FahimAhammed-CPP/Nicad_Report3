package com.android.essdk.eyou;

import android.content.Context;

class h implements Runnable {
  h(d paramd, Context paramContext, int paramInt) {}
  
  public void run() {
    l.a().a(this.b, d.c(this.a), this.c, d.d(this.a));
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */