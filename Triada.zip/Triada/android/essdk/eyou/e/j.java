package com.android.essdk.eyou.e;

import android.content.Context;

public class j {
  public static String[] a(Context paramContext) {
    // Byte code:
    //   0: iconst_4
    //   1: anewarray java/lang/String
    //   4: astore_1
    //   5: aload_1
    //   6: iconst_0
    //   7: ldc ''
    //   9: aastore
    //   10: aload_1
    //   11: iconst_1
    //   12: ldc ''
    //   14: aastore
    //   15: aload_1
    //   16: iconst_2
    //   17: ldc ''
    //   19: aastore
    //   20: aload_1
    //   21: iconst_3
    //   22: ldc ''
    //   24: aastore
    //   25: new java/lang/StringBuffer
    //   28: invokespecial <init> : ()V
    //   31: aload_0
    //   32: ldc 'phone'
    //   34: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   37: checkcast android/telephony/TelephonyManager
    //   40: astore_0
    //   41: aload_0
    //   42: invokevirtual getNetworkOperator : ()Ljava/lang/String;
    //   45: astore_2
    //   46: ldc ''
    //   48: aload_2
    //   49: invokevirtual equals : (Ljava/lang/Object;)Z
    //   52: ifne -> 59
    //   55: aload_2
    //   56: ifnonnull -> 61
    //   59: aload_1
    //   60: areturn
    //   61: aload_2
    //   62: iconst_0
    //   63: iconst_3
    //   64: invokevirtual substring : (II)Ljava/lang/String;
    //   67: invokestatic parseInt : (Ljava/lang/String;)I
    //   70: istore_3
    //   71: aload_2
    //   72: iconst_3
    //   73: invokevirtual substring : (I)Ljava/lang/String;
    //   76: invokestatic parseInt : (Ljava/lang/String;)I
    //   79: istore #4
    //   81: aload_0
    //   82: invokevirtual getCellLocation : ()Landroid/telephony/CellLocation;
    //   85: astore #5
    //   87: aload #5
    //   89: ifnull -> 449
    //   92: aload #5
    //   94: instanceof android/telephony/gsm/GsmCellLocation
    //   97: ifeq -> 440
    //   100: aload #5
    //   102: checkcast android/telephony/gsm/GsmCellLocation
    //   105: astore_2
    //   106: aload_2
    //   107: invokevirtual getLac : ()I
    //   110: istore #6
    //   112: aload_2
    //   113: invokevirtual getCid : ()I
    //   116: istore #7
    //   118: aload #5
    //   120: instanceof android/telephony/cdma/CdmaCellLocation
    //   123: ifeq -> 437
    //   126: aload #5
    //   128: checkcast android/telephony/cdma/CdmaCellLocation
    //   131: astore_2
    //   132: aload_2
    //   133: invokevirtual getNetworkId : ()I
    //   136: istore #6
    //   138: aload_2
    //   139: invokevirtual getBaseStationId : ()I
    //   142: istore #7
    //   144: aload_0
    //   145: invokevirtual getNeighboringCellInfo : ()Ljava/util/List;
    //   148: astore #5
    //   150: aload #5
    //   152: ifnull -> 431
    //   155: aload #5
    //   157: invokeinterface isEmpty : ()Z
    //   162: ifne -> 431
    //   165: aload #5
    //   167: invokeinterface iterator : ()Ljava/util/Iterator;
    //   172: astore_2
    //   173: iconst_0
    //   174: istore #8
    //   176: aload_2
    //   177: invokeinterface hasNext : ()Z
    //   182: ifne -> 381
    //   185: iload #8
    //   187: istore #9
    //   189: aload #5
    //   191: ifnull -> 230
    //   194: iload #8
    //   196: istore #9
    //   198: aload #5
    //   200: invokeinterface isEmpty : ()Z
    //   205: ifne -> 230
    //   208: aload #5
    //   210: iconst_0
    //   211: invokeinterface get : (I)Ljava/lang/Object;
    //   216: checkcast android/telephony/NeighboringCellInfo
    //   219: invokevirtual getRssi : ()I
    //   222: iconst_2
    //   223: imul
    //   224: sipush #133
    //   227: isub
    //   228: istore #9
    //   230: new java/lang/StringBuilder
    //   233: astore_0
    //   234: aload_0
    //   235: ldc 'lac:mcc:mnc:cid=['
    //   237: invokespecial <init> : (Ljava/lang/String;)V
    //   240: ldc 'TelUtils'
    //   242: aload_0
    //   243: iload #6
    //   245: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   248: ldc ':'
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: iload_3
    //   254: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   257: ldc ':'
    //   259: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   262: iload #4
    //   264: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   267: ldc ':'
    //   269: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   272: iload #7
    //   274: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   277: ldc '] strength：['
    //   279: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: iload #9
    //   284: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   287: ldc ']'
    //   289: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   292: invokevirtual toString : ()Ljava/lang/String;
    //   295: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   298: pop
    //   299: new java/lang/StringBuilder
    //   302: astore_0
    //   303: aload_0
    //   304: iload #6
    //   306: invokestatic valueOf : (I)Ljava/lang/String;
    //   309: invokespecial <init> : (Ljava/lang/String;)V
    //   312: aload_1
    //   313: iconst_0
    //   314: aload_0
    //   315: invokevirtual toString : ()Ljava/lang/String;
    //   318: aastore
    //   319: new java/lang/StringBuilder
    //   322: astore_0
    //   323: aload_0
    //   324: iload_3
    //   325: invokestatic valueOf : (I)Ljava/lang/String;
    //   328: invokespecial <init> : (Ljava/lang/String;)V
    //   331: aload_1
    //   332: iconst_1
    //   333: aload_0
    //   334: invokevirtual toString : ()Ljava/lang/String;
    //   337: aastore
    //   338: new java/lang/StringBuilder
    //   341: astore_0
    //   342: aload_0
    //   343: iload #4
    //   345: invokestatic valueOf : (I)Ljava/lang/String;
    //   348: invokespecial <init> : (Ljava/lang/String;)V
    //   351: aload_1
    //   352: iconst_2
    //   353: aload_0
    //   354: invokevirtual toString : ()Ljava/lang/String;
    //   357: aastore
    //   358: new java/lang/StringBuilder
    //   361: astore_0
    //   362: aload_0
    //   363: iload #7
    //   365: invokestatic valueOf : (I)Ljava/lang/String;
    //   368: invokespecial <init> : (Ljava/lang/String;)V
    //   371: aload_1
    //   372: iconst_3
    //   373: aload_0
    //   374: invokevirtual toString : ()Ljava/lang/String;
    //   377: aastore
    //   378: goto -> 59
    //   381: aload_2
    //   382: invokeinterface next : ()Ljava/lang/Object;
    //   387: checkcast android/telephony/NeighboringCellInfo
    //   390: astore_0
    //   391: iload #8
    //   393: aload_0
    //   394: invokevirtual getRssi : ()I
    //   397: iconst_2
    //   398: imul
    //   399: sipush #133
    //   402: isub
    //   403: iadd
    //   404: istore #8
    //   406: aload_0
    //   407: invokevirtual getLac : ()I
    //   410: pop
    //   411: aload_0
    //   412: invokevirtual getCid : ()I
    //   415: pop
    //   416: goto -> 176
    //   419: astore_0
    //   420: ldc 'TelUtils'
    //   422: ldc '获取基站信息出错'
    //   424: invokestatic b : (Ljava/lang/String;Ljava/lang/String;)I
    //   427: pop
    //   428: goto -> 59
    //   431: iconst_0
    //   432: istore #8
    //   434: goto -> 185
    //   437: goto -> 144
    //   440: iconst_0
    //   441: istore #7
    //   443: iconst_0
    //   444: istore #6
    //   446: goto -> 118
    //   449: iconst_0
    //   450: istore #7
    //   452: iconst_0
    //   453: istore #6
    //   455: goto -> 144
    // Exception table:
    //   from	to	target	type
    //   25	55	419	java/lang/NumberFormatException
    //   61	87	419	java/lang/NumberFormatException
    //   92	118	419	java/lang/NumberFormatException
    //   118	144	419	java/lang/NumberFormatException
    //   144	150	419	java/lang/NumberFormatException
    //   155	173	419	java/lang/NumberFormatException
    //   176	185	419	java/lang/NumberFormatException
    //   198	230	419	java/lang/NumberFormatException
    //   230	378	419	java/lang/NumberFormatException
    //   381	416	419	java/lang/NumberFormatException
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */