package com.android.essdk.eyou.e;

import android.util.Log;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;

public class g {
  public static String a(String paramString1, String paramString2) {
    try {
      PKCS8EncodedKeySpec pKCS8EncodedKeySpec = new PKCS8EncodedKeySpec();
      this(a.a(paramString2));
      PrivateKey privateKey = KeyFactory.getInstance("RSA", "BC").generatePrivate(pKCS8EncodedKeySpec);
      Signature signature = Signature.getInstance("SHA1WithRSA");
      signature.initSign(privateKey);
      signature.update(paramString1.getBytes("utf-8"));
      paramString1 = a.a(signature.sign());
    } catch (Exception exception) {
      Log.e("", exception.getMessage());
      exception.printStackTrace();
      exception = null;
    } 
    return (String)exception;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */