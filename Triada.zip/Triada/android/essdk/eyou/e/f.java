package com.android.essdk.eyou.e;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.NinePatch;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;

public class f {
  private static int a(byte[] paramArrayOfbyte, int paramInt) {
    return paramArrayOfbyte[paramInt + 0] | paramArrayOfbyte[paramInt + 1] << 8 | paramArrayOfbyte[paramInt + 2] << 16 | paramArrayOfbyte[paramInt + 3] << 24;
  }
  
  public static Bitmap a(InputStream paramInputStream) {
    Field field;
    Bitmap bitmap = BitmapFactory.decodeStream(paramInputStream);
    byte[] arrayOfByte = a(bitmap);
    if (NinePatch.isNinePatchChunk(arrayOfByte)) {
      Bitmap bitmap1 = Bitmap.createBitmap(bitmap, 1, 1, bitmap.getWidth() - 2, bitmap.getHeight() - 2);
      bitmap.recycle();
      field = bitmap1.getClass().getDeclaredField("mNinePatchChunk");
      field.setAccessible(true);
      field.set(bitmap1, arrayOfByte);
      return bitmap1;
    } 
    return (Bitmap)field;
  }
  
  public static Drawable a(Context paramContext, String paramString) {
    try {
      BitmapDrawable bitmapDrawable;
      Bitmap bitmap = b(paramContext, paramString);
      if (bitmap.getNinePatchChunk() == null) {
        bitmapDrawable = new BitmapDrawable();
        this(bitmap);
        return (Drawable)bitmapDrawable;
      } 
      Rect rect = new Rect();
      this();
      a(bitmap.getNinePatchChunk(), rect);
      NinePatchDrawable ninePatchDrawable = new NinePatchDrawable(bitmapDrawable.getResources(), bitmap, bitmap.getNinePatchChunk(), rect, null);
    } catch (Exception exception) {
      exception.printStackTrace();
      exception = null;
    } 
    return (Drawable)exception;
  }
  
  private static void a(Bitmap paramBitmap, byte[] paramArrayOfbyte) {
    boolean bool = false;
    int[] arrayOfInt = new int[paramBitmap.getWidth() - 2];
    paramBitmap.getPixels(arrayOfInt, 0, arrayOfInt.length, 1, paramBitmap.getHeight() - 1, arrayOfInt.length, 1);
    int i = 0;
    while (true) {
      if (i < arrayOfInt.length)
        if (-16777216 == arrayOfInt[i]) {
          a(paramArrayOfbyte, 12, i);
        } else {
          i++;
          continue;
        }  
      i = arrayOfInt.length - 1;
      while (true) {
        if (i >= 0)
          if (-16777216 == arrayOfInt[i]) {
            a(paramArrayOfbyte, 16, arrayOfInt.length - i - 2);
          } else {
            i--;
            continue;
          }  
        arrayOfInt = new int[paramBitmap.getHeight() - 2];
        paramBitmap.getPixels(arrayOfInt, 0, 1, paramBitmap.getWidth() - 1, 0, 1, arrayOfInt.length);
        i = bool;
        while (true) {
          if (i < arrayOfInt.length)
            if (-16777216 == arrayOfInt[i]) {
              a(paramArrayOfbyte, 20, i);
            } else {
              i++;
              continue;
            }  
          i = arrayOfInt.length - 1;
          while (true) {
            if (i >= 0) {
              if (-16777216 == arrayOfInt[i]) {
                a(paramArrayOfbyte, 24, arrayOfInt.length - i - 2);
                return;
              } 
              i--;
              continue;
            } 
            return;
          } 
          break;
        } 
        break;
      } 
      break;
    } 
  }
  
  private static void a(OutputStream paramOutputStream, int paramInt) {
    paramOutputStream.write(paramInt >> 0 & 0xFF);
    paramOutputStream.write(paramInt >> 8 & 0xFF);
    paramOutputStream.write(paramInt >> 16 & 0xFF);
    paramOutputStream.write(paramInt >> 24 & 0xFF);
  }
  
  private static void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
    paramArrayOfbyte[paramInt1 + 0] = (byte)(byte)(paramInt2 >> 0);
    paramArrayOfbyte[paramInt1 + 1] = (byte)(byte)(paramInt2 >> 8);
    paramArrayOfbyte[paramInt1 + 2] = (byte)(byte)(paramInt2 >> 16);
    paramArrayOfbyte[paramInt1 + 3] = (byte)(byte)(paramInt2 >> 24);
  }
  
  public static void a(byte[] paramArrayOfbyte, Rect paramRect) {
    paramRect.left = a(paramArrayOfbyte, 12);
    paramRect.right = a(paramArrayOfbyte, 16);
    paramRect.top = a(paramArrayOfbyte, 20);
    paramRect.bottom = a(paramArrayOfbyte, 24);
  }
  
  public static byte[] a(Bitmap paramBitmap) {
    int i = paramBitmap.getWidth();
    int j = paramBitmap.getHeight();
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    for (int k = 0;; k++) {
      byte[] arrayOfByte;
      if (k >= 32) {
        boolean bool;
        int m;
        int[] arrayOfInt = new int[i - 2];
        paramBitmap.getPixels(arrayOfInt, 0, i, 1, 0, i - 2, 1);
        if (arrayOfInt[0] == -16777216) {
          bool = true;
        } else {
          bool = false;
        } 
        if (arrayOfInt[arrayOfInt.length - 1] == -16777216) {
          m = 1;
        } else {
          m = 0;
        } 
        int n = arrayOfInt.length;
        i = 0;
        int i1 = 0;
        for (k = 0;; k = i2) {
          if (i >= n) {
            int i4;
            i = k;
            if (m) {
              i = k + 1;
              a(byteArrayOutputStream, n);
            } 
            k = i + 1;
            if (bool)
              k--; 
            if (m) {
              m = k - 1;
            } else {
              m = k;
            } 
            arrayOfInt = new int[j - 2];
            paramBitmap.getPixels(arrayOfInt, 0, 1, 0, 1, 1, j - 2);
            if (arrayOfInt[0] == -16777216) {
              i4 = 1;
            } else {
              i4 = 0;
            } 
            if (arrayOfInt[arrayOfInt.length - 1] == -16777216) {
              bool = true;
            } else {
              bool = false;
            } 
            int i5 = arrayOfInt.length;
            int i6 = 0;
            n = 0;
            for (k = 0;; k = i1) {
              if (i6 >= i5) {
                i6 = k;
                if (bool) {
                  i6 = k + 1;
                  a(byteArrayOutputStream, i5);
                } 
                k = i6 + 1;
                if (i4)
                  k--; 
                i4 = k;
                if (bool)
                  i4 = k - 1; 
                for (k = 0;; k++) {
                  if (k >= m * i4) {
                    arrayOfByte = byteArrayOutputStream.toByteArray();
                    arrayOfByte[0] = (byte)1;
                    arrayOfByte[1] = (byte)(byte)i;
                    arrayOfByte[2] = (byte)(byte)i6;
                    arrayOfByte[3] = (byte)(byte)(i4 * m);
                    a(paramBitmap, arrayOfByte);
                    return arrayOfByte;
                  } 
                  a((OutputStream)arrayOfByte, 1);
                } 
                break;
              } 
              j = n;
              i1 = k;
              if (n != arrayOfInt[i6]) {
                i1 = k + 1;
                a((OutputStream)arrayOfByte, i6);
                j = arrayOfInt[i6];
              } 
              i6++;
              n = j;
            } 
            break;
          } 
          int i3 = i1;
          int i2 = k;
          if (i1 != arrayOfInt[i]) {
            i2 = k + 1;
            a((OutputStream)arrayOfByte, i);
            i3 = arrayOfInt[i];
          } 
          i++;
          i1 = i3;
        } 
        break;
      } 
      arrayOfByte.write(0);
    } 
  }
  
  public static Bitmap b(Context paramContext, String paramString) {
    InputStream inputStream = paramContext.getAssets().open(paramString);
    Bitmap bitmap = a(inputStream);
    inputStream.close();
    return bitmap;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */