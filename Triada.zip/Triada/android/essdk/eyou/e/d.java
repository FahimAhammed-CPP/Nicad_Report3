package com.android.essdk.eyou.e;

import android.content.Context;
import com.android.essdk.eyou.b.e;

public class d {
  public static int a(long paramLong, int paramInt) {
    // Byte code:
    //   0: iload_2
    //   1: tableswitch default -> 24, 0 -> 54, 1 -> 60
    //   24: ldc 'yy-MM-dd hh:mm:ss SSS'
    //   26: astore_3
    //   27: new java/text/SimpleDateFormat
    //   30: dup
    //   31: aload_3
    //   32: invokespecial <init> : (Ljava/lang/String;)V
    //   35: new java/util/Date
    //   38: dup
    //   39: lload_0
    //   40: invokespecial <init> : (J)V
    //   43: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   46: astore_3
    //   47: aload_3
    //   48: invokestatic parseInt : (Ljava/lang/String;)I
    //   51: istore_2
    //   52: iload_2
    //   53: ireturn
    //   54: ldc 'MM'
    //   56: astore_3
    //   57: goto -> 27
    //   60: ldc 'dd'
    //   62: astore_3
    //   63: goto -> 27
    //   66: astore_3
    //   67: iconst_m1
    //   68: istore_2
    //   69: goto -> 52
    // Exception table:
    //   from	to	target	type
    //   47	52	66	java/lang/Exception
  }
  
  public static void a(int paramInt, Context paramContext, String paramString) {
    if (paramInt == 0) {
      e.e(paramContext, paramString);
      return;
    } 
    if (paramInt == 1) {
      e.d(paramContext, paramString);
      return;
    } 
    if (paramInt == 2)
      e.f(paramContext, paramString); 
  }
  
  public static boolean a(int paramInt, Context paramContext) {
    String str = null;
    if (paramInt == 0) {
      str = e.c(paramContext);
    } else if (paramInt == 1) {
      str = e.b(paramContext);
    } else if (paramInt == 2) {
      str = e.d(paramContext);
    } 
    int i = a(System.currentTimeMillis(), 0);
    int j = a(System.currentTimeMillis(), 1);
    if (str != null && !str.trim().equals("")) {
      String[] arrayOfString = str.split("_");
      int k = Integer.parseInt(arrayOfString[0].split(":")[0]);
      int m = Integer.parseInt(arrayOfString[0].split(":")[1]);
      int n = Integer.parseInt(arrayOfString[1]);
      int i1 = Integer.parseInt(arrayOfString[2]);
      if (i != k) {
        a(paramInt, paramContext, String.valueOf(i) + ":" + j + "_1" + "_1");
      } else if (j != m) {
        if (n < 500) {
          a(paramInt, paramContext, String.valueOf(i) + ":" + j + "_" + (n + 1) + "_1");
          return true;
        } 
      } else if (n <= 500 && i1 <= 100) {
        a(paramInt, paramContext, String.valueOf(i) + ":" + j + "_" + (n + 1) + "_" + (i1 + 1));
        return true;
      } 
      b.a("JudgeTimeUtil", "timeCount is " + str + ",超过最大调用次数");
      return false;
    } 
    a(paramInt, paramContext, String.valueOf(i) + ":" + j + "_1" + "_1");
    return true;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */