package com.android.essdk.eyou.e;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.os.Build;
import com.android.essdk.eyou.b.e;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

public class k {
  private static boolean a = false;
  
  private static boolean b = true;
  
  private static FileWriter c = null;
  
  private static String d = "/sdcard/Platform-Log.txt";
  
  private static int[] e = new int[] { 10, 20, 30, 50, 100, 300, 500 };
  
  public static String a() {
    return "sign_type=\"RSA\"";
  }
  
  public static String a(InputStream paramInputStream) {
    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    StringBuffer stringBuffer = new StringBuffer();
    try {
      while (true) {
        String str = bufferedReader.readLine();
        if (str != null) {
          stringBuffer.append(str);
          continue;
        } 
        return stringBuffer.toString();
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return stringBuffer.toString();
  }
  
  public static String a(String paramString1, String paramString2, String paramString3) {
    return g.a(paramString2, paramString3);
  }
  
  public static String a(HttpEntity paramHttpEntity) {
    String str;
    try {
      String str1 = EntityUtils.toString(paramHttpEntity);
      str = str1;
    } catch (Exception exception) {
      b.f("====", "处理entity错误" + str + " , " + exception.getMessage() + " , " + exception.getStackTrace());
      str = null;
    } 
    return str;
  }
  
  public static String a(HttpResponse paramHttpResponse, Context paramContext) {
    paramHttpResponse.getAllHeaders();
    try {
      String str = EntityUtils.toString(paramHttpResponse.getEntity());
    } catch (Exception exception) {
      exception = null;
    } 
    return (String)exception;
  }
  
  public static HttpResponse a(String paramString, Header[] paramArrayOfHeader, Context paramContext) {
    DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
    HttpGet httpGet = new HttpGet(paramString);
    if (a(paramContext)) {
      HttpHost httpHost = new HttpHost(Proxy.getDefaultHost(), Proxy.getDefaultPort(), "http");
      defaultHttpClient.getParams().setParameter("http.route.default-proxy", httpHost);
    } 
    if (paramArrayOfHeader != null)
      httpGet.setHeaders(paramArrayOfHeader); 
    return defaultHttpClient.execute((HttpUriRequest)httpGet);
  }
  
  public static boolean a(Context paramContext) {
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null && networkInfo.getType() == 1)
        return false; 
      String str = Proxy.getDefaultHost();
      if (str != null) {
        boolean bool = str.equals("");
        if (!bool)
          return true; 
      } 
    } catch (Exception exception) {}
    return false;
  }
  
  public static Header[] a(Context paramContext, String paramString1, String paramString2) {
    String[] arrayOfString = new String[4];
    arrayOfString[0] = "0";
    arrayOfString[1] = "0";
    arrayOfString[2] = "0";
    arrayOfString[3] = "0";
    arrayOfString[0] = e.b(paramContext, "lac", "0");
    arrayOfString[1] = e.b(paramContext, "mcc", "0");
    arrayOfString[2] = e.b(paramContext, "mnc", "0");
    arrayOfString[3] = e.b(paramContext, "cid", "0");
    String str1 = e.b(paramContext, "latitude", "-1");
    String str2 = e.b(paramContext, "longitude", "-1");
    return a(paramContext, paramString1, paramString2, e.b(paramContext, "qn", "0"), "0", arrayOfString, Double.valueOf(str1).doubleValue(), Double.valueOf(str2).doubleValue());
  }
  
  public static Header[] a(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4, String[] paramArrayOfString, double paramDouble1, double paramDouble2) {
    return new Header[] { 
        (Header)new BasicHeader("mobileModel", Build.MODEL), (Header)new BasicHeader("sign", paramString1), (Header)new BasicHeader("osVersion", (new StringBuilder(String.valueOf(Build.VERSION.SDK_INT))).toString()), (Header)new BasicHeader("netMode", i.f(paramContext)), (Header)new BasicHeader("sdkVersion", "2.6.05"), (Header)new BasicHeader("package", i.j(paramContext)), (Header)new BasicHeader("mobile", i.k(paramContext)), (Header)new BasicHeader("clientmobile", i.l(paramContext)), (Header)new BasicHeader("mobileimsi", i.b(paramContext)), (Header)new BasicHeader("mobileimei", i.d(paramContext)), 
        (Header)new BasicHeader("cp", paramString2), (Header)new BasicHeader("qn", paramString3), (Header)new BasicHeader("appId", paramString4), (Header)new BasicHeader("lac", paramArrayOfString[0]), (Header)new BasicHeader("mcc", paramArrayOfString[1]), (Header)new BasicHeader("mnc", paramArrayOfString[2]), (Header)new BasicHeader("cid", paramArrayOfString[3]), (Header)new BasicHeader("latitude", (new StringBuilder(String.valueOf(paramDouble1))).toString()), (Header)new BasicHeader("longitude", (new StringBuilder(String.valueOf(paramDouble2))).toString()) };
  }
  
  public static Header[] a(Context paramContext, String paramString1, String paramString2, String[] paramArrayOfString, double paramDouble1, double paramDouble2) {
    return a(paramContext, paramString1, paramString2, e.b(paramContext, "qn", "0"), "0", paramArrayOfString, paramDouble1, paramDouble2);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */