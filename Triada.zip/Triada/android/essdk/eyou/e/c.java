package com.android.essdk.eyou.e;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.IOException;
import java.io.InputStream;

public class c {
  public static float a(Context paramContext) {
    DisplayMetrics displayMetrics = new DisplayMetrics();
    ((WindowManager)paramContext.getSystemService("window")).getDefaultDisplay().getMetrics(displayMetrics);
    return displayMetrics.density;
  }
  
  public static Bitmap a(String paramString, Context paramContext) {
    AssetManager assetManager = paramContext.getResources().getAssets();
    try {
      InputStream inputStream = assetManager.open(paramString);
      Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
      try {
        inputStream.close();
        return bitmap;
      } catch (IOException null) {}
    } catch (IOException iOException) {
      paramString = null;
    } 
    iOException.printStackTrace();
    return (Bitmap)paramString;
  }
  
  public static Bitmap a(String paramString, Context paramContext, int paramInt1, int paramInt2) {
    Bitmap bitmap1 = a(paramString, paramContext);
    Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap1, paramInt1, paramInt2, true);
    bitmap1.recycle();
    return bitmap2;
  }
  
  public static StateListDrawable a(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4) {
    StateListDrawable stateListDrawable = new StateListDrawable();
    Drawable drawable2 = f.a(paramContext, paramString1);
    Drawable drawable3 = f.a(paramContext, paramString2);
    Drawable drawable4 = f.a(paramContext, paramString3);
    Drawable drawable1 = f.a(paramContext, paramString4);
    stateListDrawable.addState(new int[] { 16842919, 16842910 }, drawable3);
    stateListDrawable.addState(new int[] { 16842910, 16842908 }, drawable4);
    stateListDrawable.addState(new int[] { 16842910 }, drawable2);
    stateListDrawable.addState(new int[] { 16842908 }, drawable4);
    stateListDrawable.addState(new int[] { 16842909 }, drawable1);
    stateListDrawable.addState(new int[0], drawable2);
    return stateListDrawable;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */