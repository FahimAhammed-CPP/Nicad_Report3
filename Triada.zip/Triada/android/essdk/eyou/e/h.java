package com.android.essdk.eyou.e;

import android.content.Context;
import android.telephony.TelephonyManager;

public class h {
  private boolean a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  public static h a(Context paramContext) {
    h h1 = new h();
    TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    if (telephonyManager.getSimState() == 5) {
      if (telephonyManager.getNetworkOperator().equals("") || telephonyManager.getNetworkOperatorName().equals("")) {
        h1.a(false);
        h1.b(telephonyManager.getNetworkOperator());
        h1.c(telephonyManager.getNetworkOperatorName());
        h1.a(telephonyManager.getSubscriberId());
        return h1;
      } 
      h1.a(true);
      h1.b(telephonyManager.getNetworkOperator());
      h1.c(telephonyManager.getNetworkOperatorName());
      h1.a(telephonyManager.getSubscriberId());
      return h1;
    } 
    telephonyManager.getSimState();
    h1.a(false);
    h1.b(telephonyManager.getNetworkOperator());
    h1.c(telephonyManager.getNetworkOperatorName());
    h1.a(telephonyManager.getSubscriberId());
    return h1;
  }
  
  public void a(String paramString) {
    this.b = paramString;
  }
  
  public void a(boolean paramBoolean) {
    this.a = paramBoolean;
  }
  
  public boolean a() {
    return this.a;
  }
  
  public void b(String paramString) {
    this.c = paramString;
  }
  
  public void c(String paramString) {
    this.d = paramString;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */