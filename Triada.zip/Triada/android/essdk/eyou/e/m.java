package com.android.essdk.eyou.e;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;

public class m {
  private static final String a = m.class.getName();
  
  private WifiManager b;
  
  private WifiInfo c;
  
  public m(Context paramContext) {
    this.b = (WifiManager)paramContext.getSystemService("wifi");
    this.c = this.b.getConnectionInfo();
  }
  
  public void a() {
    if (!this.b.isWifiEnabled())
      this.b.setWifiEnabled(true); 
  }
  
  public boolean b() {
    b.f(a, "WIFImanageEnable is " + this.b.isWifiEnabled());
    return this.b.isWifiEnabled();
  }
  
  public void c() {
    if (this.b.isWifiEnabled())
      this.b.setWifiEnabled(false); 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */