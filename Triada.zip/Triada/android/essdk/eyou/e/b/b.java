package com.android.essdk.eyou.e.b;

public class b {
  public static String a(String paramString1, String paramString2) {
    return a.a(String.valueOf(paramString1) + paramString2);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/b/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */