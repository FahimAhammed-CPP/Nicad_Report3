package com.android.essdk.eyou.e.b;

import java.security.MessageDigest;

public class a {
  public static String a(String paramString) {
    try {
      byte[] arrayOfByte = paramString.getBytes("UTF-8");
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      messageDigest.update(arrayOfByte);
      arrayOfByte = messageDigest.digest();
      StringBuffer stringBuffer = new StringBuffer();
      this();
      for (byte b = 0;; b++) {
        if (b >= arrayOfByte.length)
          return stringBuffer.toString(); 
        int i = arrayOfByte[b] & 0xFF;
        if (i < 16)
          stringBuffer.append("0"); 
        stringBuffer.append(Integer.toHexString(i));
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      exception = null;
    } 
    return (String)exception;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/b/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */