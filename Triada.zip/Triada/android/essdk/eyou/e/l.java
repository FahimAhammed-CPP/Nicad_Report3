package com.android.essdk.eyou.e;

import android.content.Context;

public class l {
  public static int a(Context paramContext, float paramFloat) {
    return (int)((paramContext.getResources().getDisplayMetrics()).density * paramFloat + 0.5F);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */