package com.android.essdk.eyou.e.a;

import org.json.JSONObject;

public class b {
  public static d a(String paramString) {
    try {
      JSONObject jSONObject = new JSONObject();
      this(paramString);
      d d = new d();
      this();
      try {
        String str1 = jSONObject.getString("id");
        d.a(str1);
        String str2 = jSONObject.getString("port");
        d.b(str2);
        String str3 = jSONObject.getString("content");
        d.c(str3);
        String str4 = jSONObject.getString("contentsid");
        d.d(str4);
        String str5 = jSONObject.getString("status");
        d.e(str5);
        StringBuilder stringBuilder = new StringBuilder();
        this("id为：");
        stringBuilder.append(str1).append("port为：").append(str2).append("content为：").append(str3).append("contentsid为：").append(str4).append("status为：").append(str5);
        return d;
      } catch (Exception exception1) {}
    } catch (Exception exception) {
      exception = null;
    } 
    com.android.essdk.eyou.e.b.b("JSonParser", "json指令解析出错");
    return (d)exception;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/a/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */