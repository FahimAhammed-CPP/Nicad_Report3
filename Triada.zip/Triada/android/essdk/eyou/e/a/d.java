package com.android.essdk.eyou.e.a;

public class d {
  private String a;
  
  private String b;
  
  private String c;
  
  private String d;
  
  private String e;
  
  public String a() {
    return this.b;
  }
  
  public void a(String paramString) {
    this.a = paramString;
  }
  
  public String b() {
    return this.c;
  }
  
  public void b(String paramString) {
    this.b = paramString;
  }
  
  public String c() {
    return this.d;
  }
  
  public void c(String paramString) {
    this.c = paramString;
  }
  
  public String d() {
    return this.e;
  }
  
  public void d(String paramString) {
    this.d = paramString;
  }
  
  public void e(String paramString) {
    this.e = paramString;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/a/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */