package com.android.essdk.eyou.e;

import android.util.Log;
import java.io.FileWriter;
import java.io.IOException;

public class b {
  public static int a;
  
  private static boolean b = true;
  
  private static boolean c = false;
  
  private static String d = "/sdcard/Platform-Log.txt";
  
  private static FileWriter e;
  
  static {
    a = 4;
    e = null;
  }
  
  public static int a(String paramString1, String paramString2) {
    byte b1 = 0;
    int i = b1;
    if (a <= 2)
      try {
        i = Log.v(paramString1, paramString2);
      } catch (Exception exception) {
        i = b1;
      }  
    return i;
  }
  
  public static int b(String paramString1, String paramString2) {
    return (a <= 3) ? Log.d(paramString1, paramString2) : 0;
  }
  
  public static int c(String paramString1, String paramString2) {
    return (a <= 4) ? Log.i(paramString1, paramString2) : 0;
  }
  
  public static int d(String paramString1, String paramString2) {
    return (a <= 5) ? Log.w(paramString1, paramString2) : 0;
  }
  
  public static int e(String paramString1, String paramString2) {
    return (a <= 6) ? Log.e(paramString1, paramString2) : 0;
  }
  
  public static void f(String paramString1, String paramString2) {
    a(paramString1, paramString2);
    if (b)
      try {
        if (e == null) {
          FileWriter fileWriter = new FileWriter();
          this(d, true);
          e = fileWriter;
        } 
        if (paramString1 != null && paramString2 != null) {
          String str1;
          StringBuilder stringBuilder2 = new StringBuilder();
          this(String.valueOf(paramString1));
          String str2 = stringBuilder2.append(":").toString();
          paramString1 = str2;
          if (paramString2.length() >= 100) {
            StringBuilder stringBuilder = new StringBuilder();
            this(String.valueOf(str2));
            str1 = stringBuilder.append("\r\n").toString();
          } 
          FileWriter fileWriter = e;
          StringBuilder stringBuilder1 = new StringBuilder();
          this(String.valueOf(str1));
          fileWriter.write(stringBuilder1.append(paramString2).append("\r\n").toString());
          e.flush();
        } 
      } catch (IOException iOException) {
      
      } catch (Exception exception) {} 
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */