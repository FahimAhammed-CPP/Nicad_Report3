package com.android.essdk.eyou.e;

public final class a {
  private static final byte[] a = new byte[128];
  
  private static final char[] b = new char[64];
  
  static {
    for (byte b = 0;; b++) {
      if (b >= '') {
        for (b = 90;; b--) {
          if (b < 65) {
            for (b = 122;; b--) {
              if (b < 97) {
                for (b = 57;; b--) {
                  if (b < 48) {
                    a[43] = (byte)62;
                    a[47] = (byte)63;
                    for (b = 0;; b++) {
                      if (b > 25) {
                        byte b1 = 26;
                        for (b = 0;; b++) {
                          if (b1 > 51) {
                            b = 52;
                            for (b1 = bool;; b1++) {
                              if (b > 61) {
                                b[62] = (char)'+';
                                b[63] = (char)'/';
                                return;
                              } 
                              b[b] = (char)(char)(b1 + 48);
                              b++;
                            } 
                            break;
                          } 
                          b[b1] = (char)(char)(b + 97);
                          b1++;
                        } 
                        break;
                      } 
                      b[b] = (char)(char)(b + 65);
                    } 
                    break;
                  } 
                  a[b] = (byte)(byte)(b - 48 + 52);
                } 
                break;
              } 
              a[b] = (byte)(byte)(b - 97 + 26);
            } 
            break;
          } 
          a[b] = (byte)(byte)(b - 65);
        } 
        break;
      } 
      a[b] = (byte)-1;
    } 
  }
  
  private static int a(char[] paramArrayOfchar) {
    int i = 0;
    int j = 0;
    if (paramArrayOfchar != null) {
      int k = paramArrayOfchar.length;
      byte b = 0;
      while (true) {
        j = i;
        if (b < k) {
          if (!a(paramArrayOfchar[b])) {
            j = i + 1;
            paramArrayOfchar[i] = paramArrayOfchar[b];
            i = j;
          } 
          b++;
          continue;
        } 
        return j;
      } 
    } 
    return j;
  }
  
  public static String a(byte[] paramArrayOfbyte) {
    int i = 0;
    if (paramArrayOfbyte == null)
      return null; 
    int j = paramArrayOfbyte.length * 8;
    if (j == 0)
      return ""; 
    int k = j % 24;
    int m = j / 24;
    if (k != 0) {
      j = m + 1;
    } else {
      j = m;
    } 
    char[] arrayOfChar = new char[j * 4];
    byte b = 0;
    j = 0;
    while (true) {
      byte b4;
      if (b >= m) {
        if (k == 8) {
          b = paramArrayOfbyte[i];
          i = (byte)(b & 0x3);
          if ((b & 0xFFFFFF80) == 0) {
            b = (byte)(b >> 2);
          } else {
            b = (byte)(b >> 2 ^ 0xC0);
          } 
          int i3 = j + 1;
          arrayOfChar[j] = (char)b[b];
          j = i3 + 1;
          arrayOfChar[i3] = (char)b[i << 4];
          arrayOfChar[j] = (char)'=';
          arrayOfChar[j + 1] = (char)'=';
        } else if (k == 16) {
          b = paramArrayOfbyte[i];
          i = paramArrayOfbyte[i + 1];
          byte b5 = (byte)(i & 0xF);
          b4 = (byte)(b & 0x3);
          if ((b & 0xFFFFFF80) == 0) {
            b = (byte)(b >> 2);
          } else {
            b = (byte)(b >> 2 ^ 0xC0);
          } 
          if ((i & 0xFFFFFF80) == 0) {
            i = (byte)(i >> 4);
          } else {
            i = (byte)(i >> 4 ^ 0xF0);
          } 
          m = j + 1;
          arrayOfChar[j] = (char)b[b];
          j = m + 1;
          arrayOfChar[m] = (char)b[i | b4 << 4];
          arrayOfChar[j] = (char)b[b5 << 2];
          arrayOfChar[j + 1] = (char)'=';
        } 
        return new String(arrayOfChar);
      } 
      int n = i + 1;
      i = paramArrayOfbyte[i];
      int i1 = n + 1;
      n = paramArrayOfbyte[n];
      byte b1 = paramArrayOfbyte[i1];
      byte b2 = (byte)(n & 0xF);
      byte b3 = (byte)(i & 0x3);
      if ((i & 0xFFFFFF80) == 0) {
        i = (byte)(i >> 2);
      } else {
        i = (byte)(i >> 2 ^ 0xC0);
      } 
      if ((n & 0xFFFFFF80) == 0) {
        n = (byte)(n >> 4);
      } else {
        n = (byte)(n >> 4 ^ 0xF0);
      } 
      if ((b1 & Byte.MIN_VALUE) == 0) {
        b4 = (byte)(b1 >> 6);
      } else {
        b4 = (byte)(b1 >> 6 ^ 0xFC);
      } 
      int i2 = j + 1;
      arrayOfChar[j] = (char)b[i];
      j = i2 + 1;
      arrayOfChar[i2] = (char)b[n | b3 << 4];
      i = j + 1;
      arrayOfChar[j] = (char)b[b4 | b2 << 2];
      arrayOfChar[i] = (char)b[b1 & 0x3F];
      b++;
      j = i + 1;
      i = i1 + 1;
    } 
  }
  
  private static boolean a(char paramChar) {
    return !(paramChar != ' ' && paramChar != '\r' && paramChar != '\n' && paramChar != '\t');
  }
  
  public static byte[] a(String paramString) {
    String str = null;
    if (paramString == null)
      return (byte[])str; 
    char[] arrayOfChar = paramString.toCharArray();
    int i = a(arrayOfChar);
    paramString = str;
    if (i % 4 == 0) {
      int j = i / 4;
      if (j == 0)
        return new byte[0]; 
      byte[] arrayOfByte = new byte[j * 3];
      int k = 0;
      i = 0;
      byte b = 0;
      while (true) {
        if (b >= j - 1) {
          byte[] arrayOfByte1;
          j = k + 1;
          char c1 = arrayOfChar[k];
          paramString = str;
          if (c(c1)) {
            int n = j + 1;
            char c2 = arrayOfChar[j];
            paramString = str;
            if (c(c2)) {
              j = a[c1];
              k = a[c2];
              c2 = arrayOfChar[n];
              c1 = arrayOfChar[n + 1];
              if (!c(c2) || !c(c1)) {
                byte[] arrayOfByte2;
                if (b(c2)) {
                  if (b(c1)) {
                    paramString = str;
                    if ((k & 0xF) == 0) {
                      arrayOfByte2 = new byte[b * 3 + 1];
                      System.arraycopy(arrayOfByte, 0, arrayOfByte2, 0, b * 3);
                      arrayOfByte2[i] = (byte)(byte)(j << 2 | k >> 4);
                    } 
                    return arrayOfByte2;
                  } 
                  continue;
                } 
                paramString = str;
                if (!b(c2)) {
                  paramString = str;
                  if (b(c1)) {
                    n = a[c2];
                    paramString = str;
                    if ((n & 0x3) == 0) {
                      arrayOfByte2 = new byte[b * 3 + 2];
                      System.arraycopy(arrayOfByte, 0, arrayOfByte2, 0, b * 3);
                      arrayOfByte2[i] = (byte)(byte)(j << 2 | k >> 4);
                      arrayOfByte2[i + 1] = (byte)(byte)((k & 0xF) << 4 | n >> 2 & 0xF);
                    } 
                  } 
                } 
                return arrayOfByte2;
              } 
              n = a[c2];
              b = a[c1];
              int i1 = i + 1;
              arrayOfByte[i] = (byte)(byte)(j << 2 | k >> 4);
              arrayOfByte[i1] = (byte)(byte)((k & 0xF) << 4 | n >> 2 & 0xF);
              arrayOfByte[i1 + 1] = (byte)(byte)(n << 6 | b);
              arrayOfByte1 = arrayOfByte;
            } 
          } 
          return arrayOfByte1;
        } 
        int m = k + 1;
        char c = arrayOfChar[k];
        paramString = str;
        if (c(c)) {
          k = m + 1;
          char c1 = arrayOfChar[m];
          paramString = str;
          if (c(c1)) {
            m = k + 1;
            char c2 = arrayOfChar[k];
            paramString = str;
            if (c(c2)) {
              k = m + 1;
              char c3 = arrayOfChar[m];
              paramString = str;
              if (c(c3)) {
                byte b1 = a[c];
                byte b2 = a[c1];
                m = a[c2];
                byte b3 = a[c3];
                int i1 = i + 1;
                arrayOfByte[i] = (byte)(byte)(b1 << 2 | b2 >> 4);
                int n = i1 + 1;
                arrayOfByte[i1] = (byte)(byte)((b2 & 0xF) << 4 | m >> 2 & 0xF);
                i = n + 1;
                arrayOfByte[n] = (byte)(byte)(m << 6 | b3);
                b++;
                continue;
              } 
            } 
          } 
        } 
        return (byte[])paramString;
      } 
    } 
    return (byte[])paramString;
  }
  
  private static boolean b(char paramChar) {
    return (paramChar == '=');
  }
  
  private static boolean c(char paramChar) {
    return (paramChar < '' && a[paramChar] != -1);
  }
  
  static {
    boolean bool = false;
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */