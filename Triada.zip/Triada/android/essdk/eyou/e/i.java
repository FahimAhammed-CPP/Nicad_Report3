package com.android.essdk.eyou.e;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.telephony.TelephonyManager;
import com.android.essdk.eyou.b.e;
import java.net.InetSocketAddress;
import java.net.Proxy;

public class i {
  public static String a = "platform";
  
  public static String b;
  
  private static String c;
  
  private static String d;
  
  private static String e = "00000000000";
  
  private static String f = "unknow";
  
  private static int g = -1;
  
  private static int h = -1;
  
  private static int i = -1;
  
  private static String j = "";
  
  private static String k = "";
  
  public static void a(Context paramContext) {
    NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
    f = "unknow";
    if (networkInfo != null) {
      Proxy proxy;
      int j;
      switch (networkInfo.getType()) {
        default:
          f = "unknow";
          return;
        case 0:
          j = ((TelephonyManager)paramContext.getSystemService("phone")).getNetworkType();
          proxy = g(paramContext);
          if (j == 1) {
            if (proxy != null) {
              f = "gprs-wap";
              return;
            } 
            f = "gprs-net";
            return;
          } 
          if (j == 2 || j == 0) {
            if (proxy != null) {
              f = "edge-wap";
              return;
            } 
            f = "edge-net";
            return;
          } 
          if (proxy != null) {
            f = "3g-wap";
            return;
          } 
          f = "3g-net";
          return;
        case 1:
          break;
      } 
    } else {
      return;
    } 
    f = "wifi";
  }
  
  public static String b(Context paramContext) {
    if (c != null)
      return c; 
    null = ((TelephonyManager)paramContext.getSystemService("phone")).getSubscriberId();
    c = null;
    if (null == null)
      c = ""; 
    return c;
  }
  
  public static void c(Context paramContext) {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getSubscriberId();
    c = str;
    if (str != null) {
      if (c.startsWith("46000") || c.startsWith("46002") || c.startsWith("46007")) {
        b = "mobile";
        return;
      } 
      if (c.startsWith("46001")) {
        System.out.println("是联通卡");
        b = "unicom";
        return;
      } 
      if (c.startsWith("46003")) {
        b = "telecom";
        return;
      } 
      b = "unknow";
      return;
    } 
    c = "";
    b = "unknown";
  }
  
  public static String d(Context paramContext) {
    if (d != null)
      return d; 
    null = ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
    d = null;
    if (null == null)
      d = ""; 
    return d;
  }
  
  public static String e(Context paramContext) {
    try {
      String str = b(paramContext);
      StringBuilder stringBuilder = new StringBuilder();
      this("imsi");
      b.f("==", stringBuilder.append(str).toString());
      if (str != null) {
        if (str.startsWith("46000") || str.startsWith("46002") || str.startsWith("46007"))
          b = "mobile"; 
        if (str.startsWith("46001")) {
          System.out.println("是联通卡");
          b = "unicom";
        } 
        if (str.startsWith("46003")) {
          b = "telecom";
          return b;
        } 
        b = "unknow";
        return b;
      } 
    } catch (Exception exception) {
      b = "unknow";
      return b;
    } 
    b = "unknow";
    return b;
  }
  
  public static String f(Context paramContext) {
    a(paramContext);
    return f;
  }
  
  public static Proxy g(Context paramContext) {
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo != null && networkInfo.getType() == 1)
        return null; 
      String str = Proxy.getDefaultHost();
      if (str != null && !str.equals("")) {
        Proxy proxy = new Proxy();
        Proxy.Type type = Proxy.Type.HTTP;
        InetSocketAddress inetSocketAddress = new InetSocketAddress();
        this(Proxy.getDefaultHost(), Proxy.getDefaultPort());
        this(type, inetSocketAddress);
        return proxy;
      } 
    } catch (Exception exception) {}
    return null;
  }
  
  public static int h(Context paramContext) {
    if (g != -1)
      return g; 
    try {
      g = (paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128)).metaData.getInt("EPAY_CPID");
    } catch (Exception exception) {
      g = 0;
      b.f("===", "得到CPID 异常" + exception.getMessage());
    } 
    return g;
  }
  
  public static int i(Context paramContext) {
    if (h != -1)
      return h; 
    try {
      h = (paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128)).metaData.getInt("EPAY_APPFEE_ID");
    } catch (Exception exception) {
      h = -1;
      b.f("===", "得到serviceId 异常" + exception.getMessage());
    } 
    return h;
  }
  
  public static String j(Context paramContext) {
    if (paramContext == null)
      return null; 
    String str = paramContext.getPackageName();
    b.f("", "包名为" + str);
    return str;
  }
  
  public static String k(Context paramContext) {
    return e.e(paramContext);
  }
  
  public static String l(Context paramContext) {
    return ((TelephonyManager)paramContext.getSystemService("phone")).getLine1Number();
  }
}


/* Location:              /home/fahim/Desktop/triada1-dex2jar.jar!/com/android/essdk/eyou/e/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */