package com.baidu.android.pushservice;

import android.content.Context;
import com.baidu.android.pushservice.apiproxy.BridgePushSettings;

public class PushSettings {
  public static void enableDebugMode(Context paramContext, boolean paramBoolean) {
    (new Thread(paramContext, paramBoolean) {
        public void run() {
          if (LoadExecutor.loadPush(this.a))
            BridgePushSettings.enableDebugMode(this.a, this.b); 
        }
      }).start();
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/PushSettings.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */