package com.baidu.android.pushservice;

import android.app.Activity;
import android.content.Context;
import android.provider.Settings;
import com.baidu.android.pushservice.apiproxy.BridgePushManager;
import java.util.List;

public class PushManager {
  private static final String a = "com.baidu.pushservice.PushSettings.connect_state";
  
  private static boolean a(Context paramContext) {
    boolean bool = true;
    try {
      int i = Settings.System.getInt(paramContext.getContentResolver(), "com.baidu.pushservice.PushSettings.connect_state");
      if (i != 1)
        bool = false; 
    } catch (android.provider.Settings.SettingNotFoundException settingNotFoundException) {
      bool = false;
    } 
    return bool;
  }
  
  public static void activityStarted(Activity paramActivity) {
    LoadExecutor.excuteMethod(new Runnable(paramActivity) {
          public void run() {
            BridgePushManager.activityStarted(this.a);
          }
        },  (Context)paramActivity);
  }
  
  public static void activityStoped(Activity paramActivity) {
    LoadExecutor.excuteMethod(new Runnable(paramActivity) {
          public void run() {
            BridgePushManager.activityStoped(this.a);
          }
        },  (Context)paramActivity);
  }
  
  public static void bind(Context paramContext, int paramInt) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramInt) {
          public void run() {
            BridgePushManager.bind(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void bindGroup(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.bindGroup(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void delTags(Context paramContext, List<String> paramList) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramList) {
          public void run() {
            BridgePushManager.delTags(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void deleteMessages(Context paramContext, String[] paramArrayOfString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramArrayOfString) {
          public void run() {
            BridgePushManager.deleteMessages(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void disableLbs(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.disableLbs(this.a);
          }
        },  paramContext);
  }
  
  public static void enableLbs(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.enableLbs(this.a);
          }
        },  paramContext);
  }
  
  public static void fetchGroupMessages(Context paramContext, String paramString, int paramInt1, int paramInt2) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString, paramInt1, paramInt2) {
          public void run() {
            BridgePushManager.fetchGroupMessages(this.a, this.b, this.c, this.d);
          }
        }paramContext);
  }
  
  public static void fetchMessages(Context paramContext, int paramInt1, int paramInt2) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramInt1, paramInt2) {
          public void run() {
            BridgePushManager.fetchMessages(this.a, this.b, this.c);
          }
        }paramContext);
  }
  
  public static void getGroupInfo(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.getGroupInfo(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void getGroupList(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.getGroupList(this.a);
          }
        },  paramContext);
  }
  
  public static void getGroupMessageCounts(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.getGroupMessageCounts(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void getMessageCounts(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.getMessageCounts(this.a);
          }
        },  paramContext);
  }
  
  public static void init(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.init(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void init(Context paramContext, String paramString1, String paramString2) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString1, paramString2) {
          public void run() {
            BridgePushManager.init(this.a, this.b, this.c);
          }
        }paramContext);
  }
  
  public static void initFromAKSK(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.initFromAKSK(this.a, this.b);
          }
        }paramContext);
  }
  
  public static boolean isConnected(Context paramContext) {
    boolean bool = false;
    if (paramContext != null && a(paramContext))
      bool = true; 
    return bool;
  }
  
  public static boolean isPushEnabled(Context paramContext) {
    boolean bool = true;
    String str = paramContext.getSharedPreferences("pst", 0).getString("s_e", "default");
    if (!"enabled".equals(str) && "disabled".equals(str))
      bool = false; 
    return bool;
  }
  
  public static void listTags(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.listTags(this.a);
          }
        },  paramContext);
  }
  
  public static void resumeWork(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.resumeWork(this.a);
          }
        },  paramContext);
  }
  
  public static void sdkBind(Context paramContext, int paramInt1, String paramString, int paramInt2) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramInt1, paramString, paramInt2) {
          public void run() {
            BridgePushManager.sdkBind(this.a, this.b, this.c, this.d);
          }
        }paramContext);
  }
  
  public static void sdkStartWork(Context paramContext, String paramString, int paramInt) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString, paramInt) {
          public void run() {
            BridgePushManager.sdkStartWork(this.a, this.b, this.c);
          }
        }paramContext);
  }
  
  public static void sendMsgToUser(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString1, paramString2, paramString3, paramString4) {
          public void run() {
            BridgePushManager.sendMsgToUser(this.a, this.b, this.c, this.d, this.e);
          }
        }paramContext);
  }
  
  public static void setAccessToken(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.setAccessToken(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void setApiKey(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.setApiKey(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void setBduss(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.setBduss(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void setDefaultNotificationBuilder(Context paramContext, PushNotificationBuilder paramPushNotificationBuilder) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramPushNotificationBuilder) {
          public void run() {
            BridgePushManager.setDefaultNotificationBuilder(this.a, this.b.getInner());
          }
        }paramContext);
  }
  
  public static void setMediaNotificationBuilder(Context paramContext, PushNotificationBuilder paramPushNotificationBuilder) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramPushNotificationBuilder) {
          public void run() {
            BridgePushManager.setMediaNotificationBuilder(this.a, this.b.getInner());
          }
        }paramContext);
  }
  
  public static void setNotificationBuilder(Context paramContext, int paramInt, PushNotificationBuilder paramPushNotificationBuilder) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramInt, paramPushNotificationBuilder) {
          public void run() {
            BridgePushManager.setNotificationBuilder(this.a, this.b, this.c.getInner());
          }
        }paramContext);
  }
  
  public static void setTags(Context paramContext, List<String> paramList) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramList) {
          public void run() {
            BridgePushManager.setTags(this.a, this.b);
          }
        }paramContext);
  }
  
  public static void startWork(Context paramContext, int paramInt, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramInt, paramString) {
          public void run() {
            BridgePushManager.startWork(this.a, this.b, this.c);
          }
        }paramContext);
  }
  
  public static void startWork(Context paramContext, String paramString1, String paramString2) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString1, paramString2) {
          public void run() {
            BridgePushManager.startWork(this.a, this.b, this.c);
          }
        }paramContext);
  }
  
  public static void stopWork(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.stopWork(this.a);
          }
        },  paramContext);
  }
  
  public static void tryConnect(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.tryConnect(this.a);
          }
        },  paramContext);
  }
  
  public static void unbind(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgePushManager.unbind(this.a);
          }
        },  paramContext);
  }
  
  public static void unbindGroup(Context paramContext, String paramString) {
    LoadExecutor.excuteMethod(new Runnable(paramContext, paramString) {
          public void run() {
            BridgePushManager.unbindGroup(this.a, this.b);
          }
        }paramContext);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/PushManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */