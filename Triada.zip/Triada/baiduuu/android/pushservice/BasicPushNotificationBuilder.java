package com.baidu.android.pushservice;

import android.app.Notification;
import android.content.Context;
import com.baidu.android.pushservice.apiproxy.BridgeBasicPushNotificationBuilder;

public class BasicPushNotificationBuilder {
  private BridgeBasicPushNotificationBuilder a;
  
  public BasicPushNotificationBuilder(Context paramContext) {
    (new Thread(this, paramContext) {
        public void run() {
          if (LoadExecutor.loadPush(this.b))
            BasicPushNotificationBuilder.a(this.a, new BridgeBasicPushNotificationBuilder()); 
        }
      }).start();
  }
  
  public BasicPushNotificationBuilder(Context paramContext, BridgeBasicPushNotificationBuilder paramBridgeBasicPushNotificationBuilder) {
    this.a = paramBridgeBasicPushNotificationBuilder;
  }
  
  private void a(int paramInt) {
    long l = paramInt;
    try {
      Thread.sleep(l);
    } catch (Exception exception) {}
  }
  
  public Notification construct(Context paramContext) {
    return !LoadExecutor.loadPush(paramContext) ? null : this.a.construct(paramContext);
  }
  
  public BridgeBasicPushNotificationBuilder getInner() {
    return this.a;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/BasicPushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */