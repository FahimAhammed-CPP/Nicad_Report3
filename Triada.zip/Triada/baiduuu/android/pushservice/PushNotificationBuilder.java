package com.baidu.android.pushservice;

import android.app.Notification;
import android.content.Context;
import android.net.Uri;
import com.baidu.android.pushservice.apiproxy.BridgePushNotificationBuilder;

public abstract class PushNotificationBuilder {
  private boolean a = false;
  
  protected BridgePushNotificationBuilder mInstance = null;
  
  public PushNotificationBuilder(Context paramContext) {
    (new Thread(this, paramContext) {
        public void run() {
          boolean bool;
          PushNotificationBuilder pushNotificationBuilder = this.a;
          if (LoadExecutor.loadPush(this.b)) {
            bool = false;
          } else {
            bool = true;
          } 
          PushNotificationBuilder.a(pushNotificationBuilder, bool);
        }
      }).start();
  }
  
  public PushNotificationBuilder(Context paramContext, BridgePushNotificationBuilder paramBridgePushNotificationBuilder) {
    this.mInstance = paramBridgePushNotificationBuilder;
  }
  
  private void a(int paramInt) {
    long l = paramInt;
    try {
      Thread.sleep(l);
    } catch (Exception exception) {}
  }
  
  public abstract Notification construct(Context paramContext);
  
  public BridgePushNotificationBuilder getInner() {
    return this.mInstance;
  }
  
  public void setNotificationDefaults(int paramInt) {
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationDefaults(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationFlags(int paramInt) {
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationFlags(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationSound(Uri paramUri) {
    (new Thread(this, paramUri) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationSound(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationText(String paramString) {
    (new Thread(this, paramString) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationText(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationTitle(String paramString) {
    (new Thread(this, paramString) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationTitle(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationVibrate(long[] paramArrayOflong) {
    (new Thread(this, paramArrayOflong) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationVibrate(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setStatusbarIcon(int paramInt) {
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || PushNotificationBuilder.a(this.a)) {
              if (!PushNotificationBuilder.a(this.a))
                this.a.mInstance.setStatusbarIcon(this.b); 
              return;
            } 
            PushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/PushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */