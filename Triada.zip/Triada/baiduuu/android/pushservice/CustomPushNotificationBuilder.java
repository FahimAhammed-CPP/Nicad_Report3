package com.baidu.android.pushservice;

import android.app.Notification;
import android.content.Context;
import android.net.Uri;
import com.baidu.android.pushservice.apiproxy.BridgeCustomPushNotificationBuilder;
import com.baidu.android.pushservice.apiproxy.BridgePushNotificationBuilder;

public class CustomPushNotificationBuilder extends PushNotificationBuilder {
  private boolean a = false;
  
  public CustomPushNotificationBuilder(Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramContext);
    if (LoadExecutor.isPushLibLoaded(paramContext)) {
      this.mInstance = (BridgePushNotificationBuilder)new BridgeCustomPushNotificationBuilder(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    (new Thread(this, paramContext, paramInt1, paramInt2, paramInt3, paramInt4) {
        public void run() {
          if (!LoadExecutor.loadPush(this.b)) {
            CustomPushNotificationBuilder.a(this.a, true);
            return;
          } 
          this.a.mInstance = (BridgePushNotificationBuilder)new BridgeCustomPushNotificationBuilder(this.c, this.d, this.e, this.f);
        }
      }).start();
  }
  
  public CustomPushNotificationBuilder(Context paramContext, BridgeCustomPushNotificationBuilder paramBridgeCustomPushNotificationBuilder) {
    super(paramContext);
    this.mInstance = (BridgePushNotificationBuilder)paramBridgeCustomPushNotificationBuilder;
  }
  
  private void a(int paramInt) {
    long l = paramInt;
    try {
      Thread.sleep(l);
    } catch (Exception exception) {}
  }
  
  public Notification construct(Context paramContext) {
    return !LoadExecutor.loadPush(paramContext) ? null : this.mInstance.construct(paramContext);
  }
  
  public BridgeCustomPushNotificationBuilder getInner() {
    while (true) {
      if (this.mInstance != null || this.a) {
        if (this.a)
          return null; 
      } else {
        a(50);
        continue;
      } 
      return (BridgeCustomPushNotificationBuilder)this.mInstance;
    } 
  }
  
  public void setLayoutDrawable(int paramInt) {
    if (this.mInstance != null) {
      ((BridgeCustomPushNotificationBuilder)this.mInstance).setLayoutDrawable(paramInt);
      return;
    } 
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                ((BridgeCustomPushNotificationBuilder)this.a.mInstance).setLayoutDrawable(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationDefaults(int paramInt) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationDefaults(paramInt);
      return;
    } 
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationDefaults(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationFlags(int paramInt) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationFlags(paramInt);
      return;
    } 
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationFlags(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationSound(Uri paramUri) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationSound(paramUri);
      return;
    } 
    (new Thread(this, paramUri) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationSound(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationText(String paramString) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationText(paramString);
      return;
    } 
    (new Thread(this, paramString) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationText(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationTitle(String paramString) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationTitle(paramString);
      return;
    } 
    (new Thread(this, paramString) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationTitle(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setNotificationVibrate(long[] paramArrayOflong) {
    if (this.mInstance != null) {
      this.mInstance.setNotificationVibrate(paramArrayOflong);
      return;
    } 
    (new Thread(this, paramArrayOflong) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setNotificationVibrate(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
  
  public void setStatusbarIcon(int paramInt) {
    if (this.mInstance != null) {
      this.mInstance.setStatusbarIcon(paramInt);
      return;
    } 
    (new Thread(this, paramInt) {
        public void run() {
          while (true) {
            if (this.a.mInstance != null || CustomPushNotificationBuilder.a(this.a)) {
              if (!CustomPushNotificationBuilder.a(this.a))
                this.a.mInstance.setStatusbarIcon(this.b); 
              return;
            } 
            CustomPushNotificationBuilder.a(this.a, 50);
          } 
        }
      }).start();
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/CustomPushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */