package com.baidu.android.pushservice;

import android.content.Context;
import com.baidu.android.pushservice.apiproxy.BridgeInternal;

public class Internal {
  public static void createBdussIntent(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgeInternal.createBdussIntent(this.a);
          }
        },  paramContext);
  }
  
  public static void disablePushConnection(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgeInternal.disablePushConnection(this.a);
          }
        },  paramContext);
  }
  
  public static void disablePushService(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgeInternal.disablePushService(this.a);
          }
        },  paramContext);
  }
  
  public static void enablePushConnection(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgeInternal.enablePushConnection(this.a);
          }
        },  paramContext);
  }
  
  public static void enablePushService(Context paramContext) {
    LoadExecutor.excuteMethod(new Runnable(paramContext) {
          public void run() {
            BridgeInternal.enablePushService(this.a);
          }
        },  paramContext);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/Internal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */