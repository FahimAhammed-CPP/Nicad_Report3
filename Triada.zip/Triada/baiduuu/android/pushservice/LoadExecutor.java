package com.baidu.android.pushservice;

import android.content.Context;

public class LoadExecutor {
  private static final String a = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYAFbG0oYmKgh6o7BhZIHf1njBpZXqyWBnYz2ip3Wp+s97OeA/pTe8xebuGJHwq4xbsGQrJWepIbUVrdjm6JRmdvuJhar7/hC/UNnUkJgYdYl10OZKlvcFFgK3V7XGBPplXldDnhbgscna3JG8U3025WSxZCP5vy/8cfxsEoVx5QIDAQAB";
  
  public static void excuteMethod(Runnable paramRunnable, Context paramContext) {
    if (isPushLibLoaded(paramContext)) {
      paramRunnable.run();
      return;
    } 
    (new Thread(paramContext, paramRunnable) {
        public void run() {
          if (LoadExecutor.loadPush(this.a))
            this.b.run(); 
        }
      }).start();
  }
  
  public static boolean isPushLibLoaded(Context paramContext) {
    boolean bool = false;
    try {
      paramContext.getClassLoader().loadClass("com.baidu.android.pushservice.internal.PushManager");
      bool = true;
    } catch (ClassNotFoundException classNotFoundException) {}
    return bool;
  }
  
  public static boolean loadPush(Context paramContext) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: ldc com/baidu/android/pushservice/LoadExecutor
    //   4: monitorenter
    //   5: aload_0
    //   6: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   9: ldc 'com.baidu.android.pushservice.internal.PushManager'
    //   11: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   14: pop
    //   15: ldc com/baidu/android/pushservice/LoadExecutor
    //   17: monitorexit
    //   18: iload_1
    //   19: ireturn
    //   20: astore_2
    //   21: ldc 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYAFbG0oYmKgh6o7BhZIHf1njBpZXqyWBnYz2ip3Wp+s97OeA/pTe8xebuGJHwq4xbsGQrJWepIbUVrdjm6JRmdvuJhar7/hC/UNnUkJgYdYl10OZKlvcFFgK3V7XGBPplXldDnhbgscna3JG8U3025WSxZCP5vy/8cfxsEoVx5QIDAQAB'
    //   23: invokestatic setKey : (Ljava/lang/String;)V
    //   26: aload_0
    //   27: ldc 'frontia_plugin'
    //   29: ldc 'plugin-deploy.jar'
    //   31: invokestatic loadLib : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    //   34: pop
    //   35: aload_0
    //   36: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   39: ldc 'com.baidu.android.pushservice.internal.PushManager'
    //   41: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   44: pop
    //   45: goto -> 15
    //   48: astore_0
    //   49: iconst_0
    //   50: istore_1
    //   51: goto -> 15
    //   54: astore_0
    //   55: ldc com/baidu/android/pushservice/LoadExecutor
    //   57: monitorexit
    //   58: aload_0
    //   59: athrow
    // Exception table:
    //   from	to	target	type
    //   5	15	20	java/lang/ClassNotFoundException
    //   5	15	54	finally
    //   21	26	54	finally
    //   26	45	48	java/lang/Exception
    //   26	45	54	finally
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/LoadExecutor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */