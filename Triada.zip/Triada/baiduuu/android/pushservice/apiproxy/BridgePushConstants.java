package com.baidu.android.pushservice.apiproxy;

import android.content.Context;
import android.content.Intent;
import com.baidu.android.pushservice.internal.PushConstants;

public class BridgePushConstants {
  public static Intent createMethodIntent(Context paramContext) {
    return PushConstants.createMethodIntent(paramContext);
  }
  
  public static void restartPushService(Context paramContext) {
    PushConstants.restartPushService(paramContext);
  }
  
  public static void startPushService(Context paramContext) {
    PushConstants.startPushService(paramContext);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgePushConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */