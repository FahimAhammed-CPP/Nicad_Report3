package com.baidu.android.pushservice.apiproxy;

import android.app.Notification;
import android.content.Context;
import android.net.Uri;
import com.baidu.android.pushservice.internal.PushNotificationBuilder;

public abstract class BridgePushNotificationBuilder {
  protected PushNotificationBuilder mInstance = new PushNotificationBuilder(this) {
      public Notification construct(Context param1Context) {
        return this.a.construct(param1Context);
      }
    };
  
  public BridgePushNotificationBuilder() {}
  
  public BridgePushNotificationBuilder(PushNotificationBuilder paramPushNotificationBuilder) {}
  
  public abstract Notification construct(Context paramContext);
  
  public PushNotificationBuilder getInner() {
    return this.mInstance;
  }
  
  public void setNotificationDefaults(int paramInt) {
    this.mInstance.setNotificationDefaults(paramInt);
  }
  
  public void setNotificationFlags(int paramInt) {
    this.mInstance.setNotificationFlags(paramInt);
  }
  
  public void setNotificationSound(Uri paramUri) {
    this.mInstance.setNotificationSound(paramUri);
  }
  
  public void setNotificationText(String paramString) {
    this.mInstance.setNotificationText(paramString);
  }
  
  public void setNotificationTitle(String paramString) {
    this.mInstance.setNotificationTitle(paramString);
  }
  
  public void setNotificationVibrate(long[] paramArrayOflong) {
    this.mInstance.setNotificationVibrate(paramArrayOflong);
  }
  
  public void setStatusbarIcon(int paramInt) {
    this.mInstance.setStatusbarIcon(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/pushservice/apiproxy/BridgePushNotificationBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */