package com.baidu.android.silentupdate;

import android.app.Application;
import java.lang.reflect.Field;

class c {
  public static void a(Application paramApplication, String paramString) {
    try {
      Field field3 = Class.forName("android.content.ContextWrapper").getDeclaredField("mBase");
      field3.setAccessible(true);
      Object object = field3.get(paramApplication);
      Class<?> clazz1 = Class.forName("android.app.ContextImpl");
      clazz1.getDeclaredField("mMainThread").setAccessible(true);
      Field field2 = clazz1.getDeclaredField("mPackageInfo");
      field2.setAccessible(true);
      object = field2.get(object);
      Class<?> clazz2 = Class.forName("android.app.LoadedApk");
      field2 = clazz2.getDeclaredField("mResDir");
      field2.setAccessible(true);
      field2.set(object, paramString);
      Field field1 = clazz2.getDeclaredField("mResources");
      field1.setAccessible(true);
      field1.set(object, null);
    } catch (ClassNotFoundException classNotFoundException) {
      classNotFoundException.printStackTrace();
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
    } catch (IllegalArgumentException illegalArgumentException) {
      illegalArgumentException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/silentupdate/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */