package com.baidu.android.silentupdate;

import android.content.Context;
import android.util.Log;
import dalvik.system.DexClassLoader;
import java.lang.reflect.Field;

class b {
  private static final String a = "PushClassloader";
  
  public static ClassLoader a(String paramString1, String paramString2, String paramString3, Context paramContext) {
    DexClassLoader dexClassLoader;
    try {
      DexClassLoader dexClassLoader1 = new DexClassLoader();
      this(paramString1, paramString2, paramString3, paramContext.getClassLoader());
      dexClassLoader = dexClassLoader1;
    } catch (Exception exception) {}
    return (ClassLoader)dexClassLoader;
  }
  
  public static boolean a(ClassLoader paramClassLoader1, ClassLoader paramClassLoader2) {
    boolean bool = true;
    for (ClassLoader classLoader = paramClassLoader2; classLoader != null; classLoader = classLoader.getParent()) {
      if (classLoader == paramClassLoader1) {
        Log.d("PushClassloader", "the classloader has been inserted");
        return bool;
      } 
    } 
    try {
      Field field = Class.forName("java.lang.ClassLoader").getDeclaredField("parent");
      field.setAccessible(true);
      field.set(paramClassLoader1, field.get(paramClassLoader2));
      field.set(paramClassLoader2, paramClassLoader1);
    } catch (ClassNotFoundException classNotFoundException) {
      bool = false;
    } catch (SecurityException securityException) {
    
    } catch (NoSuchFieldException noSuchFieldException) {
      bool = false;
    } catch (IllegalArgumentException illegalArgumentException) {
      bool = false;
    } catch (IllegalAccessException illegalAccessException) {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/silentupdate/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */