package com.baidu.android.silentupdate;

import java.io.UnsupportedEncodingException;

final class a {
  private static final byte[] a = new byte[] { 
      65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
      75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
      85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
      101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
      111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
      121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
      56, 57, 43, 47 };
  
  public static String a(byte[] paramArrayOfbyte, String paramString) throws UnsupportedEncodingException {
    int i = paramArrayOfbyte.length * 4 / 3;
    byte[] arrayOfByte = new byte[i + i / 76 + 3];
    int j = paramArrayOfbyte.length - paramArrayOfbyte.length % 3;
    int k = 0;
    int m = 0;
    i = 0;
    while (k < j) {
      int n = i + 1;
      arrayOfByte[i] = (byte)a[(paramArrayOfbyte[k] & 0xFF) >> 2];
      i = n + 1;
      arrayOfByte[n] = (byte)a[(paramArrayOfbyte[k] & 0x3) << 4 | (paramArrayOfbyte[k + 1] & 0xFF) >> 4];
      n = i + 1;
      arrayOfByte[i] = (byte)a[(paramArrayOfbyte[k + 1] & 0xF) << 2 | (paramArrayOfbyte[k + 2] & 0xFF) >> 6];
      int i1 = n + 1;
      arrayOfByte[n] = (byte)a[paramArrayOfbyte[k + 2] & 0x3F];
      n = m;
      i = i1;
      if ((i1 - m) % 76 == 0)
        if (i1 == 0) {
          i = i1;
          n = m;
        } else {
          arrayOfByte[i1] = (byte)10;
          n = m + 1;
          i = i1 + 1;
        }  
      k += 3;
      m = n;
    } 
    switch (paramArrayOfbyte.length % 3) {
      default:
        return new String(arrayOfByte, 0, i, paramString);
      case 1:
        k = i + 1;
        arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j] & 0xFF) >> 2];
        i = k + 1;
        arrayOfByte[k] = (byte)a[(paramArrayOfbyte[j] & 0x3) << 4];
        k = i + 1;
        arrayOfByte[i] = (byte)61;
        i = k + 1;
        arrayOfByte[k] = (byte)61;
      case 2:
        break;
    } 
    k = i + 1;
    arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j] & 0xFF) >> 2];
    i = k + 1;
    arrayOfByte[k] = (byte)a[(paramArrayOfbyte[j] & 0x3) << 4 | (paramArrayOfbyte[j + 1] & 0xFF) >> 4];
    k = i + 1;
    arrayOfByte[i] = (byte)a[(paramArrayOfbyte[j + 1] & 0xF) << 2];
    i = k + 1;
    arrayOfByte[k] = (byte)61;
  }
  
  public static byte[] a(byte[] paramArrayOfbyte) {
    return a(paramArrayOfbyte, paramArrayOfbyte.length);
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt) {
    int i = paramInt / 4 * 3;
    if (i == 0)
      return new byte[0]; 
    byte[] arrayOfByte = new byte[i];
    int j = 0;
    int k = paramInt;
    while (true) {
      i = paramArrayOfbyte[k - 1];
      paramInt = j;
      if (i != 10) {
        paramInt = j;
        if (i != 13) {
          paramInt = j;
          if (i != 32) {
            paramInt = j;
            if (i != 9) {
              if (i != 61) {
                byte b = 0;
                m = 0;
                i = 0;
                for (paramInt = 0;; paramInt = i1) {
                  if (b < k) {
                    byte b1 = paramArrayOfbyte[b];
                    if (b1 != 10 && b1 != 13) {
                      int i2;
                      if (b1 == 32) {
                        i2 = m;
                        m = paramInt;
                        paramInt = i2;
                      } else if (i2 == 9) {
                        i2 = m;
                        m = paramInt;
                        paramInt = i2;
                      } else {
                        if (i2 >= 65 && i2 <= 90) {
                          i2 -= 65;
                        } else if (i2 >= 97 && i2 <= 122) {
                          i2 -= 71;
                        } else if (i2 >= 48 && i2 <= 57) {
                          i2 += 4;
                        } else if (i2 == 43) {
                          i2 = 62;
                        } else if (i2 == 47) {
                          i2 = 63;
                        } else {
                          return null;
                        } 
                        i2 = m << 6 | (byte)i2;
                        if (i % 4 == 3) {
                          m = paramInt + 1;
                          arrayOfByte[paramInt] = (byte)(byte)((0xFF0000 & i2) >> 16);
                          int i3 = m + 1;
                          arrayOfByte[m] = (byte)(byte)((0xFF00 & i2) >> 8);
                          paramInt = i3 + 1;
                          arrayOfByte[i3] = (byte)(byte)(i2 & 0xFF);
                        } 
                        i++;
                        m = paramInt;
                        paramInt = i2;
                      } 
                      continue;
                    } 
                  } else {
                    i = paramInt;
                    if (j) {
                      m <<= j * 6;
                      i = paramInt + 1;
                      arrayOfByte[paramInt] = (byte)(byte)((0xFF0000 & m) >> 16);
                      if (j == 1) {
                        paramInt = i + 1;
                        arrayOfByte[i] = (byte)(byte)((0xFF00 & m) >> 8);
                        i = paramInt;
                      } 
                    } 
                    paramArrayOfbyte = new byte[i];
                    System.arraycopy(arrayOfByte, 0, paramArrayOfbyte, 0, i);
                    return paramArrayOfbyte;
                  } 
                  int i1 = m;
                  m = paramInt;
                  paramInt = i1;
                  continue;
                  b++;
                  i1 = m;
                  m = paramInt;
                } 
              } 
              paramInt = j + 1;
            } 
          } 
        } 
      } 
      k--;
      j = paramInt;
    } 
    int n = m;
    int m = paramInt;
    paramInt = n;
    continue;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/silentupdate/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */