package com.baidu.android.silentupdate;

import android.app.ActivityManager;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Process;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Date;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import org.json.JSONObject;

public class SilentManager {
  private static final String a = SilentManager.class.getSimpleName();
  
  private static final String b = "push_lib";
  
  private static final String c = "push_dex";
  
  private static final String d = "push_update";
  
  private static String e = null;
  
  private static boolean f = false;
  
  private static boolean g = true;
  
  private static String a(File paramFile) {
    String str1 = null;
    String str2 = str1;
    if (paramFile.isFile()) {
      if (!paramFile.exists())
        return str1; 
    } else {
      return str2;
    } 
    byte[] arrayOfByte = new byte[1024];
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      FileInputStream fileInputStream = new FileInputStream();
      this(paramFile);
      while (true) {
        int i = fileInputStream.read(arrayOfByte, 0, 1024);
        if (i != -1) {
          messageDigest.update(arrayOfByte, 0, i);
          continue;
        } 
        fileInputStream.close();
        String str = a(messageDigest.digest()).toLowerCase();
        // Byte code: goto -> 20
      } 
    } catch (Exception exception) {
      str2 = str1;
    } 
    return str2;
  }
  
  private static String a(String paramString) {
    int i = paramString.lastIndexOf(".");
    if (paramString.lastIndexOf("/") > i)
      return paramString; 
    String str = paramString;
    if (i > 0) {
      str = paramString;
      if (i < paramString.length())
        str = paramString.substring(0, i); 
    } 
    return str;
  }
  
  private static String a(byte[] paramArrayOfbyte) {
    String str = "";
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      String str1 = Integer.toHexString(paramArrayOfbyte[b] & 0xFF);
      if (str1.length() == 1) {
        str = str + "0" + str1;
      } else {
        str = str + str1;
      } 
    } 
    return str;
  }
  
  private static void a(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
      } catch (IOException iOException) {} 
  }
  
  private static void a(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    InputStream inputStream = paramInputStream;
    if (!(paramInputStream instanceof BufferedInputStream))
      inputStream = new BufferedInputStream(paramInputStream); 
    OutputStream outputStream = paramOutputStream;
    if (!(paramOutputStream instanceof BufferedOutputStream))
      outputStream = new BufferedOutputStream(paramOutputStream); 
    null = new byte[512];
    try {
      while (true) {
        int i = inputStream.read(null);
        if (i == -1) {
          outputStream.flush();
          return;
        } 
        outputStream.write(null, 0, i);
      } 
    } finally {
      a(inputStream);
      a(outputStream);
    } 
  }
  
  private static boolean a(Context paramContext, File paramFile1, File paramFile2, String paramString1, String paramString2, String paramString3) {
    boolean bool = true;
    if (!g)
      return bool; 
    String str2 = "";
    String str3 = str2;
    String str4 = str2;
    try {
      FileInputStream fileInputStream = new FileInputStream();
      str3 = str2;
      str4 = str2;
      this(paramFile1);
      str3 = str2;
      str4 = str2;
      InputStreamReader inputStreamReader1 = new InputStreamReader();
      str3 = str2;
      str4 = str2;
      this(fileInputStream);
      str3 = str2;
      str4 = str2;
      BufferedReader bufferedReader1 = new BufferedReader();
      str3 = str2;
      str4 = str2;
      this(inputStreamReader1);
      String str = str2;
      while (true) {
        str3 = str;
        str4 = str;
        str2 = bufferedReader1.readLine();
        str4 = str;
        if (str2 != null) {
          str3 = str;
          str4 = str;
          StringBuilder stringBuilder1 = new StringBuilder();
          str3 = str;
          str4 = str;
          this();
          str3 = str;
          str4 = str;
          str = stringBuilder1.append(str).append(str2).append("\r\n").toString();
          continue;
        } 
        break;
      } 
    } catch (FileNotFoundException fileNotFoundException) {
    
    } catch (IOException iOException) {
      str4 = str3;
    } catch (Exception exception) {
      return false;
    } 
    JSONObject jSONObject = new JSONObject();
    this(decrypt(paramString1, str4));
    AssetManager assetManager = exception.getAssets();
    StringBuilder stringBuilder = new StringBuilder();
    this();
    InputStream inputStream = assetManager.open(stringBuilder.append(paramString2).append("/").append(a(paramString3)).append(".key").toString());
    InputStreamReader inputStreamReader = new InputStreamReader();
    this(inputStream);
    BufferedReader bufferedReader = new BufferedReader();
    this(inputStreamReader);
    String str1 = "";
    while (true) {
      String str6 = bufferedReader.readLine();
      if (str6 != null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        str1 = stringBuilder1.append(str1).append(str6).append("\r\n").toString();
        continue;
      } 
      JSONObject jSONObject1 = new JSONObject();
      this(decrypt(paramString1, str1));
      if (!jSONObject1.getString("flag").equals(jSONObject.getString("flag"))) {
        if (f)
          Log.d(a, "Flag not equal!"); 
        return false;
      } 
      if (jSONObject1.getLong("timestamp") > jSONObject.getLong("timestamp")) {
        if (f)
          Log.d(a, "APK newer than dex!"); 
        return false;
      } 
      String str5 = a(paramFile2);
      if (f) {
        paramString1 = a;
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        Log.d(paramString1, stringBuilder1.append("Lib MD5 : ").append(str5).toString());
      } 
      if (!jSONObject.getString("md5").equals(str5)) {
        if (f)
          Log.d(a, "RSA check fail"); 
        return false;
      } 
      boolean bool1 = bool;
      if (f) {
        Log.d(a, "RSA check ok");
        bool1 = bool;
      } 
      return bool1;
    } 
  }
  
  private static boolean a(Context paramContext, String paramString1, String paramString2, String paramString3, String paramString4) {
    ClassLoader classLoader;
    Context context = paramContext.getApplicationContext();
    if (e == null)
      throw new RuntimeException("public key must init first!"); 
    if (paramString2 == null)
      throw new RuntimeException("Lib Name Must Not Null!"); 
    Date date = new Date();
    if (paramString1 == null)
      paramString1 = ""; 
    File file1 = new File(context.getDir("push_lib", 0).getAbsolutePath() + "/" + paramString2);
    String str = a(paramString2) + ".key";
    File file2 = new File(context.getDir("push_lib", 0).getAbsolutePath() + "/" + str);
    if (paramString4 != null) {
      File file3 = new File(paramString4 + "/" + paramString2);
      File file4 = new File(paramString4 + "/" + str);
      if (file3.exists() && file4.exists()) {
        int i = Process.myPid();
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : ((ActivityManager)context.getSystemService("activity")).getRunningAppProcesses()) {
          if (runningAppProcessInfo.pid == i && runningAppProcessInfo.processName.endsWith(context.getPackageName())) {
            if (f)
              Log.d(a, "Found update"); 
            file3.renameTo(file1);
            file4.renameTo(file2);
          } 
        } 
      } 
    } 
    if (!file1.exists() || !file2.exists() || !a(context, file2, file1, e, paramString1, paramString2)) {
      if (f)
        Log.d(a, "Need copy lib from assert"); 
      try {
        AssetManager assetManager2 = context.getAssets();
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        InputStream inputStream2 = assetManager2.open(stringBuilder2.append(paramString1).append("/").append(paramString2).toString());
        FileOutputStream fileOutputStream2 = new FileOutputStream();
        this(file1);
        a(inputStream2, fileOutputStream2);
        AssetManager assetManager1 = context.getAssets();
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        InputStream inputStream1 = assetManager1.open(stringBuilder1.append(paramString1).append("/").append(str).toString());
        FileOutputStream fileOutputStream1 = new FileOutputStream();
        this(file2);
        a(inputStream1, fileOutputStream1);
        classLoader = b.a(file1.getAbsolutePath(), context.getDir("push_dex", 0).getAbsolutePath(), paramString3, context);
      } catch (IOException iOException) {
        if (f)
          Log.e(a, "Copy from assert fail!"); 
        return false;
      } 
    } else {
      if (f)
        Log.d(a, "Lib file check ok"); 
      classLoader = b.a(file1.getAbsolutePath(), context.getDir("push_dex", 0).getAbsolutePath(), paramString3, context);
    } 
    boolean bool2 = b.a(classLoader, iOException.getClassLoader());
    if (bool2) {
      boolean bool = bool2;
      if (f) {
        Log.d(a, "Load lib ok, cost " + ((new Date()).getTime() - date.getTime()) + "ms");
        bool = bool2;
      } 
      return bool;
    } 
    boolean bool1 = bool2;
    if (f) {
      Log.e(a, "Insert classloader fail");
      bool1 = bool2;
    } 
    return bool1;
  }
  
  public static String decrypt(String paramString1, String paramString2) {
    null = new X509EncodedKeySpec(a.a(paramString1.getBytes()));
    try {
      PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(null);
      Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(2, publicKey);
      byte[] arrayOfByte = cipher.doFinal(a.a(paramString2.getBytes()));
      String str2 = new String();
      this(arrayOfByte, "UTF8");
      if (f) {
        String str = a;
        StringBuilder stringBuilder = new StringBuilder();
        this();
        Log.d(str, stringBuilder.append("RSA decrypt:").append(str2).toString());
      } 
      String str1 = new String();
      this(arrayOfByte, "UTF8");
      return str1;
    } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
    
    } catch (InvalidKeySpecException invalidKeySpecException) {
    
    } catch (NoSuchPaddingException noSuchPaddingException) {
    
    } catch (InvalidKeyException invalidKeyException) {
    
    } catch (IllegalBlockSizeException illegalBlockSizeException) {
    
    } catch (BadPaddingException badPaddingException) {
    
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
    
    } catch (Exception exception) {}
    if (f)
      Log.d(a, "RSA decrypt fail"); 
    return null;
  }
  
  public static void enableDebugMode(boolean paramBoolean) {
    f = paramBoolean;
  }
  
  public static void enableRSA(boolean paramBoolean) {
    g = paramBoolean;
  }
  
  public static String getKey() {
    return e;
  }
  
  public static boolean loadLib(Context paramContext, String paramString1, String paramString2) {
    return loadLib(paramContext, paramString1, paramString2, "/data/data/" + paramContext.getPackageName() + "/lib");
  }
  
  public static boolean loadLib(Context paramContext, String paramString1, String paramString2, String paramString3) {
    return a(paramContext, paramString1, paramString2, paramString3, paramContext.getDir("push_update", 0).getAbsolutePath());
  }
  
  public static void setKey(String paramString) {
    e = paramString;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/android/silentupdate/SilentManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */