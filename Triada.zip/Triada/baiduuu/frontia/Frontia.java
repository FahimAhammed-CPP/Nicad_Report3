package com.baidu.frontia;

import android.content.Context;
import android.util.Log;
import com.baidu.frontia.api.FrontiaPush;
import com.baidu.frontia.base.impl.FrontiaImpl;

public class Frontia {
  private static final String a = "Frontia";
  
  private static FrontiaImpl b;
  
  private static final String c = "1";
  
  public static String getApiKey() {
    return b.getAppKey();
  }
  
  public static String getFrontiaVersion() {
    return "1";
  }
  
  public static FrontiaPush getPush() {
    FrontiaPush frontiaPush = null;
    if (b.getAppKey() != null && b.getAppContext() != null) {
      frontiaPush = FrontiaPush.newInstance(b.getAppContext());
      frontiaPush.init(b.getAppKey());
      return frontiaPush;
    } 
    Log.i("Frontia", "Frontia is not initialized, need to call Frontia.init to initialize Frontia first");
    return frontiaPush;
  }
  
  public static boolean init(Context paramContext, String paramString) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (paramContext != null) {
      if (paramString == null)
        return bool1; 
    } else {
      return bool2;
    } 
    b = FrontiaImpl.get();
    bool2 = bool1;
    if (b != null) {
      b.setAppContext(paramContext.getApplicationContext());
      b.setAppKey(paramString);
      b.start();
      Log.d("frontia", "frontia init");
      a.a(paramContext, paramString);
      bool2 = true;
    } 
    return bool2;
  }
  
  public static void setSlientUpdateEnabled(boolean paramBoolean) {
    b.setCheckForUpdatesEnabled(paramBoolean);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/Frontia.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */