package com.baidu.frontia.api;

import com.baidu.frontia.module.push.FrontiaPushListenerImpl;
import java.util.List;
import org.json.JSONObject;

public interface FrontiaPushListener {
  public static interface CommonMessageListener {
    void onFailure(int param1Int, String param1String);
    
    void onSuccess();
  }
  
  public static interface DescribeMessageListener {
    void onFailure(int param1Int, String param1String);
    
    void onSuccess(FrontiaPushListener.DescribeMessageResult param1DescribeMessageResult);
  }
  
  public static class DescribeMessageResult {
    private FrontiaPushListenerImpl.DescribeMessageResult a;
    
    DescribeMessageResult(FrontiaPushListenerImpl.DescribeMessageResult param1DescribeMessageResult) {
      this.a = param1DescribeMessageResult;
    }
    
    public String getChannelId() {
      return this.a.getChannelId();
    }
    
    public JSONObject getExtras() {
      return this.a.getExtras();
    }
    
    public String getId() {
      return this.a.getId();
    }
    
    public FrontiaPushUtil.MessageContent getMessage() {
      return new FrontiaPushUtil.MessageContent(this.a.getMessage());
    }
    
    public String getTag() {
      return this.a.getTag();
    }
    
    public FrontiaPushUtil.Trigger getTrigger() {
      return new FrontiaPushUtil.Trigger(this.a.getTrigger());
    }
    
    public String getUserId() {
      return this.a.getUserId();
    }
  }
  
  public static interface ListMessageListener {
    void onFailure(int param1Int, String param1String);
    
    void onSuccess(List<FrontiaPushListener.DescribeMessageResult> param1List);
  }
  
  public static interface PushMessageListener {
    void onFailure(int param1Int, String param1String);
    
    void onSuccess(String param1String);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/api/FrontiaPushListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */