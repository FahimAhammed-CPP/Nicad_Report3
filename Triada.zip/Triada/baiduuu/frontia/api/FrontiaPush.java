package com.baidu.frontia.api;

import android.content.Context;
import com.baidu.android.pushservice.internal.PushManager;
import com.baidu.android.pushservice.internal.PushSettings;
import com.baidu.frontia.FrontiaQuery;
import com.baidu.frontia.base.stat.StatUtils;
import com.baidu.frontia.framework.IModule;
import com.baidu.frontia.module.push.FrontiaPushImpl;
import com.baidu.frontia.module.push.FrontiaPushListenerImpl;
import java.util.ArrayList;
import java.util.List;

public class FrontiaPush implements IModule {
  private static FrontiaPush a = null;
  
  private FrontiaPushImpl b;
  
  private Context c;
  
  private FrontiaPush(Context paramContext) {
    this.c = paramContext;
    this.b = new FrontiaPushImpl(paramContext);
  }
  
  public static FrontiaPush newInstance(Context paramContext) {
    if (paramContext == null)
      return null; 
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/baidu/frontia/api/FrontiaPush}} */
    if (a == null) {
      try {
        if (a == null) {
          FrontiaPush frontiaPush2 = new FrontiaPush();
          this(paramContext);
          a = frontiaPush2;
        } 
        /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/baidu/frontia/api/FrontiaPush}} */
        FrontiaPush frontiaPush1 = a;
      } finally {}
      return (FrontiaPush)paramContext;
    } 
    FrontiaPush frontiaPush = a;
  }
  
  FrontiaPushImpl a() {
    return this.b;
  }
  
  public void deleteTags(List<String> paramList) {
    this.b.deleteTags(paramList);
  }
  
  public void describeMessage(String paramString, FrontiaPushListener.DescribeMessageListener paramDescribeMessageListener) {
    b b = new b(this, paramDescribeMessageListener);
    this.b.describeMessage(paramString, b.a());
  }
  
  public void disableLbs() {
    this.b.disableLbs();
  }
  
  public void enableLbs() {
    this.b.enableLbs();
  }
  
  public void init(String paramString) {
    this.b.init(paramString);
  }
  
  public boolean isPushWorking() {
    return PushManager.isPushEnabled(this.c);
  }
  
  public void listMessage(FrontiaQuery paramFrontiaQuery, FrontiaPushListener.ListMessageListener paramListMessageListener) {
    c c = new c(this, paramListMessageListener);
    this.b.listMessage(paramFrontiaQuery.toJSONObject(), c.a());
  }
  
  public void listTags() {
    this.b.listTags();
  }
  
  public void pushMessage(FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramMessageContent.a(), d.a());
  }
  
  public void pushMessage(FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramTrigger.a(), paramMessageContent.a(), d.a());
  }
  
  public void pushMessage(String paramString, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramString, paramMessageContent.a(), d.a());
  }
  
  public void pushMessage(String paramString, FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramString, paramTrigger.a(), paramMessageContent.a(), d.a());
  }
  
  public void pushMessage(String paramString1, String paramString2, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramString1, paramString2, paramMessageContent.a(), d.a());
  }
  
  public void pushMessage(String paramString1, String paramString2, FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.PushMessageListener paramPushMessageListener) {
    d d = new d(this, paramPushMessageListener);
    this.b.pushMessage(paramString1, paramString2, paramTrigger.a(), paramMessageContent.a(), d.a());
  }
  
  public void removeMessage(String paramString, FrontiaPushListener.CommonMessageListener paramCommonMessageListener) {
    a a = new a(this, paramCommonMessageListener);
    this.b.removeMessage(paramString, a.a());
  }
  
  public void replaceMessage(String paramString, FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.CommonMessageListener paramCommonMessageListener) {
    a a = new a(this, paramCommonMessageListener);
    this.b.replaceMessage(paramString, paramTrigger.a(), paramMessageContent.a(), a.a());
  }
  
  public void replaceMessage(String paramString1, String paramString2, FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.CommonMessageListener paramCommonMessageListener) {
    a a = new a(this, paramCommonMessageListener);
    this.b.replaceMessage(paramString1, paramString2, paramTrigger.a(), paramMessageContent.a(), a.a());
  }
  
  public void replaceMessage(String paramString1, String paramString2, String paramString3, FrontiaPushUtil.Trigger paramTrigger, FrontiaPushUtil.MessageContent paramMessageContent, FrontiaPushListener.CommonMessageListener paramCommonMessageListener) {
    a a = new a(this, paramCommonMessageListener);
    this.b.replaceMessage(paramString1, paramString2, paramString3, paramTrigger.a(), paramMessageContent.a(), a.a());
  }
  
  public void resume() {
    PushManager.resumeWork(this.c);
  }
  
  public void setDebugModeEnabled(boolean paramBoolean) {
    PushSettings.enableDebugMode(this.c, paramBoolean);
  }
  
  public void setNotificationBuilder(int paramInt, FrontiaPushUtil.a parama) {
    if (parama != null)
      PushManager.setNotificationBuilder(this.c, paramInt, parama.a()); 
  }
  
  public void setTags(List<String> paramList) {
    this.b.setTags(paramList);
  }
  
  public void start() {
    this.b.start();
  }
  
  public void start(String paramString) {
    this.b.start(paramString);
  }
  
  public void stop() {
    PushManager.stopWork(this.c);
    StatUtils.insertBehavior(this.c, "010702", 0, "", "", System.currentTimeMillis());
  }
  
  class a {
    FrontiaPushListenerImpl.CommonMessageListenerImpl a = new FrontiaPushListenerImpl.CommonMessageListenerImpl(this) {
        public void onFailure(int param2Int, String param2String) {
          if (FrontiaPush.a.a(this.a) != null)
            FrontiaPush.a.a(this.a).onFailure(param2Int, param2String); 
        }
        
        public void onSuccess() {
          if (FrontiaPush.a.a(this.a) != null)
            FrontiaPush.a.a(this.a).onSuccess(); 
        }
      };
    
    private FrontiaPushListener.CommonMessageListener c;
    
    a(FrontiaPush this$0, FrontiaPushListener.CommonMessageListener param1CommonMessageListener) {
      this.c = param1CommonMessageListener;
    }
    
    FrontiaPushListenerImpl.CommonMessageListenerImpl a() {
      return this.a;
    }
  }
  
  class null implements FrontiaPushListenerImpl.CommonMessageListenerImpl {
    null(FrontiaPush this$0) {}
    
    public void onFailure(int param1Int, String param1String) {
      if (FrontiaPush.a.a(this.a) != null)
        FrontiaPush.a.a(this.a).onFailure(param1Int, param1String); 
    }
    
    public void onSuccess() {
      if (FrontiaPush.a.a(this.a) != null)
        FrontiaPush.a.a(this.a).onSuccess(); 
    }
  }
  
  class b {
    FrontiaPushListenerImpl.DescribeMessageListenerImpl a = new FrontiaPushListenerImpl.DescribeMessageListenerImpl(this) {
        public void onFailure(int param2Int, String param2String) {
          if (FrontiaPush.b.a(this.a) != null)
            FrontiaPush.b.a(this.a).onFailure(param2Int, param2String); 
        }
        
        public void onSuccess(FrontiaPushListenerImpl.DescribeMessageResult param2DescribeMessageResult) {
          if (FrontiaPush.b.a(this.a) != null)
            FrontiaPush.b.a(this.a).onSuccess(new FrontiaPushListener.DescribeMessageResult(param2DescribeMessageResult)); 
        }
      };
    
    private FrontiaPushListener.DescribeMessageListener c;
    
    b(FrontiaPush this$0, FrontiaPushListener.DescribeMessageListener param1DescribeMessageListener) {
      this.c = param1DescribeMessageListener;
    }
    
    FrontiaPushListenerImpl.DescribeMessageListenerImpl a() {
      return this.a;
    }
  }
  
  class null implements FrontiaPushListenerImpl.DescribeMessageListenerImpl {
    null(FrontiaPush this$0) {}
    
    public void onFailure(int param1Int, String param1String) {
      if (FrontiaPush.b.a(this.a) != null)
        FrontiaPush.b.a(this.a).onFailure(param1Int, param1String); 
    }
    
    public void onSuccess(FrontiaPushListenerImpl.DescribeMessageResult param1DescribeMessageResult) {
      if (FrontiaPush.b.a(this.a) != null)
        FrontiaPush.b.a(this.a).onSuccess(new FrontiaPushListener.DescribeMessageResult(param1DescribeMessageResult)); 
    }
  }
  
  class c {
    FrontiaPushListenerImpl.ListMessageListenerImpl a = new FrontiaPushListenerImpl.ListMessageListenerImpl(this) {
        public void onFailure(int param2Int, String param2String) {
          if (FrontiaPush.c.a(this.a) != null)
            FrontiaPush.c.a(this.a).onFailure(param2Int, param2String); 
        }
        
        public void onSuccess(List<FrontiaPushListenerImpl.DescribeMessageResult> param2List) {
          if (FrontiaPush.c.a(this.a) != null) {
            ArrayList<FrontiaPushListener.DescribeMessageResult> arrayList = new ArrayList();
            for (byte b = 0; b < param2List.size(); b++)
              arrayList.add(new FrontiaPushListener.DescribeMessageResult(param2List.get(b))); 
            FrontiaPush.c.a(this.a).onSuccess(arrayList);
          } 
        }
      };
    
    private FrontiaPushListener.ListMessageListener c;
    
    c(FrontiaPush this$0, FrontiaPushListener.ListMessageListener param1ListMessageListener) {
      this.c = param1ListMessageListener;
    }
    
    FrontiaPushListenerImpl.ListMessageListenerImpl a() {
      return this.a;
    }
  }
  
  class null implements FrontiaPushListenerImpl.ListMessageListenerImpl {
    null(FrontiaPush this$0) {}
    
    public void onFailure(int param1Int, String param1String) {
      if (FrontiaPush.c.a(this.a) != null)
        FrontiaPush.c.a(this.a).onFailure(param1Int, param1String); 
    }
    
    public void onSuccess(List<FrontiaPushListenerImpl.DescribeMessageResult> param1List) {
      if (FrontiaPush.c.a(this.a) != null) {
        ArrayList<FrontiaPushListener.DescribeMessageResult> arrayList = new ArrayList();
        for (byte b = 0; b < param1List.size(); b++)
          arrayList.add(new FrontiaPushListener.DescribeMessageResult(param1List.get(b))); 
        FrontiaPush.c.a(this.a).onSuccess(arrayList);
      } 
    }
  }
  
  class d {
    FrontiaPushListenerImpl.PushMessageListenerImpl a = new FrontiaPushListenerImpl.PushMessageListenerImpl(this) {
        public void onFailure(int param2Int, String param2String) {
          if (FrontiaPush.d.a(this.a) != null)
            FrontiaPush.d.a(this.a).onFailure(param2Int, param2String); 
        }
        
        public void onSuccess(String param2String) {
          if (FrontiaPush.d.a(this.a) != null)
            FrontiaPush.d.a(this.a).onSuccess(param2String); 
        }
      };
    
    private FrontiaPushListener.PushMessageListener c;
    
    d(FrontiaPush this$0, FrontiaPushListener.PushMessageListener param1PushMessageListener) {
      this.c = param1PushMessageListener;
    }
    
    FrontiaPushListenerImpl.PushMessageListenerImpl a() {
      return this.a;
    }
  }
  
  class null implements FrontiaPushListenerImpl.PushMessageListenerImpl {
    null(FrontiaPush this$0) {}
    
    public void onFailure(int param1Int, String param1String) {
      if (FrontiaPush.d.a(this.a) != null)
        FrontiaPush.d.a(this.a).onFailure(param1Int, param1String); 
    }
    
    public void onSuccess(String param1String) {
      if (FrontiaPush.d.a(this.a) != null)
        FrontiaPush.d.a(this.a).onSuccess(param1String); 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/api/FrontiaPush.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */