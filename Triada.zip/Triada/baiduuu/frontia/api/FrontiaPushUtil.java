package com.baidu.frontia.api;

import android.net.Uri;
import com.baidu.android.pushservice.internal.BasicPushNotificationBuilder;
import com.baidu.android.pushservice.internal.CustomPushNotificationBuilder;
import com.baidu.android.pushservice.internal.PushNotificationBuilder;
import com.baidu.frontia.module.push.FrontiaPushUtilImpl;
import org.json.JSONObject;

public class FrontiaPushUtil {
  public static class AndroidContent {
    private FrontiaPushUtilImpl.AndroidContentImpl a = new FrontiaPushUtilImpl.AndroidContentImpl();
    
    public AndroidContent() {}
    
    AndroidContent(FrontiaPushUtilImpl.AndroidContentImpl param1AndroidContentImpl) {}
    
    FrontiaPushUtilImpl.AndroidContentImpl a() {
      return this.a;
    }
    
    public int getBuilderId() {
      return this.a.getBuilderId();
    }
    
    public FrontiaPushUtil.DefaultNotificationStyle getNotificationStyle() {
      return new FrontiaPushUtil.DefaultNotificationStyle(this.a.getNotificationStyle());
    }
    
    public String getPKGContent() {
      return this.a.getPKGContent();
    }
    
    public String getUrl() {
      return this.a.getUrl();
    }
    
    public void setBuilderId(int param1Int) {
      this.a.setBuilderId(param1Int);
    }
    
    public void setNotificationStyle(FrontiaPushUtil.DefaultNotificationStyle param1DefaultNotificationStyle) {
      this.a.setNotificationStyle(param1DefaultNotificationStyle.a());
    }
    
    public void setPKGContent(String param1String) {
      this.a.setPKGContent(param1String);
    }
    
    public void setUrl(String param1String) {
      this.a.setUrl(param1String);
    }
  }
  
  public static class DefaultNotificationStyle {
    private FrontiaPushUtilImpl.DefaultNotificationStyleImpl a = new FrontiaPushUtilImpl.DefaultNotificationStyleImpl();
    
    public DefaultNotificationStyle() {}
    
    DefaultNotificationStyle(FrontiaPushUtilImpl.DefaultNotificationStyleImpl param1DefaultNotificationStyleImpl) {}
    
    FrontiaPushUtilImpl.DefaultNotificationStyleImpl a() {
      return this.a;
    }
    
    public void disableAlert() {
      this.a.disableAlert();
    }
    
    public void disableDismissible() {
      this.a.disableDismissible();
    }
    
    public void disableVibration() {
      this.a.disableVibration();
    }
    
    public void enableAlert() {
      this.a.enableAlert();
    }
    
    public void enableDismissible() {
      this.a.enableDismissible();
    }
    
    public void enableVibration() {
      this.a.enableVibration();
    }
    
    public boolean isAlertEnabled() {
      return this.a.isAlertEnabled();
    }
    
    public boolean isDismissible() {
      return this.a.isDismissible();
    }
    
    public boolean isVibrationEnabled() {
      return this.a.isVibrationEnabled();
    }
  }
  
  public enum DeployStatus {
    DEVELOPE, PRODUCTION;
  }
  
  public static class FrontiaPushBasicNotificationBuilder extends a {
    private BasicPushNotificationBuilder a = new BasicPushNotificationBuilder();
    
    PushNotificationBuilder a() {
      return (PushNotificationBuilder)this.a;
    }
    
    public void setNotificationDefaults(int param1Int) {
      this.a.setNotificationDefaults(param1Int);
    }
    
    public void setNotificationFlags(int param1Int) {
      this.a.setNotificationFlags(param1Int);
    }
    
    public void setNotificationSound(Uri param1Uri) {
      this.a.setNotificationSound(param1Uri);
    }
    
    public void setNotificationText(String param1String) {
      this.a.setNotificationText(param1String);
    }
    
    public void setNotificationTitle(String param1String) {
      this.a.setNotificationTitle(param1String);
    }
    
    public void setNotificationVibrate(long[] param1ArrayOflong) {
      this.a.setNotificationVibrate(param1ArrayOflong);
    }
    
    public void setStatusbarIcon(int param1Int) {
      this.a.setStatusbarIcon(param1Int);
    }
  }
  
  public static class FrontiaPushCustomNotificationBuilder extends a {
    private CustomPushNotificationBuilder a = null;
    
    public FrontiaPushCustomNotificationBuilder(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a = new CustomPushNotificationBuilder(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    PushNotificationBuilder a() {
      return (PushNotificationBuilder)this.a;
    }
    
    public void setNotificationDefaults(int param1Int) {
      this.a.setNotificationDefaults(param1Int);
    }
    
    public void setNotificationFlags(int param1Int) {
      this.a.setNotificationFlags(param1Int);
    }
    
    public void setNotificationSound(Uri param1Uri) {
      this.a.setNotificationSound(param1Uri);
    }
    
    public void setNotificationText(String param1String) {
      this.a.setNotificationText(param1String);
    }
    
    public void setNotificationTitle(String param1String) {
      this.a.setNotificationTitle(param1String);
    }
    
    public void setNotificationVibrate(long[] param1ArrayOflong) {
      this.a.setNotificationVibrate(param1ArrayOflong);
    }
    
    public void setStatusbarIcon(int param1Int) {
      this.a.setStatusbarIcon(param1Int);
    }
  }
  
  public static class IOSContent {
    private FrontiaPushUtilImpl.IOSContentImpl a = new FrontiaPushUtilImpl.IOSContentImpl();
    
    public IOSContent() {}
    
    IOSContent(FrontiaPushUtilImpl.IOSContentImpl param1IOSContentImpl) {}
    
    FrontiaPushUtilImpl.IOSContentImpl a() {
      return this.a;
    }
    
    public String getAlertMsg() {
      return this.a.getAlertMsg();
    }
    
    public int getBadge() {
      return this.a.getBadge();
    }
    
    public String getSoundFile() {
      return this.a.getSoundFile();
    }
    
    public void setAlertMsg(String param1String) {
      this.a.setAlertMsg(param1String);
    }
    
    public void setBadge(int param1Int) {
      this.a.setBadge(param1Int);
    }
    
    public void setSoundFile(String param1String) {
      this.a.setSoundFile(param1String);
    }
  }
  
  public static class MessageContent {
    private FrontiaPushUtilImpl.MessageContentImpl a;
    
    private int b;
    
    MessageContent(FrontiaPushUtilImpl.MessageContentImpl param1MessageContentImpl) {
      this.a = param1MessageContentImpl;
    }
    
    public MessageContent(String param1String, FrontiaPushUtil.DeployStatus param1DeployStatus) {
      if (param1DeployStatus == FrontiaPushUtil.DeployStatus.DEVELOPE) {
        this.b = 1;
      } else {
        this.b = 2;
      } 
      this.a = new FrontiaPushUtilImpl.MessageContentImpl(param1String, this.b);
    }
    
    public static MessageContent createNotificationMessage(String param1String1, String param1String2, String param1String3) {
      return new MessageContent(FrontiaPushUtilImpl.MessageContentImpl.createNotificationMessage(param1String1, param1String2, param1String3));
    }
    
    public static MessageContent createStringMessage(String param1String1, String param1String2) {
      return new MessageContent(FrontiaPushUtilImpl.MessageContentImpl.createStringMessage(param1String1, param1String2));
    }
    
    FrontiaPushUtilImpl.MessageContentImpl a() {
      return this.a;
    }
    
    public FrontiaPushUtil.DeployStatus getDeployStatus() {
      return (this.a.getDeployStatus() == 1) ? FrontiaPushUtil.DeployStatus.DEVELOPE : FrontiaPushUtil.DeployStatus.PRODUCTION;
    }
    
    public String getMessage() {
      return this.a.getMesssage();
    }
    
    public String getMessageKeys() {
      return this.a.getMessageKeys();
    }
    
    public FrontiaPushUtil.NotificationContent getNotification() {
      return new FrontiaPushUtil.NotificationContent(this.a.getNotificationContent());
    }
    
    public void setMessage(String param1String) {
      this.a.setMessage(param1String);
    }
    
    public void setNotification(FrontiaPushUtil.NotificationContent param1NotificationContent) {
      this.a.setNotification(param1NotificationContent.a());
    }
  }
  
  public static class NotificationContent {
    private FrontiaPushUtilImpl.NotificationContentImpl a;
    
    NotificationContent(FrontiaPushUtilImpl.NotificationContentImpl param1NotificationContentImpl) {
      this.a = param1NotificationContentImpl;
    }
    
    public NotificationContent(String param1String1, String param1String2) {
      this.a = new FrontiaPushUtilImpl.NotificationContentImpl(param1String1, param1String2);
    }
    
    FrontiaPushUtilImpl.NotificationContentImpl a() {
      return this.a;
    }
    
    public void addAndroidContent(FrontiaPushUtil.AndroidContent param1AndroidContent) {
      this.a.addAndroidContent(param1AndroidContent.a());
    }
    
    public void addCustomContent(String param1String1, String param1String2) {
      this.a.addCustomContent(param1String1, param1String2);
    }
    
    public void addIOSContent(FrontiaPushUtil.IOSContent param1IOSContent) {
      this.a.addIOSContent(param1IOSContent.a());
    }
    
    public FrontiaPushUtil.AndroidContent getAndroidContent() {
      return new FrontiaPushUtil.AndroidContent(this.a.getAndroidContent());
    }
    
    public JSONObject getCustomContent() {
      return this.a.getCustomContent();
    }
    
    public String getDescription() {
      return this.a.getDescription();
    }
    
    public FrontiaPushUtil.IOSContent getIOSContent() {
      return new FrontiaPushUtil.IOSContent(this.a.getIOSContent());
    }
    
    public String getTitle() {
      return this.a.getTitle();
    }
  }
  
  public static class Trigger {
    private FrontiaPushUtilImpl.TriggerImpl a = new FrontiaPushUtilImpl.TriggerImpl();
    
    public Trigger() {}
    
    Trigger(FrontiaPushUtilImpl.TriggerImpl param1TriggerImpl) {}
    
    FrontiaPushUtilImpl.TriggerImpl a() {
      return this.a;
    }
    
    public String getCrontab() {
      return this.a.getCrontab();
    }
    
    public String getTime() {
      return this.a.getTime();
    }
    
    public void setCrontab(String param1String) {
      this.a.setCrontab(param1String);
    }
    
    public void setTime(String param1String) {
      this.a.setTime(param1String);
    }
  }
  
  static abstract class a {
    abstract PushNotificationBuilder a();
    
    public abstract void setNotificationDefaults(int param1Int);
    
    public abstract void setNotificationFlags(int param1Int);
    
    public abstract void setNotificationSound(Uri param1Uri);
    
    public abstract void setNotificationText(String param1String);
    
    public abstract void setNotificationTitle(String param1String);
    
    public abstract void setNotificationVibrate(long[] param1ArrayOflong);
    
    public abstract void setStatusbarIcon(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/api/FrontiaPushUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */