package com.baidu.frontia.api;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class FrontiaPushMessageReceiver extends BroadcastReceiver {
  public static final String TAG = FrontiaPushMessageReceiver.class.getSimpleName();
  
  public abstract void onBind(Context paramContext, int paramInt, String paramString1, String paramString2, String paramString3, String paramString4);
  
  public abstract void onDelTags(Context paramContext, int paramInt, List<String> paramList1, List<String> paramList2, String paramString);
  
  public abstract void onListTags(Context paramContext, int paramInt, List<String> paramList, String paramString);
  
  public abstract void onMessage(Context paramContext, String paramString1, String paramString2);
  
  public abstract void onNotificationClicked(Context paramContext, String paramString1, String paramString2, String paramString3);
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    String str;
    boolean bool = false;
    byte b = 0;
    if (paramIntent.getAction().equals("com.baidu.android.pushservice.action.MESSAGE")) {
      if (paramIntent.getExtras() != null)
        onMessage(paramContext, paramIntent.getExtras().getString("message_string"), paramIntent.getStringExtra("extra_extra_custom_content")); 
      return;
    } 
    if (paramIntent.getAction().equals("com.baidu.android.pushservice.action.RECEIVE")) {
      JSONArray jSONArray1;
      ArrayList<String> arrayList;
      JSONObject jSONObject;
      JSONArray jSONArray2;
      String str1 = paramIntent.getStringExtra("method");
      int i = paramIntent.getIntExtra("error_msg", 0);
      String str2 = "";
      if (paramIntent.getByteArrayExtra("content") != null)
        str2 = new String(paramIntent.getByteArrayExtra("content")); 
      try {
        if (str1.equals("method_bind")) {
          if (!TextUtils.isEmpty(str2)) {
            JSONObject jSONObject1 = new JSONObject();
            this(str2);
            str = jSONObject1.getString("request_id");
            jSONObject = jSONObject1.getJSONObject("response_params");
            String str3 = jSONObject.getString("appid");
            str1 = jSONObject.getString("channel_id");
            onBind(paramContext, i, str3, jSONObject.getString("user_id"), str1, str);
          } 
          return;
        } 
      } catch (JSONException jSONException) {
        jSONException.printStackTrace();
        return;
      } 
      if (str1.equals("method_unbind")) {
        JSONObject jSONObject1 = new JSONObject();
        this((String)jSONObject);
        onUnbind((Context)jSONException, i, jSONObject1.getString("request_id"));
        return;
      } 
      if (str1.equals("method_set_tags")) {
        JSONObject jSONObject1 = new JSONObject();
        this((String)jSONObject);
        str = jSONObject1.getString("request_id");
        jSONArray1 = jSONObject1.getJSONObject("response_params").getJSONArray("details");
        ArrayList<String> arrayList1 = new ArrayList();
        this();
        ArrayList<String> arrayList2 = new ArrayList();
        this();
        while (b < jSONArray1.length()) {
          jSONObject = jSONArray1.getJSONObject(b);
          String str3 = jSONObject.getString("tag");
          if (jSONObject.getInt("result") == 0) {
            arrayList1.add(str3);
          } else {
            arrayList2.add(str3);
          } 
          b++;
        } 
        onSetTags((Context)jSONException, i, arrayList1, arrayList2, str);
        return;
      } 
      if (jSONArray1.equals("method_del_tags")) {
        JSONObject jSONObject1 = new JSONObject();
        this((String)jSONObject);
        str = jSONObject1.getString("request_id");
        jSONArray2 = jSONObject1.getJSONObject("response_params").getJSONArray("details");
        ArrayList<String> arrayList1 = new ArrayList();
        this();
        arrayList = new ArrayList();
        this();
        for (b = bool; b < jSONArray2.length(); b++) {
          JSONObject jSONObject2 = jSONArray2.getJSONObject(b);
          String str3 = jSONObject2.getString("tag");
          if (jSONObject2.getInt("result") == 0) {
            arrayList1.add(str3);
          } else {
            arrayList.add(str3);
          } 
        } 
        onDelTags((Context)jSONException, i, arrayList1, arrayList, str);
        return;
      } 
      if (arrayList.equals("method_listtags")) {
        JSONObject jSONObject1 = new JSONObject();
        this((String)jSONArray2);
        String str3 = jSONObject1.getString("request_id");
        onListTags((Context)jSONException, i, str.getStringArrayListExtra("tags_list"), str3);
      } 
      return;
    } 
    if (str.getAction().equals("com.baidu.android.pushservice.action.notification.CLICK"))
      onNotificationClicked((Context)jSONException, str.getStringExtra("notification_title"), str.getStringExtra("notification_content"), str.getStringExtra("extra_extra_custom_content")); 
  }
  
  public abstract void onSetTags(Context paramContext, int paramInt, List<String> paramList1, List<String> paramList2, String paramString);
  
  public abstract void onUnbind(Context paramContext, int paramInt, String paramString);
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/api/FrontiaPushMessageReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */