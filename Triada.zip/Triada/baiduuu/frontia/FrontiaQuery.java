package com.baidu.frontia;

import com.baidu.frontia.base.impl.FrontiaQueryImpl;
import org.json.JSONObject;

public class FrontiaQuery {
  private FrontiaQueryImpl a = new FrontiaQueryImpl();
  
  void a(FrontiaQueryImpl paramFrontiaQueryImpl) {
    this.a = paramFrontiaQueryImpl;
  }
  
  public FrontiaQuery addSort(String paramString, SortOrder paramSortOrder) {
    if (paramSortOrder == SortOrder.ASC) {
      this.a.addSort(paramString, FrontiaQueryImpl.SortOrder.ASC);
      return this;
    } 
    this.a.addSort(paramString, FrontiaQueryImpl.SortOrder.DESC);
    return this;
  }
  
  public FrontiaQuery all(String paramString, Object[] paramArrayOfObject) {
    this.a = this.a.all(paramString, paramArrayOfObject);
    return this;
  }
  
  public FrontiaQuery and(FrontiaQuery paramFrontiaQuery) {
    this.a = this.a.and(paramFrontiaQuery.a);
    return this;
  }
  
  public FrontiaQuery endsWith(String paramString1, String paramString2) {
    this.a.endsWith(paramString1, paramString2);
    return this;
  }
  
  public FrontiaQuery equals(String paramString, Object paramObject) {
    this.a = this.a.equals(paramString, paramObject);
    return this;
  }
  
  public int getLimit() {
    return this.a.getLimit();
  }
  
  public int getSkip() {
    return this.a.getSkip();
  }
  
  public JSONObject getSort() {
    return this.a.getSort();
  }
  
  public FrontiaQuery greaterThan(String paramString, Object paramObject) {
    this.a = this.a.greaterThan(paramString, paramObject);
    return this;
  }
  
  public FrontiaQuery greaterThanEqualTo(String paramString, Object paramObject) {
    this.a = this.a.greaterThanEqualTo(paramString, paramObject);
    return this;
  }
  
  public FrontiaQuery in(String paramString, Object[] paramArrayOfObject) {
    this.a = this.a.in(paramString, paramArrayOfObject);
    return this;
  }
  
  public FrontiaQuery lessThan(String paramString, Object paramObject) {
    this.a = this.a.lessThan(paramString, paramObject);
    return this;
  }
  
  public FrontiaQuery lessThanEqualTo(String paramString, Object paramObject) {
    this.a = this.a.lessThanEqualTo(paramString, paramObject);
    return this;
  }
  
  public FrontiaQuery not() {
    this.a.not();
    return this;
  }
  
  public FrontiaQuery notEqual(String paramString, Object paramObject) {
    this.a.notEqual(paramString, paramObject);
    return this;
  }
  
  public FrontiaQuery notIn(String paramString, Object[] paramArrayOfObject) {
    this.a = this.a.notIn(paramString, paramArrayOfObject);
    return this;
  }
  
  public FrontiaQuery or(FrontiaQuery paramFrontiaQuery) {
    this.a = this.a.or(paramFrontiaQuery.a);
    return this;
  }
  
  public FrontiaQuery regEx(String paramString1, String paramString2) {
    this.a = this.a.regEx(paramString1, paramString2);
    return this;
  }
  
  public FrontiaQuery setLimit(int paramInt) {
    this.a.setLimit(paramInt);
    return this;
  }
  
  public FrontiaQuery setSkip(int paramInt) {
    this.a.setSkip(paramInt);
    return this;
  }
  
  public FrontiaQuery size(String paramString, int paramInt) {
    this.a.size(paramString, paramInt);
    return this;
  }
  
  public FrontiaQuery startsWith(String paramString1, String paramString2) {
    this.a = this.a.startsWith(paramString1, paramString2);
    return this;
  }
  
  public JSONObject toJSONObject() {
    return this.a.toJSONObject();
  }
  
  public enum SortOrder {
    ASC, DESC;
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/FrontiaQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */