package com.baidu.frontia.framework;

public interface IModule {
  void init(String paramString);
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/framework/IModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */