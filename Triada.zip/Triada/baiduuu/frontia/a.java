package com.baidu.frontia;

import android.content.Context;
import com.baidu.frontia.framework.IModule;
import java.lang.reflect.Method;

class a {
  public static void a(Context paramContext, String paramString) {
    try {
      String[] arrayOfString = a();
      if (arrayOfString != null)
        for (byte b = 0; b < arrayOfString.length; b++) {
          String str = arrayOfString[b];
          if (str != null && str.length() > 0) {
            Class<?> clazz = Class.forName(str);
            if (clazz != null) {
              Method method = clazz.getMethod("newInstance", new Class[] { Context.class });
              if (method != null) {
                IModule iModule = (IModule)method.invoke(null, new Object[] { paramContext });
                if (iModule != null)
                  iModule.init(paramString); 
              } 
            } 
          } 
        }  
    } catch (Exception exception) {}
  }
  
  public static String[] a() {
    return new String[] { "com.baidu.frontia.api.FrontiaPush" };
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */