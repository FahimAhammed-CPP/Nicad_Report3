package com.baidu.frontia;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Process;
import android.text.TextUtils;
import com.baidu.android.silentupdate.SilentManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.json.JSONException;
import org.json.JSONObject;

public class FrontiaApplication extends Application {
  private static final String a = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYAFbG0oYmKgh6o7BhZIHf1njBpZXqyWBnYz2ip3Wp+s97OeA/pTe8xebuGJHwq4xbsGQrJWepIbUVrdjm6JRmdvuJhar7/hC/UNnUkJgYdYl10OZKlvcFFgK3V7XGBPplXldDnhbgscna3JG8U3025WSxZCP5vy/8cfxsEoVx5QIDAQAB";
  
  private static final String b = "f5de4bda49c00a19757289cd02a60f5d";
  
  private static final String c = "com.baidu.android.pushservice.PushService";
  
  private static boolean a(Context paramContext) {
    try {
      ActivityManager activityManager = (ActivityManager)paramContext.getSystemService("activity");
      int i = Process.myPid();
      for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : activityManager.getRunningAppProcesses()) {
        if (runningAppProcessInfo.pid == i) {
          String str = c(paramContext);
          if (runningAppProcessInfo.processName.equalsIgnoreCase(str) && !b(paramContext.getApplicationContext()))
            Process.killProcess(i); 
        } 
      } 
    } catch (Exception exception) {
      boolean bool = false;
      exception.printStackTrace();
      return bool;
    } 
    return true;
  }
  
  private static boolean b(Context paramContext) {
    boolean bool2;
    boolean bool1 = false;
    try {
      SilentManager.setKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYAFbG0oYmKgh6o7BhZIHf1njBpZXqyWBnYz2ip3Wp+s97OeA/pTe8xebuGJHwq4xbsGQrJWepIbUVrdjm6JRmdvuJhar7/hC/UNnUkJgYdYl10OZKlvcFFgK3V7XGBPplXldDnhbgscna3JG8U3025WSxZCP5vy/8cfxsEoVx5QIDAQAB");
      SilentManager.enableRSA(true);
      bool2 = SilentManager.loadLib(paramContext.getApplicationContext(), "frontia_plugin", "plugin-deploy.jar");
    } catch (Exception exception) {
      exception.printStackTrace();
      bool2 = bool1;
    } 
    return bool2;
  }
  
  private static String c(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   4: astore_1
    //   5: aload_1
    //   6: aload_0
    //   7: invokevirtual getPackageName : ()Ljava/lang/String;
    //   10: iconst_4
    //   11: invokevirtual getPackageInfo : (Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   14: getfield services : [Landroid/content/pm/ServiceInfo;
    //   17: astore_0
    //   18: aload_0
    //   19: ifnonnull -> 36
    //   22: aconst_null
    //   23: astore_0
    //   24: aload_0
    //   25: areturn
    //   26: astore_0
    //   27: aload_0
    //   28: invokevirtual printStackTrace : ()V
    //   31: aconst_null
    //   32: astore_0
    //   33: goto -> 18
    //   36: iconst_0
    //   37: istore_2
    //   38: iload_2
    //   39: aload_0
    //   40: arraylength
    //   41: if_icmpge -> 74
    //   44: ldc 'com.baidu.android.pushservice.PushService'
    //   46: aload_0
    //   47: iload_2
    //   48: aaload
    //   49: getfield name : Ljava/lang/String;
    //   52: invokevirtual equals : (Ljava/lang/Object;)Z
    //   55: ifeq -> 68
    //   58: aload_0
    //   59: iload_2
    //   60: aaload
    //   61: getfield processName : Ljava/lang/String;
    //   64: astore_0
    //   65: goto -> 24
    //   68: iinc #2, 1
    //   71: goto -> 38
    //   74: aconst_null
    //   75: astore_0
    //   76: goto -> 24
    // Exception table:
    //   from	to	target	type
    //   5	18	26	android/content/pm/PackageManager$NameNotFoundException
  }
  
  private static boolean d(Context paramContext) {
    boolean bool2;
    boolean bool1 = false;
    try {
      InputStream inputStream = paramContext.getAssets().open("frontia_plugin/plugin-deploy.key");
      InputStreamReader inputStreamReader = new InputStreamReader();
      this(inputStream);
      BufferedReader bufferedReader = new BufferedReader();
      this(inputStreamReader);
      String str = "";
      while (true) {
        String str2 = bufferedReader.readLine();
        if (str2 != null) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          str = stringBuilder.append(str).append(str2).append("\r\n").toString();
          continue;
        } 
        String str1 = SilentManager.decrypt("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCYAFbG0oYmKgh6o7BhZIHf1njBpZXqyWBnYz2ip3Wp+s97OeA/pTe8xebuGJHwq4xbsGQrJWepIbUVrdjm6JRmdvuJhar7/hC/UNnUkJgYdYl10OZKlvcFFgK3V7XGBPplXldDnhbgscna3JG8U3025WSxZCP5vy/8cfxsEoVx5QIDAQAB", str);
        bool2 = bool1;
        if (!TextUtils.isEmpty(str1)) {
          JSONObject jSONObject = new JSONObject();
          this(str1);
          bool2 = jSONObject.optString("flag", "null").equals("f5de4bda49c00a19757289cd02a60f5d");
        } 
        return bool2;
      } 
    } catch (IOException iOException) {
      iOException.printStackTrace();
      bool2 = bool1;
    } catch (JSONException jSONException) {
      jSONException.printStackTrace();
      bool2 = bool1;
    } catch (Exception exception) {
      exception.printStackTrace();
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public static void initFrontiaApplication(Context paramContext) {
    if (d(paramContext)) {
      if (!a(paramContext))
        b(paramContext); 
      return;
    } 
    b(paramContext);
  }
  
  public void onCreate() {
    super.onCreate();
    initFrontiaApplication(getApplicationContext());
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/baidu/frontia/FrontiaApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */