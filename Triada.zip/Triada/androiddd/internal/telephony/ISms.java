package com.android.internal.telephony;

import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.List;

public interface ISms extends IInterface {
  boolean copyMessageToIccEf(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws RemoteException;
  
  boolean disableCellBroadcast(int paramInt) throws RemoteException;
  
  boolean disableCellBroadcastRange(int paramInt1, int paramInt2) throws RemoteException;
  
  boolean enableCellBroadcast(int paramInt) throws RemoteException;
  
  boolean enableCellBroadcastRange(int paramInt1, int paramInt2) throws RemoteException;
  
  List<SmsRawData> getAllMessagesFromIccEf() throws RemoteException;
  
  void sendData(String paramString1, String paramString2, int paramInt, byte[] paramArrayOfbyte, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2) throws RemoteException;
  
  void sendMultipartText(String paramString1, String paramString2, List<String> paramList, List<PendingIntent> paramList1, List<PendingIntent> paramList2) throws RemoteException;
  
  void sendText(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2) throws RemoteException;
  
  boolean updateMessageOnIccEf(int paramInt1, int paramInt2, byte[] paramArrayOfbyte) throws RemoteException;
  
  public static abstract class Stub extends Binder implements ISms {
    private static final String DESCRIPTOR = "com.android.internal.telephony.ISms";
    
    static final int TRANSACTION_copyMessageToIccEf = 3;
    
    static final int TRANSACTION_disableCellBroadcast = 8;
    
    static final int TRANSACTION_disableCellBroadcastRange = 10;
    
    static final int TRANSACTION_enableCellBroadcast = 7;
    
    static final int TRANSACTION_enableCellBroadcastRange = 9;
    
    static final int TRANSACTION_getAllMessagesFromIccEf = 1;
    
    static final int TRANSACTION_sendData = 4;
    
    static final int TRANSACTION_sendMultipartText = 6;
    
    static final int TRANSACTION_sendText = 5;
    
    static final int TRANSACTION_updateMessageOnIccEf = 2;
    
    public Stub() {
      attachInterface(this, "com.android.internal.telephony.ISms");
    }
    
    public static ISms asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.android.internal.telephony.ISms");
      return (iInterface != null && iInterface instanceof ISms) ? (ISms)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      List<SmsRawData> list;
      String str1;
      String str2;
      byte[] arrayOfByte;
      String str3;
      PendingIntent pendingIntent;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.android.internal.telephony.ISms");
          return true;
        case 1:
          param1Parcel1.enforceInterface("com.android.internal.telephony.ISms");
          list = getAllMessagesFromIccEf();
          param1Parcel2.writeNoException();
          param1Parcel2.writeTypedList(list);
          return true;
        case 2:
          list.enforceInterface("com.android.internal.telephony.ISms");
          null = updateMessageOnIccEf(list.readInt(), list.readInt(), list.createByteArray());
          param1Parcel2.writeNoException();
          if (null) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 3:
          list.enforceInterface("com.android.internal.telephony.ISms");
          null = copyMessageToIccEf(list.readInt(), list.createByteArray(), list.createByteArray());
          param1Parcel2.writeNoException();
          if (null) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 4:
          list.enforceInterface("com.android.internal.telephony.ISms");
          str1 = list.readString();
          str2 = list.readString();
          param1Int1 = list.readInt();
          arrayOfByte = list.createByteArray();
          if (list.readInt() != 0) {
            pendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel((Parcel)list);
          } else {
            pendingIntent = null;
          } 
          if (list.readInt() != 0) {
            PendingIntent pendingIntent1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel((Parcel)list);
          } else {
            list = null;
          } 
          sendData(str1, str2, param1Int1, arrayOfByte, pendingIntent, (PendingIntent)list);
          param1Parcel2.writeNoException();
          return true;
        case 5:
          list.enforceInterface("com.android.internal.telephony.ISms");
          str2 = list.readString();
          str3 = list.readString();
          str1 = list.readString();
          if (list.readInt() != 0) {
            pendingIntent = (PendingIntent)PendingIntent.CREATOR.createFromParcel((Parcel)list);
          } else {
            pendingIntent = null;
          } 
          if (list.readInt() != 0) {
            PendingIntent pendingIntent1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel((Parcel)list);
          } else {
            list = null;
          } 
          sendText(str2, str3, str1, pendingIntent, (PendingIntent)list);
          param1Parcel2.writeNoException();
          return true;
        case 6:
          list.enforceInterface("com.android.internal.telephony.ISms");
          sendMultipartText(list.readString(), list.readString(), list.createStringArrayList(), list.createTypedArrayList(PendingIntent.CREATOR), list.createTypedArrayList(PendingIntent.CREATOR));
          param1Parcel2.writeNoException();
          return true;
        case 7:
          list.enforceInterface("com.android.internal.telephony.ISms");
          null = enableCellBroadcast(list.readInt());
          param1Parcel2.writeNoException();
          if (null) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 8:
          list.enforceInterface("com.android.internal.telephony.ISms");
          null = disableCellBroadcast(list.readInt());
          param1Parcel2.writeNoException();
          if (null) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 9:
          list.enforceInterface("com.android.internal.telephony.ISms");
          null = enableCellBroadcastRange(list.readInt(), list.readInt());
          param1Parcel2.writeNoException();
          if (null) {
            param1Int1 = 1;
          } else {
            param1Int1 = 0;
          } 
          param1Parcel2.writeInt(param1Int1);
          return true;
        case 10:
          break;
      } 
      list.enforceInterface("com.android.internal.telephony.ISms");
      null = disableCellBroadcastRange(list.readInt(), list.readInt());
      param1Parcel2.writeNoException();
      if (null) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      param1Parcel2.writeInt(param1Int1);
      return true;
    }
    
    private static class Proxy implements ISms {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public boolean copyMessageToIccEf(int param2Int, byte[] param2ArrayOfbyte1, byte[] param2ArrayOfbyte2) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int);
          parcel1.writeByteArray(param2ArrayOfbyte1);
          parcel1.writeByteArray(param2ArrayOfbyte2);
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableCellBroadcast(int param2Int) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int);
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean disableCellBroadcastRange(int param2Int1, int param2Int2) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          this.mRemote.transact(10, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int1 = parcel2.readInt();
          if (param2Int1 != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableCellBroadcast(int param2Int) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int);
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int = parcel2.readInt();
          if (param2Int != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean enableCellBroadcastRange(int param2Int1, int param2Int2) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          this.mRemote.transact(9, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int1 = parcel2.readInt();
          if (param2Int1 != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public List<SmsRawData> getAllMessagesFromIccEf() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.createTypedArrayList(SmsRawData.CREATOR);
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void sendData(String param2String1, String param2String2, int param2Int, byte[] param2ArrayOfbyte, PendingIntent param2PendingIntent1, PendingIntent param2PendingIntent2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeInt(param2Int);
          parcel1.writeByteArray(param2ArrayOfbyte);
          if (param2PendingIntent1 != null) {
            parcel1.writeInt(1);
            param2PendingIntent1.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2PendingIntent2 != null) {
            parcel1.writeInt(1);
            param2PendingIntent2.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void sendMultipartText(String param2String1, String param2String2, List<String> param2List, List<PendingIntent> param2List1, List<PendingIntent> param2List2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeStringList(param2List);
          parcel1.writeTypedList(param2List1);
          parcel1.writeTypedList(param2List2);
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public void sendText(String param2String1, String param2String2, String param2String3, PendingIntent param2PendingIntent1, PendingIntent param2PendingIntent2) throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeString(param2String1);
          parcel1.writeString(param2String2);
          parcel1.writeString(param2String3);
          if (param2PendingIntent1 != null) {
            parcel1.writeInt(1);
            param2PendingIntent1.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          if (param2PendingIntent2 != null) {
            parcel1.writeInt(1);
            param2PendingIntent2.writeToParcel(parcel1, 0);
          } else {
            parcel1.writeInt(0);
          } 
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public boolean updateMessageOnIccEf(int param2Int1, int param2Int2, byte[] param2ArrayOfbyte) throws RemoteException {
        boolean bool = false;
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
          parcel1.writeInt(param2Int1);
          parcel1.writeInt(param2Int2);
          parcel1.writeByteArray(param2ArrayOfbyte);
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          param2Int1 = parcel2.readInt();
          if (param2Int1 != 0)
            bool = true; 
          return bool;
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements ISms {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public boolean copyMessageToIccEf(int param1Int, byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int);
        parcel1.writeByteArray(param1ArrayOfbyte1);
        parcel1.writeByteArray(param1ArrayOfbyte2);
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableCellBroadcast(int param1Int) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int);
        this.mRemote.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean disableCellBroadcastRange(int param1Int1, int param1Int2) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        this.mRemote.transact(10, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int1 = parcel2.readInt();
        if (param1Int1 != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableCellBroadcast(int param1Int) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int);
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int = parcel2.readInt();
        if (param1Int != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean enableCellBroadcastRange(int param1Int1, int param1Int2) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        this.mRemote.transact(9, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int1 = parcel2.readInt();
        if (param1Int1 != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public List<SmsRawData> getAllMessagesFromIccEf() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.createTypedArrayList(SmsRawData.CREATOR);
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void sendData(String param1String1, String param1String2, int param1Int, byte[] param1ArrayOfbyte, PendingIntent param1PendingIntent1, PendingIntent param1PendingIntent2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeInt(param1Int);
        parcel1.writeByteArray(param1ArrayOfbyte);
        if (param1PendingIntent1 != null) {
          parcel1.writeInt(1);
          param1PendingIntent1.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1PendingIntent2 != null) {
          parcel1.writeInt(1);
          param1PendingIntent2.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void sendMultipartText(String param1String1, String param1String2, List<String> param1List, List<PendingIntent> param1List1, List<PendingIntent> param1List2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeStringList(param1List);
        parcel1.writeTypedList(param1List1);
        parcel1.writeTypedList(param1List2);
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public void sendText(String param1String1, String param1String2, String param1String3, PendingIntent param1PendingIntent1, PendingIntent param1PendingIntent2) throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeString(param1String1);
        parcel1.writeString(param1String2);
        parcel1.writeString(param1String3);
        if (param1PendingIntent1 != null) {
          parcel1.writeInt(1);
          param1PendingIntent1.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        if (param1PendingIntent2 != null) {
          parcel1.writeInt(1);
          param1PendingIntent2.writeToParcel(parcel1, 0);
        } else {
          parcel1.writeInt(0);
        } 
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public boolean updateMessageOnIccEf(int param1Int1, int param1Int2, byte[] param1ArrayOfbyte) throws RemoteException {
      boolean bool = false;
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.ISms");
        parcel1.writeInt(param1Int1);
        parcel1.writeInt(param1Int2);
        parcel1.writeByteArray(param1ArrayOfbyte);
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        param1Int1 = parcel2.readInt();
        if (param1Int1 != 0)
          bool = true; 
        return bool;
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/android/internal/telephony/ISms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */