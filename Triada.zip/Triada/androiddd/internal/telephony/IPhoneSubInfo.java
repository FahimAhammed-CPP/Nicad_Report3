package com.android.internal.telephony;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public interface IPhoneSubInfo extends IInterface {
  String getDeviceId() throws RemoteException;
  
  String getDeviceSvn() throws RemoteException;
  
  String getIccSerialNumber() throws RemoteException;
  
  String getLine1AlphaTag() throws RemoteException;
  
  String getLine1Number() throws RemoteException;
  
  String getSubscriberId() throws RemoteException;
  
  String getVoiceMailAlphaTag() throws RemoteException;
  
  String getVoiceMailNumber() throws RemoteException;
  
  public static abstract class Stub extends Binder implements IPhoneSubInfo {
    private static final String DESCRIPTOR = "com.android.internal.telephony.IPhoneSubInfo";
    
    static final int TRANSACTION_getDeviceId = 1;
    
    static final int TRANSACTION_getDeviceSvn = 2;
    
    static final int TRANSACTION_getIccSerialNumber = 4;
    
    static final int TRANSACTION_getLine1AlphaTag = 6;
    
    static final int TRANSACTION_getLine1Number = 5;
    
    static final int TRANSACTION_getSubscriberId = 3;
    
    static final int TRANSACTION_getVoiceMailAlphaTag = 8;
    
    static final int TRANSACTION_getVoiceMailNumber = 7;
    
    public Stub() {
      attachInterface(this, "com.android.internal.telephony.IPhoneSubInfo");
    }
    
    public static IPhoneSubInfo asInterface(IBinder param1IBinder) {
      if (param1IBinder == null)
        return null; 
      IInterface iInterface = param1IBinder.queryLocalInterface("com.android.internal.telephony.IPhoneSubInfo");
      return (iInterface != null && iInterface instanceof IPhoneSubInfo) ? (IPhoneSubInfo)iInterface : new Proxy(param1IBinder);
    }
    
    public IBinder asBinder() {
      return (IBinder)this;
    }
    
    public boolean onTransact(int param1Int1, Parcel param1Parcel1, Parcel param1Parcel2, int param1Int2) throws RemoteException {
      null = true;
      switch (param1Int1) {
        default:
          return super.onTransact(param1Int1, param1Parcel1, param1Parcel2, param1Int2);
        case 1598968902:
          param1Parcel2.writeString("com.android.internal.telephony.IPhoneSubInfo");
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 1:
          param1Parcel1.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getDeviceId();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 2:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getDeviceSvn();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 3:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getSubscriberId();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 4:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getIccSerialNumber();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 5:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getLine1Number();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 6:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getLine1AlphaTag();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 7:
          str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
          str = getVoiceMailNumber();
          param1Parcel2.writeNoException();
          param1Parcel2.writeString(str);
          return SYNTHETIC_LOCAL_VARIABLE_5;
        case 8:
          break;
      } 
      str.enforceInterface("com.android.internal.telephony.IPhoneSubInfo");
      String str = getVoiceMailAlphaTag();
      param1Parcel2.writeNoException();
      param1Parcel2.writeString(str);
      return SYNTHETIC_LOCAL_VARIABLE_5;
    }
    
    private static class Proxy implements IPhoneSubInfo {
      private IBinder mRemote;
      
      Proxy(IBinder param2IBinder) {
        this.mRemote = param2IBinder;
      }
      
      public IBinder asBinder() {
        return this.mRemote;
      }
      
      public String getDeviceId() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(1, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getDeviceSvn() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(2, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getIccSerialNumber() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(4, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getLine1AlphaTag() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(6, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getLine1Number() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(5, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getSubscriberId() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(3, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getVoiceMailAlphaTag() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(8, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
      
      public String getVoiceMailNumber() throws RemoteException {
        Parcel parcel1 = Parcel.obtain();
        Parcel parcel2 = Parcel.obtain();
        try {
          parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
          this.mRemote.transact(7, parcel1, parcel2, 0);
          parcel2.readException();
          return parcel2.readString();
        } finally {
          parcel2.recycle();
          parcel1.recycle();
        } 
      }
    }
  }
  
  private static class Proxy implements IPhoneSubInfo {
    private IBinder mRemote;
    
    Proxy(IBinder param1IBinder) {
      this.mRemote = param1IBinder;
    }
    
    public IBinder asBinder() {
      return this.mRemote;
    }
    
    public String getDeviceId() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(1, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getDeviceSvn() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(2, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getIccSerialNumber() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(4, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getLine1AlphaTag() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(6, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getLine1Number() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(5, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getSubscriberId() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(3, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getVoiceMailAlphaTag() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(8, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
    
    public String getVoiceMailNumber() throws RemoteException {
      Parcel parcel1 = Parcel.obtain();
      Parcel parcel2 = Parcel.obtain();
      try {
        parcel1.writeInterfaceToken("com.android.internal.telephony.IPhoneSubInfo");
        this.mRemote.transact(7, parcel1, parcel2, 0);
        parcel2.readException();
        return parcel2.readString();
      } finally {
        parcel2.recycle();
        parcel1.recycle();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/triada3-dex2jar.jar!/com/android/internal/telephony/IPhoneSubInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */